"use strict";

const defaults = {
  aytGlobalEnabled: true,
  isExtensionEnabled: true,
  masterEnabled: true,
  aytSpeedEnabled: true,
  aytXgEnabled: true,
};

const moduleMap = [
  { key: "ukrywacz", storageKey: "isExtensionEnabled", globalBound: true },
  { key: "ytstopper", storageKey: "masterEnabled", globalBound: true },
  { key: "speed", storageKey: "aytSpeedEnabled", globalBound: true },
  { key: "autoplay", storageKey: "aytXgEnabled", globalBound: true },
  { key: "timeyt", storageKey: "vtmButtonEnabled", storageArea: "local", globalBound: false },
];

const globalToggle = document.getElementById("globalToggle");

function setStorage(nextValues, area = "sync") {
  chrome.storage[area].set(nextValues, () => {
    if (chrome.runtime.lastError) {
      console.error("[Advanced YT] Nie udało się zapisać ustawienia:", chrome.runtime.lastError.message);
    }
  });
}

function closeAllExcept(targetModule) {
  document.querySelectorAll(".module").forEach((module) => {
    if (module !== targetModule) {
      module.classList.remove("open");
      module.querySelector(".module-header")?.setAttribute("aria-expanded", "false");
    }
  });
}

function syncUi(values) {
  const globalEnabled = values.aytGlobalEnabled !== false;
  globalToggle.checked = globalEnabled;
  document.body.classList.toggle("global-off", !globalEnabled);

  moduleMap.forEach(({ key, storageKey, globalBound }) => {
    const module = document.querySelector(`.module[data-module="${key}"]`);
    const toggle = module?.querySelector("input[type='checkbox']");
    if (!module || !toggle) return;
    const enabled = values[storageKey] !== false;
    const disabledByGlobal = globalBound && !globalEnabled;
    toggle.checked = enabled;
    toggle.disabled = disabledByGlobal;
    module.classList.toggle("disabled", disabledByGlobal || (globalBound && !enabled));
  });
}

function loadUiState() {
  chrome.storage.sync.get(defaults, (settings) => {
    if (chrome.runtime.lastError) {
      console.error("[Advanced YT] Nie udało się odczytać ustawień:", chrome.runtime.lastError.message);
      return;
    }
    chrome.storage.local.get({ vtmButtonEnabled: true }, (localSettings) => {
      if (chrome.runtime.lastError) {
        console.error("[Advanced YT] Nie udało się odczytać lokalnych ustawień:", chrome.runtime.lastError.message);
        return;
      }
      syncUi({ ...settings, ...localSettings });
    });
  });
}

document.querySelectorAll(".module-header:not(.static)").forEach((header) => {
  const module = header.closest(".module");
  const toggleOpen = () => {
    const isOpen = module.classList.contains("open");
    closeAllExcept(module);
    module.classList.toggle("open", !isOpen);
    header.setAttribute("aria-expanded", String(!isOpen));
  };

  header.addEventListener("click", (event) => {
    if (event.target.closest(".switch")) return;
    toggleOpen();
  });
  header.addEventListener("keydown", (event) => {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      toggleOpen();
    }
  });
});

globalToggle.addEventListener("change", () => {
  setStorage({ aytGlobalEnabled: globalToggle.checked });
});

moduleMap.forEach(({ key, storageKey, storageArea = "sync" }) => {
  const toggle = document.querySelector(`.module[data-module="${key}"] input[type='checkbox']`);
  if (!toggle) return;
  toggle.addEventListener("change", () => setStorage({ [storageKey]: toggle.checked }, storageArea));
});

loadUiState();
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "sync" && area !== "local") return;
  loadUiState();
});
