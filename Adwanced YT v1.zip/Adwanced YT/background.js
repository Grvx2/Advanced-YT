importScripts(
  "modules/timeyt/storage.js",
  "modules/timeyt/background.js",
  "modules/wtyczka-ukrywacz/background.js",
  "modules/ytspeed/background.js",
  "modules/ytstopper/background.js"
);
