"use strict";

function localDateKey(date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

chrome.runtime.onInstalled.addListener(() => {
  Promise.all([
    VtmStorage.getSetting("tracking-start-date", ""),
    VtmStorage.getFirstHistoryDate(),
  ]).then(async ([savedStart, firstRecord]) => {
    const startDate = [savedStart, firstRecord].filter(Boolean).sort()[0] || localDateKey(new Date());
    await VtmStorage.setSetting("tracking-start-date", startDate);
  }).catch((error) => {
    console.error("[VTM Local] Nie udało się zapisać początku zbierania danych:", error);
  });
});

chrome.tabs.onRemoved.addListener((tabId) => {
  VtmStorage.releasePlaybackOwner(tabId).catch((error) => {
    console.warn("[VTM Local] Nie udało się zwolnić aktywnej karty śledzenia:", error);
  });
});

async function broadcastButtonSettings() {
  const [image, scale, offset, offsetX, delay, unlimited, enabled] = await Promise.all([
    VtmStorage.getSetting("youtube-button-image", ""),
    VtmStorage.getSetting("youtube-button-scale", 24),
    VtmStorage.getSetting("youtube-button-offset", 0),
    VtmStorage.getSetting("youtube-button-offset-x", 0),
    VtmStorage.getSetting("youtube-button-delay", 0),
    VtmStorage.getSetting("youtube-button-unlimited", false),
    getButtonEnabled(),
  ]);
  const tabs = await chrome.tabs.query({
    url: ["https://www.youtube.com/*", "https://music.youtube.com/*"],
  });
  await Promise.all(tabs.filter((tab) => tab.id !== undefined).map((tab) =>
    chrome.tabs.sendMessage(tab.id, {
      type: "vtm:button-settings",
      settings: { image, scale, offset, offsetX, delay, unlimited, enabled },
    }).catch((error) => {
      console.warn("[VTM Local] Nie udało się zaktualizować ikonki na karcie:", error);
    })));
}

function getButtonEnabled() {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get({ vtmButtonEnabled: true }, (settings) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      resolve(settings.vtmButtonEnabled !== false);
    });
  });
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local" || !changes.vtmButtonEnabled) return;
  broadcastButtonSettings().catch((error) => {
    console.error("[VTM Local] Nie udało się zmienić widoczności ikonki YouTube:", error);
  });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "vtm:get-button-settings") {
    Promise.all([
      VtmStorage.getSetting("youtube-button-image", ""),
      VtmStorage.getSetting("youtube-button-scale", 24),
      VtmStorage.getSetting("youtube-button-offset", 0),
      VtmStorage.getSetting("youtube-button-offset-x", 0),
      VtmStorage.getSetting("youtube-button-delay", 0),
      VtmStorage.getSetting("youtube-button-unlimited", false),
      getButtonEnabled(),
    ]).then(([image, scale, offset, offsetX, delay, unlimited, enabled]) => {
      sendResponse({ ok: true, settings: { image, scale, offset, offsetX, delay, unlimited, enabled } });
    }).catch((error) => {
      console.error("[VTM Local] Nie udało się odczytać ustawień ikonki:", error);
      sendResponse({ ok: false, error: error.message });
    });
    return true;
  }

  if (message?.type === "vtm:open-dashboard") {
    const pageUrl = sender.url ?? sender.tab?.url ?? "";
    if (!/^https:\/\/(?:www|music)\.youtube\.com\//.test(pageUrl) || sender.tab?.id === undefined) {
      sendResponse({ ok: false, error: "Przycisk pulpitu jest dostępny na stronach YouTube." });
      return false;
    }
    chrome.tabs.sendMessage(sender.tab.id, { type: "vtm:toggle-dashboard" })
      .then(() => sendResponse({ ok: true }))
      .catch((error) => {
        console.error("[VTM Local] Nie udało się otworzyć pulpitu na stronie YouTube:", error);
        sendResponse({ ok: false, error: error.message });
      });
    return true;
  }

  if (message?.type === "vtm:button-settings-changed") {
    broadcastButtonSettings()
      .then(() => sendResponse({ ok: true }))
      .catch((error) => {
        console.error("[VTM Local] Nie udało się zaktualizować ikonki YouTube:", error);
        sendResponse({ ok: false, error: error.message });
      });
    return true;
  }

  if (message?.type === "vtm:watch-event") {
    const pageUrl = sender.url ?? sender.tab?.url ?? "";
    if (!/^https:\/\/(?:www|music)\.youtube\.com\//.test(pageUrl)) {
      sendResponse({ ok: false, error: "Zapis dozwolony jest tylko dla stron YouTube." });
      return false;
    }

    VtmStorage.saveWatchEvent(message.event, sender.tab?.id ?? null)
      .then(({ seconds, duplicate }) => {
        const savedEvent = { ...message.event, seconds };
        if (!duplicate) chrome.runtime.sendMessage({ type: "vtm:history-changed", event: savedEvent }).catch((error) => {
          console.warn("[VTM Local] Nie udało się powiadomić pulpitu o nowym zapisie:", error);
        });
        sendResponse({ ok: true });
      })
      .catch((error) => {
        console.error("[VTM Local] Nie udało się zapisać czasu oglądania:", error);
        sendResponse({ ok: false, error: error.message });
      });
    return true;
  }

  if (message?.type === "vtm:release-playback") {
    const pageUrl = sender.url ?? sender.tab?.url ?? "";
    if (!/^https:\/\/(?:www|music)\.youtube\.com\//.test(pageUrl)
      || sender.tab?.id === undefined) {
      sendResponse({ ok: false, error: "Zwolnienie blokady jest dozwolone tylko dla kart YouTube." });
      return false;
    }
    VtmStorage.releasePlaybackOwner(sender.tab.id)
      .then((released) => sendResponse({ ok: true, released }))
      .catch((error) => {
        console.error("[VTM Local] Nie udało się zwolnić blokady czasu oglądania:", error);
        sendResponse({ ok: false, error: error.message });
      });
    return true;
  }

  return false;
});
