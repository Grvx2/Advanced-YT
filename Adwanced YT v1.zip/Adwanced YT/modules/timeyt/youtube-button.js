"use strict";

(() => {
  const BUTTON_ID = "vtm-local-dashboard-trigger";
  const BUTTONS_SELECTOR = [
    "#buttons.ytd-masthead",
    "ytd-masthead #buttons",
    "ytd-masthead #end #buttons",
    "#masthead-container #buttons",
    "#masthead #buttons",
  ].join(", ");
  const PANEL_ID = "vtm-local-dashboard-panel";
  let activeDashboardFrame;
  let outsidePointerHandler;
  let insertionDelay = 0;
  let buttonSettingsReady = false;
  let pendingInsertion;
  let dashboardButton;
  let currentSettings = {
    image: "",
    scale: 24,
    offset: 0,
    offsetX: 0,
    delay: 0,
    unlimited: false,
    enabled: true,
  };

  function closeDashboard() {
    document.getElementById(PANEL_ID)?.remove();
    if (outsidePointerHandler) {
      document.removeEventListener("pointerdown", outsidePointerHandler, true);
      outsidePointerHandler = undefined;
    }
    activeDashboardFrame = undefined;
  }

  function toggleDashboard() {
    const existing = document.getElementById(PANEL_ID);
    if (existing) {
      closeDashboard();
      return;
    }
    const host = document.createElement("div");
    host.id = PANEL_ID;
    const shadow = host.attachShadow({ mode: "closed" });
    const style = document.createElement("style");
    style.textContent = `
      :host { all: initial; position: fixed; inset: 0; z-index: 2147483647; pointer-events: none; }
      iframe { position: fixed; top: 72px; right: 18px; width: 580px; height: 590px; max-width: calc(100vw - 24px); max-height: calc(100vh - 84px); border: 1px solid rgba(120,110,130,.65); border-radius: 3px; background: transparent; box-shadow: 0 8px 32px rgba(0,0,0,.45); pointer-events: auto; transition: height .16s ease; }
      @media (max-width: 620px) { iframe { top: 55px; right: 8px; width: calc(100vw - 16px); height: calc(100vh - 65px); } }
    `;
    const frame = document.createElement("iframe");
    activeDashboardFrame = frame;
    frame.title = "TimeYT";
    frame.src = `${chrome.runtime.getURL("modules/timeyt/dashboard.html")}?embedded=1`;
    shadow.append(style, frame);
    document.documentElement.append(host);
    outsidePointerHandler = (event) => {
      if (event.target === host || host.contains(event.target)) return;
      closeDashboard();
    };
    document.addEventListener("pointerdown", outsidePointerHandler, true);
  }

  function applySettings(button, settings) {
    const unlimited = Boolean(settings.unlimited);
    const readInteger = (value, fallback) => {
      const parsed = Number(value);
      return Number.isSafeInteger(parsed) ? parsed : fallback;
    };
    const scale = readInteger(settings.scale, 24);
    const offset = readInteger(settings.offset, 0);
    const offsetX = readInteger(settings.offsetX, 0);
    const delay = readInteger(settings.delay, 0);
    currentSettings = {
      image: typeof settings.image === "string" ? settings.image : "",
      scale: unlimited ? Math.max(1, scale) : Math.max(8, Math.min(60, scale || 24)),
      offset: unlimited ? offset : Math.max(-24, Math.min(24, offset)),
      offsetX: unlimited ? offsetX : Math.max(-24, Math.min(24, offsetX)),
      delay: unlimited ? Math.max(0, delay) : Math.max(0, Math.min(2000, delay)),
      unlimited,
      enabled: settings.enabled !== false,
    };
    button.hidden = !currentSettings.enabled;
    const frame = button.querySelector(".vtm-local-icon-frame");
    const validImage = currentSettings.image
      && /^data:image\/(?:png|jpeg|webp|gif);base64,/.test(currentSettings.image);
    const existingImage = frame.querySelector("img");
    if (validImage && existingImage?.src !== currentSettings.image) {
      const icon = document.createElement("img");
      icon.alt = "";
      icon.addEventListener("load", () => applyIconLayout(button, currentSettings), { once: true });
      icon.src = currentSettings.image;
      frame.replaceChildren(icon);
    } else if (!validImage && !frame.querySelector("span")) {
      const icon = document.createElement("span");
      icon.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3a9 9 0 1 0 9 9h-2a7 7 0 1 1-2.05-4.95l-2.1 2.1H21V3l-2.64 2.64A8.96 8.96 0 0 0 12 3Zm-1 4v6l5 3 .99-1.66L13 12V7h-2Z"/></svg>';
      frame.replaceChildren(icon);
    }
    frame.classList.toggle("custom", Boolean(validImage));
    button.classList.toggle("custom-icon", Boolean(validImage));
    applyIconLayout(button, currentSettings);
  }

  function applyIconLayout(button, settings) {
    const frame = button.querySelector(".vtm-local-icon-frame");
    const icon = frame?.querySelector("img");
    if (!frame || !icon) return;

    const size = settings.unlimited
      ? Math.max(1, Number(settings.scale) || 24)
      : Math.max(8, Math.min(60, Number(settings.scale) || 24));
    const aspectRatio = icon.naturalWidth && icon.naturalHeight
      ? icon.naturalWidth / icon.naturalHeight
      : 1;
    const layoutWidth = 60;
    const widthFromAspect = Math.max(16, size * Math.min(4, Math.max(1, aspectRatio)));
    const imageWidth = Math.min(settings.unlimited ? widthFromAspect : layoutWidth, size * aspectRatio);
    const imageHeight = imageWidth / aspectRatio;

    frame.style.setProperty("--vtm-layout-width", `${layoutWidth}px`);
    frame.style.setProperty("--vtm-icon-max-width", settings.unlimited ? `${widthFromAspect}px` : `${layoutWidth}px`);
    frame.style.setProperty("--vtm-icon-max-height", settings.unlimited ? "none" : "60px");
    frame.style.setProperty("--vtm-icon-width", `${imageWidth}px`);
    frame.style.setProperty("--vtm-icon-height", `${imageHeight}px`);
    frame.style.setProperty("--vtm-icon-y", `${settings.unlimited ? Number(settings.offset) || 0 : Math.max(-24, Math.min(24, Number(settings.offset) || 0))}px`);
    frame.style.setProperty("--vtm-icon-x", `${settings.unlimited ? Number(settings.offsetX) || 0 : Math.max(-24, Math.min(24, Number(settings.offsetX) || 0))}px`);
    button.style.setProperty("--vtm-layout-width", `${layoutWidth}px`);
    button.dataset.iconSlotWidth = String(layoutWidth);
  }

  function createButton() {
    const button = document.createElement("button");
    dashboardButton = button;
    button.id = BUTTON_ID;
    button.className = "vtm-local-dashboard-trigger";
    button.type = "button";
    button.title = "Czas oglądania";
    button.setAttribute("aria-label", "Otwórz historię czasu oglądania");
    button.innerHTML = '<span class="vtm-local-icon-frame"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3a9 9 0 1 0 9 9h-2a7 7 0 1 1-2.05-4.95l-2.1 2.1H21V3l-2.64 2.64A8.96 8.96 0 0 0 12 3Zm-1 4v6l5 3 .99-1.66L13 12V7h-2Z"/></svg></span><span class="vtm-local-label">Czas oglądania</span>';
    button.addEventListener("click", () => {
      button.disabled = true;
      chrome.runtime.sendMessage({ type: "vtm:open-dashboard" })
        .then((response) => {
          if (!response?.ok) throw new Error(response?.error || "Nie udało się otworzyć pulpitu.");
        })
        .catch((error) => console.error("[VTM Local] Nie udało się otworzyć pulpitu:", error))
        .finally(() => { button.disabled = false; });
    });
    return button;
  }

  function findUploadAction(container) {
    const labelPattern = /\b(?:create|utw[oó]rz|prze[śs]lij|upload)\b/i;
    const directChildren = [...container.children];
    for (const child of directChildren) {
      const nodes = [child, ...child.querySelectorAll("[aria-label], [title], [tooltip], [data-tooltip-text]")];
      const hasUploadLabel = nodes.some((node) =>
        [node.getAttribute("aria-label"), node.getAttribute("title"), node.getAttribute("tooltip"),
          node.getAttribute("data-tooltip-text")]
          .some((label) => labelPattern.test(label || "")));
      if (hasUploadLabel) return child;
    }
    return null;
  }

  function placeButton(force = false) {
    const container = document.querySelector(BUTTONS_SELECTOR);
    if (!container) return;
    const uploadButton = container.querySelector("#upload-button, #create-button, #create-icon")
      ? [...container.children].find((child) =>
        child.matches("#upload-button, #create-button, #create-icon")
        || child.querySelector("#upload-button, #create-button, #create-icon"))
      : findUploadAction(container);
    const existing = dashboardButton ?? document.getElementById(BUTTON_ID);
    if (!uploadButton) {
      if (pendingInsertion) clearTimeout(pendingInsertion.timer);
      pendingInsertion = undefined;
      return;
    }
    if (!buttonSettingsReady && !existing) return;
    if (existing?.parentElement === container) {
      if (pendingInsertion) clearTimeout(pendingInsertion.timer);
      pendingInsertion = undefined;
      if (existing.nextElementSibling !== uploadButton) container.insertBefore(existing, uploadButton);
      if (buttonSettingsReady && existing.querySelector(".vtm-local-icon-frame img")) {
        applyIconLayout(existing, currentSettings);
      }
      return;
    }
    if (pendingInsertion?.target === uploadButton) return;
    if (pendingInsertion) clearTimeout(pendingInsertion.timer);
    pendingInsertion = undefined;
    if (insertionDelay > 0 && !force && !existing) {
      let remainingDelay = insertionDelay;
      const scheduleNextChunk = () => {
        const chunk = Math.min(remainingDelay, 2_147_483_647);
        const timer = setTimeout(() => {
          remainingDelay -= chunk;
          if (remainingDelay > 0 && pendingInsertion?.target === uploadButton) {
            pendingInsertion.timer = scheduleNextChunk();
            return;
          }
          pendingInsertion = undefined;
          placeButton(true);
        }, chunk);
        return timer;
      };
      pendingInsertion = { target: uploadButton, timer: scheduleNextChunk() };
      return;
    }
    const button = existing ?? createButton();
    container.insertBefore(button, uploadButton);
    if (buttonSettingsReady && !button.querySelector(".vtm-local-icon-frame img")) {
      applySettings(button, currentSettings);
    }
  }

  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === "vtm:toggle-dashboard") {
      toggleDashboard();
      return;
    }
    if (message?.type === "vtm:button-settings") {
      if (message.settings) currentSettings = { ...currentSettings, ...message.settings };
      const button = dashboardButton ?? document.getElementById(BUTTON_ID);
      if (button && message.settings) applySettings(button, currentSettings);
      if (message.settings) {
        insertionDelay = message.settings.unlimited
          ? Math.max(0, Number.isSafeInteger(Number(message.settings.delay)) ? Number(message.settings.delay) : 0)
          : Math.max(0, Math.min(2000, Math.round((Number(message.settings.delay) || 0) / 100) * 100));
        buttonSettingsReady = true;
        if (pendingInsertion) clearTimeout(pendingInsertion.timer);
        pendingInsertion = undefined;
        placeButton();
      }
    }
  });

  window.addEventListener("message", (event) => {
    if (!activeDashboardFrame || event.source !== activeDashboardFrame.contentWindow
      || event.origin !== new URL(chrome.runtime.getURL("modules/timeyt/dashboard.html")).origin) return;
    if (event.data?.type === "vtm:close-embedded-dashboard") {
      closeDashboard();
      return;
    }
    if (event.data?.type === "vtm:resize-embedded-dashboard"
      && Number.isFinite(event.data.height)) {
      activeDashboardFrame.style.height = `${Math.max(300, Math.min(window.innerHeight - 84, event.data.height))}px`;
    }
  });

  placeButton();
  chrome.runtime.sendMessage({ type: "vtm:get-button-settings" })
    .then((response) => {
      if (!response?.ok) throw new Error(response?.error || "Nie udało się odczytać ustawień ikonki.");
      insertionDelay = response.settings.unlimited
        ? Math.max(0, Number.isSafeInteger(Number(response.settings.delay)) ? Number(response.settings.delay) : 0)
        : Math.max(0, Math.min(2000, Math.round((Number(response.settings.delay) || 0) / 100) * 100));
      currentSettings = { ...currentSettings, ...response.settings };
      buttonSettingsReady = true;
      const button = dashboardButton ?? document.getElementById(BUTTON_ID);
      if (button) applySettings(button, currentSettings);
      placeButton();
    })
    .catch((error) => {
      console.error("[VTM Local] Nie udało się odczytać ustawień ikonki YouTube:", error);
      buttonSettingsReady = true;
      placeButton();
    });
  new MutationObserver(() => placeButton()).observe(document.documentElement, {
    childList: true,
    subtree: true,
  });
  window.addEventListener("pageshow", () => placeButton());
  document.addEventListener("yt-navigate-finish", () => placeButton());
  window.addEventListener("resize", () => {
    if (dashboardButton) applyIconLayout(dashboardButton, currentSettings);
  });
})();
