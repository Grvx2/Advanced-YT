﻿(() => {
  'use strict';
  const __adwancedYtModuleWrapper = true;

const SETTINGS_DEFAULTS = {
  masterEnabled: true,
  ytAdvancedMode: true,
  enabledYoutube: true,
  enabledOtherSites: true,
  youtubeNewTabOnly: false,
  youtubeApplyShorts: false
};

const GLOBAL_ENABLED_KEY = 'aytGlobalEnabled';
const SESSION_ID_STORAGE_KEY = 'ytstopperSessionId';
const SESSION_MARKER_KEY = 'ytstopper:session-handled';

const PROGRESS_PREFIX = "ytstopper:progress:";
const SAME_TAB_MARKER_KEY = "ytstopper:same-tab-next";

let currentVideo = null;
let currentVideoKey = "";
let lockIntervalId = null;
let lockUntilTs = 0;
let lastSavedAt = 0;
let settingsCache = { ...SETTINGS_DEFAULTS };
let globalEnabled = true;
let bootstrapDoneForKey = "";
let bootstrapInProgressVideo = null;
let bypassForVideoKey = "";
let originalAudioByKey = Object.create(null);
let bootstrapCancelByVideo = new WeakMap();

// Czy ta karta jeszcze nie "obsluzyla" biezacej sesji przegladarki -
// patrz sekcja "WYMUSZONE ZATRZYMANIE PO STARCIE PRZEGLADARKI" nizej.
let forcedStartupSessionId = null;
let forcedStartupPending = false;

function isYouTubeHost(hostname) {
  return hostname === "youtube.com" || hostname.endsWith(".youtube.com") || hostname === "youtu.be";
}

function isShortsPage() {
  return window.location.pathname.startsWith("/shorts/");
}

function isEnabledForCurrentSite(settings) {
  if (!globalEnabled) return false;
  if (!settings.masterEnabled) return false;
  const onYoutube = isYouTubeHost(window.location.hostname);
  if (onYoutube) {
    return !!settings.enabledYoutube;
  }
  return !!settings.enabledOtherSites;
}

function getPageYouTubeKey() {
  const url = new URL(window.location.href);
  const v = url.searchParams.get("v");
  if (v) return `yt:${v}`;
  if (url.pathname.startsWith("/shorts/")) return `yt:${url.pathname}`;
  return "";
}

function getVideoKey(videoEl) {
  const src = videoEl.currentSrc || videoEl.src || "";

  if (isYouTubeHost(window.location.hostname)) {
    const key = getPageYouTubeKey();
    if (key) return key;
  }

  if (src) {
    try {
      const u = new URL(src, window.location.href);
      return `src:${u.href}`;
    } catch {
      return `src:${src}`;
    }
  }

  return `page:${window.location.origin}${window.location.pathname}`;
}

function saveProgress(videoEl, force = false) {
  const now = Date.now();
  if (!force && now - lastSavedAt < 700) return;
  lastSavedAt = now;

  const key = PROGRESS_PREFIX + getVideoKey(videoEl);
  const t = Number(videoEl.currentTime || 0);
  if (!Number.isFinite(t) || t < 0) return;
  chrome.storage.local.set({ [key]: t });
}

function stopLockTimer() {
  if (!lockIntervalId) return;
  clearInterval(lockIntervalId);
  lockIntervalId = null;
}

function startPauseLock(videoEl, targetTime, ms = 900) {
  stopLockTimer();
  lockUntilTs = Date.now() + ms;

  const enforce = () => {
    if (currentVideo !== videoEl || Date.now() > lockUntilTs) {
      stopLockTimer();
      return;
    }
    try {
      if (Math.abs(videoEl.currentTime - targetTime) > 0.35) {
        videoEl.currentTime = targetTime;
      }
    } catch {}
    videoEl.pause();
  };

  enforce();
  lockIntervalId = setInterval(enforce, 140);
}

// ==================================================================
// MODE+ (tryb zaawansowany, "ytAdvancedMode") - silnik pauzy/cofania.
//
// Historia poprawek (najnowsze na gorze):
//
// 6) NAPRAWA WYSCIGU Z REKLAMA (glowna przyczyna "czasem nie stopuje /
//    nie wycisza filmu"): kiedy podczas oczekiwania na koniec reklamy
//    YouTube podmienial <video> reklamy na <video> wlasciwego filmu,
//    stara logika blokowala sie sama - flaga "w trakcie zabiegu" byla
//    przypisana do klucza filmu (a nie do konkretnego elementu wideo),
//    wiec po podmiance elementu nowy zabieg widzial "przeciez juz
//    trwa" i w ogole sie nie uruchamial, a stary (dla juz odlaczonego
//    elementu reklamy) cichutko sie poddawal i nigdy nie czyscil tej
//    flagi. Efekt: film zostawal odblokowany na zawsze (do nastepnej
//    nawigacji) i Mode+ juz go nie dotykal. Teraz zabieg "w trakcie"
//    jest przypisany do KONKRETNEGO elementu wideo (nie tylko klucza),
//    a gdy element sie zmieni w trakcie oczekiwania, stary zabieg jest
//    jawnie anulowany (cancel()) i od razu startuje nowy dla aktualnego
//    elementu - zamiast utykac.
// 7) WYCISZENIE PODCZAS SAMEJ REKLAMY: dawniej Mode+ w ogole nie ruszal
//    reklamy - nie pauzowal jej (dobrze), ale tez jej nie wyciszal.
//    Teraz na czas oczekiwania na koniec reklamy dzwiek jest wyciszany
//    (przez natywne API odtwarzacza), a gdy uzytkownik sam kliknie
//    przycisk wyciszenia na reklamie, przestajemy sie tym "przycisku"
//    przejmowac do konca tej reklamy (nie walczymy z uzytkownikiem).
// 8) PRAWDZIWY STAN WYJSCIOWY DZWIEKU: stan "czy bylo wyciszone /
//    jaka byla glosnosc" jest teraz zapamietywany raz, przy pierwszym
//    zobaczeniu danego filmu (klucza) na stronie - zanim wtyczka
//    czegokolwiek dotknie. Dawniej odczytywala ten stan dopiero na
//    starcie wlasciwego zabiegu (czyli juz PO wymuszonym wyciszeniu
//    reklamy), wiec potrafila "przywrocic" dzwiek do stanu wyciszonego,
//    mimo ze uzytkownik mial normalnie wlaczony dzwiek. Teraz zawsze
//    wraca do prawdziwego stanu sprzed ingerencji wtyczki.
// 1) Wyciszanie/przywracanie dźwięku idzie przez natywne API
//    odtwarzacza YouTube (#movie_player -> mute()/unMute()/isMuted()),
//    a nie tylko przez video.muted. Dzięki temu stan przycisku "M" w
//    interfejsie YouTube jest zawsze zgodny z realnym wyciszeniem —
//    koniec z koniecznością podwójnego wciskania "M".
// 2) Cały mikro-zabieg (chwilowe odtworzenie + cofnięcie) jest
//    wykrywany po zdarzeniach (timeupdate/seeked), a nie po sztywnych,
//    długich setTimeoutach — jest więc szybszy i mniej podatny na
//    "wyścig" z użytkownikiem, który od razu klika play.
// 3) Na czas trwania zabiegu wideo jest wizualnie ukrywane (klasa CSS
//    z opacity:0), więc użytkownik nie widzi żadnego "skoku" ani
//    momentu z dźwiękiem - widzi dopiero gotową, zapauzowaną klatkę,
//    a nie ekran startowy z dużym przyciskiem play.
// 4) Jeśli w danym momencie leci reklama, Mode+ czeka aż się skończy
//    i dopiero wtedy robi swój zabieg na właściwym filmie - reklamy
//    same w sobie nigdy nie są pauzowane/cofane.
// 5) Jeśli w trakcie zabiegu użytkownik sam kliknie play, wtyczka
//    natychmiast przerywa swój proces i oddaje kontrolę.
// ==================================================================

let ytstopperHideStyleInjected = false;
function ensureHideStyleInjected() {
  if (ytstopperHideStyleInjected) return;
  ytstopperHideStyleInjected = true;
  try {
    const style = document.createElement("style");
    style.setAttribute("data-ytstopper", "hide-style");
    style.textContent = ".ytstopper-hide-video{opacity:0 !important;}";
    (document.head || document.documentElement).appendChild(style);
  } catch {}
}

function getMoviePlayerEl() {
  try {
    const el = document.getElementById("movie_player");
    if (el && typeof el.getPlayerState === "function") return el;
  } catch {}
  return null;
}

function isAdShowingNow(player) {
  try {
    if (player && player.classList && player.classList.contains("ad-showing")) return true;
  } catch {}
  try {
    if (document.querySelector(".ad-showing")) return true;
  } catch {}
  return false;
}

function readIsMuted(player, videoEl) {
  try {
    if (player && typeof player.isMuted === "function") return !!player.isMuted();
  } catch {}
  return !!videoEl.muted;
}

function applyMuteViaPlayer(player, videoEl) {
  try { if (player && typeof player.mute === "function") player.mute(); } catch {}
  try { videoEl.muted = true; } catch {}
  try { videoEl.volume = 0; } catch {}
}

function applyUnmuteViaPlayer(player, videoEl, targetVolume) {
  try { if (player && typeof player.unMute === "function") player.unMute(); } catch {}
  try { videoEl.muted = false; } catch {}
  try { videoEl.volume = Number.isFinite(targetVolume) && targetVolume > 0 ? targetVolume : 1; } catch {}
}

// Zapamietuje prawdziwy stan dzwieku (sprzed jakiejkolwiek ingerencji
// wtyczki) - raz, dla danego klucza filmu. Wykorzystywane pozniej do
// poprawnego przywracania dzwieku (patrz punkt 8 w historii poprawek).
function captureOriginalAudioIfNeeded(key, player, videoEl) {
  if (!key) return;
  if (Object.prototype.hasOwnProperty.call(originalAudioByKey, key)) return;
  originalAudioByKey[key] = {
    muted: readIsMuted(player, videoEl),
    volume: Number.isFinite(videoEl.volume) ? videoEl.volume : 1
  };
}

function getOriginalAudio(key, player, videoEl) {
  if (key && Object.prototype.hasOwnProperty.call(originalAudioByKey, key)) {
    return originalAudioByKey[key];
  }
  return { muted: readIsMuted(player, videoEl), volume: videoEl.volume };
}

// Anuluje zabieg (oczekiwanie na reklame lub sam mikro-zabieg pauzy)
// przypisany do konkretnego, juz nieaktualnego elementu wideo.
function abandonBootstrapFor(videoEl) {
  if (!videoEl) return;
  const cancel = bootstrapCancelByVideo.get(videoEl);
  if (cancel) {
    bootstrapCancelByVideo.delete(videoEl);
    try { cancel(); } catch {}
  }
}

// Czeka az ewentualna reklama sie skonczy i dopiero wtedy odpala fn().
// Dzieki temu Mode+ nigdy nie dotyka reklam - tylko wlasciwego filmu.
// Na czas oczekiwania reklama jest wyciszana (patrz punkt 7).
function waitOutAdThenRun(videoEl, player, key, fn) {
  if (!isAdShowingNow(player)) {
    fn();
    return () => {};
  }

  let settled = false;
  let cancelled = false;
  let obs = null;
  let muteEnforceId = null;
  let userUnmutedAd = false;

  const onAdMuteButtonClick = (event) => {
    const target = event.target;
    if (target && target.closest && target.closest(".ytp-mute-button")) {
      userUnmutedAd = true;
    }
  };
  document.addEventListener("click", onAdMuteButtonClick, true);

  const enforceAdMute = () => {
    if (userUnmutedAd) return;
    applyMuteViaPlayer(player, videoEl);
  };
  enforceAdMute();
  muteEnforceId = setInterval(enforceAdMute, 200);

  const teardown = () => {
    if (muteEnforceId) { clearInterval(muteEnforceId); muteEnforceId = null; }
    try { document.removeEventListener("click", onAdMuteButtonClick, true); } catch {}
    try { if (obs) obs.disconnect(); } catch {}
    clearInterval(pollId);
    clearTimeout(giveUpId);
  };

  const finishWaiting = () => {
    if (settled || cancelled) return;
    settled = true;
    teardown();
    // Maly bufor, zeby metadane wlasciwego filmu zdazyly sie ustawic.
    setTimeout(fn, 120);
  };

  const check = () => {
    if (settled || cancelled) return;
    if (currentVideo !== videoEl) {
      // Element zostal podmieniony (np. reklama -> wlasciwy film).
      // Konczymy TEN zabieg bez wywolywania fn(), ale NIE blokujemy juz
      // niczego dla nowego elementu - restoreAndPause() dla nowego
      // elementu i tak zostanie/zostal wywolany osobno przez
      // attachTracking(), a to tutaj tylko sprzata po sobie.
      settled = true;
      teardown();
      return;
    }
    if (!isAdShowingNow(player)) finishWaiting();
  };

  try {
    if (player) {
      obs = new MutationObserver(check);
      obs.observe(player, { attributes: true, attributeFilter: ["class"] });
    }
  } catch {}

  const pollId = setInterval(check, 250);
  // Zabezpieczenie, zeby nie czekac w nieskonczonosc na dziwny przypadek.
  const giveUpId = setTimeout(finishWaiting, 30000);

  return () => {
    if (settled || cancelled) return;
    cancelled = true;
    teardown();
  };
}

function pauseAndRewindOnce(videoEl, key, targetTime, doneCb) {
  const player = getMoviePlayerEl();
  captureOriginalAudioIfNeeded(key, player, videoEl);

  let bootstrapCancel = null;
  const cancelAll = () => {
    if (bootstrapCancel) { try { bootstrapCancel(); } catch {} bootstrapCancel = null; }
  };
  bootstrapCancelByVideo.set(videoEl, cancelAll);

  const waitCancel = waitOutAdThenRun(videoEl, player, key, () => {
    if (bootstrapCancelByVideo.get(videoEl) !== cancelAll) return; // zostal juz anulowany
    bootstrapCancel = runModePlusBootstrap(videoEl, player, key, targetTime, () => {
      bootstrapCancelByVideo.delete(videoEl);
      if (doneCb) doneCb();
    });
  });
  bootstrapCancel = waitCancel;
}

function runModePlusBootstrap(videoEl, player, key, targetTime, doneCb) {
  const shouldRewind = targetTime <= 0.2;
  const finalTarget = shouldRewind ? 0 : targetTime;

  const original = getOriginalAudio(key, player, videoEl);
  const originalMuted = original.muted;
  const originalVolume = original.volume;

  let done = false;
  let userTookOver = false;
  let startedAt = null;
  let muteEnforceId = null;
  let safetyTimeoutId = null;

  ensureHideStyleInjected();
  try { videoEl.classList.add("ytstopper-hide-video"); } catch {}

  const reveal = () => {
    try { videoEl.classList.remove("ytstopper-hide-video"); } catch {}
  };

  const cleanupListeners = () => {
    if (muteEnforceId) { clearInterval(muteEnforceId); muteEnforceId = null; }
    if (safetyTimeoutId) { clearTimeout(safetyTimeoutId); safetyTimeoutId = null; }
    videoEl.removeEventListener("timeupdate", onTimeUpdate);
    videoEl.removeEventListener("playing", onPlaying);
    videoEl.removeEventListener("play", onUserPlayMaybe);
  };

  const restoreAudioLater = () => {
    setTimeout(() => {
      if (userTookOver || currentVideo !== videoEl) return;
      if (originalMuted) applyMuteViaPlayer(player, videoEl);
      else applyUnmuteViaPlayer(player, videoEl, originalVolume || 1);
    }, 60);
  };

  const finalize = () => {
    if (done) return;
    done = true;
    cleanupListeners();

    try { if (player && typeof player.pauseVideo === "function") player.pauseVideo(); else videoEl.pause(); } catch {}

    const onSeeked = () => {
      videoEl.removeEventListener("seeked", onSeeked);
      reveal();
    };
    try {
      videoEl.addEventListener("seeked", onSeeked, { once: true });
      if (player && typeof player.seekTo === "function") player.seekTo(finalTarget, true);
      else videoEl.currentTime = finalTarget;
    } catch {
      reveal();
    }
    // Zabezpieczenie na wypadek gdyby 'seeked' sie nie odpalilo.
    setTimeout(reveal, 260);

    startPauseLock(videoEl, finalTarget, 900);
    restoreAudioLater();
    if (doneCb) doneCb();
  };

  // Jesli w trakcie naszego mikro-zabiegu uzytkownik sam kliknie play
  // (np. bardzo szybko po otwarciu filmu), traktujemy to jako jego
  // swiadoma decyzje i natychmiast oddajemy kontrole.
  const onUserPlayMaybe = () => {
    if (done) return;
    userTookOver = true;
    done = true;
    cleanupListeners();
    reveal();
    if (originalMuted) applyMuteViaPlayer(player, videoEl);
    else applyUnmuteViaPlayer(player, videoEl, originalVolume || 1);
    stopLockTimer();
    if (doneCb) doneCb();
  };

  const onPlaying = () => {
    if (startedAt === null) startedAt = Number(videoEl.currentTime || 0);
  };

  const onTimeUpdate = () => {
    if (done) return;
    if (startedAt === null) startedAt = Number(videoEl.currentTime || 0);
    const now = Number(videoEl.currentTime || 0);
    const requiredDelta = shouldRewind ? 0.15 : 0.12;
    if ((now - startedAt) >= requiredDelta) finalize();
  };

  let readyTimeoutId = null;
  const startWhenReady = () => {
    if (done) return;

    applyMuteViaPlayer(player, videoEl);
    muteEnforceId = setInterval(() => {
      if (done) return;
      applyMuteViaPlayer(player, videoEl);
    }, 60);

    videoEl.addEventListener("playing", onPlaying);
    videoEl.addEventListener("timeupdate", onTimeUpdate);
    videoEl.addEventListener("play", onUserPlayMaybe);

    if (player && typeof player.playVideo === "function") {
      player.playVideo();
    } else {
      const p = videoEl.play();
      if (p && typeof p.then === "function") {
        p.catch(() => { if (!done) setTimeout(finalize, 220); });
      }
    }

    safetyTimeoutId = setTimeout(() => { if (!done) finalize(); }, shouldRewind ? 420 : 360);
  };

  if (videoEl.readyState >= 2) {
    startWhenReady();
  } else {
    videoEl.addEventListener("canplay", startWhenReady, { once: true });
    readyTimeoutId = setTimeout(() => { if (!done) startWhenReady(); }, 4000);
  }

  // Funkcja anulujaca caly zabieg (wywolywana, gdy element wideo
  // przestaje byc aktualny zanim zdazylismy skonczyc).
  return () => {
    if (done) return;
    done = true;
    if (readyTimeoutId) clearTimeout(readyTimeoutId);
    cleanupListeners();
    reveal();
  };
}

function restoreAndPause(videoEl) {
  const key = PROGRESS_PREFIX + getVideoKey(videoEl);
  const trackingKey = getVideoKey(videoEl);

  chrome.storage.local.get([key], (data) => {
    const saved = Number(data[key]);
    const target = Number.isFinite(saved) && saved >= 2 ? Math.max(0, saved) : 0;
    const onYouTube = isYouTubeHost(window.location.hostname);

    const apply = () => {
      if (onYouTube && settingsCache.ytAdvancedMode) {
        if (bootstrapDoneForKey === trackingKey) return;
        if (bootstrapInProgressVideo === videoEl) return;

        if (bootstrapInProgressVideo && bootstrapInProgressVideo !== videoEl) {
          // Inny element (np. reklama) mial w toku wlasny zabieg dla
          // tego samego filmu - anulujemy go, zeby nie blokowal nowego.
          abandonBootstrapFor(bootstrapInProgressVideo);
        }

        bootstrapInProgressVideo = videoEl;
        pauseAndRewindOnce(videoEl, trackingKey, target, () => {
          bootstrapDoneForKey = trackingKey;
          if (bootstrapInProgressVideo === videoEl) bootstrapInProgressVideo = null;
        });
        return;
      }

      try { videoEl.currentTime = target; } catch {}
      videoEl.pause();
      setTimeout(() => videoEl.pause(), 130);
      setTimeout(() => videoEl.pause(), 420);
    };

    if (videoEl.readyState >= 1) apply();
    else videoEl.addEventListener("loadedmetadata", apply, { once: true });
  });
}

function detachCurrentVideo() {
  if (!currentVideo) return;
  saveProgress(currentVideo, true);
  stopLockTimer();
  currentVideo = null;
  currentVideoKey = "";
}

function attachTracking(videoEl) {
  if (!videoEl) return;
  const newKey = getVideoKey(videoEl);
  if (currentVideo === videoEl && currentVideoKey === newKey) return;

  detachCurrentVideo();
  currentVideo = videoEl;
  currentVideoKey = newKey;

  restoreAndPause(videoEl);

  const saveNow = () => {
    if (currentVideo === videoEl) saveProgress(videoEl);
  };

  videoEl.addEventListener("timeupdate", saveNow);
  videoEl.addEventListener("pause", saveNow);
  videoEl.addEventListener("ended", () => {
    if (currentVideo === videoEl) saveProgress(videoEl, true);
  });
}

function findMainVideo() {
  const videos = Array.from(document.querySelectorAll("video"));
  if (!videos.length) return null;

  const visible = videos.filter((v) => {
    const r = v.getBoundingClientRect();
    return r.width > 220 && r.height > 124;
  });

  const list = visible.length ? visible : videos;
  list.sort((a, b) => {
    const ra = a.getBoundingClientRect();
    const rb = b.getBoundingClientRect();
    return rb.width * rb.height - ra.width * ra.height;
  });

  return list[0] || null;
}

function shouldRunOnCurrentUrl() {
  if (!isYouTubeHost(window.location.hostname)) return true;

  const path = window.location.pathname;
  if (path === "/watch") return true;
  if (path.startsWith("/shorts/")) return !!settingsCache.youtubeApplyShorts;

  return false;
}

function markSameTabYouTubeOpen() {
  try {
    sessionStorage.setItem(SAME_TAB_MARKER_KEY, String(Date.now()));
  } catch {}
}

function consumeSameTabMarker(maxAgeMs = 15000) {
  try {
    const raw = sessionStorage.getItem(SAME_TAB_MARKER_KEY);
    if (!raw) return false;
    sessionStorage.removeItem(SAME_TAB_MARKER_KEY);
    const t = Number(raw);
    return Number.isFinite(t) && (Date.now() - t) <= maxAgeMs;
  } catch {
    return false;
  }
}

function setupYouTubeClickMarker() {
  const isCandidateLink = (el) => {
    if (!el) return false;
    const href = el.getAttribute("href") || "";
    return href.startsWith("/watch") || href.startsWith("/shorts/");
  };

  document.addEventListener("click", (e) => {
    if (!isYouTubeHost(window.location.hostname)) return;
    const a = e.target && e.target.closest ? e.target.closest("a") : null;
    if (!a || !isCandidateLink(a)) return;

    const target = (a.getAttribute("target") || "").toLowerCase();
    const newTabIntent = target === "_blank" || e.ctrlKey || e.metaKey || e.shiftKey || e.button === 1;
    if (!newTabIntent) markSameTabYouTubeOpen();
  }, true);
}

function recalcBypassForCurrentPage() {
  if (!isYouTubeHost(window.location.hostname) || !settingsCache.youtubeNewTabOnly) {
    bypassForVideoKey = "";
    return;
  }

  const sameTab = consumeSameTabMarker();
  bypassForVideoKey = sameTab ? getPageYouTubeKey() : "";
}

function isLikelyNewTabContext() {
  // Nowa karta z filmem zazwyczaj startuje z pojedynczym wpisem historii.
  return window.history.length <= 1;
}

// ==================================================================
// WYMUSZONE ZATRZYMANIE PO STARCIE PRZEGLADARKI
//
// Za kazdym razem, gdy Opera GX (przegladarka) faktycznie sie uruchamia
// od nowa, background.js zapisuje swiezy, losowy identyfikator sesji
// (patrz modules/ytstopper/background.js) - niezalezny od tego, ile razy
// sam Service Worker w miedzyczasie usnie/obudzi sie. Kazda karta z
// filmem YouTube porownuje ten identyfikator z tym, co ma zapisane w
// swoim WLASNYM sessionStorage (ktory jest per-karta i przetrwa tylko
// nawigacje w obrebie tej samej karty). Jesli sie roznia (albo nic tam
// jeszcze nie ma) - znaczy to, ze ta karta "nie widziala" jeszcze
// biezacego startu przegladarki, wiec film ma zostac zastopowany w
// sposob Mode+ ZAWSZE, niezaleznie od ustawienia "New Tab" (ktore w
// innych sytuacjach ogranicza dzialanie tylko do faktycznie nowych kart).
// Dotyczy to kazdej karty z YouTube - przywroconej z poprzedniej sesji,
// otwartej z zakladki, wklejonego linku, itd. Po pierwszym zastosowaniu
// dla danej karty, dalsze przegladanie w tej karcie wraca do normalnych
// ustawien.
// ==================================================================

function checkForcedStartupState(cb) {
  try {
    chrome.storage.local.get([SESSION_ID_STORAGE_KEY], (data) => {
      if (chrome.runtime.lastError) { cb(false); return; }
      const sid = data[SESSION_ID_STORAGE_KEY];
      if (!sid) { cb(false); return; }

      forcedStartupSessionId = sid;
      let handledSid = null;
      try { handledSid = sessionStorage.getItem(SESSION_MARKER_KEY); } catch {}

      cb(handledSid !== sid);
    });
  } catch {
    cb(false);
  }
}

function markForcedStartupHandled() {
  if (!forcedStartupSessionId) return;
  try { sessionStorage.setItem(SESSION_MARKER_KEY, forcedStartupSessionId); } catch {}
  forcedStartupPending = false;
}

function tryAttach() {
  if (!isEnabledForCurrentSite(settingsCache) || !shouldRunOnCurrentUrl()) {
    detachCurrentVideo();
    return;
  }

  if (isYouTubeHost(window.location.hostname) && settingsCache.youtubeNewTabOnly) {
    if (isShortsPage() && !settingsCache.youtubeApplyShorts) {
      detachCurrentVideo();
      return;
    }

    // Wymuszone zatrzymanie po starcie przegladarki ma pierwszenstwo
    // przed ograniczeniem "tylko nowa karta".
    if (!forcedStartupPending) {
      const pageKey = getPageYouTubeKey();
      const sameTabMarked = !!(pageKey && bypassForVideoKey === pageKey);
      const likelyNewTab = isLikelyNewTabContext();

      if (sameTabMarked || !likelyNewTab) {
        detachCurrentVideo();
        return;
      }
    }
  }

  const main = findMainVideo();
  if (main) {
    attachTracking(main);
    if (forcedStartupPending) markForcedStartupHandled();
  }
}

function resetForNavigation() {
  detachCurrentVideo();
  bootstrapDoneForKey = "";
  bootstrapInProgressVideo = null;
  originalAudioByKey = Object.create(null);
  recalcBypassForCurrentPage();
}

function startForCurrentPage() {
  setupYouTubeClickMarker();

  chrome.storage.sync.get({ ...SETTINGS_DEFAULTS, [GLOBAL_ENABLED_KEY]: true }, (settings) => {
    settingsCache = { ...SETTINGS_DEFAULTS, ...settings };
    globalEnabled = settings[GLOBAL_ENABLED_KEY] !== false;
    recalcBypassForCurrentPage();

    checkForcedStartupState((pending) => {
      forcedStartupPending = pending;
      tryAttach();
    });

    const observer = new MutationObserver(() => tryAttach());
    observer.observe(document.documentElement, { childList: true, subtree: true });

    setInterval(tryAttach, 900);

    document.addEventListener("yt-navigate-finish", () => {
      resetForNavigation();
      setTimeout(tryAttach, 60);
      setTimeout(tryAttach, 260);
      setTimeout(tryAttach, 700);
    });

    // Karta otwarta w tle (np. "otworz w nowej karcie") moze miec
    // spowolnione timery, wiec dorzucamy dodatkowy trigger na moment
    // przejscia w widocznosc - dzieki ukrywaniu wideo w Mode+ jest to
    // w pelni bezpieczne i nie powoduje zadnego widocznego "skoku".
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible") tryAttach();
    });

    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "sync") {
        if (changes[GLOBAL_ENABLED_KEY]) globalEnabled = changes[GLOBAL_ENABLED_KEY].newValue !== false;
        if (changes.masterEnabled) settingsCache.masterEnabled = !!changes.masterEnabled.newValue;
        if (changes.ytAdvancedMode) settingsCache.ytAdvancedMode = !!changes.ytAdvancedMode.newValue;
        if (changes.enabledYoutube) settingsCache.enabledYoutube = !!changes.enabledYoutube.newValue;
        if (changes.enabledOtherSites) settingsCache.enabledOtherSites = !!changes.enabledOtherSites.newValue;
        if (changes.youtubeNewTabOnly) settingsCache.youtubeNewTabOnly = !!changes.youtubeNewTabOnly.newValue;
        if (changes.youtubeApplyShorts) settingsCache.youtubeApplyShorts = !!changes.youtubeApplyShorts.newValue;

        recalcBypassForCurrentPage();
        if ((!globalEnabled || !settingsCache.enabledYoutube) && isYouTubeHost(window.location.hostname)) {
          detachCurrentVideo();
        }
        tryAttach();
      }

      if (area === "local" && changes[SESSION_ID_STORAGE_KEY]) {
        // Przegladarka zostala uruchomiona ponownie w miedzyczasie -
        // przy nastepnej wizycie na filmie ta karta ma zostac
        // potraktowana jako "jeszcze nie widziala" nowej sesji.
        forcedStartupSessionId = changes[SESSION_ID_STORAGE_KEY].newValue;
        forcedStartupPending = true;
        try { sessionStorage.removeItem(SESSION_MARKER_KEY); } catch {}
      }
    });

    window.addEventListener("beforeunload", () => {
      if (currentVideo) saveProgress(currentVideo, true);
    });
  });
}

startForCurrentPage();

})();
