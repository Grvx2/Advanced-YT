// modules/ytstopper/background.js
//
// Generuje swiezy identyfikator sesji za kazdym razem, gdy przegladarka
// faktycznie sie uruchamia (chrome.runtime.onStartup - odpala sie tylko
// przy realnym starcie przegladarki, nie przy kazdym "obudzeniu" Service
// Workera). modules/ytstopper/content.js porownuje ten identyfikator ze
// znacznikiem zapisanym w sessionStorage danej karty, zeby wiedziec, czy
// dana karta "widziala juz" biezacy start przegladarki - jesli nie,
// pierwszy film YouTube w tej karcie zostaje zastopowany w sposob Mode+
// bez wzgledu na ustawienie "New Tab".

function generateSessionId() {
  return `${Date.now()}-${Math.random().toString(36).slice(2)}`;
}

function refreshYtstopperSessionId() {
  chrome.storage.local.set({ ytstopperSessionId: generateSessionId() });
}

chrome.runtime.onStartup.addListener(refreshYtstopperSessionId);

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(["ytstopperSessionId"], (data) => {
    if (!data.ytstopperSessionId) {
      refreshYtstopperSessionId();
    }
  });
});
