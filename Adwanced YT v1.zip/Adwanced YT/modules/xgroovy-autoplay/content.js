(() => {
  "use strict";

  if (!window.location.pathname.startsWith("/gifs/")) {
    return;
  }

  const EXTENSION_FLAG = "__xgroovyAutoplayInitialized";
  if (window[EXTENSION_FLAG]) {
    return;
  }
  window[EXTENSION_FLAG] = true;

  const PLAY_LABELS = ["play", "odtworz", "odtwarzaj", "start", "preview"];
  const CLICK_FLAG = "xgAutoplayClicked";
  const PROCESSING_FLAG = "xgAutoplayProcessing";
  const HOVER_FLAG = "xgAutoplayHovered";
  const VIEWPORT_BUFFER_PX = 0;
  const AUDIO_SETTINGS_KEY = "audioSettings";
  const EXTENSION_ENABLED_KEY = "extensionEnabled";
  const DEFAULT_AUDIO_SETTINGS = {
    muted: false,
    volume: 1,
  };
  const DEFAULT_EXTENSION_ENABLED = true;
  let currentAudioSettings = { ...DEFAULT_AUDIO_SETTINGS };
  let isExtensionEnabled = DEFAULT_EXTENSION_ENABLED;

  function normalizeText(value) {
    return (value || "")
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .trim();
  }

  function getFirstNonEmptyAttribute(element, names) {
    for (const name of names) {
      const value = element.getAttribute(name);
      if (value) {
        return value;
      }
    }
    return "";
  }

  function normalizeAudioSettings(settings) {
    const rawMuted =
      settings && typeof settings.muted === "boolean"
        ? settings.muted
        : DEFAULT_AUDIO_SETTINGS.muted;

    const rawVolume =
      settings && Number.isFinite(settings.volume)
        ? settings.volume
        : DEFAULT_AUDIO_SETTINGS.volume;

    const volume = Math.max(0, Math.min(1, rawVolume));
    return {
      muted: rawMuted || volume === 0,
      volume,
    };
  }

  function applyAudioSettingsToVideo(video) {
    if (!(video instanceof HTMLVideoElement)) {
      return;
    }
    if (!isExtensionEnabled) {
      return;
    }

    const normalized = normalizeAudioSettings(currentAudioSettings);
    video.volume = normalized.volume;

    if (normalized.muted || normalized.volume === 0) {
      video.muted = true;
      video.defaultMuted = true;
      video.setAttribute("muted", "");
      return;
    }

    video.muted = false;
    video.defaultMuted = false;
    video.removeAttribute("muted");
  }

  function applyAudioSettingsToAllVideos() {
    const videos = document.querySelectorAll("video");
    videos.forEach((video) => {
      applyAudioSettingsToVideo(video);
    });
  }

  async function loadAudioSettingsFromStorage() {
    try {
      const result = await chrome.storage.local.get([AUDIO_SETTINGS_KEY, EXTENSION_ENABLED_KEY]);
      currentAudioSettings = normalizeAudioSettings(result[AUDIO_SETTINGS_KEY]);
      isExtensionEnabled =
        typeof result[EXTENSION_ENABLED_KEY] === "boolean"
          ? result[EXTENSION_ENABLED_KEY]
          : DEFAULT_EXTENSION_ENABLED;
    } catch (_error) {
      currentAudioSettings = { ...DEFAULT_AUDIO_SETTINGS };
      isExtensionEnabled = DEFAULT_EXTENSION_ENABLED;
    }
  }

  function isFullyWithinViewport(element, bufferPx = VIEWPORT_BUFFER_PX) {
    if (!(element instanceof HTMLElement)) {
      return false;
    }

    const style = window.getComputedStyle(element);
    if (style.display === "none" || style.visibility === "hidden" || style.opacity === "0") {
      return false;
    }

    const rect = element.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) {
      return false;
    }

    const viewportWidth = window.innerWidth || document.documentElement.clientWidth;
    const viewportHeight = window.innerHeight || document.documentElement.clientHeight;

    return (
      rect.top >= bufferPx &&
      rect.left >= bufferPx &&
      rect.bottom <= viewportHeight - bufferPx &&
      rect.right <= viewportWidth - bufferPx
    );
  }

  function markVideoForAutoplay(video) {
    video.muted = false;
    video.defaultMuted = false;
    video.autoplay = true;
    video.playsInline = true;
    video.loop = true;
    video.preload = "auto";
    video.setAttribute("autoplay", "");
    video.setAttribute("playsinline", "");
    video.setAttribute("preload", "auto");

    const sourceElements = video.querySelectorAll("source");
    sourceElements.forEach((source) => {
      if (!source.src) {
        const sourceDataSrc = getFirstNonEmptyAttribute(source, [
          "data-src",
          "data-lazy-src",
          "data-original",
          "data-video",
          "data-mp4",
          "data-webm",
        ]);
        if (sourceDataSrc) {
          source.src = sourceDataSrc;
        }
      }
    });

    if (!video.src) {
      const dataSrc = getFirstNonEmptyAttribute(video, [
        "data-src",
        "data-lazy-src",
        "data-original",
        "data-preview",
        "data-video",
        "data-mp4",
        "data-webm",
      ]);
      if (dataSrc) {
        video.src = dataSrc;
      }
    }

    if (video.readyState === 0) {
      video.load();
    }

    applyAudioSettingsToVideo(video);
  }

  function isPlayLikeControl(element) {
    if (!(element instanceof HTMLElement)) {
      return false;
    }

    const ariaLabel = normalizeText(element.getAttribute("aria-label"));
    const title = normalizeText(element.getAttribute("title"));
    const text = normalizeText(element.textContent);
    const className = normalizeText(element.className);

    return PLAY_LABELS.some(
      (keyword) =>
        ariaLabel.includes(keyword) ||
        title.includes(keyword) ||
        text.includes(keyword) ||
        className.includes(keyword),
    );
  }

  function clickPlayControlsNear(video) {
    const localRoot = video.closest("article, li, div, section") || video.parentElement;
    if (!localRoot) {
      return;
    }

    const candidates = localRoot.querySelectorAll(
      "button, [role='button'], .play, .play-btn, .play-button, .vjs-big-play-button, [data-action='play']",
    );

    candidates.forEach((element) => {
      if (!(element instanceof HTMLElement)) {
        return;
      }
      if (element.tagName.toLowerCase() === "a") {
        return;
      }
      if (element.dataset[CLICK_FLAG] === "1") {
        return;
      }
      if (!isPlayLikeControl(element)) {
        return;
      }

      element.dataset[CLICK_FLAG] = "1";
      element.dispatchEvent(
        new MouseEvent("click", {
          bubbles: true,
          cancelable: true,
          view: window,
        }),
      );
    });
  }

  function isSafeClickable(element) {
    if (!(element instanceof HTMLElement)) {
      return false;
    }
    if (element instanceof HTMLAnchorElement) {
      const href = (element.getAttribute("href") || "").trim().toLowerCase();
      if (href && !href.startsWith("#") && !href.startsWith("javascript:")) {
        return false;
      }
    }
    return true;
  }

  function dispatchHover(element) {
    const eventTypes = ["pointerenter", "pointerover", "mouseenter", "mouseover"];
    eventTypes.forEach((eventType) => {
      const isPointerEvent = eventType.startsWith("pointer");
      const EventClass = isPointerEvent && typeof PointerEvent !== "undefined" ? PointerEvent : MouseEvent;
      element.dispatchEvent(
        new EventClass(eventType, {
          bubbles: true,
          cancelable: true,
          view: window,
        }),
      );
    });
  }

  function warmUpPotentialCards() {
    const candidates = document.querySelectorAll(
      [
        "article",
        "li",
        "[class*='thumb']",
        "[class*='gif']",
        "[class*='video']",
        "[data-preview]",
        "[data-video]",
        "[data-mp4]",
      ].join(","),
    );

    candidates.forEach((element) => {
      if (!(element instanceof HTMLElement)) {
        return;
      }
      if (element.dataset[HOVER_FLAG] === "1") {
        return;
      }
      if (!isFullyWithinViewport(element)) {
        return;
      }
      element.dataset[HOVER_FLAG] = "1";
      dispatchHover(element);
    });
  }

  function clickGlobalPlayControls() {
    const candidates = document.querySelectorAll(
      [
        "button",
        "[role='button']",
        "[class*='play']",
        "[data-action*='play']",
        "[data-play]",
      ].join(","),
    );

    candidates.forEach((element) => {
      if (!(element instanceof HTMLElement)) {
        return;
      }
      if (element.dataset[CLICK_FLAG] === "1") {
        return;
      }
      if (!isSafeClickable(element)) {
        return;
      }
      if (!isFullyWithinViewport(element)) {
        return;
      }
      if (!isPlayLikeControl(element)) {
        return;
      }

      element.dataset[CLICK_FLAG] = "1";
      element.dispatchEvent(
        new MouseEvent("click", {
          bubbles: true,
          cancelable: true,
          view: window,
        }),
      );
    });
  }

  async function forcePlay(video) {
    if (!(video instanceof HTMLVideoElement)) {
      return;
    }
    if (!isExtensionEnabled) {
      return;
    }

    if (video.dataset[PROCESSING_FLAG] === "1") {
      return;
    }

    video.dataset[PROCESSING_FLAG] = "1";

    try {
      markVideoForAutoplay(video);
      await video.play();
    } catch (_error) {
      clickPlayControlsNear(video);
      try {
        markVideoForAutoplay(video);
        await video.play();
      } catch (_secondError) {
        // Browser policy can still block play() in some cases.
      }
    } finally {
      video.dataset[PROCESSING_FLAG] = "0";
    }
  }

  function pauseIfPlaying(video) {
    if (!(video instanceof HTMLVideoElement)) {
      return;
    }
    if (!video.paused && !video.ended) {
      video.pause();
    }
  }

  function bindVideoEvents(video) {
    if (!(video instanceof HTMLVideoElement)) {
      return;
    }
    if (video.dataset.xgAutoplayBound === "1") {
      return;
    }
    video.dataset.xgAutoplayBound = "1";

    video.addEventListener("loadeddata", () => {
      if (!isExtensionEnabled) {
        return;
      }
      if (isFullyWithinViewport(video)) {
        forcePlay(video);
      }
      applyAudioSettingsToVideo(video);
    });

    video.addEventListener("canplay", () => {
      if (!isExtensionEnabled) {
        return;
      }
      if (isFullyWithinViewport(video)) {
        forcePlay(video);
      }
      applyAudioSettingsToVideo(video);
    });

    video.addEventListener("pause", () => {
      if (!isExtensionEnabled) {
        return;
      }
      if (!video.ended && isFullyWithinViewport(video)) {
        forcePlay(video);
      }
      applyAudioSettingsToVideo(video);
    });

    video.addEventListener("play", () => {
      if (!isExtensionEnabled) {
        return;
      }
      applyAudioSettingsToVideo(video);
    });
  }

  function runAutoplayScan() {
    if (!isExtensionEnabled) {
      return;
    }

    warmUpPotentialCards();
    clickGlobalPlayControls();

    const videos = document.querySelectorAll("video");
    videos.forEach((video) => {
      bindVideoEvents(video);
      if (isFullyWithinViewport(video)) {
        forcePlay(video);
      } else {
        pauseIfPlaying(video);
      }
      applyAudioSettingsToVideo(video);
    });
  }

  let scanQueued = false;
  function scheduleScan() {
    if (scanQueued) {
      return;
    }
    scanQueued = true;
    requestAnimationFrame(() => {
      scanQueued = false;
      runAutoplayScan();
    });
  }

  const observer = new MutationObserver(() => {
    scheduleScan();
  });

  observer.observe(document.documentElement, {
    childList: true,
    subtree: true,
  });

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== "local") {
      return;
    }

    if (changes[AUDIO_SETTINGS_KEY]) {
      currentAudioSettings = normalizeAudioSettings(changes[AUDIO_SETTINGS_KEY].newValue);
      applyAudioSettingsToAllVideos();
    }

    if (changes[EXTENSION_ENABLED_KEY]) {
      const nextEnabled = changes[EXTENSION_ENABLED_KEY].newValue;
      isExtensionEnabled =
        typeof nextEnabled === "boolean" ? nextEnabled : DEFAULT_EXTENSION_ENABLED;
      if (isExtensionEnabled) {
        scheduleScan();
      }
    }
  });

  chrome.runtime.onMessage.addListener((message) => {
    if (!message) {
      return;
    }

    if (message.type === "xg-audio-settings-updated") {
      currentAudioSettings = normalizeAudioSettings(message.payload);
      applyAudioSettingsToAllVideos();
      return;
    }

    if (message.type === "xg-enabled-updated") {
      isExtensionEnabled =
        typeof message.payload === "boolean" ? message.payload : DEFAULT_EXTENSION_ENABLED;
      if (isExtensionEnabled) {
        scheduleScan();
      }
    }
  });

  window.addEventListener("scroll", scheduleScan, { passive: true });
  window.addEventListener("resize", scheduleScan, { passive: true });

  setInterval(scheduleScan, 1200);

  loadAudioSettingsFromStorage().finally(() => {
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", scheduleScan, { once: true });
    } else {
      scheduleScan();
    }
  });
})();

