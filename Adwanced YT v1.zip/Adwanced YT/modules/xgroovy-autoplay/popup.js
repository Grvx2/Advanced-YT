(() => {
  "use strict";

  if (new URLSearchParams(window.location.search).has("embedded")) {
    document.body.classList.add("embedded");
  }

  const AUDIO_STORAGE_KEY = "audioSettings";
  const ENABLED_STORAGE_KEY = "extensionEnabled";
  const DEFAULT_SETTINGS = {
    muted: false,
    volume: 1,
  };
  const DEFAULT_ENABLED = true;

  const enabledToggle = document.getElementById("enabledToggle");
  const muteToggle = document.getElementById("muteToggle");
  const volumeSlider = document.getElementById("volumeSlider");
  const volumeLabel = document.getElementById("volumeLabel");

  function normalizeSettings(input) {
    const rawMuted = typeof input?.muted === "boolean" ? input.muted : DEFAULT_SETTINGS.muted;
    const rawVolume = Number.isFinite(input?.volume) ? input.volume : DEFAULT_SETTINGS.volume;
    const clampedVolume = Math.max(0, Math.min(1, rawVolume));
    return {
      muted: rawMuted || clampedVolume === 0,
      volume: clampedVolume,
    };
  }

  function toSliderValue(volume) {
    return Math.round((volume * 100) / 5) * 5;
  }

  function updateUi(settings) {
    const sliderValue = toSliderValue(settings.volume);
    enabledToggle.checked = settings.enabled;
    muteToggle.checked = settings.muted;
    muteToggle.disabled = !settings.enabled;
    volumeSlider.disabled = !settings.enabled;
    volumeSlider.value = String(sliderValue);
    volumeLabel.textContent = `Glosnosc: ${sliderValue}%`;
  }

  function normalizeEnabled(value) {
    return typeof value === "boolean" ? value : DEFAULT_ENABLED;
  }

  async function readSettings() {
    const result = await chrome.storage.local.get([AUDIO_STORAGE_KEY, ENABLED_STORAGE_KEY]);
    return {
      ...normalizeSettings(result[AUDIO_STORAGE_KEY]),
      enabled: normalizeEnabled(result[ENABLED_STORAGE_KEY]),
    };
  }

  async function writeAudioSettings(nextAudioSettings) {
    const normalized = normalizeSettings(nextAudioSettings);
    await chrome.storage.local.set({ [AUDIO_STORAGE_KEY]: normalized });
    chrome.runtime.sendMessage({ type: "xg-audio-settings-updated", payload: normalized });
  }

  async function writeEnabledSetting(enabled) {
    const normalized = normalizeEnabled(enabled);
    await chrome.storage.local.set({ [ENABLED_STORAGE_KEY]: normalized });
    chrome.runtime.sendMessage({ type: "xg-enabled-updated", payload: normalized });
  }

  muteToggle.addEventListener("change", async () => {
    const current = await readSettings();
    if (!current.enabled) {
      updateUi(current);
      return;
    }

    const next = {
      muted: muteToggle.checked,
      volume: current.volume === 0 && !muteToggle.checked ? 0.2 : current.volume,
    };
    await writeAudioSettings(next);
    updateUi({ ...current, ...normalizeSettings(next) });
  });

  volumeSlider.addEventListener("input", async () => {
    const current = await readSettings();
    if (!current.enabled) {
      updateUi(current);
      return;
    }

    const value = Number(volumeSlider.value);
    const nextVolume = Math.max(0, Math.min(100, value)) / 100;
    const next = {
      muted: nextVolume === 0,
      volume: nextVolume,
    };
    await writeAudioSettings(next);
    updateUi({ ...current, ...normalizeSettings(next) });
  });

  enabledToggle.addEventListener("change", async () => {
    const current = await readSettings();
    const nextEnabled = enabledToggle.checked;
    await writeEnabledSetting(nextEnabled);
    updateUi({ ...current, enabled: nextEnabled });
  });

  (async () => {
    const settings = await readSettings();
    updateUi(settings);
  })();
})();
