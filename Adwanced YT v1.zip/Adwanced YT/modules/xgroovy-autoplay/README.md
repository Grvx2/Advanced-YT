# XGroovy GIFs AutoPlay (Opera GX)

To rozszerzenie automatycznie uruchamia wszystkie filmiki na:

- `https://pl.xgroovy.com/gifs/*`

Nie trzeba klikac kazdego mini-filmu recznie.

## Instalacja w Opera GX

1. Otworz `opera://extensions`.
2. Wlacz `Tryb dewelopera` (Developer mode).
3. Kliknij `Wczytaj rozpakowane` (Load unpacked).
4. Wybierz folder:
   - `C:\Users\fmarc\Documents\Playground\xgroovy-autoplay-opera-gx`
5. Otworz (lub odswiez) strone `https://pl.xgroovy.com/gifs/`.

## Co robi skrypt

- wyszukuje wszystkie elementy `<video>` na stronie,
- ustawia `muted`, `autoplay`, `playsinline`, `loop`,
- probuje odpalic `play()` tylko dla filmikow, ktore sa w 100% widoczne w obszarze ekranu,
- zatrzymuje (`pause`) filmiki, ktore wychodza poza obszar ekranu,
- nasluchuje dynamicznego doladowywania elementow i uruchamia nowe filmiki automatycznie.

## Menu rozszerzenia

Po kliknieciu ikonki rozszerzenia (prawy gorny rog przegladarki) masz:

- przelacznik `Dzialanie wtyczki`,
- przelacznik `Wycisz`,
- suwak glosnosci: od `0%` do `100%` co `5%`.

Zasada:

- gdy suwak jest na `0%`, wyciszenie wlacza sie automatycznie.

## Uwagi

- Przegladarki moga blokowac autoplay z dzwiekiem, dlatego filmy sa uruchamiane jako wyciszone.
- Rozszerzenie dziala tylko na podanej domenie i sciezce.
