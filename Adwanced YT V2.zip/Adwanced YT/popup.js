"use strict";

const defaults = {
  aytGlobalEnabled: true,
  isExtensionEnabled: true,
  masterEnabled: true,
  aytSpeedEnabled: true,
  aytSpeedBindings: [
    { key: "v", rate: 1 },
    { key: "b", rate: 1.5 },
    { key: "n", rate: 2 },
    { key: "x", rate: 2.5 },
    { key: "z", rate: 3 },
  ],
  enabledYoutube: true,
  enabledOtherSites: true,
  ytAdvancedMode: true,
  youtubeNewTabOnly: false,
  youtubeApplyShorts: false,
  watchedPercentage: 1,
};

const moduleMap = [
  { key: "ukrywacz", storageKey: "isExtensionEnabled", globalBound: true },
  { key: "ytstopper", storageKey: "masterEnabled", globalBound: true },
  { key: "speed", storageKey: "aytSpeedEnabled", globalBound: true },
  { key: "adblock", storageKey: "adblockDesired", storageArea: "local", globalBound: true },
  { key: "timeyt", storageKey: "vtmEnabled", storageArea: "local", globalBound: true },
  { key: "sponsorblock", storageKey: "sponsorBlockEnabled", storageArea: "local", globalBound: true },
  { key: "autohd", storageKey: "autoHdModuleEnabled", storageArea: "local", globalBound: true },
  { key: "unhook", storageKey: "unhookModuleEnabled", storageArea: "local", globalBound: true },
];

const syncBackupKeys = new Set([
  "aytGlobalEnabled", "isExtensionEnabled", "masterEnabled", "aytSpeedEnabled",
  "aytSpeedBindings", "enabledYoutube", "enabledOtherSites", "ytAdvancedMode",
  "youtubeNewTabOnly", "youtubeApplyShorts", "watchedPercentage",
]);
const localBackupKeys = new Set([
  "adblockDesired", "ads", "networkRules", "cssRules", "scripletsRules",
  "vtmEnabled", "vtmButtonEnabled", "sponsorBlockEnabled", "autoHdModuleEnabled", "unhookModuleEnabled",
]);
const hiderSettingsKeys = new Set(["isExtensionEnabled", "watchedPercentage"]);
const ytstopperSettingsKeys = new Set([
  "masterEnabled", "enabledYoutube", "enabledOtherSites", "ytAdvancedMode",
  "youtubeNewTabOnly", "youtubeApplyShorts",
]);
const sponsorBlockStoragePrefix = "sponsorblock:";
const DEFAULT_SPEED_BINDINGS = defaults.aytSpeedBindings;
const globalToggle = document.getElementById("globalToggle");
const speedBindingsContainer = document.getElementById("speedBindings");
const speedStatus = document.getElementById("speedStatus");
const transferStatus = document.getElementById("transferStatus");
let currentGlobalEnabled = true;
const settingsToggle = document.getElementById("settingsToggle");
const moduleList = document.getElementById("moduleList");
const settingsView = document.getElementById("settingsView");

function storageGet(area, defaultsOrKeys = null) {
  return new Promise((resolve, reject) => {
    chrome.storage[area].get(defaultsOrKeys, (values) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      resolve(values);
    });
  });
}

function selectSafeAutoHdSettings(input) {
  if (!input || typeof input !== "object" || Array.isArray(input)) return {};
  return Object.fromEntries(Object.entries(input)
    .filter(([key]) => key.startsWith("autohd:")
      && !/(?:analytics|user[-_]?id|userproperties|device[-_]?id|unsubmittedsegments)/i.test(key))
    .map(([key, value]) => [key.slice("autohd:".length), value]));
}

function storageSet(area, values) {
  return new Promise((resolve, reject) => {
    chrome.storage[area].set(values, () => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      resolve();
    });
  });
}

function closeAllExcept(targetModule) {
  document.querySelectorAll(".module").forEach((module) => {
    if (module !== targetModule) {
      module.classList.remove("open");
      module.querySelector(".module-header")?.setAttribute("aria-expanded", "false");
    }
  });
}

function normalizeBindings(value) {
  if (!Array.isArray(value)) return DEFAULT_SPEED_BINDINGS.map((binding) => ({ ...binding }));
  return value
    .filter((binding) => binding && typeof binding.key === "string" && Number.isFinite(Number(binding.rate)))
    .map((binding) => ({ key: binding.key.toLowerCase(), rate: Number(binding.rate) }));
}

function syncUi(syncValues, localValues) {
  currentGlobalEnabled = syncValues.aytGlobalEnabled !== false;
  globalToggle.checked = currentGlobalEnabled;
  document.body.classList.toggle("global-off", !currentGlobalEnabled);

  moduleMap.forEach(({ key, storageKey, storageArea = "sync", globalBound }) => {
    const module = document.querySelector(`.module[data-module="${key}"]`);
    const toggle = module?.querySelector("input[type='checkbox']");
    if (!module || !toggle) return;
    const areaValues = storageArea === "local" ? localValues : syncValues;
    const enabled = areaValues[storageKey] !== false;
    const disabledByGlobal = globalBound && !currentGlobalEnabled;
    toggle.checked = enabled;
    toggle.disabled = disabledByGlobal;
    module.classList.toggle("disabled", disabledByGlobal || !enabled);
  });

  const iconToggle = document.getElementById("vtmIconToggle");
  iconToggle.checked = localValues.vtmButtonEnabled !== false;
  iconToggle.disabled = !currentGlobalEnabled || localValues.vtmEnabled === false;
  renderSpeedBindings(normalizeBindings(syncValues.aytSpeedBindings));
}

function loadUiState() {
  Promise.all([storageGet("sync", defaults), storageGet("local")])
    .then(async ([syncValues, localValues]) => {
      const globalEnabled = syncValues.aytGlobalEnabled !== false;
      if (localValues.adblockDesired === undefined) {
        localValues.adblockDesired = true;
        await storageSet("local", {
          adblockDesired: localValues.adblockDesired,
          ads: globalEnabled && localValues.adblockDesired,
          vtmEnabled: localValues.vtmEnabled !== false,
          vtmButtonEnabled: localValues.vtmButtonEnabled !== false,
        });
      } else {
        localValues.vtmEnabled = localValues.vtmEnabled !== false;
        localValues.vtmButtonEnabled = localValues.vtmButtonEnabled !== false;
        localValues.adblockDesired = localValues.adblockDesired !== false;
        const effectiveAdblock = syncValues.aytGlobalEnabled !== false && localValues.adblockDesired;
        if (localValues.ads !== effectiveAdblock) {
          await storageSet("local", { ads: effectiveAdblock });
          localValues.ads = effectiveAdblock;
        }
      }
      const missingModuleDefaults = {};
      for (const key of ["autoHdModuleEnabled", "unhookModuleEnabled"]) {
        if (localValues[key] === undefined) {
          localValues[key] = true;
          missingModuleDefaults[key] = true;
        }
      }
      if (Object.keys(missingModuleDefaults).length) {
        await storageSet("local", missingModuleDefaults);
      }
      syncUi(syncValues, localValues);
    })
    .catch((error) => {
      console.error("[Advanced YT] Nie udało się odczytać ustawień:", error);
    });
}

function renderSpeedBindings(bindings) {
  speedBindingsContainer.replaceChildren();
  bindings.forEach((binding, index) => {
    const row = document.createElement("div");
    row.className = "speed-binding";

    const keyInput = document.createElement("input");
    keyInput.className = "speed-key";
    keyInput.type = "text";
    keyInput.maxLength = 1;
    keyInput.autocomplete = "off";
    keyInput.spellcheck = false;
    keyInput.value = binding.key;
    keyInput.setAttribute("aria-label", `Skrót ${index + 1}`);
    keyInput.title = "Wpisz pojedynczy klawisz";

    const rateInput = document.createElement("input");
    rateInput.className = "speed-rate";
    rateInput.type = "number";
    rateInput.min = "0.25";
    rateInput.max = "16";
    rateInput.step = "0.25";
    rateInput.value = String(binding.rate);
    rateInput.setAttribute("aria-label", `Prędkość dla skrótu ${index + 1}`);

    const suffix = document.createElement("span");
    suffix.textContent = "×";

    const removeButton = document.createElement("button");
    removeButton.className = "remove-binding";
    removeButton.type = "button";
    removeButton.textContent = "Usuń";
    removeButton.setAttribute("aria-label", `Usuń skrót ${index + 1}`);
    removeButton.addEventListener("click", async () => {
      row.remove();
      await saveSpeedBindings();
    });

    row.append(keyInput, rateInput, suffix, removeButton);
    speedBindingsContainer.append(row);
  });
}

async function saveSpeedBindings() {
  const rows = [...speedBindingsContainer.querySelectorAll(".speed-binding")];
  const bindings = [];
  const keys = new Set();
  for (const row of rows) {
    const key = row.querySelector(".speed-key").value;
    const rate = Number(row.querySelector(".speed-rate").value);
    if ([...key].length !== 1 || /\s/.test(key)) {
      speedStatus.textContent = "Każdy skrót musi być jednym niebiałym znakiem.";
      speedStatus.classList.add("error");
      return;
    }
    const normalizedKey = key.toLowerCase();
    if (keys.has(normalizedKey)) {
      speedStatus.textContent = `Skrót „${key}” jest przypisany więcej niż raz.`;
      speedStatus.classList.add("error");
      return;
    }
    if (!Number.isFinite(rate) || rate < 0.25 || rate > 16) {
      speedStatus.textContent = "Prędkość musi mieścić się w zakresie 0,25–16.";
      speedStatus.classList.add("error");
      return;
    }
    keys.add(normalizedKey);
    bindings.push({ key: normalizedKey, rate });
  }
  try {
    await storageSet("sync", { aytSpeedBindings: bindings });
    speedStatus.textContent = "Skróty zapisane.";
    speedStatus.classList.remove("error");
  } catch (error) {
    speedStatus.textContent = error.message;
    speedStatus.classList.add("error");
    console.error("[Advanced YT] Nie udało się zapisać skrótów:", error);
  }
}

function selectAllowedSettings(input, allowedKeys) {
  if (!input || typeof input !== "object" || Array.isArray(input)) return {};
  return Object.fromEntries(Object.entries(input).filter(([key]) => allowedKeys.has(key)));
}

function selectNamespacedSettings(input, prefix) {
  if (!input || typeof input !== "object" || Array.isArray(input)) return {};
  return Object.fromEntries(Object.entries(input)
    .filter(([key]) => key.startsWith(prefix) && key !== `${prefix}unsubmittedSegments`)
    .map(([key, value]) => [key.slice(prefix.length), value]));
}

function selectSponsorBlockSettings(input) {
  if (!input || typeof input !== "object" || Array.isArray(input)) return {};
  return Object.fromEntries(Object.entries(input)
    .filter(([key]) => key !== "unsubmittedSegments"));
}

function prefixSettings(input, prefix) {
  return Object.fromEntries(Object.entries(input).map(([key, value]) => [`${prefix}${key}`, value]));
}

function updateStatus(element, message, isError = false) {
  element.textContent = message;
  element.classList.toggle("error", isError);
}

async function exportSettings() {
  const [syncValues, localValues, timeytSettings] = await Promise.all([
    storageGet("sync"),
    storageGet("local"),
    VtmStorage.getAllSettings(),
  ]);
  const safeTimeytSettings = Object.fromEntries(
    Object.entries(timeytSettings).filter(([key]) =>
      key !== "tracking-start-date" && key !== "youtube-button-image-original"),
  );
  if (typeof timeytSettings["youtube-button-image-original"] === "string") {
    safeTimeytSettings["youtube-button-image"] = timeytSettings["youtube-button-image-original"];
  }
  const backup = {
    format: "advanced-yt-settings",
    version: 2,
    exportedAt: new Date().toISOString(),
    sync: selectAllowedSettings(syncValues, syncBackupKeys),
    local: selectAllowedSettings(localValues, localBackupKeys),
    modules: {
      ukrywacz: selectAllowedSettings(syncValues, hiderSettingsKeys),
      ytstopper: selectAllowedSettings(syncValues, ytstopperSettingsKeys),
      sponsorblock: {
        sync: selectNamespacedSettings(syncValues, sponsorBlockStoragePrefix),
        local: selectNamespacedSettings(localValues, sponsorBlockStoragePrefix),
      },
      unhook: {
        sync: selectNamespacedSettings(syncValues, "unhook:"),
        local: selectNamespacedSettings(localValues, "unhook:"),
      },
      autohd: {
        sync: selectSafeAutoHdSettings(syncValues),
        local: selectSafeAutoHdSettings(localValues),
      },
    },
    timeyt: safeTimeytSettings,
  };
  const json = JSON.stringify(backup, null, 2);
  if (new Blob([json]).size > 8 * 1024 * 1024) {
    throw new Error("Plik ustawień przekracza limit 8 MB.");
  }
  const url = URL.createObjectURL(new Blob([json], { type: "application/json" }));
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = `advanced-yt-settings-${new Date().toISOString().slice(0, 10)}.json`;
  anchor.click();
  setTimeout(() => URL.revokeObjectURL(url), 1_000);
}

function isPlainObject(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

async function importSettings(file) {
  if (file.size > 8 * 1024 * 1024) throw new Error("Plik ustawień przekracza limit 8 MB.");
  const backup = JSON.parse(await file.text());
  if (!isPlainObject(backup) || backup.format !== "advanced-yt-settings"
    || ![1, 2].includes(backup.version)) {
    throw new Error("Plik nie jest zgodną kopią ustawień Advanced YT.");
  }
  if (!isPlainObject(backup.sync) || !isPlainObject(backup.local) || !isPlainObject(backup.timeyt)) {
    throw new Error("Kopia ustawień jest niekompletna lub ma nieprawidłowy format.");
  }

  const syncValues = selectAllowedSettings(backup.sync, syncBackupKeys);
  const localValues = selectAllowedSettings(backup.local, localBackupKeys);
  const moduleSettings = isPlainObject(backup.modules) ? backup.modules : {};
  const hiderSettings = selectAllowedSettings(moduleSettings.ukrywacz, hiderSettingsKeys);
  const ytstopperSettings = selectAllowedSettings(moduleSettings.ytstopper, ytstopperSettingsKeys);
  const sponsorBlockSettings = isPlainObject(moduleSettings.sponsorblock)
    ? moduleSettings.sponsorblock
    : {};
  const autoHdSettings = isPlainObject(moduleSettings.autohd) ? moduleSettings.autohd : {};
  const unhookSettings = isPlainObject(moduleSettings.unhook) ? moduleSettings.unhook : {};
  if (isPlainObject(sponsorBlockSettings.sync)) {
    Object.assign(syncValues, prefixSettings(selectSponsorBlockSettings(sponsorBlockSettings.sync), sponsorBlockStoragePrefix));
  }
  if (isPlainObject(sponsorBlockSettings.local)) {
    Object.assign(localValues, prefixSettings(selectSponsorBlockSettings(sponsorBlockSettings.local), sponsorBlockStoragePrefix));
  }
  if (isPlainObject(unhookSettings.sync)) {
    Object.assign(syncValues, prefixSettings(unhookSettings.sync, "unhook:"));
  }
  if (isPlainObject(unhookSettings.local)) {
    Object.assign(localValues, prefixSettings(unhookSettings.local, "unhook:"));
  }
  if (isPlainObject(autoHdSettings.sync)) {
    Object.assign(syncValues, prefixSettings(selectSafeAutoHdSettings(
      prefixSettings(autoHdSettings.sync, "autohd:"),
    ), "autohd:"));
  }
  if (isPlainObject(autoHdSettings.local)) {
    Object.assign(localValues, prefixSettings(selectSafeAutoHdSettings(
      prefixSettings(autoHdSettings.local, "autohd:"),
    ), "autohd:"));
  }
  Object.assign(syncValues, hiderSettings, ytstopperSettings);
  const timeytValues = Object.fromEntries(
    Object.entries(backup.timeyt).filter(([key]) =>
      typeof key === "string" && key.length > 0 && key.length <= 120
        && key !== "tracking-start-date" && key !== "youtube-button-image-original"),
  );
  const originalButtonImage = backup.timeyt["youtube-button-image-original"];
  if (typeof originalButtonImage === "string"
    && /^data:image\/(?:png|jpeg|webp|gif);base64,/i.test(originalButtonImage)) {
    timeytValues["youtube-button-image"] = originalButtonImage;
  }
  if (syncValues.aytSpeedBindings !== undefined) {
    const validBindings = normalizeBindings(syncValues.aytSpeedBindings);
    if (validBindings.length !== syncValues.aytSpeedBindings.length) {
      throw new Error("Lista skrótów prędkości w kopii jest nieprawidłowa.");
    }
    syncValues.aytSpeedBindings = validBindings;
  }
  for (const [key, value] of Object.entries(timeytValues)) {
    if (value === undefined || JSON.stringify(value) === undefined) {
      throw new Error(`Nieprawidłowa wartość ustawienia TimeYT „${key}”.`);
    }
  }

  const globalEnabled = syncValues.aytGlobalEnabled !== false;
  const desiredAdblock = localValues.adblockDesired !== undefined
    ? localValues.adblockDesired !== false
    : true;
  localValues.adblockDesired = desiredAdblock;
  localValues.ads = globalEnabled && desiredAdblock;

  await storageSet("sync", syncValues);
  await storageSet("local", localValues);
  if (isPlainObject(autoHdSettings.storage)) {
    const autoHdStorage = Object.fromEntries(Object.entries(autoHdSettings.storage)
      .filter(([key]) => key.startsWith("autohd:")));
    if (Object.keys(autoHdStorage).length) {
      await chrome.storage.session.set(autoHdStorage);
    }
  }
  await VtmStorage.setSettings(timeytValues);
  const restoredButtonImage = timeytValues["youtube-button-image"];
  if (typeof restoredButtonImage === "string"
    && /^data:image\/(?:png|jpeg|webp|gif);base64,/i.test(restoredButtonImage)) {
    await storageSet("local", { vtmButtonImage: restoredButtonImage });
  }
  await chrome.runtime.sendMessage({ type: "vtm:button-settings-changed" });
}

document.querySelectorAll(".module-header:not(.static)").forEach((header) => {
  const module = header.closest(".module");
  const toggleOpen = () => {
    const isOpen = module.classList.contains("open");
    closeAllExcept(module);
    module.classList.toggle("open", !isOpen);
    header.setAttribute("aria-expanded", String(!isOpen));
  };

  header.addEventListener("click", (event) => {
    if (event.target.closest(".switch")) return;
    toggleOpen();
  });
  header.addEventListener("keydown", (event) => {
    if (event.target.closest(".switch")) return;
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      toggleOpen();
    }
  });
});

settingsToggle.addEventListener("click", () => {
  const opening = settingsView.hidden;
  moduleList.hidden = opening;
  settingsView.hidden = !opening;
  settingsToggle.textContent = opening ? "← Advanced YT" : "Advanced YT";
  settingsToggle.setAttribute("aria-expanded", String(opening));
  if (opening) closeAllExcept(null);
});

document.getElementById("sponsorBlockSettingsButton").addEventListener("click", () => {
  try {
    chrome.runtime.openOptionsPage(() => {
      if (chrome.runtime.lastError) {
        console.error("[Advanced YT] Nie udało się otworzyć ustawień SponsorBlock:", chrome.runtime.lastError.message);
      }
    });
  } catch (error) {
    console.error("[Advanced YT] Nie udało się otworzyć ustawień SponsorBlock:", error);
  }
});

globalToggle.addEventListener("change", async () => {
  const enabled = globalToggle.checked;
  try {
    await storageSet("sync", { aytGlobalEnabled: enabled });
    const localValues = await storageGet("local");
    const desiredAdblock = localValues.adblockDesired !== false;
    await storageSet("local", { ads: enabled && desiredAdblock });
  } catch (error) {
    console.error("[Advanced YT] Nie udało się zmienić stanu rozszerzenia:", error);
    loadUiState();
  }
});

moduleMap.forEach(({ key, storageKey, storageArea = "sync" }) => {
  const toggle = document.querySelector(`.module[data-module="${key}"] input[type='checkbox']`);
  if (!toggle) return;
  toggle.addEventListener("change", async () => {
    try {
      if (key === "adblock") {
        await storageSet("local", {
          adblockDesired: toggle.checked,
          ads: currentGlobalEnabled && toggle.checked,
        });
      } else {
        await storageSet(storageArea, { [storageKey]: toggle.checked });
      }
    } catch (error) {
      console.error(`[Advanced YT] Nie udało się zmienić modułu ${key}:`, error);
      loadUiState();
    }
  });
});

document.getElementById("vtmIconToggle").addEventListener("change", async (event) => {
  try {
    await storageSet("local", { vtmButtonEnabled: event.currentTarget.checked });
  } catch (error) {
    console.error("[Advanced YT] Nie udało się zmienić widoczności ikonki TimeYT:", error);
    loadUiState();
  }
});

document.getElementById("addSpeedBinding").addEventListener("click", () => {
  const current = [...speedBindingsContainer.querySelectorAll(".speed-binding")].map((row) => ({
    key: row.querySelector(".speed-key").value.toLowerCase(),
    rate: Number(row.querySelector(".speed-rate").value),
  }));
  renderSpeedBindings([...current, { key: "", rate: 1 }]);
  speedBindingsContainer.querySelector(".speed-binding:last-child .speed-key")?.focus();
});
speedBindingsContainer.addEventListener("change", () => { void saveSpeedBindings(); });

document.getElementById("exportSettings").addEventListener("click", () => {
  exportSettings()
    .then(() => updateStatus(transferStatus, "Ustawienia zostały wyeksportowane."))
    .catch((error) => {
      updateStatus(transferStatus, error.message, true);
      console.error("[Advanced YT] Nie udało się wyeksportować ustawień:", error);
    });
});
const settingsFile = document.getElementById("settingsFile");
document.getElementById("importSettings").addEventListener("click", () => settingsFile.click());
settingsFile.addEventListener("change", async () => {
  const [file] = settingsFile.files ?? [];
  settingsFile.value = "";
  if (!file) return;
  try {
    await importSettings(file);
    updateStatus(transferStatus, "Ustawienia zaimportowano. Historia oglądania pozostała bez zmian.");
  } catch (error) {
    updateStatus(transferStatus, error.message, true);
    console.error("[Advanced YT] Nie udało się zaimportować ustawień:", error);
  }
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "sync" || area === "local") loadUiState();
});

loadUiState();
