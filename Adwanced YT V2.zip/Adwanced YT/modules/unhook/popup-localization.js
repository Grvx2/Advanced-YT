"use strict";

const popupTranslations = {
  dark_mode: ["Ciemny motyw", "Włącza ciemny wygląd okna ustawień."],
  hide_feed: ["Ukryj stronę główną", "Ukrywa rekomendacje na stronie głównej YouTube."],
  hide_redirect_home: ["Przekieruj do subskrypcji", "Po otwarciu strony głównej przekierowuje do kanałów z subskrypcji."],
  hide_sidebar: ["Ukryj panel boczny filmu", "Ukrywa boczny panel obok odtwarzanego filmu."],
  hide_recommended: ["Ukryj polecane filmy", "Ukrywa rekomendowane filmy w panelu bocznym."],
  hide_chat: ["Ukryj czat na żywo", "Ukrywa czat podczas transmisji na żywo."],
  hide_playlists: ["Ukryj playlisty", "Ukrywa playlisty wyświetlane przy filmie."],
  hide_donate: ["Ukryj zbiórki", "Ukrywa karty zbiórek i akcji charytatywnych."],
  hide_endscreen: ["Ukryj propozycje na końcu filmu", "Ukrywa siatkę polecanych filmów po zakończeniu odtwarzania."],
  hide_cards: ["Ukryj karty filmu", "Ukrywa interaktywne karty wyświetlane na filmie."],
  hide_shorts: ["Ukryj Shorts", "Ukrywa sekcje i propozycje YouTube Shorts."],
  hide_comments: ["Ukryj komentarze", "Ukrywa sekcję komentarzy pod filmem."],
  hide_prof: ["Ukryj zdjęcia profilowe", "Ukrywa zdjęcia profilowe w sekcji komentarzy."],
  hide_mix: ["Ukryj miksy", "Ukrywa automatycznie tworzone miksy YouTube."],
  hide_merch: ["Ukryj produkty i oferty", "Ukrywa produkty, bilety i inne oferty powiązane z filmem."],
  hide_meta: ["Ukryj informacje o filmie", "Ukrywa szczegóły i dodatkowe informacje pod odtwarzaczem."],
  hide_bar: ["Ukryj pasek przycisków", "Ukrywa pasek przycisków pod filmem."],
  hide_channel: ["Ukryj kanał", "Ukrywa nazwę kanału i informacje o nim pod filmem."],
  hide_desc: ["Ukryj opis filmu", "Ukrywa opis filmu pod odtwarzaczem."],
  hide_header: ["Ukryj górny pasek", "Ukrywa górny pasek nawigacyjny YouTube."],
  hide_notifs: ["Ukryj powiadomienia", "Ukrywa menu powiadomień w górnym pasku."],
  hide_search: ["Ukryj niepasujące wyniki", "Ukrywa wyniki wyszukiwania uznane przez rozszerzenie za niepasujące."],
  hide_trending: ["Ukryj Eksploruj i Na czasie", "Ukrywa stronę Eksploruj oraz sekcję Na czasie."],
  hide_moreyt: ["Ukryj Więcej z YouTube", "Ukrywa sekcje promujące inne usługi YouTube."],
  hide_subs: ["Ukryj subskrypcje", "Ukrywa stronę i pozycje dotyczące subskrypcji."],
  hide_autoplay: ["Wyłącz autoodtwarzanie", "Wyłącza automatyczne odtwarzanie kolejnego filmu."],
  hide_annotations: ["Wyłącz adnotacje", "Ukrywa adnotacje i nakładki dodane do filmu."],
  sidebar_tree: ["Ustawienia panelu bocznego", "Zaznacza lub odznacza jednocześnie opcje ukrywania elementów panelu bocznego."],
  comment_tree: ["Ustawienia komentarzy", "Zaznacza lub odznacza jednocześnie opcje dotyczące komentarzy."],
  meta_tree: ["Ustawienia informacji o filmie", "Zaznacza lub odznacza jednocześnie opcje dotyczące informacji pod filmem."],
  header_tree: ["Ustawienia górnego paska", "Zaznacza lub odznacza jednocześnie opcje dotyczące górnego paska."],
  yt_on: ["Włącz lub wyłącz moduł", "Wyłącza lub włącza ukrywanie elementów YouTube."],
};

document.addEventListener("DOMContentLoaded", () => {
  document.documentElement.lang = "pl";
  document.title = "Ukrywanie interfejsu YouTube";

  for (const [id, [labelText, description]] of Object.entries(popupTranslations)) {
    const input = document.getElementById(id);
    if (!input) continue;
    const label = document.querySelector(`label[for="${id}"]`);
    if (label && labelText) {
      const svg = label.querySelector("svg");
      if (svg) svg.setAttribute("aria-label", labelText);
      else label.textContent = labelText;
    }
    input.title = description;
    if (label) label.title = description;
  }

  const logo = document.querySelector("#logo > div");
  if (logo) logo.textContent = "Ukrywanie interfejsu";
  const donate = document.querySelector('#footer a[href="donate.html"]');
  if (donate) donate.textContent = "Wesprzyj";
  const request = document.querySelector('#footer a[href^="https://docs.google.com/"]');
  if (request) request.textContent = "Zaproponuj funkcję";
  const support = document.querySelector('#footer a[href="troubleshoot.html"]');
  if (support) support.textContent = "Pomoc";
  const offMessage = document.querySelector("#off p");
  if (offMessage) offMessage.textContent = "Moduł jest wyłączony.";
});
