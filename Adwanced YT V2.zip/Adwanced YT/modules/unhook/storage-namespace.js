"use strict";

(() => {
  if (globalThis.UnhookBrowser) return;
  globalThis.UnhookBrowser = globalThis.createNamespacedExtensionApi({
    name: "Ukrywanie Interfejsu YouTube",
    prefix: "unhook:",
    moduleEnabledKey: "unhookModuleEnabled",
    visibleSettingKey: "yt_on",
    resourceRoot: "modules/unhook",
  });
})();
