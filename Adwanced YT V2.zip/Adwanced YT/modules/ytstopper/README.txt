﻿# YTstopper (Opera GX)

Proste rozszerzenie, ktore:
- zatrzymuje glowne wideo po zaladowaniu strony,
- dla nowego filmu zatrzymuje na `00:00`,
- dla wczesniej ogladanego filmu wraca do ostatniego czasu i zatrzymuje,
- ma 2 przelaczniki w popupie:
  - `YT` - wlacz/wyacz tylko dla YouTube,
  - `WWW` - wlacz/wyacz dla innych stron (bez YouTube).

## Instalacja w Opera GX

1. Wejdz na `opera://extensions`.
2. Wlacz `Tryb deweloperski`.
3. Kliknij `Wczytaj rozpakowane`.
4. Wskaz folder:
   - `C:\Users\fmarc\Documents\Playground\YTstopper`
5. Przypnij ikone rozszerzenia i kliknij ja, aby przelaczac `YT` / `WWW`.

## Uwagi

- Postep ogladania zapisywany jest lokalnie przez rozszerzenie.
- Dziala najlepiej dla glownego odtwarzacza na stronie (najwiekszy widoczny element video).
