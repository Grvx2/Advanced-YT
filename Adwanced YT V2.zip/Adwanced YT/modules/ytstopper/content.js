﻿(() => {
  'use strict';
  const __adwancedYtModuleWrapper = true;

const SETTINGS_DEFAULTS = {
  masterEnabled: true,
  ytAdvancedMode: true,
  enabledYoutube: true,
  enabledOtherSites: true,
  youtubeNewTabOnly: false,
  youtubeApplyShorts: false,
  youtubeResumeOnRefresh: false
};

const GLOBAL_ENABLED_KEY = 'aytGlobalEnabled';
const SESSION_MARKER_KEY = 'ytstopper:session-handled';

const PROGRESS_PREFIX = "ytstopper:progress:";
const SAME_TAB_MARKER_KEY = "ytstopper:same-tab-next";

let currentVideo = null;
let currentVideoKey = "";
let lastSavedAt = 0;
let settingsCache = { ...SETTINGS_DEFAULTS };
let globalEnabled = true;
let settingsReady = false;
let bootstrapDoneForKey = "";
let bootstrapInProgressVideo = null;
let bypassForVideoKey = "";
let bootstrapCancelByVideo = new WeakMap();
let lastUserPlayIntentAt = 0;

// Czy ta karta jeszcze nie "obsluzyla" biezacej sesji przegladarki -
// patrz sekcja "WYMUSZONE ZATRZYMANIE PO STARCIE PRZEGLADARKI" nizej.
let forcedStartupSessionId = null;
let forcedStartupPending = false;
let forcedStartupStopVideo = null;
let forcedStartupVideoKey = "";
let forcedStartupGuardPageKey = "";
let refreshPlaybackPageKey = "";
let refreshPlaybackVideo = null;
let refreshPlaybackUserIntent = false;
let startupStopRequested = false;

function releaseForcedStartupGuard() {
  forcedStartupGuardPageKey = "";
}

function guardForcedStartupPlayback(event) {
  if (!forcedStartupGuardPageKey) return;
  if (getPageYouTubeKey() !== forcedStartupGuardPageKey) {
    releaseForcedStartupGuard();
    return;
  }
  if (event.target?.tagName === "VIDEO") event.target.pause();
}

function armForcedStartupGuard(videoEl) {
  forcedStartupGuardPageKey = forcedStartupVideoKey || getPageYouTubeKey();
  videoEl.pause();
}

function queueForcedStartupStop(sessionId, pageKey) {
  if (!sessionId) return;
  if (pageKey && getPageYouTubeKey() !== pageKey) return;
  const startupYouTubeVideo = isYouTubeHost(window.location.hostname) && Boolean(getPageYouTubeKey());
  if (settingsReady && (!isEnabledForCurrentSite(settingsCache)
    || (!shouldRunOnCurrentUrl() && !startupYouTubeVideo))) return;
  if (forcedStartupSessionId === sessionId) {
    if (forcedStartupPending) return;
    try {
      if (sessionStorage.getItem(SESSION_MARKER_KEY) === sessionId) return;
    } catch {}
  }
  startupStopRequested = true;
  refreshPlaybackVideo = null;
  forcedStartupSessionId = sessionId;
  forcedStartupPending = true;
  forcedStartupStopVideo = null;
  forcedStartupVideoKey = pageKey || getPageYouTubeKey();
  try { sessionStorage.removeItem(SESSION_MARKER_KEY); } catch {}

  if (currentVideo) {
    abandonBootstrapFor(currentVideo);
    bootstrapInProgressVideo = null;
    bootstrapDoneForKey = "";
  }
  if (settingsReady) tryAttach();
}

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type === "YTSTOPPER_FORCE_STARTUP_STOP") {
    queueForcedStartupStop(message.sessionId, message.pageKey);
  }
});

document.addEventListener("play", guardForcedStartupPlayback, true);

function isYouTubeHost(hostname) {
  return hostname === "youtube.com" || hostname.endsWith(".youtube.com") || hostname === "youtu.be";
}

function isShortsPage() {
  return window.location.pathname.startsWith("/shorts/");
}

function isEnabledForCurrentSite(settings) {
  if (!globalEnabled) return false;
  if (!settings.masterEnabled) return false;
  const onYoutube = isYouTubeHost(window.location.hostname);
  if (onYoutube) {
    return !!settings.enabledYoutube;
  }
  return !!settings.enabledOtherSites;
}

function getPageYouTubeKey() {
  const url = new URL(window.location.href);
  const v = url.searchParams.get("v");
  if (v && url.pathname === "/watch") return `yt:${v}`;
  if (url.pathname.startsWith("/shorts/")) return `yt:${url.pathname}`;
  if (url.pathname.startsWith("/live/") || url.pathname.startsWith("/embed/")) {
    return `yt:${url.origin}${url.pathname}`;
  }
  if (url.hostname === "youtu.be" && url.pathname.length > 1) {
    return `yt:${url.pathname}`;
  }
  return "";
}

function isCurrentRefreshTarget() {
  return Boolean(refreshPlaybackPageKey
    && !startupStopRequested
    && getPageYouTubeKey() === refreshPlaybackPageKey);
}

function detectInitialRefresh() {
  const navigationEntry = performance.getEntriesByType?.("navigation")?.[0];
  const isReload = navigationEntry?.type === "reload"
    || (!navigationEntry && performance.navigation?.type === 1);
  if (!isReload || !isYouTubeHost(window.location.hostname)) return;

  const pageKey = getPageYouTubeKey();
  if (!pageKey) return;
  refreshPlaybackPageKey = pageKey;
  if (!isShortsPage()) forcedStartupGuardPageKey = pageKey;
}

detectInitialRefresh();

function getVideoKey(videoEl) {
  const src = videoEl.currentSrc || videoEl.src || "";

  if (isYouTubeHost(window.location.hostname)) {
    const key = getPageYouTubeKey();
    if (key) return key;
  }

  if (src) {
    try {
      const u = new URL(src, window.location.href);
      return `src:${u.href}`;
    } catch {
      return `src:${src}`;
    }
  }

  return `page:${window.location.origin}${window.location.pathname}`;
}

function saveProgress(videoEl, force = false) {
  const now = Date.now();
  if (!force && now - lastSavedAt < 700) return;
  lastSavedAt = now;

  const key = PROGRESS_PREFIX + getVideoKey(videoEl);
  const t = Number(videoEl.currentTime || 0);
  if (!Number.isFinite(t) || t < 0) return;
  chrome.storage.local.set({ [key]: t });
}

// Mode+ pauses and restores the saved position without changing audio or
// intercepting subsequent playback initiated by the user.

let modePlusStyleInjected = false;
function ensureModePlusStyle() {
  if (modePlusStyleInjected) return;
  modePlusStyleInjected = true;
  const style = document.createElement("style");
  style.setAttribute("data-ytstopper", "mode-plus-style");
  style.textContent = ".ytstopper-modeplus .ytp-cued-thumbnail-overlay,.ytstopper-modeplus .ytp-large-play-button{display:none!important;}";
  (document.head || document.documentElement).appendChild(style);
}

function getMoviePlayerEl() {
  return document.getElementById("movie_player");
}

function isAdShowingNow(player) {
  return Boolean(player?.classList.contains("ad-showing"));
}

function refreshModePlusPresentation() {
  if (!isYouTubeHost(window.location.hostname)) return;
  ensureModePlusStyle();
  const player = getMoviePlayerEl();
  if (!player) return;
  player.classList.toggle(
    "ytstopper-modeplus",
    isEnabledForCurrentSite(settingsCache) && settingsCache.ytAdvancedMode,
  );
}

function isTypingTarget(target) {
  return target instanceof Element
    && (target.isContentEditable || ["INPUT", "TEXTAREA", "SELECT"].includes(target.tagName));
}

function markUserPlayIntent() {
  lastUserPlayIntentAt = Date.now();
  if (isCurrentRefreshTarget()) refreshPlaybackUserIntent = true;
  releaseForcedStartupGuard();
}

document.addEventListener("pointerdown", (event) => {
  const player = getMoviePlayerEl();
  const target = event.target instanceof Element ? event.target : null;
  const playControl = target?.closest(
    "#movie_player .ytp-play-button, #movie_player .ytp-large-play-button, #movie_player .ytp-cued-thumbnail-overlay",
  );
  const video = player?.querySelector("video");
  const playSurface = video?.paused
    && target?.closest("#movie_player .html5-video-container, #movie_player video");
  if (target && !isAdShowingNow(player) && (playControl || playSurface)) {
    markUserPlayIntent();
  }
}, true);

document.addEventListener("keydown", (event) => {
  if (isTypingTarget(event.target) || !(event.target instanceof Element)) return;
  const isPlayControl = Boolean(event.target.closest(
    "#movie_player .ytp-play-button, #movie_player .ytp-large-play-button, #movie_player .ytp-cued-thumbnail-overlay",
  ));
  const isPlayerShortcut = event.target.closest("#movie_player")
    && (["k", "K", " "].includes(event.key) || event.code === "Space");
  const activatesPlayControl = event.key === "Enter" && isPlayControl;
  if ((isPlayerShortcut || activatesPlayControl) && !isAdShowingNow(getMoviePlayerEl())) {
    markUserPlayIntent();
  }
}, true);

document.addEventListener("dblclick", (event) => {
  if (event.target instanceof Element
    && !isAdShowingNow(getMoviePlayerEl())
    && event.target.closest("#movie_player .html5-video-container, #movie_player video")) {
    markUserPlayIntent();
  }
}, true);

function hasRecentUserPlayIntent() {
  return Date.now() - lastUserPlayIntentAt < 1_500;
}

// Anuluje odtwarzanie lub przywracanie pozycji dla nieaktualnego elementu.
function abandonBootstrapFor(videoEl) {
  if (!videoEl) return;
  const cancel = bootstrapCancelByVideo.get(videoEl);
  if (cancel) {
    bootstrapCancelByVideo.delete(videoEl);
    try { cancel(); } catch {}
  }
}

function pauseAndRewindOnce(videoEl, targetTime, doneCb) {
  let cancelled = false;
  let settled = false;
  let metadataTimeout;

  const cleanup = () => {
    clearTimeout(metadataTimeout);
    videoEl.removeEventListener("loadedmetadata", applyPosition);
    videoEl.removeEventListener("play", guardUnexpectedAutoplay);
    document.removeEventListener("pointerdown", cancelOnUserIntent, true);
    document.removeEventListener("keydown", cancelOnUserIntent, true);
  };
  const finish = () => {
    if (settled) return;
    settled = true;
    cleanup();
    bootstrapCancelByVideo.delete(videoEl);
    doneCb?.();
  };
  const cancel = () => {
    if (settled) return;
    cancelled = true;
    finish();
  };
  const cancelOnUserIntent = () => {
    if (hasRecentUserPlayIntent()) cancel();
  };
  const guardUnexpectedAutoplay = () => {
    if (!cancelled && !hasRecentUserPlayIntent()) videoEl.pause();
  };
  const applyPosition = () => {
    if (settled) return;
    if (currentVideo !== videoEl || hasRecentUserPlayIntent()) {
      cancel();
      return;
    }
    const duration = Number(videoEl.duration);
    const position = Number.isFinite(duration) && duration > 0
      ? Math.min(targetTime, Math.max(0, duration - 0.1))
      : targetTime;
    try {
      videoEl.pause();
      if (videoEl.readyState >= 1) videoEl.currentTime = position;
      videoEl.pause();
    } catch (error) {
      console.warn("[YTstopper] Nie udało się przywrócić pozycji filmu:", error);
    }
    finish();
  };

  if (hasRecentUserPlayIntent()) {
    doneCb?.();
    return;
  }

  videoEl.addEventListener("loadedmetadata", applyPosition);
  videoEl.addEventListener("play", guardUnexpectedAutoplay);
  document.addEventListener("pointerdown", cancelOnUserIntent, true);
  document.addEventListener("keydown", cancelOnUserIntent, true);
  bootstrapCancelByVideo.set(videoEl, cancel);
  videoEl.pause();

  if (videoEl.readyState >= 1) applyPosition();
  else metadataTimeout = setTimeout(applyPosition, 3_000);
}

function restoreAndPause(videoEl, onComplete) {
  const key = PROGRESS_PREFIX + getVideoKey(videoEl);
  const trackingKey = getVideoKey(videoEl);

  chrome.storage.local.get([key], (data) => {
    if (currentVideo !== videoEl) return;
    const saved = Number(data[key]);
    const target = Number.isFinite(saved) && saved >= 2 ? Math.max(0, saved) : 0;
    const onYouTube = isYouTubeHost(window.location.hostname);

    const apply = () => {
      if (onYouTube && settingsCache.ytAdvancedMode) {
        if (bootstrapDoneForKey === trackingKey) {
          onComplete?.();
          return;
        }
        if (bootstrapInProgressVideo === videoEl) return;

        if (bootstrapInProgressVideo && bootstrapInProgressVideo !== videoEl) {
          // Inny element (np. reklama) mial w toku wlasny zabieg dla
          // tego samego filmu - anulujemy go, zeby nie blokowal nowego.
          abandonBootstrapFor(bootstrapInProgressVideo);
        }

        bootstrapInProgressVideo = videoEl;
        pauseAndRewindOnce(videoEl, target, () => {
          bootstrapDoneForKey = trackingKey;
          if (bootstrapInProgressVideo === videoEl) bootstrapInProgressVideo = null;
          onComplete?.();
        });
        return;
      }

      try {
        if (videoEl.readyState >= 1) videoEl.currentTime = target;
      } catch (error) {
        console.warn("[YTstopper] Nie udało się przywrócić pozycji filmu:", error);
      }
      videoEl.pause();
      onComplete?.();
    };

    const applyWhenReady = () => {
      if (currentVideo !== videoEl) return;
      if (videoEl.readyState >= 1) apply();
      else videoEl.addEventListener("loadedmetadata", apply, { once: true });
    };
    applyWhenReady();
  });
}

function restoreAndPlay(videoEl, onComplete) {
  const key = PROGRESS_PREFIX + getVideoKey(videoEl);
  let completed = false;
  let metadataTimeout;

  const finish = () => {
    if (completed) return;
    completed = true;
    clearTimeout(metadataTimeout);
    videoEl.removeEventListener("loadedmetadata", apply);
    onComplete?.();
  };
  const play = () => {
    try {
      const result = videoEl.play();
      if (result && typeof result.catch === "function") {
        result.catch((error) => console.warn("[YTstopper] Nie udało się wznowić filmu po odświeżeniu:", error));
      }
    } catch (error) {
      console.warn("[YTstopper] Nie udało się wznowić filmu po odświeżeniu:", error);
    }
  };
  const apply = () => {
    if (completed || currentVideo !== videoEl) return;
    if (videoEl.readyState < 1) {
      play();
      finish();
      return;
    }

    const saved = Number(progress);
    const duration = Number(videoEl.duration);
    const target = Number.isFinite(saved) && saved >= 2 ? Math.max(0, saved) : 0;
    const position = Number.isFinite(duration) && duration > 0
      ? Math.min(target, Math.max(0, duration - 0.1))
      : target;
    try {
      videoEl.currentTime = position;
    } catch (error) {
      console.warn("[YTstopper] Nie udało się przywrócić pozycji przed wznowieniem:", error);
    }
    play();
    finish();
  };

  let progress = 0;
  chrome.storage.local.get([key], (data) => {
    if (chrome.runtime.lastError) {
      console.error("[YTstopper] Nie udało się odczytać pozycji filmu:", chrome.runtime.lastError.message);
      apply();
      return;
    }
    progress = data[key];
    if (videoEl.readyState >= 1) {
      apply();
      return;
    }
    videoEl.addEventListener("loadedmetadata", apply);
    metadataTimeout = setTimeout(apply, 8_000);
  });
}

function detachCurrentVideo() {
  if (!currentVideo) return;
  abandonBootstrapFor(currentVideo);
  saveProgress(currentVideo, true);
  currentVideo = null;
  currentVideoKey = "";
}

function attachTracking(videoEl, restore = true) {
  if (!videoEl) return;
  const newKey = getVideoKey(videoEl);
  if (currentVideo === videoEl && currentVideoKey === newKey) return;

  detachCurrentVideo();
  currentVideo = videoEl;
  currentVideoKey = newKey;

  if (restore) restoreAndPause(videoEl);

  const saveNow = () => {
    if (currentVideo === videoEl) saveProgress(videoEl);
  };

  videoEl.addEventListener("timeupdate", saveNow);
  videoEl.addEventListener("pause", saveNow);
  videoEl.addEventListener("ended", () => {
    if (currentVideo === videoEl) saveProgress(videoEl, true);
  });
}

function findMainVideo() {
  const videos = Array.from(document.querySelectorAll("video"));
  if (!videos.length) return null;

  const visible = videos.filter((v) => {
    const r = v.getBoundingClientRect();
    return r.width > 220 && r.height > 124;
  });

  const list = visible.length ? visible : videos;
  list.sort((a, b) => {
    const ra = a.getBoundingClientRect();
    const rb = b.getBoundingClientRect();
    return rb.width * rb.height - ra.width * ra.height;
  });

  return list[0] || null;
}

function shouldRunOnCurrentUrl() {
  if (!isYouTubeHost(window.location.hostname)) return true;

  const path = window.location.pathname;
  if (path === "/watch") return true;
  if (path.startsWith("/live/") || path.startsWith("/embed/")) return true;
  if (path.startsWith("/shorts/")) return !!settingsCache.youtubeApplyShorts;

  return false;
}

function markSameTabYouTubeOpen() {
  try {
    sessionStorage.setItem(SAME_TAB_MARKER_KEY, String(Date.now()));
  } catch {}
}

function consumeSameTabMarker(maxAgeMs = 15000) {
  try {
    const raw = sessionStorage.getItem(SAME_TAB_MARKER_KEY);
    if (!raw) return false;
    sessionStorage.removeItem(SAME_TAB_MARKER_KEY);
    const t = Number(raw);
    return Number.isFinite(t) && (Date.now() - t) <= maxAgeMs;
  } catch {
    return false;
  }
}

function setupYouTubeClickMarker() {
  const isCandidateLink = (el) => {
    if (!el) return false;
    const href = el.getAttribute("href") || "";
    return href.startsWith("/watch") || href.startsWith("/shorts/");
  };

  document.addEventListener("click", (e) => {
    if (!isYouTubeHost(window.location.hostname)) return;
    const a = e.target && e.target.closest ? e.target.closest("a") : null;
    if (!a || !isCandidateLink(a)) return;

    const target = (a.getAttribute("target") || "").toLowerCase();
    const newTabIntent = target === "_blank" || e.ctrlKey || e.metaKey || e.shiftKey || e.button === 1;
    if (!newTabIntent) markSameTabYouTubeOpen();
  }, true);
}

function recalcBypassForCurrentPage() {
  if (!isYouTubeHost(window.location.hostname) || !settingsCache.youtubeNewTabOnly) {
    bypassForVideoKey = "";
    return;
  }

  const sameTab = consumeSameTabMarker();
  bypassForVideoKey = sameTab ? getPageYouTubeKey() : "";
}

function isLikelyNewTabContext() {
  // Nowa karta z filmem zazwyczaj startuje z pojedynczym wpisem historii.
  return window.history.length <= 1;
}

function markForcedStartupHandled() {
  if (!forcedStartupSessionId) return;
  try { sessionStorage.setItem(SESSION_MARKER_KEY, forcedStartupSessionId); } catch {}
  forcedStartupPending = false;
}

function tryAttach() {
  const refreshTarget = isCurrentRefreshTarget();
  const refreshShorts = refreshTarget && isShortsPage();
  const forcedYouTubeStartupStop = forcedStartupPending
    && isYouTubeHost(window.location.hostname)
    && Boolean(getPageYouTubeKey());
  if (!isEnabledForCurrentSite(settingsCache)
    || (!shouldRunOnCurrentUrl() && !forcedYouTubeStartupStop && !refreshTarget)) {
    releaseForcedStartupGuard();
    if (forcedStartupPending) markForcedStartupHandled();
    refreshModePlusPresentation();
    detachCurrentVideo();
    return;
  }
  refreshModePlusPresentation();

  if (isYouTubeHost(window.location.hostname) && settingsCache.youtubeNewTabOnly) {
    if (!forcedYouTubeStartupStop && !refreshTarget
      && isShortsPage() && !settingsCache.youtubeApplyShorts) {
      detachCurrentVideo();
      return;
    }

    // Wymuszone zatrzymanie po starcie przegladarki ma pierwszenstwo
    // przed ograniczeniem "tylko nowa karta".
    if (!forcedStartupPending && !refreshTarget) {
      const pageKey = getPageYouTubeKey();
      const sameTabMarked = !!(pageKey && bypassForVideoKey === pageKey);
      const likelyNewTab = isLikelyNewTabContext();

      if (sameTabMarked || !likelyNewTab) {
        detachCurrentVideo();
        return;
      }
    }
  }

  const main = findMainVideo();
  if (main) {
    attachTracking(main, !forcedStartupPending && !refreshTarget);
    if (forcedStartupPending) {
      if (forcedStartupStopVideo !== main) {
        forcedStartupStopVideo = main;
        armForcedStartupGuard(main);
        restoreAndPause(main, () => {
          if (currentVideo === main && forcedStartupStopVideo === main) {
            markForcedStartupHandled();
            forcedStartupStopVideo = null;
          }
        });
      }
    } else if (refreshTarget && refreshPlaybackVideo !== main) {
      refreshPlaybackVideo = main;
      if (refreshShorts || refreshPlaybackUserIntent) {
        if (refreshPlaybackUserIntent) releaseForcedStartupGuard();
      } else if (settingsCache.youtubeResumeOnRefresh) {
        releaseForcedStartupGuard();
        restoreAndPlay(main);
      } else {
        forcedStartupGuardPageKey = refreshPlaybackPageKey;
        main.pause();
        restoreAndPause(main);
      }
    }
  }
}

function resetForNavigation() {
  if (refreshPlaybackPageKey && getPageYouTubeKey() !== refreshPlaybackPageKey) {
    refreshPlaybackPageKey = "";
    refreshPlaybackVideo = null;
    refreshPlaybackUserIntent = false;
    if (!forcedStartupPending) releaseForcedStartupGuard();
  }
  detachCurrentVideo();
  bootstrapDoneForKey = "";
  bootstrapInProgressVideo = null;
  forcedStartupStopVideo = null;
  if (forcedStartupVideoKey && getPageYouTubeKey() !== forcedStartupVideoKey) {
    releaseForcedStartupGuard();
    forcedStartupPending = false;
    startupStopRequested = false;
    forcedStartupVideoKey = "";
  }
  recalcBypassForCurrentPage();
}

function startForCurrentPage() {
  setupYouTubeClickMarker();

  chrome.storage.sync.get({ ...SETTINGS_DEFAULTS, [GLOBAL_ENABLED_KEY]: true }, (settings) => {
    settingsCache = { ...SETTINGS_DEFAULTS, ...settings };
    globalEnabled = settings[GLOBAL_ENABLED_KEY] !== false;
    settingsReady = true;
    if (!isEnabledForCurrentSite(settingsCache)
      || (isCurrentRefreshTarget()
        && (isShortsPage() || settingsCache.youtubeResumeOnRefresh)
        && !forcedStartupPending)) {
      releaseForcedStartupGuard();
    }
    recalcBypassForCurrentPage();
    tryAttach();

    const observeDocument = () => {
      if (!document.documentElement) {
        document.addEventListener("DOMContentLoaded", observeDocument, { once: true });
        return;
      }
      const observer = new MutationObserver(() => tryAttach());
      observer.observe(document.documentElement, { childList: true, subtree: true });
      tryAttach();
    };
    observeDocument();

    setInterval(tryAttach, 900);

    document.addEventListener("yt-navigate-finish", () => {
      resetForNavigation();
      setTimeout(tryAttach, 60);
      setTimeout(tryAttach, 260);
      setTimeout(tryAttach, 700);
    });

    // Karta otwarta w tle (np. "otworz w nowej karcie") moze miec
    // spowolnione timery, wiec dorzucamy dodatkowy trigger na moment
    // przejscia w widocznosc - dzieki ukrywaniu wideo w Mode+ jest to
    // w pelni bezpieczne i nie powoduje zadnego widocznego "skoku".
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible") tryAttach();
    });

    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "sync") {
        if (changes[GLOBAL_ENABLED_KEY]) globalEnabled = changes[GLOBAL_ENABLED_KEY].newValue !== false;
        if (changes.masterEnabled) settingsCache.masterEnabled = !!changes.masterEnabled.newValue;
        if (changes.ytAdvancedMode) settingsCache.ytAdvancedMode = !!changes.ytAdvancedMode.newValue;
        if (changes.enabledYoutube) settingsCache.enabledYoutube = !!changes.enabledYoutube.newValue;
        if (changes.enabledOtherSites) settingsCache.enabledOtherSites = !!changes.enabledOtherSites.newValue;
        if (changes.youtubeNewTabOnly) settingsCache.youtubeNewTabOnly = !!changes.youtubeNewTabOnly.newValue;
        if (changes.youtubeApplyShorts) settingsCache.youtubeApplyShorts = !!changes.youtubeApplyShorts.newValue;
        if (changes.youtubeResumeOnRefresh) {
          settingsCache.youtubeResumeOnRefresh = !!changes.youtubeResumeOnRefresh.newValue;
          refreshPlaybackVideo = null;
        }

        recalcBypassForCurrentPage();
        refreshModePlusPresentation();
        if (changes.ytAdvancedMode && currentVideo) {
          abandonBootstrapFor(currentVideo);
          bootstrapInProgressVideo = null;
          bootstrapDoneForKey = "";
          if (isEnabledForCurrentSite(settingsCache) && shouldRunOnCurrentUrl()) {
            restoreAndPause(currentVideo);
          }
        }
        if ((!globalEnabled || !settingsCache.enabledYoutube) && isYouTubeHost(window.location.hostname)) {
          detachCurrentVideo();
        }
        tryAttach();
      }

    });

    window.addEventListener("beforeunload", () => {
      if (currentVideo) saveProgress(currentVideo, true);
    });
  });
}

startForCurrentPage();

})();
