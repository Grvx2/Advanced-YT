"use strict";

const STARTUP_TARGETS_KEY = "ytstopper:startup-targets";
const startupTargets = new Map();
const startupTabIds = new Set();
let startupSessionId = "";
let startupSnapshotLoaded = false;
let startupScanUntil = 0;
let storageWriteQueue = Promise.resolve();
const STARTUP_SCAN_WINDOW_MS = 30_000;

function generateSessionId() {
  return `${Date.now()}-${Math.random().toString(36).slice(2)}`;
}

function getYouTubePageKey(url) {
  try {
    const page = new URL(url);
    const hostname = page.hostname.toLowerCase();
    if (hostname !== "youtube.com"
      && !hostname.endsWith(".youtube.com")
      && hostname !== "youtu.be") return "";

    const videoId = page.searchParams.get("v");
    if (videoId && page.pathname === "/watch") return `yt:${videoId}`;
    if (page.pathname.startsWith("/shorts/")) return `yt:${page.pathname}`;
    if (page.pathname.startsWith("/live/") || page.pathname.startsWith("/embed/")) {
      return `yt:${page.origin}${page.pathname}`;
    }
    if (hostname === "youtu.be" && page.pathname.length > 1) return `yt:${page.pathname}`;
    return "";
  } catch {
    return "";
  }
}

function serializeStartupTargets() {
  return {
    sessionId: startupSessionId,
    targets: [...startupTargets.entries()].map(([id, pageKey]) => ({ id, pageKey })),
    tabIds: [...startupTabIds],
    scanUntil: startupScanUntil,
  };
}

function persistStartupTargets() {
  if (!chrome.storage.session) {
    console.warn("[YTstopper] Sesyjny magazyn kart nie jest dostępny.");
    return;
  }

  const snapshot = serializeStartupTargets();
  storageWriteQueue = storageWriteQueue
    .then(() => new Promise((resolve, reject) => {
      chrome.storage.session.set({ [STARTUP_TARGETS_KEY]: snapshot }, () => {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else resolve();
      });
    }))
    .catch((error) => {
      console.error("[YTstopper] Nie udało się zapisać listy kart startowych:", error);
    });
}

function loadStartupTargets(callback) {
  if (startupSnapshotLoaded) {
    callback();
    return;
  }
  if (!chrome.storage.session) {
    startupSnapshotLoaded = true;
    callback();
    return;
  }
  chrome.storage.session.get([STARTUP_TARGETS_KEY], (result) => {
    if (chrome.runtime.lastError) {
      console.error("[YTstopper] Nie udało się odczytać listy kart startowych:", chrome.runtime.lastError.message);
      callback();
      return;
    }
    const snapshot = result[STARTUP_TARGETS_KEY];
    if (snapshot && typeof snapshot.sessionId === "string" && Array.isArray(snapshot.targets)) {
      startupSessionId = snapshot.sessionId;
      for (const target of snapshot.targets) {
        if (Number.isInteger(target?.id) && typeof target.pageKey === "string" && target.pageKey) {
          startupTargets.set(target.id, target.pageKey);
        }
      }
      if (Array.isArray(snapshot.tabIds)) {
        for (const tabId of snapshot.tabIds) {
          if (Number.isInteger(tabId)) startupTabIds.add(tabId);
        }
      }
      startupScanUntil = Number.isFinite(snapshot.scanUntil) ? snapshot.scanUntil : 0;
    }
    startupSnapshotLoaded = true;
    callback();
  });
}

function removeStartupTarget(tabId) {
  if (!startupTargets.delete(tabId)) return;
  persistStartupTargets();
}

function notifyStartupTab(tabId) {
  const expectedPageKey = startupTargets.get(tabId);
  if (!expectedPageKey || !startupSessionId) return;

  chrome.tabs.get(tabId, (tab) => {
    if (chrome.runtime.lastError || !tab) return;
    const currentPageKey = getYouTubePageKey(tab.pendingUrl || tab.url || "");
    if (currentPageKey && currentPageKey !== expectedPageKey) {
      removeStartupTarget(tabId);
      return;
    }
    if (currentPageKey !== expectedPageKey) return;

    chrome.tabs.sendMessage(tabId, {
      type: "YTSTOPPER_FORCE_STARTUP_STOP",
      sessionId: startupSessionId,
      pageKey: expectedPageKey,
    }, () => {
      if (!chrome.runtime.lastError) removeStartupTarget(tabId);
    });
  });
}

function discoverStartupYouTubeTab(tabId, tab) {
  if (Date.now() > startupScanUntil || !startupTabIds.has(tabId)) return;
  const pageKey = getYouTubePageKey(tab.pendingUrl || tab.url || "");
  if (!pageKey) return;
  startupTabIds.delete(tabId);
  if (startupTargets.get(tabId) === pageKey) {
    persistStartupTargets();
    notifyStartupTab(tabId);
    return;
  }
  startupTargets.set(tabId, pageKey);
  persistStartupTargets();
  notifyStartupTab(tabId);
}

function scanStartupTabs() {
  chrome.tabs.query({}, (tabs) => {
    if (chrome.runtime.lastError) {
      console.warn("[YTstopper] Nie udało się znaleźć kart podczas przywracania sesji:", chrome.runtime.lastError.message);
      return;
    }
    for (const tab of tabs) {
      if (!Number.isInteger(tab.id) || !startupTabIds.has(tab.id)) continue;
      discoverStartupYouTubeTab(tab.id, tab);
    }
  });
}

function stopRestoredYouTubeTabs() {
  startupSessionId = generateSessionId();
  startupTargets.clear();
  startupTabIds.clear();
  startupScanUntil = Date.now() + STARTUP_SCAN_WINDOW_MS;
  startupSnapshotLoaded = true;

  chrome.tabs.query({}, (tabs) => {
    if (chrome.runtime.lastError) {
      console.warn("[YTstopper] Nie udało się znaleźć kart po uruchomieniu:", chrome.runtime.lastError.message);
      return;
    }

    for (const tab of tabs) {
      if (!Number.isInteger(tab.id)) continue;
      startupTabIds.add(tab.id);
      discoverStartupYouTubeTab(tab.id, tab);
    }
    startupSnapshotLoaded = true;
    persistStartupTargets();

    const retryDelays = [0, 250, 600, 1200, 2400, 4000, 8000, 14000, 22000];
    for (const delay of retryDelays) {
      setTimeout(scanStartupTabs, delay);
    }
    setTimeout(() => {
      if (Date.now() < startupScanUntil) return;
      startupTabIds.clear();
      startupScanUntil = 0;
      persistStartupTargets();
    }, STARTUP_SCAN_WINDOW_MS);
  });
}

chrome.tabs.onCreated.addListener((tab) => {
  if (!Number.isInteger(tab.id) || Date.now() > startupScanUntil) return;
  startupTabIds.add(tab.id);
  persistStartupTargets();
  discoverStartupYouTubeTab(tab.id, tab);
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (!changeInfo.url && changeInfo.status !== "complete") return;
  loadStartupTargets(() => {
    if (Date.now() > startupScanUntil || !startupTabIds.has(tabId)) {
      notifyStartupTab(tabId);
      return;
    }
    chrome.tabs.get(tabId, (tab) => {
      if (chrome.runtime.lastError || !tab) return;
      discoverStartupYouTubeTab(tabId, tab);
      notifyStartupTab(tabId);
    });
  });
});

chrome.tabs.onRemoved.addListener((tabId) => {
  loadStartupTargets(() => removeStartupTarget(tabId));
});

chrome.runtime.onStartup.addListener(stopRestoredYouTubeTabs);
