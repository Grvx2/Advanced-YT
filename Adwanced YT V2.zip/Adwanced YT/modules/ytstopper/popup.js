﻿const defaults = {
  masterEnabled: true,
  ytAdvancedMode: true,
  enabledYoutube: true,
  enabledOtherSites: true,
  youtubeNewTabOnly: false,
  youtubeApplyShorts: false,
  youtubeResumeOnRefresh: false
};

if (new URLSearchParams(window.location.search).has("embedded")) {
  document.body.classList.add("embedded");
}

const masterToggle = document.getElementById("masterToggle");
const ytToggle = document.getElementById("ytToggle");
const ytAdvancedToggle = document.getElementById("ytAdvancedToggle");
const ytNewTabOnlyToggle = document.getElementById("ytNewTabOnlyToggle");
const ytShortsToggle = document.getElementById("ytShortsToggle");
const ytResumeOnRefreshToggle = document.getElementById("ytResumeOnRefreshToggle");
const otherToggle = document.getElementById("otherToggle");
const modeRow = document.getElementById("modeRow");
const newTabRow = document.getElementById("newTabRow");
const shortsRow = document.getElementById("shortsRow");
const resumeOnRefreshRow = document.getElementById("resumeOnRefreshRow");

function applyUiState() {
  const master = masterToggle.checked;
  const ytEnabled = ytToggle.checked;

  ytToggle.disabled = !master;
  otherToggle.disabled = !master;

  modeRow.style.display = ytEnabled ? "flex" : "none";
  newTabRow.style.display = ytEnabled ? "flex" : "none";
  shortsRow.style.display = ytEnabled ? "flex" : "none";
  resumeOnRefreshRow.style.display = ytEnabled ? "flex" : "none";

  ytAdvancedToggle.disabled = !master || !ytEnabled;
  ytNewTabOnlyToggle.disabled = !master || !ytEnabled;
  ytShortsToggle.disabled = !master || !ytEnabled;
  ytResumeOnRefreshToggle.disabled = !master || !ytEnabled;
}

function loadSettings() {
  chrome.storage.sync.get(defaults, (s) => {
    masterToggle.checked = !!s.masterEnabled;
    ytToggle.checked = !!s.enabledYoutube;
    ytAdvancedToggle.checked = !!s.ytAdvancedMode;
    ytNewTabOnlyToggle.checked = !!s.youtubeNewTabOnly;
    ytShortsToggle.checked = !!s.youtubeApplyShorts;
    ytResumeOnRefreshToggle.checked = !!s.youtubeResumeOnRefresh;
    otherToggle.checked = !!s.enabledOtherSites;
    applyUiState();
  });
}

function saveSettings() {
  applyUiState();
  chrome.storage.sync.set({
    masterEnabled: masterToggle.checked,
    enabledYoutube: ytToggle.checked,
    ytAdvancedMode: ytAdvancedToggle.checked,
    youtubeNewTabOnly: ytNewTabOnlyToggle.checked,
    youtubeApplyShorts: ytShortsToggle.checked,
    youtubeResumeOnRefresh: ytResumeOnRefreshToggle.checked,
    enabledOtherSites: otherToggle.checked
  });
}

masterToggle.addEventListener("change", saveSettings);
ytToggle.addEventListener("change", saveSettings);
ytAdvancedToggle.addEventListener("change", saveSettings);
ytNewTabOnlyToggle.addEventListener("change", saveSettings);
ytShortsToggle.addEventListener("change", saveSettings);
ytResumeOnRefreshToggle.addEventListener("change", saveSettings);
otherToggle.addEventListener("change", saveSettings);

loadSettings();
