(() => {
  "use strict";

  const promptText = ["film nie odtwarza sie plynnie", "video not playing smoothly"];
  const toastSelector = [
    "tp-yt-paper-toast",
    "ytd-player-toast-renderer",
    "ytd-notification-action-renderer",
    "#toast",
    ".ytp-popup",
    "[role='alert']",
    "[aria-live='polite']",
  ].join(", ");

  function normalizeText(value) {
    return (value || "")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLocaleLowerCase()
      .replace(/ł/g, "l")
      .replace(/\s+/g, " ")
      .trim();
  }

  function isTargetPrompt(element) {
    const text = normalizeText(element.textContent);
    return text.length <= 180 && promptText.some((phrase) => text.includes(phrase));
  }

  function hidePrompt(element) {
    if (element.matches("ytd-popup-container, ytd-app, ytd-player, #movie_player, body, html")) return;
    const knownToast = element.closest(toastSelector);
    if (knownToast && isTargetPrompt(knownToast)) {
      knownToast.setAttribute("data-ayt-playback-feedback", "");
      return;
    }

    let target = element;
    let parent = element.parentElement;
    for (let depth = 0; parent && depth < 6; depth += 1, parent = parent.parentElement) {
      if (parent.matches("ytd-popup-container, ytd-app, ytd-player, body, html")) break;
      if (!isTargetPrompt(parent)) break;
      target = parent;
      if (parent.matches(toastSelector)) break;
    }
    target.setAttribute("data-ayt-playback-feedback", "");
  }

  function inspectNode(node) {
    if (node.nodeType === Node.TEXT_NODE) {
      const parent = node.parentElement;
      if (parent && isTargetPrompt(parent)) hidePrompt(parent);
      return;
    }
    if (!(node instanceof Element)) return;

    if (isTargetPrompt(node)) hidePrompt(node);
    node.querySelectorAll(toastSelector).forEach((toast) => {
      if (isTargetPrompt(toast)) hidePrompt(toast);
    });
  }

  const observer = new MutationObserver((records) => {
    for (const record of records) {
      if (record.type === "characterData") inspectNode(record.target);
      for (const node of record.addedNodes) inspectNode(node);
    }
  });
  observer.observe(document.documentElement, {
    childList: true,
    characterData: true,
    subtree: true,
  });
  document.querySelectorAll(toastSelector).forEach((toast) => {
    if (isTargetPrompt(toast)) hidePrompt(toast);
  });
})();
