chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.get(["isExtensionEnabled", "watchedPercentage"], (settings) => {
    if (chrome.runtime.lastError) {
      console.error("[Ukryj Obejrzane Filmy] Nie udało się odczytać ustawień:", chrome.runtime.lastError.message);
      return;
    }

    const defaults = {};
    if (settings.isExtensionEnabled === undefined) defaults.isExtensionEnabled = true;
    if (settings.watchedPercentage === undefined) defaults.watchedPercentage = 100;
    if (Object.keys(defaults).length === 0) return;

    chrome.storage.sync.set(defaults, () => {
      if (chrome.runtime.lastError) {
        console.error("[Ukryj Obejrzane Filmy] Nie udało się ustawić wartości domyślnych:", chrome.runtime.lastError.message);
      }
    });
  });
});
