"use strict";

document.addEventListener("DOMContentLoaded", () => {
  const slider = document.getElementById("percentage-slider");
  const label = document.getElementById("percentage-label");

  chrome.storage.sync.get({ watchedPercentage: 100 }, (settings) => {
    if (chrome.runtime.lastError) {
      console.error("[Ukryj Obejrzane Filmy] Nie udało się odczytać progu:", chrome.runtime.lastError.message);
      return;
    }
    slider.value = String(settings.watchedPercentage || 100);
    label.textContent = `(${slider.value}%)`;
  });

  slider.addEventListener("input", () => {
    label.textContent = `(${slider.value}%)`;
  });

  slider.addEventListener("change", () => {
    chrome.storage.sync.set({ watchedPercentage: Number(slider.value) }, () => {
      if (chrome.runtime.lastError) {
        console.error("[Ukryj Obejrzane Filmy] Nie udało się zapisać progu:", chrome.runtime.lastError.message);
      }
    });
  });
});
