﻿(() => {
  'use strict';
  const __adwancedYtModuleWrapper = true;

// content.js
//
// Poprawki:
// 1) SZYBKOSC: dawniej kazda zmiana w DOM czekala az 500ms (debounce),
//    a dodatkowo byl jeszcze sztywny skan co 5000ms jako siatka
//    bezpieczenstwa. To dawalo widoczne opoznienie - film potrafil
//    zniknac dopiero chwile po tym, jak uzytkownik juz na niego patrzyl.
//    Teraz debounce dla nowych elementow jest dużo krotszy (120ms), a
//    dodatkowo kazdy pasek postepu ogladania, ktory raz znajdziemy, jest
//    obserwowany OSOBNO (attrybut "style") - dzieki temu, gdy YouTube
//    dopiero co doladuje/zaktualizuje pasek na 100%, wykrywamy to niemal
//    natychmiast, bez czekania na nastepny skan co kilka sekund.
// 2) FALSZYWE UKRYWANIE PRZY PODGLADZIE PO NAJECHANIU: gdy najezdzasz
//    na miniaturke, YouTube pokazuje krotki podglad wideo z wlasnym,
//    ruchomym paskiem postepu podgladu - ten pasek tez bywa elementem
//    "div ze stylem width: X%" i przy luznym dopasowaniu (samo slowo
//    "progress" w klasie) potrafil zostac pomylony z paskiem "juz
//    obejrzane". Dopasowanie paska "juz obejrzane" jest teraz scislejsze
//    (wymaga faktycznie kontenera odtworzenia/"resume playback", a nie
//    jakiegokolwiek paska z "progress" w nazwie), a dodatkowo pomijamy
//    cala karte filmu, jesli w tej chwili trwa w niej aktywne
//    odtwarzanie (obecny, grajacy <video>) - to jest jednoznaczny znak,
//    ze to podglad po najechaniu, a nie statyczna miniaturka.
// ===================================================================

// --- Global State ---
let config = {
    isEnabled: true,
    globalEnabled: true,
    percentage: 100
};
let constantScanInterval = null;
let pageObserver = null;
let isRunning = false;
let debounceTimer = null;
let immediateDebounceTimer = null;
let lastUrl = window.location.href;
let observedProgressBars = new WeakSet();
let barAttributeObserver = null;

// Selectors
const VIDEO_CONTAINER_SELECTOR = 'ytd-rich-item-renderer, ytd-grid-video-renderer, ytd-compact-video-renderer, ytd-video-renderer, ytd-playlist-panel-video-renderer';
// Scisle dopasowanie paska "juz obejrzane" - musi siedziec w kontenerze
// odpowiedzialnym za wznawianie odtwarzania, a nie byc jakimkolwiek
// paskiem zawierajacym w nazwie klasy slowo "progress" (to ostatnie
// pasuje tez do paska podgladu po najechaniu).
const PROGRESS_BAR_SELECTOR = '#progress.ytd-thumbnail-overlay-resume-playback-renderer, .ytThumbnailOverlayProgressBarHostWatchedProgressBarSegment';
// Kontenery/klasy zwiazane z podgladem po najechaniu - jesli pasek
// postepu siedzi w ktoryms z nich, to na pewno NIE jest paskiem
// "juz obejrzane", tylko paskiem samego podgladu.
const PREVIEW_CONTEXT_SELECTOR = 'ytd-video-preview, ytd-moving-thumbnail-renderer, #mouseover-overlay, #preview, [class*="preview" i], [class*="Preview"]';
const TITLE_SELECTOR = '#video-title, #video-title-link, #title';
const CHANNEL_SELECTOR = '#channel-name, .ytd-channel-name, #text.ytd-channel-name, [class*="channel-name"]';
const ALLOWED_PATHS = new Set([
    '/',
    '/results',
    '/feed/subscriptions',
    '/feed/channels',
    '/watch'
]);

function normalizePath(pathname) {
    if (!pathname) return '/';
    if (pathname !== '/' && pathname.endsWith('/')) {
        return pathname.slice(0, -1);
    }
    return pathname;
}

function isAllowedPage() {
    const currentPath = normalizePath(window.location.pathname);
    return ALLOWED_PATHS.has(currentPath);
}

// --- Helper: sprawdza, czy element paska nalezy do podgladu po najechaniu ---
function isInsidePreviewContext(barEl) {
    try {
        return !!barEl.closest(PREVIEW_CONTEXT_SELECTOR);
    } catch {
        return false;
    }
}

// --- Helper: Find Progress Bar ---
function findWatchedProgressBar(videoNode) {
    // 1. Selektor podstawowy - scisle dopasowanie do paska "juz obejrzane".
    let progressBar = videoNode.querySelector(PROGRESS_BAR_SELECTOR);
    if (progressBar && progressBar.style.width && progressBar.style.width.endsWith('%') && !isInsidePreviewContext(progressBar)) {
        return progressBar;
    }

    // 2. Dynamiczny fallback - szuka paska z szerokoscia w %, ale wymaga,
    // zeby siedzial konkretnie w kontenerze "resume playback" (a nie
    // jakimkolwiek elemencie z "progress" w nazwie - to zbyt luzne
    // dopasowanie pasowalo tez do paska podgladu po najechaniu).
    const potentialBars = videoNode.querySelectorAll('div[style*="width:"]');
    for (const bar of potentialBars) {
        const styleWidth = bar.style.width;
        if (!styleWidth || !styleWidth.endsWith('%')) continue;
        if (isInsidePreviewContext(bar)) continue;

        const isInsideResumeOverlay = bar.closest('ytd-thumbnail-overlay-resume-playback-renderer, .ytThumbnailOverlayProgressBarHostWatchedProgressBar');
        const classNameValue = typeof bar.className === 'string'
            ? bar.className
            : (bar.getAttribute('class') || '');
        const hasWatchedClass = classNameValue.toLowerCase().includes('watched');

        if (isInsideResumeOverlay || hasWatchedClass) {
            return bar;
        }
    }

    return null;
}

// --- Helper: czy karta w tej chwili aktywnie odtwarza podglad (hover) ---
function isCurrentlyPreviewPlaying(videoNode) {
    const liveVideo = videoNode.querySelector('video');
    if (!liveVideo) return false;
    // Aktywny, grajacy <video> wewnatrz karty na stronie glownej/wynikow
    // wyszukiwania oznacza podglad po najechaniu (statyczne miniaturki
    // nie maja wlasnego <video>, tylko obrazek).
    return !liveVideo.paused && !liveVideo.ended && liveVideo.readyState > 0;
}

// --- Core Hiding Logic ---
function hideVideoIfNeeded(videoNode) {
    if (!videoNode || typeof videoNode.querySelector !== 'function') return;

    if (window.location.pathname === '/watch' && videoNode.closest('ytd-playlist-panel-renderer')) return;

    // Pomijamy karty aktualnie hoverowane (CSS :hover) ORAZ karty z
    // aktywnie odtwarzanym podgladem (na wypadek, gdyby podglad
    // zostal np. "oderwany" do innego miejsca w DOM i :hover nie
    // objelby go bezposrednio).
    if (videoNode.matches(':hover') || videoNode.querySelector(':hover')) return;
    if (isCurrentlyPreviewPlaying(videoNode)) return;

    if (videoNode.getAttribute('data-yt-hider-hidden') === 'true') return;

    const progressBar = findWatchedProgressBar(videoNode);
    if (progressBar) {
        observeProgressBar(progressBar, videoNode);

        const currentPercentage = parseInt(progressBar.style.width, 10);
        if (!isNaN(currentPercentage) && currentPercentage >= config.percentage) {
            hideVideoElement(videoNode);
        }
    }
}

function hideVideoElement(element) {
    element.style.display = 'none';
    element.setAttribute('data-yt-hider-hidden', 'true');
}

// --- Natychmiastowa reakcja na zmiane paska postepu (bez czekania na kolejny skan) ---
function observeProgressBar(barEl, videoNode) {
    if (!barEl || observedProgressBars.has(barEl)) return;
    observedProgressBars.add(barEl);

    if (!barAttributeObserver) {
        barAttributeObserver = new MutationObserver((mutations) => {
            if (!config.isEnabled || !config.globalEnabled) return;
            const nodesToCheck = new Set();
            for (const mutation of mutations) {
                const container = mutation.target.closest
                    ? mutation.target.closest(VIDEO_CONTAINER_SELECTOR)
                    : null;
                if (container) nodesToCheck.add(container);
            }
            nodesToCheck.forEach((node) => hideVideoIfNeeded(node));
        });
    }

    try {
        barAttributeObserver.observe(barEl, { attributes: true, attributeFilter: ['style'] });
    } catch {}
}

// --- Main Scan Function ---
function runScan() {
    try {
    if (!config.isEnabled || !config.globalEnabled) {
        restoreAllVideos();
        return;
    }

    if (!isAllowedPage()) {
        restoreAllVideos();
        return;
    }

    document.querySelectorAll(VIDEO_CONTAINER_SELECTOR).forEach(hideVideoIfNeeded);
    } catch (error) {
        console.error('[UnseenTube] runScan failed:', error);
    }
}

function restoreAllVideos() {
    const hiddenElements = document.querySelectorAll('[data-yt-hider-hidden="true"]');
    if (hiddenElements.length === 0) return;

    hiddenElements.forEach(el => {
        el.style.display = '';
        el.removeAttribute('data-yt-hider-hidden');
    });
}

// --- Dynamic Node Processing ---
function processNewNodes() {
    // Krotki debounce (grupuje serie mutacji w jeden skan), ale znacznie
    // krotszy niz wczesniej - 120ms zamiast 500ms, wiec nowo zaladowane
    // filmy znikaja niemal od razu, a nie z zauwazalnym opoznieniem.
    if (debounceTimer) clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => {
        runScan();
    }, 120);
}

// --- Control Functions ---
function startMonitors() {
    if (isRunning) return;
    isRunning = true;
    runScan();
    // Skan okresowy jako siatka bezpieczenstwa - skrocony z 5000ms do
    // 1000ms, zeby lapac tez aktualizacje paska postepu, ktore z jakiegos
    // powodu nie wywolaly obserwatora (np. YouTube podmienilo caly
    // element paska zamiast zmienic mu atrybut).
    constantScanInterval = setInterval(runScan, 1000);

    const targetNode = document.documentElement || document.body;
    if (targetNode) {
        pageObserver = new MutationObserver(mutations => {
            let shouldScan = false;
            for (const mutation of mutations) {
                if (mutation.addedNodes.length > 0) {
                    shouldScan = true;
                    break;
                }
            }
            if (shouldScan) processNewNodes();
        });
        pageObserver.observe(targetNode, { childList: true, subtree: true });
    }
}

function stopMonitors() {
    if (!isRunning) return;
    isRunning = false;
    if (pageObserver) pageObserver.disconnect();
    if (constantScanInterval) clearInterval(constantScanInterval);
    if (barAttributeObserver) barAttributeObserver.disconnect();
    barAttributeObserver = null;
    observedProgressBars = new WeakSet();
    pageObserver = null;
    constantScanInterval = null;
    debounceTimer = null;
    restoreAllVideos();
}

// --- Initialization ---
function initialize() {
    chrome.storage.sync.get([
        'isExtensionEnabled', 'watchedPercentage', 'aytGlobalEnabled'
    ], (data) => {
        config.isEnabled = data.isExtensionEnabled !== false;
        config.globalEnabled = data.aytGlobalEnabled !== false;
        config.percentage = data.watchedPercentage || 100;

        if (config.isEnabled && config.globalEnabled) {
            startMonitors();
        } else {
            stopMonitors();
        }
    });
}

chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'sync') return;

    // Reagujemy na zywo na kazda istotna zmiane ustawien w pamieci -
    // nie tylko na wiadomosc z wlasnego (ukrytego w widoku glownym)
    // popupu. Dzieki temu przelacznik na glownej liscie "Adwanced YT"
    // faktycznie natychmiast wlacza/wylacza modul, a nie dopiero po
    // odswiezeniu strony.
    const relevantKeys = [
        'aytGlobalEnabled', 'isExtensionEnabled', 'watchedPercentage'
    ];
    if (!relevantKeys.some((k) => changes[k])) return;

    if (changes.aytGlobalEnabled) config.globalEnabled = changes.aytGlobalEnabled.newValue !== false;
    if (changes.isExtensionEnabled) config.isEnabled = changes.isExtensionEnabled.newValue !== false;
    if (changes.watchedPercentage) config.percentage = changes.watchedPercentage.newValue || 100;

    restoreAllVideos();
    if (config.isEnabled && config.globalEnabled) startMonitors();
    else stopMonitors();
});

window.addEventListener('yt-navigate-finish', () => {
    const currentUrl = window.location.href;
    if (currentUrl !== lastUrl) {
        lastUrl = currentUrl;
        initialize();
    }
});

window.addEventListener('popstate', () => {
    const currentUrl = window.location.href;
    if (currentUrl !== lastUrl) {
        lastUrl = currentUrl;
        initialize();
    }
});

// Initial run
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => initialize());
} else {
    initialize();
}

})();
