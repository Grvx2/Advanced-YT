"use strict";

(() => {
  const nativeStorage = chrome.storage;

  function invoke(area, method, argument) {
    return new Promise((resolve, reject) => {
      let settled = false;
      const finish = (value) => {
        if (settled) return;
        settled = true;
        const error = chrome.runtime.lastError;
        if (error) reject(new Error(error.message));
        else resolve(value);
      };

      try {
        const result = area[method](argument, finish);
        if (result && typeof result.then === "function") result.then(finish, reject);
      } catch (error) {
        reject(error);
      }
    });
  }

  function createNamespacedExtensionApi(options) {
    const { name, prefix, moduleEnabledKey, visibleSettingKey } = options;
    const listeners = new Set();
    const moduleStateKeys = new Set([moduleEnabledKey, "aytGlobalEnabled"]);
    let effectiveEnabled = true;
    let stateInitialized = false;

    const reportCallbackError = (error, operation) => {
      console.error(`[${name}] Nie udało się ${operation}:`, error);
    };

    function readModuleEnabled() {
      return Promise.all([
        invoke(nativeStorage.local, "get", { [moduleEnabledKey]: true }),
        invoke(nativeStorage.sync, "get", { aytGlobalEnabled: true }),
      ]).then(([localSettings, syncSettings]) =>
        localSettings[moduleEnabledKey] !== false && syncSettings.aytGlobalEnabled !== false);
    }

    function notifyListeners(changes, areaName) {
      for (const listener of listeners) {
        try {
          listener(changes, areaName);
        } catch (error) {
          reportCallbackError(error, "aktualizować ustawienia");
        }
      }
    }

    function refreshModuleState() {
      return readModuleEnabled().then((enabled) => {
        const changed = stateInitialized && effectiveEnabled !== enabled;
        const previous = effectiveEnabled;
        effectiveEnabled = enabled;
        stateInitialized = true;
        if (changed) {
          const change = {
            [visibleSettingKey]: { oldValue: previous, newValue: enabled },
          };
          notifyListeners(change, "sync");
          notifyListeners(change, "local");
        }
        return enabled;
      });
    }

    function prefixKeys(keys) {
      if (keys === null || keys === undefined) return null;
      if (typeof keys === "string") return `${prefix}${keys}`;
      if (Array.isArray(keys)) return keys.map((key) => `${prefix}${key}`);
      if (typeof keys === "object") {
        return Object.fromEntries(Object.entries(keys).map(([key, value]) => [`${prefix}${key}`, value]));
      }
      return keys;
    }

    function unprefixValues(values, enabled) {
      const result = Object.fromEntries(Object.entries(values || {})
        .filter(([key]) => key.startsWith(prefix))
        .map(([key, value]) => [key.slice(prefix.length), value]));
      if (!enabled) result[visibleSettingKey] = false;
      return result;
    }

    function callbackResult(promise, callback, operation) {
      if (typeof callback !== "function") return promise;
      promise.then((value) => callback(value)).catch((error) => reportCallbackError(error, operation));
      return undefined;
    }

    function createStorageArea(areaName) {
      const area = nativeStorage[areaName];
      return {
        get(keys, callback) {
          const promise = refreshModuleState()
            .then((enabled) => invoke(area, "get", areaName === "local" || areaName === "sync"
              ? prefixKeys(keys)
              : keys)
              .then((values) => {
                if (areaName !== "local" && areaName !== "sync") return values || {};
                return unprefixValues(values, enabled);
              }));
          return callbackResult(promise, callback, `odczytać ustawienia ${areaName}`);
        },
        set(values, callback) {
          if (areaName !== "local" && areaName !== "sync") {
            return callbackResult(invoke(area, "set", values), callback, `zapisać ustawienia ${areaName}`);
          }
          const prefixed = Object.fromEntries(Object.entries(values || {})
            .map(([key, value]) => [`${prefix}${key}`, value]));
          return callbackResult(invoke(area, "set", prefixed), callback, `zapisać ustawienia ${areaName}`);
        },
        remove(keys, callback) {
          if (areaName !== "local" && areaName !== "sync") {
            return callbackResult(invoke(area, "remove", keys), callback, `usunąć ustawienia ${areaName}`);
          }
          const prefixed = typeof keys === "string"
            ? `${prefix}${keys}`
            : Array.isArray(keys)
              ? keys.map((key) => `${prefix}${key}`)
              : keys;
          return callbackResult(invoke(area, "remove", prefixed), callback, `usunąć ustawienia ${areaName}`);
        },
        clear(callback) {
          if (areaName !== "local" && areaName !== "sync") {
            return callbackResult(invoke(area, "clear"), callback, `wyczyścić ustawienia ${areaName}`);
          }
          const promise = invoke(area, "get", null).then((values) => {
            const keys = Object.keys(values || {}).filter((key) => key.startsWith(prefix));
            return keys.length ? invoke(area, "remove", keys) : undefined;
          });
          return callbackResult(promise, callback, `wyczyścić ustawienia ${areaName}`);
        },
        getBytesInUse(keys, callback) {
          return callbackResult(
            invoke(area, "getBytesInUse", areaName === "local" || areaName === "sync"
              ? prefixKeys(keys)
              : keys),
            callback,
            `odczytać rozmiar ustawień ${areaName}`,
          );
        },
      };
    }

    const storage = {
      local: createStorageArea("local"),
      sync: createStorageArea("sync"),
      onChanged: Object.freeze({
        addListener(listener) {
          listeners.add(listener);
        },
        removeListener(listener) {
          listeners.delete(listener);
        },
        hasListener(listener) {
          return listeners.has(listener);
        },
        hasListeners() {
          return listeners.size > 0;
        },
      }),
    };
    for (const areaName of ["session", "managed"]) {
      if (nativeStorage[areaName]) storage[areaName] = createStorageArea(areaName);
    }

    nativeStorage.onChanged.addListener((changes, areaName) => {
      const moduleToggleChanged = areaName === "local" && Object.hasOwn(changes, moduleEnabledKey);
      const globalToggleChanged = areaName === "sync" && Object.hasOwn(changes, "aytGlobalEnabled");
      if (moduleToggleChanged || globalToggleChanged) {
        refreshModuleState().catch((error) => reportCallbackError(error, "odczytać stan modułu"));
      }

      const namespacedChanges = Object.fromEntries(Object.entries(changes)
        .filter(([key]) => key.startsWith(prefix))
        .map(([key, change]) => [key.slice(prefix.length), { ...change }]));
      if (!Object.keys(namespacedChanges).length) return;

      if (Object.hasOwn(namespacedChanges, visibleSettingKey)) {
        const change = namespacedChanges[visibleSettingKey];
        if (!effectiveEnabled) change.newValue = false;
      }
      notifyListeners(namespacedChanges, areaName);
    });

    const runtime = new Proxy(chrome.runtime, {
      get(target, property) {
        if (property === "openOptionsPage") {
          return (callback) => {
            const tab = chrome.tabs.create({
              url: chrome.runtime.getURL(`${options.resourceRoot}/popup.html`),
            });
            if (typeof callback === "function") tab.then(() => callback(), (error) => {
              reportCallbackError(error, "otworzyć ustawienia");
            });
            return tab;
          };
        }
        if (property === "setUninstallURL") {
          return (url, callback) => {
            if (typeof callback === "function") callback();
          };
        }
        if (property === "getURL") {
          return (resource) => {
            if (typeof resource !== "string" || /^[a-z][a-z\d+.-]*:/i.test(resource)) return resource;
            const relative = resource.replace(/^\/+/, "");
            return chrome.runtime.getURL(`${options.resourceRoot}/${relative}`);
          };
        }
        const value = Reflect.get(target, property, target);
        return typeof value === "function" ? value.bind(target) : value;
      },
    });

    const nativeAction = chrome.action || chrome.browserAction;
    const action = nativeAction && new Proxy(nativeAction, {
      get(target, property) {
        if (property === "setIcon") {
          return (details, callback) => {
            if (typeof callback === "function") callback();
          };
        }
        const value = Reflect.get(target, property, target);
        return typeof value === "function" ? value.bind(target) : value;
      },
    });

    return new Proxy(chrome, {
      get(target, property) {
        if (property === "storage") return storage;
        if (property === "runtime") return runtime;
        if (property === "action" || property === "browserAction") return action;
        return Reflect.get(target, property, target);
      },
    });
  }

  globalThis.createNamespacedExtensionApi = createNamespacedExtensionApi;
})();
