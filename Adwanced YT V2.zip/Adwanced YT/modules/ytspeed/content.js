﻿(() => {
  'use strict';
  const __adwancedYtModuleWrapper = true;

  // ==================================================================
  // YTSpeedCTRL
  //
  // Naprawa: modul potrafil "przestac dzialac" i wymagal wylaczenia
  // i wlaczenia, zeby znow zaczac reagowac na klawisze. Przyczyna:
  // trzymal jedno, zapamietane w zmiennej "video" i odswiezane tylko
  // przez MutationObserver. Przy nawigacji SPA na YouTube (przejscie
  // na kolejny film), reklamach czy zmianie jakosci, ten element
  // potrafil zostac odlaczony od DOM (albo w DOM pojawial sie nowy
  // <video>), a obserwator nie zawsze zdazyl / trafil w odswiezenie
  // w porownaniu ten sam stary, martwy element - w efekcie ustawianie
  // predkosci nic juz nie robilo, mimo ze skrot byl wcisniety.
  //
  // Teraz zamiast trzymac cache, przy kazdym wcisnieciu klawisza modul
  // szuka aktywnego <video> na nowo (to tanie zapytanie), a jesli jest
  // ich wiecej niz jeden (np. podglad po najechaniu na inny film w
  // bocznym panelu), wybiera ten najwiekszy/widoczny - czyli glowny
  // odtwarzacz. Dzieki temu nie ma juz mozliwosci "utkniecia" na
  // martwym elemencie i modul dziala od razu, bez potrzeby przelaczania
  // wylacznika.
  //
  // Dodatkowo modul teraz faktycznie respektuje wlasny przelacznik
  // (dawniej wcale go nie odczytywal) oraz glowny wylacznik "Adwanced YT".
  // ==================================================================

  const STORAGE_KEY = 'aytSpeedEnabled';
  const GLOBAL_KEY = 'aytGlobalEnabled';
  const BINDINGS_KEY = 'aytSpeedBindings';
  const DEFAULT_BINDINGS = [
    { key: 'v', rate: 1 },
    { key: 'b', rate: 1.5 },
    { key: 'n', rate: 2 },
    { key: 'x', rate: 2.5 },
    { key: 'z', rate: 3 },
  ];

  let moduleEnabled = true;
  let globalEnabled = true;
  let speedBindings = DEFAULT_BINDINGS;
  let extensionContextValid = true;

  function isEffectivelyEnabled() {
    return extensionContextValid && moduleEnabled && globalEnabled;
  }

  function isTypingTarget(target) {
    if (!target) return false;
    const tagName = target.tagName;
    return (
      target.isContentEditable ||
      tagName === 'INPUT' ||
      tagName === 'TEXTAREA' ||
      tagName === 'SELECT'
    );
  }

  function findActiveVideo() {
    let videos;
    try {
      videos = Array.from(document.querySelectorAll('video'));
    } catch (error) {
      return null;
    }
    if (!videos.length) return null;
    if (videos.length === 1) return videos[0];

    const visible = videos.filter((v) => {
      const rect = v.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0;
    });

    const pool = visible.length ? visible : videos;
    pool.sort((a, b) => {
      const ra = a.getBoundingClientRect();
      const rb = b.getBoundingClientRect();
      return rb.width * rb.height - ra.width * ra.height;
    });

    return pool[0] || null;
  }

  function setPlaybackRate(rate) {
    if (!isEffectivelyEnabled()) return;
    try {
      const video = findActiveVideo();
      if (!video) return;
      video.playbackRate = rate;
    } catch (error) {
      // Nie pozwalamy, zeby przejsciowy blad DOM ubil listener klawiszy.
    }
  }

  document.addEventListener('keydown', (event) => {
    if (!isEffectivelyEnabled()) return;
    if (isTypingTarget(event.target)) return;

    const binding = speedBindings.find((item) => item.key === event.key.toLowerCase());
    if (binding) setPlaybackRate(binding.rate);
  });

  function loadEnabledState() {
    try {
      chrome.storage.sync.get({
        [STORAGE_KEY]: true,
        [GLOBAL_KEY]: true,
        [BINDINGS_KEY]: DEFAULT_BINDINGS,
      }, (data) => {
        if (chrome.runtime.lastError) return;
        moduleEnabled = data[STORAGE_KEY] !== false;
        globalEnabled = data[GLOBAL_KEY] !== false;
        const configuredBindings = data[BINDINGS_KEY];
        if (Array.isArray(configuredBindings)) {
          speedBindings = configuredBindings.filter((binding) =>
            binding && typeof binding.key === 'string'
            && [...binding.key].length === 1
            && Number.isFinite(binding.rate)
            && binding.rate >= 0.25
            && binding.rate <= 16,
          ).map((binding) => ({ key: binding.key.toLowerCase(), rate: binding.rate }));
        }
      });
    } catch (error) {
      // Kontekst rozszerzenia mogl zostac uniewazniony (np. update/reload).
      extensionContextValid = false;
    }
  }

  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'sync') return;
      if (changes[STORAGE_KEY]) moduleEnabled = changes[STORAGE_KEY].newValue !== false;
      if (changes[GLOBAL_KEY]) globalEnabled = changes[GLOBAL_KEY].newValue !== false;
      if (changes[BINDINGS_KEY] && Array.isArray(changes[BINDINGS_KEY].newValue)) {
        speedBindings = changes[BINDINGS_KEY].newValue
          .filter((binding) => binding && typeof binding.key === 'string'
            && [...binding.key].length === 1 && Number.isFinite(binding.rate)
            && binding.rate >= 0.25 && binding.rate <= 16)
          .map((binding) => ({ key: binding.key.toLowerCase(), rate: binding.rate }));
      }
    });
  } catch (error) {
    extensionContextValid = false;
  }

  loadEnabledState();
})();
