
chrome.runtime.onInstalled.addListener(function() {
  console.log('YouTube Speed Control extension installed.');
});
