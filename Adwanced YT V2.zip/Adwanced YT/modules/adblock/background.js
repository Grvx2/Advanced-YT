/******/ (() => { // webpackBootstrap
/******/ 	"use strict";

;// ./src/background/helpers/calculate-dau.ts
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var calculateDau = function () {
    setTimeout(function () { return __awaiter(void 0, void 0, void 0, function () {
        return __generator(this, function (_a) {
            chrome.runtime.reload();
            return [2];
        });
    }); }, 86400 * 1000);
};

;// ./src/background/helpers/dynamic-rules-helpers.ts
var findDynamicRuleSeparatorIndex = function (rule) {
    for (var i = rule.length - 1; i >= 0; i -= 1) {
        if (rule[i] === '$' && rule[i + 1] !== '/' && rule[i - 1] !== '\\') {
            return i;
        }
    }
    return -1;
};

;// ./src/enums/extension-keys.enum.ts
var ExtensionsKeys;
(function (ExtensionsKeys) {
    ExtensionsKeys["InstalledAt"] = "installedAt";
    ExtensionsKeys["StorageVersion"] = "storageVersion";
    ExtensionsKeys["ExtensionVersion"] = "extensionVersion";
    ExtensionsKeys["ShouldCheckUpdatePageConfig"] = "shouldCheckUpdatePageConfig";
    ExtensionsKeys["LastRulesFetchAt"] = "lastRulesFetchAt";
    ExtensionsKeys["UpdatePagePending"] = "updatePagePending";
    ExtensionsKeys["AdLeakBucket"] = "adLeakBucket";
    ExtensionsKeys["AdLeakLastShownAt"] = "adLeakLastShownAt";
    ExtensionsKeys["AdLeakDismissedAt"] = "adLeakDismissedAt";
    ExtensionsKeys["AdLeakStateCache"] = "adLeakStateCache";
    ExtensionsKeys["AdLeakShownCount"] = "adLeakShownCount";
    ExtensionsKeys["AdLeakDetectedSentAt"] = "adLeakDetectedSentAt";
})(ExtensionsKeys || (ExtensionsKeys = {}));

;// ./src/enums/settings-keys.enum.ts
var SettingsKeys;
(function (SettingsKeys) {
    SettingsKeys["Ads"] = "ads";
    SettingsKeys["InformAboutUpdates"] = "informAboutUpdates";
    SettingsKeys["NetworkRules"] = "networkRules";
    SettingsKeys["CssRules"] = "cssRules";
    SettingsKeys["PopupConfig"] = "popupConfig";
    SettingsKeys["ScripletsRules"] = "scripletsRules";
    SettingsKeys["AdLeakNotices"] = "adLeakNotices";
    SettingsKeys["AdLeakNoticeConfig"] = "adLeakNoticeConfig";
    SettingsKeys["RulesVersion"] = "rulesVersion";
    SettingsKeys["OldDailymotionAdBlockingSelectors"] = "dailymotionAdBlockingSelectors";
    SettingsKeys["OldDailymotionAdRegex"] = "dailymotionAdRegex";
    SettingsKeys["OldAdditionalBlockingEnabled"] = "isAdditionalBlockingEnabled";
    SettingsKeys["OldYoutubeAdRegex"] = "youtubeAdRegex";
    SettingsKeys["OldAdBlockingSelectors"] = "adBlockingSelectors";
    SettingsKeys["OldScriptlets"] = "scriptlets";
    SettingsKeys["OldShowUpdatePageNextLaunch"] = "showUpdatePageNextLaunch";
    SettingsKeys["OldAnnotations"] = "annotations";
})(SettingsKeys || (SettingsKeys = {}));

;// ./src/enums/actions.enum.ts
var ActionsEnum;
(function (ActionsEnum) {
    ActionsEnum["PageReady"] = "PAGE_READY";
    ActionsEnum["Ping"] = "PING";
    ActionsEnum["GetSettings"] = "GET_SETTINGS";
    ActionsEnum["SetSetting"] = "SET_SETTING";
    ActionsEnum["CanShowAdLeakNotice"] = "CAN_SHOW_AD_LEAK_NOTICE";
    ActionsEnum["AdLeakEvent"] = "AD_LEAK_EVENT";
})(ActionsEnum || (ActionsEnum = {}));

;// ./src/enums/popup-keys.enum.ts
var __assign = (undefined && undefined.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var PopupRestrictionKeysEnum;
(function (PopupRestrictionKeysEnum) {
    PopupRestrictionKeysEnum["ConfigurablePopupRestriction"] = "configurablePopupRestriction";
    PopupRestrictionKeysEnum["AntiAdblockPopupRestriction"] = "antiAdblockPopupRestriction";
    PopupRestrictionKeysEnum["PopupGeneralRestriction"] = "popupGeneralRestriction";
    PopupRestrictionKeysEnum["RatingPopupRestriction"] = "ratingDialogShown";
    PopupRestrictionKeysEnum["OldOtherStreamingPopupRestriction"] = "otherStreamingPopupRestriction";
    PopupRestrictionKeysEnum["OldUpdatePopupRestriction"] = "updatePopupRestriction";
})(PopupRestrictionKeysEnum || (PopupRestrictionKeysEnum = {}));
var PopupDontShowKeysEnum;
(function (PopupDontShowKeysEnum) {
    PopupDontShowKeysEnum["ConfigurablePopupDoNotShow"] = "configurablePopupDoNotShow";
    PopupDontShowKeysEnum["AntiAdblockPopupDoNotShow"] = "antiAdblockPopupDoNotShow";
    PopupDontShowKeysEnum["RateUsPopupDoNotShow"] = "rateUsPopupDoNotShow";
    PopupDontShowKeysEnum["OldOtherStreamingPopupDoNotShow"] = "otherStreamingPopupDoNotShow";
    PopupDontShowKeysEnum["OldUpdatePopupDoNotShow"] = "updatePopupDoNotShow";
})(PopupDontShowKeysEnum || (PopupDontShowKeysEnum = {}));
var PopupKeys = __assign(__assign({}, PopupRestrictionKeysEnum), PopupDontShowKeysEnum);
var PopupTypesEnum;
(function (PopupTypesEnum) {
    PopupTypesEnum["Windows"] = "windows";
    PopupTypesEnum["Mobile"] = "mobile";
    PopupTypesEnum["AntiAdblock"] = "anti-adblock";
    PopupTypesEnum["RateUs"] = "rate-us";
})(PopupTypesEnum || (PopupTypesEnum = {}));

;// ./src/enums/request.enum.ts
var ModifiersRequestTypeEnum;
(function (ModifiersRequestTypeEnum) {
    ModifiersRequestTypeEnum["SubDocument"] = "subdocument";
    ModifiersRequestTypeEnum["Script"] = "script";
    ModifiersRequestTypeEnum["Stylesheet"] = "stylesheet";
    ModifiersRequestTypeEnum["Object"] = "object";
    ModifiersRequestTypeEnum["Image"] = "image";
    ModifiersRequestTypeEnum["XmlHttpRequest"] = "xmlhttprequest";
    ModifiersRequestTypeEnum["Media"] = "media";
    ModifiersRequestTypeEnum["Font"] = "font";
    ModifiersRequestTypeEnum["WebSocket"] = "websocket";
    ModifiersRequestTypeEnum["Ping"] = "ping";
    ModifiersRequestTypeEnum["CspReport"] = "csp_report";
})(ModifiersRequestTypeEnum || (ModifiersRequestTypeEnum = {}));

;// ./src/enums/index.ts






;// ./src/constants/resource-map.ts
var _a;

var ResourceType = chrome.declarativeNetRequest.ResourceType;
var resourceMap = (_a = {},
    _a[ModifiersRequestTypeEnum.CspReport] = ResourceType.CSP_REPORT,
    _a[ModifiersRequestTypeEnum.Image] = ResourceType.IMAGE,
    _a[ModifiersRequestTypeEnum.Script] = ResourceType.SCRIPT,
    _a[ModifiersRequestTypeEnum.Stylesheet] = ResourceType.STYLESHEET,
    _a[ModifiersRequestTypeEnum.Font] = ResourceType.FONT,
    _a[ModifiersRequestTypeEnum.Media] = ResourceType.MEDIA,
    _a[ModifiersRequestTypeEnum.SubDocument] = ResourceType.SUB_FRAME,
    _a[ModifiersRequestTypeEnum.XmlHttpRequest] = ResourceType.XMLHTTPREQUEST,
    _a[ModifiersRequestTypeEnum.WebSocket] = ResourceType.WEBSOCKET,
    _a[ModifiersRequestTypeEnum.Ping] = ResourceType.PING,
    _a);

;// ./src/constants/default-data/ad-leak-notice.ts
var DefaultAdLeakNoticeConfig = {
    detector: {
        minVisibleMs: 3000,
        consecutiveVideos: 2,
    },
    frequency: {
        episodeQuietHours: 24,
        dismissDays: 7,
    },
    ctaUrl: '',
    texts: {
        attribution: 'Adblock for Youtube™ · An ad got through',
        body: "YouTube changed how it delivers ads, and extensions can only react after each change. Our desktop app blocks at system level, where these changes don't reach.",
        primaryCta: 'Stop ads getting through',
        secondaryCta: 'Report this ad',
        optOut: 'Turn off these notices',
        thanks: 'Thanks, that helps us fix it faster.',
    },
};

;// ./src/constants/default-data/css-rules.ts
var cssRulesFallback = [
    '#offer-module',
    '#sticker-layer',
    '#promotion-shelf',
    '#description-inner > ytd-merch-shelf-renderer > #main.ytd-merch-shelf-renderer',
    '#shorts-inner-container > .ytd-shorts:has(> .ytd-reel-video-renderer > ytd-ad-slot-renderer)',
    'ytd-rich-item-renderer:has(> #content > ytd-ad-slot-renderer)',
    '.ytReelMetapanelViewModelHost > .ytReelMetapanelViewModelMetapanelItem > .ytShortsSuggestedActionViewModelStaticHost',
    '.ytd-section-list-renderer > .ytd-item-section-renderer > ytd-search-pyv-renderer.ytd-item-section-renderer',
    '.ytd-two-column-browse-results-renderer > ytd-rich-grid-renderer > #masthead-ad.ytd-rich-grid-renderer',
    '.ytd-watch-flexy > .ytd-watch-next-secondary-results-renderer > ytd-ad-slot-renderer.ytd-watch-next-secondary-results-renderer',
    '.ytd-watch-flexy > ytd-merch-shelf-renderer > #main.ytd-merch-shelf-renderer',
    '.grid.ytd-browse > #primary > .style-scope > .ytd-rich-grid-renderer > .ytd-rich-grid-renderer > .ytd-ad-slot-renderer',
    '.ytd-rich-item-renderer.style-scope > .ytd-rich-item-renderer > .ytd-ad-slot-renderer.style-scope',
    'ytd-item-section-renderer > .ytd-item-section-renderer > ytd-ad-slot-renderer.style-scope',
    '.ytp-suggested-action > .ytp-suggested-action-badge',
    '.yt-badge-shape--ad',
    'ad-badge-view-model',
];

;// ./src/constants/default-data/network-rules.ts
var networkRulesFallback = [
    '||youtube.com/pagead/',
    '||youtube.com/youtubei/v1/player/ad_break',
    '||www.youtube.com/get_midroll_',
    '||youtube.com/get_video_info?*=adunit&',
    '||youtube.com/get_video_info?*adunit',
    '||youtube.com/embed/*&origin=https%3A%2F%2Fwww.feltet.dk&widgetid=1$subdocument',
    '||youtube.com/embed/wqLWTeNBEEQ?',
    '||youtube.com/embed/-pGjd8-iyDQ',
    '||youtube.com/embed/46p5FwQdA64',
    '||youtube.com/embed/5tDSbsDqekU',
    '||youtube.com/embed/9olr5bechjI',
    '||youtube.com/embed/_6eiTXwuYoM',
    '||youtube.com/embed/CfBt63FbFNE',
    '||youtube.com/embed/dVD5yqGie9s',
    '||youtube.com/embed/GHomo-YgJNc',
    '||youtube.com/embed/h_PXz0vN5H4',
    '||youtube.com/embed/HF49uJ-e0zg',
    '||youtube.com/embed/Innx3oYcTWQ',
    '||youtube.com/embed/iNtajKR6ZCs',
    '||youtube.com/embed/iSsvK-L5CWI',
    '||youtube.com/embed/M63OoLc3WAI',
    '||youtube.com/embed/M6fO3qmXrhE',
    '||youtube.com/embed/MdidROnkjuo',
    '||youtube.com/embed/mILt9Fnh9bI',
    '||youtube.com/embed/Oknp4IAlagg',
    '||youtube.com/embed/qBR1xJA_nyY',
    '||youtube.com/embed/qZyibLqhGhs',
    '||youtube.com/embed/R5MZoHLaxCw',
    '||youtube.com/embed/r_MQnkukVrA',
    '||youtube.com/embed/SbtEQ5-Tzkc',
    '||youtube.com/embed/uETU52vKKOU',
    '||youtube.com/embed/VYuSDoPGeCk',
    '||youtube.com/embed/wr-wYUOdKi8',
    '||youtube.com/embed/zIQ6e--UWOw',
    '||youtube.com/embed/ZpENWJBmE10',
    '||youtube.com/embed/1ljpiLRAAho',
    '||youtube.com/embed/ixacW9YeJD0',
    '||youtube.com/embed/o19SibpQEcI',
    '||youtube.com/embed/Rr8SMpvYX2I?',
    '||youtube.com/embed/wuZ5Az_ANLU',
    '||youtube.com/embed/w-gs3KRgF-4',
    '||googlesyndication.com^',
    '||googleads.g.doubleclick.net',
    '||doubleclick.com',
    '||google.com/pagead/',
    '||googlevideo.com/initplayback?source=youtube&*&c=TVHTML5&oad=$xmlhttprequest',
];

;// ./src/constants/default-data/popup-config.ts

var DefaultPopupsConfig = {
    isAntiAdblockPopupEnabled: false,
    isRateUsPopupEnabled: false,
    configurablePopup: {
        type: PopupTypesEnum.Mobile,
        isEnabled: false,
        doNotShowAgainMinutes: 120,
    },
};

;// ./src/constants/scriptlets/sriptlets.ts
var scripletsFallback = [
    {
        name: 'set-constant',
        args: ['ytInitialPlayerResponse.adPlacements', 'undefined'],
    },
    {
        name: 'set-constant',
        args: ['ytInitialPlayerResponse.adSlots', 'undefined'],
    },
    {
        name: 'set-constant',
        args: ['ytInitialPlayerResponse.playerAds', 'undefined'],
    },
    {
        name: 'set-constant',
        args: ['playerResponse.adPlacements', 'undefined'],
    },
    {
        name: 'set-constant',
        args: ['google_ad_status', '1'],
    },
    {
        name: 'json-prune',
        args: ['entries.[-].command.reelWatchEndpoint.adClientParams.isAd'],
    },
    {
        name: 'json-prune',
        args: ['playerResponse.adPlacements playerResponse.adSlots', 'playerResponse.streamingData.serverAbrStreamingUrl'],
    },
    {
        name: 'json-prune-xhr-response',
        args: [
            'playerResponse.adPlacements playerResponse.playerAds playerResponse.adSlots adPlacements playerAds adSlots',
            '',
            '/playlist\\?list=|\\/player(?!.*(get_drm_license))|watch\\?[tv]=|get_watch\\?/',
        ],
    },
    {
        name: 'json-prune-fetch-response',
        args: [
            'playerResponse.adPlacements playerResponse.playerAds playerResponse.adSlots adPlacements playerAds adSlots',
            '',
            '/playlist\\?list=|player\\?|watch\\?[tv]=|get_watch\\?/',
        ],
    },
    {
        name: 'adjust-setTimeout',
        args: ['[native code]', '17000', '0.001'],
    },
    {
        name: 'trusted-replace-outbound-text',
        args: ['JSON.stringify', '"clientScreen":"WATCH"', '"clientScreen":"ADUNIT"'],
    },
    {
        name: 'trusted-replace-outbound-text',
        args: [
            'JSON.stringify',
            'isWebNativeShareAvailable":true}}',
            'isWebNativeShareAvailable":true},"clientScreen":"ADUNIT"}',
        ],
    },
    {
        name: 'prevent-setTimeout',
        args: ['(),a,b)', '5000'],
    },
    {
        name: 'set-constant',
        args: ['ytcfg.data_.EXPERIMENT_FLAGS.web_streaming_watch', 'false'],
    },
];

;// ./src/constants/settings.ts
var settings_a;






var Settings = (settings_a = {},
    settings_a[SettingsKeys.Ads] = true,
    settings_a[SettingsKeys.InformAboutUpdates] = false,
    settings_a[SettingsKeys.NetworkRules] = networkRulesFallback,
    settings_a[SettingsKeys.CssRules] = cssRulesFallback,
    settings_a[SettingsKeys.PopupConfig] = DefaultPopupsConfig,
    settings_a[SettingsKeys.ScripletsRules] = scripletsFallback,
    settings_a[SettingsKeys.AdLeakNotices] = false,
    settings_a[SettingsKeys.AdLeakNoticeConfig] = DefaultAdLeakNoticeConfig,
    settings_a[SettingsKeys.RulesVersion] = null,
    settings_a);

;// ./src/background/helpers/dynamic-rules.ts
var dynamic_rules_awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var dynamic_rules_generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __read = (undefined && undefined.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var __spreadArray = (undefined && undefined.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};




var assignedRuleIds = 1;
var makeDynamicRules = function (rules, initiatorDomain) {
    return rules.map(function (rule) {
        var dynamicRule = {
            action: {
                type: chrome.declarativeNetRequest.RuleActionType.BLOCK,
            },
            condition: {
                initiatorDomains: [initiatorDomain],
            },
            id: assignedRuleIds++,
        };
        var separatorIndex = findDynamicRuleSeparatorIndex(rule);
        var ruleEnd = separatorIndex === -1 ? rule.length : separatorIndex;
        var ruleWithoutModifiers = rule.slice(0, ruleEnd);
        if (ruleWithoutModifiers.startsWith('/') && ruleWithoutModifiers.endsWith('/')) {
            dynamicRule.condition.regexFilter = ruleWithoutModifiers;
        }
        else {
            dynamicRule.condition.urlFilter = ruleWithoutModifiers;
        }
        if (separatorIndex !== -1) {
            var modifiers = rule.slice(separatorIndex + 1).split(',');
            dynamicRule.condition.resourceTypes = modifiers.map(function (modifier) { return resourceMap[modifier] || modifier; });
        }
        return dynamicRule;
    });
};
var deleteAllDynamicRules = function () { return dynamic_rules_awaiter(void 0, void 0, void 0, function () {
    var existingRules, removeRuleIds;
    return dynamic_rules_generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4, chrome.declarativeNetRequest.getDynamicRules()];
            case 1:
                existingRules = _a.sent();
                removeRuleIds = existingRules.map(function (r) { return r.id; });
                assignedRuleIds = 1;
                return [4, chrome.declarativeNetRequest.updateDynamicRules({
                        removeRuleIds: removeRuleIds,
                    })];
            case 2:
                _a.sent();
                return [2];
        }
    });
}); };
var removeCssFromPage = function (tabId) {
    var cssText = "".concat(Settings[SettingsKeys.CssRules].join(','), " { display:none!important; }");
    return chrome.scripting.removeCSS({
        css: cssText,
        origin: 'USER',
        target: { tabId: tabId },
    });
};
var addDynamicRulesFromRegexesArray = function () {
    var args_1 = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        args_1[_i] = arguments[_i];
    }
    return dynamic_rules_awaiter(void 0, __spreadArray([], __read(args_1), false), void 0, function (networkRuesArray, domain) {
        var addRules;
        if (networkRuesArray === void 0) { networkRuesArray = Settings[SettingsKeys.NetworkRules]; }
        if (domain === void 0) { domain = 'youtube.com'; }
        return dynamic_rules_generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    addRules = makeDynamicRules(networkRuesArray, domain);
                    return [4, chrome.declarativeNetRequest.updateDynamicRules({
                            addRules: addRules,
                        })];
                case 1:
                    _a.sent();
                    return [2];
            }
        });
    });
};
var updateDynamicRules = function () {
    return chrome.declarativeNetRequest.getDynamicRules().then(function (existingRules) {
        assignedRuleIds = 1;
        var addRules = Settings[SettingsKeys.Ads]
            ? makeDynamicRules(Settings[SettingsKeys.NetworkRules])
            : [];
        return chrome.declarativeNetRequest.updateDynamicRules({
            removeRuleIds: existingRules.map(function (rule) { return rule.id; }),
            addRules: addRules,
        });
    });
};

;// ./src/background/helpers/startup-handler.ts
var startup_handler_awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var startup_handler_generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var SESSION_IS_STARTUP_KEY = 'isStartup';
var isStartup = false;
var startupHandler = function () {
    chrome.runtime.onStartup.addListener(function () { return startup_handler_awaiter(void 0, void 0, void 0, function () {
        var e_1;
        var _a;
        return startup_handler_generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    isStartup = true;
                    _b.label = 1;
                case 1:
                    _b.trys.push([1, 3, , 4]);
                    return [4, chrome.storage.session.set((_a = {}, _a[SESSION_IS_STARTUP_KEY] = true, _a))];
                case 2:
                    _b.sent();
                    return [3, 4];
                case 3:
                    e_1 = _b.sent();
                    console.error('persist startup flag failed:', e_1);
                    return [3, 4];
                case 4: return [2];
            }
        });
    }); });
};
var clearStartupSessionFlag = function () { return startup_handler_awaiter(void 0, void 0, void 0, function () {
    var e_2;
    return startup_handler_generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                _a.trys.push([0, 2, , 3]);
                return [4, chrome.storage.session.remove(SESSION_IS_STARTUP_KEY)];
            case 1:
                _a.sent();
                return [3, 3];
            case 2:
                e_2 = _a.sent();
                console.error('clear startup flag failed:', e_2);
                return [3, 3];
            case 3: return [2];
        }
    });
}); };
var consumeStartupWake = function () { return startup_handler_awaiter(void 0, void 0, void 0, function () {
    var result, e_3;
    return startup_handler_generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (!isStartup) return [3, 2];
                isStartup = false;
                return [4, clearStartupSessionFlag()];
            case 1:
                _a.sent();
                return [2, true];
            case 2:
                _a.trys.push([2, 5, , 6]);
                return [4, chrome.storage.session.get(SESSION_IS_STARTUP_KEY)];
            case 3:
                result = _a.sent();
                if (!result[SESSION_IS_STARTUP_KEY]) {
                    return [2, false];
                }
                return [4, clearStartupSessionFlag()];
            case 4:
                _a.sent();
                return [2, true];
            case 5:
                e_3 = _a.sent();
                console.error('read startup flag failed:', e_3);
                return [2, false];
            case 6: return [2];
        }
    });
}); };

;// ./src/constants/extension-data.ts
var EXTENSION_VERSION = chrome.runtime.getManifest().version;
var EXTENSION_ID = chrome.runtime.id;
var CHROME_STORE_LINK = "https://chromewebstore.google.com/detail/".concat(EXTENSION_ID);

;// ./src/constants/urls.ts

var INSTALL_URL = "".concat("https://get.adblock-for-youtube.com", "/install?v=").concat(EXTENSION_VERSION, "&xtid=").concat(EXTENSION_ID);
var UNINSTALL_URL = "".concat("https://get.adblock-for-youtube.com", "/uninstall?v=").concat(EXTENSION_VERSION, "&xtid=").concat(EXTENSION_ID);
var UPDATE_URL = "".concat("https://get.adblock-for-youtube.com", "/update?v=").concat(EXTENSION_VERSION, "&xtid=").concat(EXTENSION_ID);

;// ./src/helpers/storage.ts
var storage_awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var storage_generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};

var setToChromeStorage = function (key, value) {
    return new Promise(function (resolve, reject) {
        var _a;
        chrome.storage.local.set((_a = {}, _a[key] = value, _a), function () {
            if (chrome.runtime.lastError) {
                reject(chrome.runtime.lastError);
            }
            resolve();
        });
    });
};
var getFromChromeStorage = function (key) {
    return new Promise(function (resolve, reject) {
        chrome.storage.local.get([key], function (result) {
            if (chrome.runtime.lastError) {
                reject(chrome.runtime.lastError);
            }
            resolve(result[key]);
        });
    });
};
var setMultipleToChromeStorage = function (data) {
    return new Promise(function (resolve, reject) {
        chrome.storage.local.set(data, function () {
            if (chrome.runtime.lastError) {
                reject(chrome.runtime.lastError);
            }
            resolve();
        });
    });
};
var getMultipleFromChromeStorage = function (keys) {
    return new Promise(function (resolve, reject) {
        chrome.storage.local.get(keys, function (result) {
            if (chrome.runtime.lastError) {
                reject(chrome.runtime.lastError);
            }
            resolve(result);
        });
    });
};
var removeFromChromeStorage = function (key) {
    return new Promise(function (resolve, reject) {
        chrome.storage.local.remove(key, function () {
            if (chrome.runtime.lastError) {
                reject(chrome.runtime.lastError);
            }
            resolve();
        });
    });
};
var setToStorageAndSettings = function (fieldName, value) { return storage_awaiter(void 0, void 0, void 0, function () {
    return storage_generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4, setToChromeStorage(fieldName, value)];
            case 1:
                _a.sent();
                Settings[fieldName] = value;
                return [2];
        }
    });
}); };
var setMultiplyToStorageAndSettings = function (settings) { return storage_awaiter(void 0, void 0, void 0, function () {
    return storage_generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4, setMultipleToChromeStorage(settings)];
            case 1:
                _a.sent();
                Object.assign(Settings, settings);
                return [2];
        }
    });
}); };

;// ./src/helpers/tabs.ts
var tabs_awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var tabs_generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var tabs_read = (undefined && undefined.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var getActiveTab = function () {
    return new Promise(function (resolve, reject) {
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            var error = chrome.runtime.lastError;
            if (error) {
                reject(error);
            }
            var _a = tabs_read(tabs, 1), tab = _a[0];
            resolve(tab);
        });
    });
};
var getAllTabs = function () {
    return new Promise(function (resolve, reject) {
        chrome.tabs.query({}, function (tabs) {
            var error = chrome.runtime.lastError;
            if (error) {
                reject(error);
            }
            resolve(tabs);
        });
    });
};
var createTab = function (url) {
    return new Promise(function (resolve, reject) {
        chrome.tabs.create({ url: url }, function (tab) {
            var error = chrome.runtime.lastError;
            if (error) {
                reject(error);
            }
            resolve(tab);
        });
    });
};
var safeTabReload = function (tabId) { return tabs_awaiter(void 0, void 0, void 0, function () {
    var e_1;
    return tabs_generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                _a.trys.push([0, 2, , 3]);
                return [4, chrome.tabs.reload(tabId)];
            case 1:
                _a.sent();
                return [3, 3];
            case 2:
                e_1 = _a.sent();
                console.log(e_1);
                return [3, 3];
            case 3: return [2];
        }
    });
}); };

;// ./src/background/helpers/install-handler.ts
var install_handler_awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var install_handler_generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};





var installHandler = function () {
    chrome.runtime.onInstalled.addListener(function (_a) { return install_handler_awaiter(void 0, [_a], void 0, function (_b) {
        var _c;
        var reason = _b.reason;
        return install_handler_generator(this, function (_d) {
            switch (_d.label) {
                case 0:
                    if (!(reason === chrome.runtime.OnInstalledReason.INSTALL)) return [3, 3];
                    return [4, setMultipleToChromeStorage((_c = {},
                            _c[SettingsKeys.Ads] = true,
                            _c[SettingsKeys.InformAboutUpdates] = false,
                            _c[SettingsKeys.AdLeakNotices] = false,
                            _c))];
                case 1:
                    _d.sent();
                    _d.label = 3;
                case 3: return [2];
            }
        });
    }); });
};
var uninstallHandler = function () {
    return;
};
var handleExtensionLifecycleEvents = function () { return install_handler_awaiter(void 0, void 0, void 0, function () {
    return install_handler_generator(this, function (_a) {
        installHandler();
        uninstallHandler();
        startupHandler();
        return [2];
    });
}); };

;// ./src/constants/time.ts
var HOUR_IN_MS = 1000 * 60 * 60;
var MIN_USER_LIVE_FOR_POPUP = (/* unused pure expression or super */ null && (1000 * 60 * 60 * 24 * 3));
var GENERAL_POPUPS_RESTRICTION_TIME = (/* unused pure expression or super */ null && (1000 * 60 * 60 * 24));
var ANTI_ADBLOCK_POPUP_RESTRICTION_TIME = (/* unused pure expression or super */ null && (1000 * 60 * 60 * 24));

;// ./src/helpers/dev-log.ts
var dev_log_read = (undefined && undefined.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var dev_log_spreadArray = (undefined && undefined.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var devLog = function () {
    var args = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
    }
    if (false) {}
};

;// ./src/types/ad-leak-event.type.ts
var AdLeakEventName;
(function (AdLeakEventName) {
    AdLeakEventName["Detected"] = "adLeakDetected";
    AdLeakEventName["NoticeShown"] = "adLeakNoticeShown";
    AdLeakEventName["NoticeDismiss"] = "adLeakNoticeDismiss";
    AdLeakEventName["NoticeOptout"] = "adLeakNoticeOptout";
    AdLeakEventName["NoticeReportClick"] = "adLeakNoticeReportClick";
})(AdLeakEventName || (AdLeakEventName = {}));

;// ./src/types/storage.type.ts


;// ./src/types/popup-config.type.ts


;// ./src/types/message.type.ts


;// ./src/types/response.type.ts


;// ./src/types/index.ts










;// ./src/background/helpers/ad-leak-events.ts
var ad_leak_events_assign = (undefined && undefined.__assign) || function () {
    ad_leak_events_assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return ad_leak_events_assign.apply(this, arguments);
};
var ad_leak_events_awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var ad_leak_events_generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};






var EVENTS_URL = "".concat("https://api.adblock-for-youtube.com", "/api/v2/tr/al");
var DETECTED_QUIET_MS = 24 * HOUR_IN_MS;
var SEND_ATTEMPTS = 3;
var SEND_RETRY_DELAY_MS = 1500;
var wait = function (ms) { return new Promise(function (resolve) { return setTimeout(resolve, ms); }); };
var chain = Promise.resolve();
var serialize = function (task) {
    var run = chain.then(task, task);
    chain = run.catch(function () { return undefined; });
    return run;
};
var post = function (payload) { return ad_leak_events_awaiter(void 0, void 0, void 0, function () {
    var attempt, response, _a;
    return ad_leak_events_generator(this, function (_b) {
        switch (_b.label) {
            case 0:
                attempt = 1;
                _b.label = 1;
            case 1:
                if (!(attempt <= SEND_ATTEMPTS)) return [3, 8];
                _b.label = 2;
            case 2:
                _b.trys.push([2, 4, , 5]);
                return [4, fetch(EVENTS_URL, {
                        method: 'POST',
                        headers: { 'content-type': 'application/json' },
                        body: JSON.stringify({ items: [payload] }),
                    })];
            case 3:
                response = _b.sent();
                if (response.ok) {
                    return [2, true];
                }
                if (response.status >= 400 && response.status < 500) {
                    devLog('[ad-leak] event rejected', response.status);
                    return [2, false];
                }
                return [3, 5];
            case 4:
                _a = _b.sent();
                return [3, 5];
            case 5:
                if (!(attempt < SEND_ATTEMPTS)) return [3, 7];
                return [4, wait(SEND_RETRY_DELAY_MS)];
            case 6:
                _b.sent();
                _b.label = 7;
            case 7:
                attempt += 1;
                return [3, 1];
            case 8:
                devLog('[ad-leak] event dropped after retries');
                return [2, false];
        }
    });
}); };
var buildPayload = function (input) { return ad_leak_events_awaiter(void 0, void 0, void 0, function () {
    var shown, rulesVersion, payload;
    return ad_leak_events_generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4, getFromChromeStorage(ExtensionsKeys.AdLeakShownCount).catch(function () { return undefined; })];
            case 1:
                shown = _a.sent();
                rulesVersion = Settings[SettingsKeys.RulesVersion];
                payload = ad_leak_events_assign(ad_leak_events_assign({}, input), { exposureCount: typeof shown === 'number' && Number.isInteger(shown) && shown >= 0 ? shown : 0 });
                if (Number.isInteger(rulesVersion)) {
                    payload.rulesVersion = rulesVersion;
                }
                return [2, payload];
        }
    });
}); };
var claimDetectedSlot = function () {
    return serialize(function () { return ad_leak_events_awaiter(void 0, void 0, void 0, function () {
        var sentAt;
        return ad_leak_events_generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4, getFromChromeStorage(ExtensionsKeys.AdLeakDetectedSentAt).catch(function () { return undefined; })];
                case 1:
                    sentAt = _a.sent();
                    if (Number.isFinite(sentAt) && Date.now() - sentAt < DETECTED_QUIET_MS) {
                        return [2, false];
                    }
                    return [4, setToChromeStorage(ExtensionsKeys.AdLeakDetectedSentAt, Date.now()).catch(function () { return undefined; })];
                case 2:
                    _a.sent();
                    return [2, true];
            }
        });
    }); });
};
var sendAdLeakEvent = function (input) { return ad_leak_events_awaiter(void 0, void 0, void 0, function () {
    var _a, payload;
    return ad_leak_events_generator(this, function (_b) {
        switch (_b.label) {
            case 0:
                _a = input.event === AdLeakEventName.Detected;
                if (!_a) return [3, 2];
                return [4, claimDetectedSlot()];
            case 1:
                _a = !(_b.sent());
                _b.label = 2;
            case 2:
                if (_a) {
                    return [2];
                }
                return [4, buildPayload(input)];
            case 3:
                payload = _b.sent();
                devLog('[ad-leak] event', payload);
                return [4, post(payload)];
            case 4:
                _b.sent();
                return [2];
        }
    });
}); };

;// ./src/background/helpers/adblock360-presence.ts
var adblock360_presence_awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var adblock360_presence_generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var PROBE_TIMEOUT_MS = 1000;
var isAdBlock360Running = function () { return adblock360_presence_awaiter(void 0, void 0, void 0, function () {
    var controller, deadline, response, _a;
    return adblock360_presence_generator(this, function (_b) {
        switch (_b.label) {
            case 0:
                controller = new AbortController();
                deadline = setTimeout(function () { return controller.abort(); }, PROBE_TIMEOUT_MS);
                _b.label = 1;
            case 1:
                _b.trys.push([1, 3, 4, 5]);
                return [4, fetch("https://filtering.adblock360.com/healthcheck", {
                        method: 'POST',
                        signal: controller.signal,
                        cache: 'no-store',
                    })];
            case 2:
                response = _b.sent();
                return [2, response.ok];
            case 3:
                _a = _b.sent();
                return [2, false];
            case 4:
                clearTimeout(deadline);
                return [7];
            case 5: return [2];
        }
    });
}); };

;// ./src/background/helpers/ad-leak-gate.ts
var ad_leak_gate_awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var ad_leak_gate_generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};






var STATE_URL = "".concat("https://api.adblock-for-youtube.com", "/api/v2/ad-leak-state");
var STATE_CACHE_MS = 60 * 1000;
var STATE_FALLBACK_MAX_AGE_MS = 24 * HOUR_IN_MS;
var DENIED = { allowed: false };
var parseState = function (payload) {
    var state = payload;
    if (typeof (state === null || state === void 0 ? void 0 : state.enabled) !== 'boolean' || !Number.isFinite(state === null || state === void 0 ? void 0 : state.rolloutPercent)) {
        return null;
    }
    return { enabled: state.enabled, rolloutPercent: Math.min(100, Math.max(0, Number(state.rolloutPercent))) };
};
var isTimestamp = function (value) { return typeof value === 'number' && Number.isFinite(value); };
var getRolloutBucket = function () { return ad_leak_gate_awaiter(void 0, void 0, void 0, function () {
    var existing, bucket;
    return ad_leak_gate_generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4, getFromChromeStorage(ExtensionsKeys.AdLeakBucket)];
            case 1:
                existing = _a.sent();
                if (typeof existing === 'number') {
                    return [2, existing];
                }
                bucket = Math.floor(Math.random() * 100);
                return [4, setToChromeStorage(ExtensionsKeys.AdLeakBucket, bucket)];
            case 2:
                _a.sent();
                return [2, bucket];
        }
    });
}); };
var getLiveState = function () { return ad_leak_gate_awaiter(void 0, void 0, void 0, function () {
    var cached, age, response, state, _a, error_1;
    return ad_leak_gate_generator(this, function (_b) {
        switch (_b.label) {
            case 0: return [4, getFromChromeStorage(ExtensionsKeys.AdLeakStateCache)];
            case 1:
                cached = _b.sent();
                age = cached ? Date.now() - cached.at : Infinity;
                if (cached && age < STATE_CACHE_MS) {
                    return [2, cached.state];
                }
                _b.label = 2;
            case 2:
                _b.trys.push([2, 6, , 7]);
                return [4, fetch(STATE_URL, { cache: 'no-store' })];
            case 3:
                response = _b.sent();
                if (!response.ok) {
                    throw new Error("state endpoint answered ".concat(response.status));
                }
                _a = parseState;
                return [4, response.json()];
            case 4:
                state = _a.apply(void 0, [_b.sent()]);
                if (!state) {
                    throw new Error('state endpoint answered with an unusable payload');
                }
                return [4, setToChromeStorage(ExtensionsKeys.AdLeakStateCache, { state: state, at: Date.now() })];
            case 5:
                _b.sent();
                return [2, state];
            case 6:
                error_1 = _b.sent();
                devLog('[ad-leak] state fetch failed', error_1);
                return [2, cached && age < STATE_FALLBACK_MAX_AGE_MS ? cached.state : null];
            case 7: return [2];
        }
    });
}); };
var canShowAdLeakNotice = function () { return ad_leak_gate_awaiter(void 0, void 0, void 0, function () {
    var config, now, stored, dismissedAt, lastShownAt, state, bucket;
    return ad_leak_gate_generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (!Settings[SettingsKeys.Ads] || !Settings[SettingsKeys.AdLeakNotices]) {
                    return [2, DENIED];
                }
                config = Settings[SettingsKeys.AdLeakNoticeConfig];
                if (!config.ctaUrl) {
                    return [2, DENIED];
                }
                now = Date.now();
                return [4, getMultipleFromChromeStorage([
                        ExtensionsKeys.AdLeakDismissedAt,
                        ExtensionsKeys.AdLeakLastShownAt,
                    ])];
            case 1:
                stored = _a.sent();
                dismissedAt = stored[ExtensionsKeys.AdLeakDismissedAt];
                if (isTimestamp(dismissedAt) && now - dismissedAt < config.frequency.dismissDays * 24 * HOUR_IN_MS) {
                    return [2, DENIED];
                }
                lastShownAt = stored[ExtensionsKeys.AdLeakLastShownAt];
                if (isTimestamp(lastShownAt) && now - lastShownAt < config.frequency.episodeQuietHours * HOUR_IN_MS) {
                    return [2, DENIED];
                }
                return [4, getLiveState()];
            case 2:
                state = _a.sent();
                if (!(state === null || state === void 0 ? void 0 : state.enabled)) {
                    return [2, DENIED];
                }
                return [4, getRolloutBucket()];
            case 3:
                bucket = _a.sent();
                if (bucket >= state.rolloutPercent) {
                    return [2, DENIED];
                }
                return [4, isAdBlock360Running()];
            case 4:
                if (_a.sent()) {
                    return [2, DENIED];
                }
                return [2, { allowed: true, texts: config.texts, ctaUrl: config.ctaUrl }];
        }
    });
}); };
var rememberAdLeakNoticeShown = function () { return ad_leak_gate_awaiter(void 0, void 0, void 0, function () {
    var shown;
    var _a;
    return ad_leak_gate_generator(this, function (_b) {
        switch (_b.label) {
            case 0: return [4, getFromChromeStorage(ExtensionsKeys.AdLeakShownCount)];
            case 1:
                shown = _b.sent();
                return [4, setMultipleToChromeStorage((_a = {},
                        _a[ExtensionsKeys.AdLeakLastShownAt] = Date.now(),
                        _a[ExtensionsKeys.AdLeakShownCount] = (typeof shown === 'number' ? shown : 0) + 1,
                        _a))];
            case 2:
                _b.sent();
                return [2];
        }
    });
}); };
var rememberAdLeakNoticeDismissed = function () { return ad_leak_gate_awaiter(void 0, void 0, void 0, function () {
    return ad_leak_gate_generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4, setToChromeStorage(ExtensionsKeys.AdLeakDismissedAt, Date.now())];
            case 1:
                _a.sent();
                return [2];
        }
    });
}); };

;// ./src/background/helpers/listen-messages.ts
var listen_messages_awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var listen_messages_generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};






var handlePageReady = function (sender) {
    var _a;
    var _b;
    if (!((_b = sender.tab) === null || _b === void 0 ? void 0 : _b.id)) {
        return;
    }
    return _a = {},
        _a[SettingsKeys.Ads] = Settings[SettingsKeys.Ads],
        _a[SettingsKeys.PopupConfig] = Settings[SettingsKeys.PopupConfig],
        _a.adLeakDetector = Settings[SettingsKeys.AdLeakNoticeConfig].detector,
        _a;
};
var isWatchPageSender = function (sender) {
    var _a, _b, _c;
    try {
        var url = new URL((_c = (_b = (_a = sender.tab) === null || _a === void 0 ? void 0 : _a.url) !== null && _b !== void 0 ? _b : sender.url) !== null && _c !== void 0 ? _c : '');
        return /(^|\.)youtube\.com$/.test(url.hostname) && url.pathname === '/watch';
    }
    catch (_d) {
        return false;
    }
};
var handleGetSettings = function () {
    var _a;
    return (_a = {},
        _a[SettingsKeys.Ads] = Settings[SettingsKeys.Ads],
        _a[SettingsKeys.InformAboutUpdates] = Settings[SettingsKeys.InformAboutUpdates],
        _a[SettingsKeys.AdLeakNotices] = Settings[SettingsKeys.AdLeakNotices],
        _a);
};
var handleSetSetting = function (payload) { return listen_messages_awaiter(void 0, void 0, void 0, function () {
    var isOptOut;
    return listen_messages_generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                isOptOut = payload.key === SettingsKeys.AdLeakNotices && payload.value === false && Settings[payload.key] !== false;
                return [4, setToStorageAndSettings(payload.key, payload.value)];
            case 1:
                _a.sent();
                if (!isOptOut) return [3, 3];
                return [4, sendAdLeakEvent({ event: AdLeakEventName.NoticeOptout })];
            case 2:
                _a.sent();
                _a.label = 3;
            case 3: return [2, { ok: true }];
        }
    });
}); };
var handleAdLeakEvent = function (input) { return listen_messages_awaiter(void 0, void 0, void 0, function () {
    return listen_messages_generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (!(input.event === AdLeakEventName.NoticeShown)) return [3, 2];
                return [4, rememberAdLeakNoticeShown()];
            case 1:
                _a.sent();
                _a.label = 2;
            case 2:
                if (!(input.event === AdLeakEventName.NoticeDismiss)) return [3, 4];
                return [4, rememberAdLeakNoticeDismissed()];
            case 3:
                _a.sent();
                _a.label = 4;
            case 4: return [4, sendAdLeakEvent(input)];
            case 5:
                _a.sent();
                return [2];
        }
    });
}); };
var handleMessage = function (message, sender) { return listen_messages_awaiter(void 0, void 0, void 0, function () {
    var _a;
    return listen_messages_generator(this, function (_b) {
        switch (_b.label) {
            case 0:
                _a = message.type;
                switch (_a) {
                    case ActionsEnum.PageReady: return [3, 1];
                    case ActionsEnum.Ping: return [3, 2];
                    case ActionsEnum.GetSettings: return [3, 4];
                    case ActionsEnum.SetSetting: return [3, 5];
                    case ActionsEnum.CanShowAdLeakNotice: return [3, 6];
                    case ActionsEnum.AdLeakEvent: return [3, 7];
                }
                return [3, 8];
            case 1: return [2, handlePageReady(sender)];
            case 2: return [4, chrome.runtime.getPlatformInfo()];
            case 3:
                _b.sent();
                return [2];
            case 4: return [2, handleGetSettings()];
            case 5: return [2, handleSetSetting(message.payload)];
            case 6: return [2, isWatchPageSender(sender) ? canShowAdLeakNotice() : { allowed: false }];
            case 7: return [2, handleAdLeakEvent(message.payload)];
            case 8:
                {
                    console.warn('[listen-messages] unknown message type:', message);
                    return [2];
                }
                _b.label = 9;
            case 9: return [2];
        }
    });
}); };
var onMessageCallback = function (message, sender, sendResponse) {
    handleMessage(message, sender)
        .then(sendResponse)
        .catch(function (error) {
        console.error('[listen-messages] handler failed:', error);
        var response = {
            error: { message: error instanceof Error ? error.message : String(error) },
        };
        sendResponse(response);
    });
    return true;
};
var listenMessages = function () {
    chrome.runtime.onMessage.addListener(onMessageCallback);
};

;// ./src/background/helpers/update-action-icon.ts
var update_action_icon_awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var update_action_icon_generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};


var updateActionIcon = function () { return Promise.resolve(); };

;// ./src/background/helpers/listen-store-changed.ts
var listen_store_changed_awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var listen_store_changed_generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __values = (undefined && undefined.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
var listen_store_changed_read = (undefined && undefined.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};





var storesChangesCallBack = function (changes) { return listen_store_changed_awaiter(void 0, void 0, void 0, function () {
    var _a, _b, _c, key, newValue, activeTab, url, id, e_1_1;
    var e_1, _d;
    return listen_store_changed_generator(this, function (_e) {
        switch (_e.label) {
            case 0:
                _e.label = 1;
            case 1:
                _e.trys.push([1, 9, 10, 11]);
                _a = __values(Object.entries(changes)), _b = _a.next();
                _e.label = 2;
            case 2:
                if (!!_b.done) return [3, 8];
                _c = listen_store_changed_read(_b.value, 2), key = _c[0], newValue = _c[1].newValue;
                if (!(key === SettingsKeys.Ads)) return [3, 7];
                Settings[key] = newValue;
                return [4, updateDynamicRules()];
            case 3:
                _e.sent();
                return [4, updateActionIcon()];
            case 4:
                _e.sent();
                return [4, getActiveTab()];
            case 5:
                activeTab = _e.sent();
                if (!activeTab) return [3, 7];
                url = activeTab.url, id = activeTab.id;
                if (!(url && id && /^https?:\/\/(\w*.)?youtube.com/i.test(url))) return [3, 7];
                return [4, newValue ? cosmeticInject(id) : removeCssFromPage(id)];
            case 6:
                _e.sent();
                _e.label = 7;
            case 7:
                _b = _a.next();
                return [3, 2];
            case 8: return [3, 11];
            case 9:
                e_1_1 = _e.sent();
                e_1 = { error: e_1_1 };
                return [3, 11];
            case 10:
                try {
                    if (_b && !_b.done && (_d = _a.return)) _d.call(_a);
                }
                finally { if (e_1) throw e_1.error; }
                return [7];
            case 11: return [2];
        }
    });
}); };
var listenStoreChanged = function () {
    chrome.storage.onChanged.addListener(storesChangesCallBack);
};

;// ./src/background/helpers/main-scheduler.ts
var main_scheduler_awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var main_scheduler_generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};

var scheduleHandler = function () {
    chrome.alarms.onAlarm.addListener(function (alarmInfo) { return main_scheduler_awaiter(void 0, void 0, void 0, function () {
        return main_scheduler_generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (!(alarmInfo.name === ActionsEnum.Ping)) return [3, 2];
                    return [4, chrome.runtime.getPlatformInfo()];
                case 1:
                    _a.sent();
                    _a.label = 2;
                case 2: return [2];
            }
        });
    }); });
};
var mainScheduler = function () { return main_scheduler_awaiter(void 0, void 0, void 0, function () {
    return main_scheduler_generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                setInterval(function () { return main_scheduler_awaiter(void 0, void 0, void 0, function () {
                    return main_scheduler_generator(this, function (_a) {
                        switch (_a.label) {
                            case 0: return [4, chrome.runtime.getPlatformInfo()];
                            case 1:
                                _a.sent();
                                return [2];
                        }
                    });
                }); }, 25000);
                return [4, chrome.alarms.create(ActionsEnum.Ping, {
                        periodInMinutes: 1,
                    })];
            case 1:
                _a.sent();
                scheduleHandler();
                return [2];
        }
    });
}); };

;// ./src/constants/default-data/storage.ts
var STORAGE_VERSION = 6;

;// ./src/background/helpers/runtime-info.ts
var runtime_info_awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var runtime_info_generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};




var runtimeInfo;
var collectAndSaveRuntimeInfo = function () { return runtime_info_awaiter(void 0, void 0, void 0, function () {
    var currentExtensionVersion, currentStorageVersion, _a, storedStorageVersion, storedExtensionVersion, isStoreInitialized, isExtensionVersionChanged, isExtensionInstalled, isExtensionUpdated;
    return runtime_info_generator(this, function (_b) {
        switch (_b.label) {
            case 0:
                currentExtensionVersion = EXTENSION_VERSION;
                currentStorageVersion = STORAGE_VERSION;
                return [4, getMultipleFromChromeStorage([
                        ExtensionsKeys.StorageVersion,
                        ExtensionsKeys.ExtensionVersion,
                        ExtensionsKeys.InstalledAt,
                    ])];
            case 1:
                _a = _b.sent(), storedStorageVersion = _a.storageVersion, storedExtensionVersion = _a.extensionVersion, isStoreInitialized = _a.installedAt;
                isExtensionVersionChanged = storedExtensionVersion !== currentExtensionVersion;
                isExtensionInstalled = isExtensionVersionChanged && !storedExtensionVersion;
                isExtensionUpdated = isExtensionVersionChanged && !!storedExtensionVersion;
                runtimeInfo = {
                    appVersion: currentExtensionVersion,
                    isAppVersionChanged: isExtensionUpdated,
                    schemaVersion: currentStorageVersion,
                    savedStorageVersion: typeof storedStorageVersion === 'number' ? storedStorageVersion : 0,
                    savedAppVersion: storedExtensionVersion,
                    isAppDownloaded: isExtensionInstalled,
                    isInstalledKeyPresent: !!isStoreInitialized,
                };
                return [2, runtimeInfo];
        }
    });
}); };
var runtimeInfoLifeCycle = function () { return runtime_info_awaiter(void 0, void 0, void 0, function () {
    var runtimeInfo;
    var _a, _b;
    return runtime_info_generator(this, function (_c) {
        switch (_c.label) {
            case 0: return [4, collectAndSaveRuntimeInfo()];
            case 1:
                runtimeInfo = _c.sent();
                if (!runtimeInfo.isAppDownloaded) return [3, 3];
                return [4, setMultipleToChromeStorage((_a = {},
                        _a[ExtensionsKeys.StorageVersion] = runtimeInfo.schemaVersion,
                        _a[ExtensionsKeys.ExtensionVersion] = runtimeInfo.appVersion,
                        _a))];
            case 2:
                _c.sent();
                _c.label = 3;
            case 3:
                if (!!runtimeInfo.isInstalledKeyPresent) return [3, 5];
                return [4, setToChromeStorage(ExtensionsKeys.InstalledAt, Date.now())];
            case 4:
                _c.sent();
                _c.label = 5;
            case 5:
                if (!runtimeInfo.isAppVersionChanged) return [3, 8];
                return [4, setMultipleToChromeStorage((_b = {},
                        _b[ExtensionsKeys.ExtensionVersion] = runtimeInfo.appVersion,
                        _b[ExtensionsKeys.StorageVersion] = runtimeInfo.schemaVersion,
                        _b[ExtensionsKeys.ShouldCheckUpdatePageConfig] = true,
                        _b[ExtensionsKeys.UpdatePagePending] = false,
                        _b))];
            case 6:
                _c.sent();
                return [4, removeFromChromeStorage(ExtensionsKeys.LastRulesFetchAt)];
            case 7:
                _c.sent();
                _c.label = 8;
            case 8: return [2];
        }
    });
}); };
var getRuntimeInfo = function () { return runtimeInfo; };

;// ./src/background/helpers/migration.ts
var migration_awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var migration_generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};



var migrateSettingsFromV0toV1 = function () { return migration_awaiter(void 0, void 0, void 0, function () {
    var ratingDialogShown;
    return migration_generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4, removeFromChromeStorage([
                    SettingsKeys.OldDailymotionAdRegex,
                    SettingsKeys.OldAdditionalBlockingEnabled,
                    SettingsKeys.OldDailymotionAdBlockingSelectors,
                    PopupDontShowKeysEnum.OldOtherStreamingPopupDoNotShow,
                    PopupDontShowKeysEnum.OldUpdatePopupDoNotShow,
                    PopupRestrictionKeysEnum.OldOtherStreamingPopupRestriction,
                    PopupRestrictionKeysEnum.OldUpdatePopupRestriction,
                ])];
            case 1:
                _a.sent();
                return [4, getFromChromeStorage(PopupRestrictionKeysEnum.RatingPopupRestriction)];
            case 2:
                ratingDialogShown = _a.sent();
                if (!ratingDialogShown) return [3, 4];
                return [4, setToChromeStorage(PopupRestrictionKeysEnum.RatingPopupRestriction, Date.now())];
            case 3:
                _a.sent();
                _a.label = 4;
            case 4: return [2];
        }
    });
}); };
var migrateSettingsFromV1toV2 = function () { return migration_awaiter(void 0, void 0, void 0, function () {
    return migration_generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4, removeFromChromeStorage([
                    SettingsKeys.OldYoutubeAdRegex,
                    SettingsKeys.OldAdBlockingSelectors,
                    SettingsKeys.OldScriptlets,
                ])];
            case 1:
                _a.sent();
                return [2];
        }
    });
}); };
var migrateSettingsFromV2toV3 = function () { return migration_awaiter(void 0, void 0, void 0, function () {
    return migration_generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4, setToStorageAndSettings(SettingsKeys.InformAboutUpdates, true)];
            case 1:
                _a.sent();
                return [2];
        }
    });
}); };
var migrateSettingsFromV3toV4 = function () { return migration_awaiter(void 0, void 0, void 0, function () {
    return migration_generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4, removeFromChromeStorage(SettingsKeys.OldShowUpdatePageNextLaunch)];
            case 1:
                _a.sent();
                return [2];
        }
    });
}); };
var migrateSettingsFromV4toV5 = function () { return migration_awaiter(void 0, void 0, void 0, function () {
    return migration_generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4, removeFromChromeStorage(SettingsKeys.OldAnnotations)];
            case 1:
                _a.sent();
                return [2];
        }
    });
}); };
var migrateSettingsFromV5toV6 = function () { return migration_awaiter(void 0, void 0, void 0, function () {
    return migration_generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4, setToStorageAndSettings(SettingsKeys.AdLeakNotices, true)];
            case 1:
                _a.sent();
                return [2];
        }
    });
}); };
var migrationsMap = {
    '0': migrateSettingsFromV0toV1,
    '1': migrateSettingsFromV1toV2,
    '2': migrateSettingsFromV2toV3,
    '3': migrateSettingsFromV3toV4,
    '4': migrateSettingsFromV4toV5,
    '5': migrateSettingsFromV5toV6,
};
var runMigration = function (storedStorageVersion, currentStorageVersion) { return migration_awaiter(void 0, void 0, void 0, function () {
    var storageVersion, schemaMigrationAction, err_1;
    return migration_generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                storageVersion = storedStorageVersion;
                _a.label = 1;
            case 1:
                if (!(storageVersion < currentStorageVersion)) return [3, 6];
                schemaMigrationAction = migrationsMap[storageVersion];
                if (!schemaMigrationAction) {
                    throw new Error("No migration: storage version - ".concat(storageVersion, ", current version - ").concat(currentStorageVersion, "."));
                }
                _a.label = 2;
            case 2:
                _a.trys.push([2, 4, , 5]);
                return [4, schemaMigrationAction()];
            case 3:
                _a.sent();
                return [3, 5];
            case 4:
                err_1 = _a.sent();
                throw new Error("Error start migration from ".concat(storageVersion, " to ").concat(currentStorageVersion, ". Error: ").concat(err_1));
            case 5:
                storageVersion += 1;
                return [3, 1];
            case 6: return [2];
        }
    });
}); };
var applyMigrations = function () { return migration_awaiter(void 0, void 0, void 0, function () {
    var _a, isInstalledKeyPresent, isAppVersionChanged, savedStorageVersion, schemaVersion;
    return migration_generator(this, function (_b) {
        switch (_b.label) {
            case 0:
                _a = getRuntimeInfo(), isInstalledKeyPresent = _a.isInstalledKeyPresent, isAppVersionChanged = _a.isAppVersionChanged, savedStorageVersion = _a.savedStorageVersion, schemaVersion = _a.schemaVersion;
                if (!(isInstalledKeyPresent && savedStorageVersion === 0)) return [3, 2];
                return [4, runMigration(savedStorageVersion, schemaVersion)];
            case 1:
                _b.sent();
                return [2];
            case 2:
                if (!isAppVersionChanged) return [3, 4];
                return [4, runMigration(savedStorageVersion, schemaVersion)];
            case 3:
                _b.sent();
                _b.label = 4;
            case 4: return [2];
        }
    });
}); };

;// ./src/helpers/is-ad-block-works-on-page.ts
var isAdBlockWorksOnPage = function (url) {
    try {
        var hostname = new URL(url).hostname;
        return hostname === 'youtube.com' || hostname.endsWith('.youtube.com');
    }
    catch (_a) {
        return false;
    }
};

;// ./src/constants/scriptlets/scriplets-lib.ts
var scriptletsLib = {
    version: '2.2.15',
    scriptlets: [
        {
            names: ['amazon-apstag', 'ubo-amazon_apstag.js', 'amazon_apstag.js'],
            scriptlet: 'function AmazonApstag(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function noopFunc(){}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source){var apstagWrapper={fetchBids(a,b){"function"==typeof b&&b([])},init:noopFunc,setDisplayBids:noopFunc,targetingKeys:noopFunc};window.apstag=apstagWrapper,function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source)}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['didomi-loader'],
            scriptlet: 'function DidomiLoader(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function noopFunc(){}function noopArray(){return[]}function trueFunc(){return!0}function falseFunc(){return!1}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source){function UserConsentStatusForVendorSubscribe(){}function UserConsentStatusForVendor(){}UserConsentStatusForVendorSubscribe.prototype.filter=function(){return new UserConsentStatusForVendorSubscribe},UserConsentStatusForVendorSubscribe.prototype.subscribe=noopFunc,UserConsentStatusForVendor.prototype.first=function(){return new UserConsentStatusForVendorSubscribe},UserConsentStatusForVendor.prototype.filter=function(){return new UserConsentStatusForVendorSubscribe},UserConsentStatusForVendor.prototype.subscribe=noopFunc;var DidomiWrapper={isConsentRequired:falseFunc,getUserConsentStatusForPurpose:trueFunc,getUserConsentStatus:trueFunc,getUserStatus:noopFunc,getRequiredPurposes:noopArray,getUserConsentStatusForVendor:trueFunc,Purposes:{Cookies:"cookies"},notice:{configure:noopFunc,hide:noopFunc,isVisible:falseFunc,show:noopFunc,showDataProcessing:trueFunc},isUserConsentStatusPartial:falseFunc,on:()=>({actions:{},emitter:{},services:{},store:{}}),shouldConsentBeCollected:falseFunc,getUserConsentStatusForAll:noopFunc,getObservableOnUserConsentStatusForVendor:()=>new UserConsentStatusForVendor};window.Didomi=DidomiWrapper,window.didomiState={didomiExperimentId:"",didomiExperimentUserGroup:"",didomiGDPRApplies:1,didomiIABConsent:"",didomiPurposesConsent:"",didomiPurposesConsentDenied:"",didomiPurposesConsentUnknown:"",didomiVendorsConsent:"",didomiVendorsConsentDenied:"",didomiVendorsConsentUnknown:"",didomiVendorsRawConsent:"",didomiVendorsRawConsentDenied:"",didomiVendorsRawConsentUnknown:""};var tcData={eventStatus:"tcloaded",gdprApplies:!1,listenerId:noopFunc,vendor:{consents:[]},purpose:{consents:[]}};window.__tcfapi=function(command,version,callback){"function"==typeof callback&&"removeEventListener"!==command&&callback(tcData,!0)};var didomiEventListenersWrapper={stub:!0,push:noopFunc};window.didomiEventListeners=didomiEventListenersWrapper;var didomiOnReadyWrapper={stub:!0,push(arg){"function"==typeof arg&&("complete"!==document.readyState?window.addEventListener("load",(function(){setTimeout(arg(window.Didomi))})):setTimeout(arg(window.Didomi)))}};window.didomiOnReady=window.didomiOnReady||didomiOnReadyWrapper,Array.isArray(window.didomiOnReady)&&window.didomiOnReady.forEach((function(arg){if("function"==typeof arg)try{setTimeout(arg(window.Didomi))}catch(e){}})),function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source)}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['fingerprintjs2', 'ubo-fingerprint2.js', 'fingerprint2.js'],
            scriptlet: 'function Fingerprintjs2(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source){for(var browserId="",i=0;i<8;i+=1)browserId+=(65536*Math.random()+4096).toString(16).slice(-4);var Fingerprint2=function(){};Fingerprint2.prototype={get:Fingerprint2.get=function(options,callback){callback||(callback=options),setTimeout((function(){callback&&callback(browserId,[])}),1)}},window.Fingerprint2=Fingerprint2,window.Fingerprint=Fingerprint2,function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source)}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['fingerprintjs3', 'ubo-fingerprint3.js', 'fingerprint3.js'],
            scriptlet: 'function Fingerprintjs3(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function noopStr(){return""}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source){var visitorId=function(){for(var id="",i=0;i<8;i+=1)id+=(65536*Math.random()+4096).toString(16).slice(-4);return id}(),FingerprintJS=function(){};FingerprintJS.prototype={load:()=>Promise.resolve(new FingerprintJS),get:()=>Promise.resolve({visitorId:visitorId}),hashComponents:noopStr},window.FingerprintJS=new FingerprintJS,function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source)}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['gemius'],
            scriptlet: 'function Gemius(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function noopFunc(){}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source){var GemiusPlayer=function(){};GemiusPlayer.prototype={setVideoObject:noopFunc,newProgram:noopFunc,programEvent:noopFunc,newAd:noopFunc,adEvent:noopFunc},window.GemiusPlayer=GemiusPlayer,function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source)}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['google-analytics-ga', 'ubo-google-analytics_ga.js', 'google-analytics_ga.js'],
            scriptlet: 'function GoogleAnalyticsGa(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function noopFunc(){}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source){function Gaq(){}Gaq.prototype.Na=noopFunc,Gaq.prototype.O=noopFunc,Gaq.prototype.Sa=noopFunc,Gaq.prototype.Ta=noopFunc,Gaq.prototype.Va=noopFunc,Gaq.prototype._createAsyncTracker=noopFunc,Gaq.prototype._getAsyncTracker=noopFunc,Gaq.prototype._getPlugin=noopFunc,Gaq.prototype.push=function(data){"function"!=typeof data?!1!==Array.isArray(data)&&("string"==typeof data[0]&&/(^|\\.)_link$/.test(data[0])&&"string"==typeof data[1]&&window.location.assign(data[1]),"_set"===data[0]&&"hitCallback"===data[1]&&"function"==typeof data[2]&&data[2]()):data()};var gaq=new Gaq,asyncTrackers=window._gaq||[];if(Array.isArray(asyncTrackers))for(;asyncTrackers[0];)gaq.push(asyncTrackers.shift());function Gat(){}window._gaq=gaq.qf=gaq;var tracker=["_addIgnoredOrganic","_addIgnoredRef","_addItem","_addOrganic","_addTrans","_clearIgnoredOrganic","_clearIgnoredRef","_clearOrganic","_cookiePathCopy","_deleteCustomVar","_getName","_setAccount","_getAccount","_getClientInfo","_getDetectFlash","_getDetectTitle","_getLinkerUrl","_getLocalGifPath","_getServiceMode","_getVersion","_getVisitorCustomVar","_initData","_link","_linkByPost","_setAllowAnchor","_setAllowHash","_setAllowLinker","_setCampContentKey","_setCampMediumKey","_setCampNameKey","_setCampNOKey","_setCampSourceKey","_setCampTermKey","_setCampaignCookieTimeout","_setCampaignTrack","_setClientInfo","_setCookiePath","_setCookiePersistence","_setCookieTimeout","_setCustomVar","_setDetectFlash","_setDetectTitle","_setDomainName","_setLocalGifPath","_setLocalRemoteServerMode","_setLocalServerMode","_setReferrerOverride","_setRemoteServerMode","_setSampleRate","_setSessionTimeout","_setSiteSpeedSampleRate","_setSessionCookieTimeout","_setVar","_setVisitorCookieTimeout","_trackEvent","_trackPageLoadTime","_trackPageview","_trackSocial","_trackTiming","_trackTrans","_visitCode"].reduce((function(res,funcName){return res[funcName]=noopFunc,res}),{});tracker._getLinkerUrl=function(a){return a},tracker._link=function(url){if("string"==typeof url)try{window.location.assign(url)}catch(e){!function(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}(source,e)}},Gat.prototype._anonymizeIP=noopFunc,Gat.prototype._createTracker=noopFunc,Gat.prototype._forceSSL=noopFunc,Gat.prototype._getPlugin=noopFunc,Gat.prototype._getTracker=function(){return tracker},Gat.prototype._getTrackerByName=function(){return tracker},Gat.prototype._getTrackers=noopFunc,Gat.prototype.aa=noopFunc,Gat.prototype.ab=noopFunc,Gat.prototype.hb=noopFunc,Gat.prototype.la=noopFunc,Gat.prototype.oa=noopFunc,Gat.prototype.pa=noopFunc,Gat.prototype.u=noopFunc;var gat=new Gat;window._gat=gat,function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source)}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: [
                'google-analytics',
                'ubo-google-analytics_analytics.js',
                'google-analytics_analytics.js',
                'googletagmanager-gtm',
                'ubo-googletagmanager_gtm.js',
                'googletagmanager_gtm.js',
            ],
            scriptlet: 'function GoogleAnalytics(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function noopFunc(){}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source){var _window$googleAnalyti,Tracker=function(){},proto=Tracker.prototype;proto.get=noopFunc,proto.set=noopFunc,proto.send=noopFunc;var googleAnalyticsName=window.GoogleAnalyticsObject||"ga",queue=null===(_window$googleAnalyti=window[googleAnalyticsName])||void 0===_window$googleAnalyti?void 0:_window$googleAnalyti.q;function ga(a){var len=arguments.length;if(0!==len){var replacer,lastArg=arguments[len-1];lastArg instanceof Object&&null!==lastArg&&"function"==typeof lastArg.hitCallback?replacer=lastArg.hitCallback:"function"==typeof lastArg&&(replacer=function(){lastArg(ga.create())});try{setTimeout(replacer,1)}catch(ex){}}}if(ga.create=function(){return new Tracker},ga.getByName=function(){return new Tracker},ga.getAll=function(){return[new Tracker]},ga.remove=noopFunc,ga.loaded=!0,window[googleAnalyticsName]=ga,Array.isArray(queue)){var push=function(arg){ga(...arg)};queue.push=push,queue.forEach(push)}var{dataLayer:dataLayer,google_optimize:google_optimize}=window;if(dataLayer instanceof Object!=0){dataLayer.hide instanceof Object&&"function"==typeof dataLayer.hide.end&&dataLayer.hide.end();var handleCallback=function(dataObj,funcName){dataObj&&"function"==typeof dataObj[funcName]&&setTimeout(dataObj[funcName])};if("function"==typeof dataLayer.push&&(dataLayer.push=function(data){if(data instanceof Object){for(var key in handleCallback(data,"eventCallback"),data)handleCallback(data[key],"event_callback");data.hasOwnProperty("eventCallback")||data.hasOwnProperty("eventCallback")||[].push.call(window.dataLayer,data)}return Array.isArray(data)&&data.forEach((function(arg){handleCallback(arg,"callback")})),noopFunc}),google_optimize instanceof Object&&"function"==typeof google_optimize.get){var googleOptimizeWrapper={get:noopFunc};window.google_optimize=googleOptimizeWrapper}!function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source)}}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['google-ima3', 'ubo-google-ima.js', 'google-ima.js'],
            scriptlet: 'function GoogleIma3(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function noopFunc(){}function logMessage(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source){var _window$google$ima,ima={},AdDisplayContainer=function(containerElement){var divElement=document.createElement("div");divElement.style.setProperty("display","none","important"),divElement.style.setProperty("visibility","collapse","important"),containerElement&&containerElement.appendChild(divElement)};AdDisplayContainer.prototype.destroy=noopFunc,AdDisplayContainer.prototype.initialize=noopFunc;var ImaSdkSettings=function(){};ImaSdkSettings.CompanionBackfillMode={ALWAYS:"always",ON_MASTER_AD:"on_master_ad"},ImaSdkSettings.VpaidMode={DISABLED:0,ENABLED:1,INSECURE:2},ImaSdkSettings.prototype={c:!0,f:{},i:!1,l:"",p:"",r:0,t:"",v:"",getCompanionBackfill:noopFunc,getDisableCustomPlaybackForIOS10Plus(){return this.i},getDisabledFlashAds:function(){return!0},getFeatureFlags(){return this.f},getLocale(){return this.l},getNumRedirects(){return this.r},getPlayerType(){return this.t},getPlayerVersion(){return this.v},getPpid(){return this.p},getVpaidMode(){return this.C},isCookiesEnabled(){return this.c},isVpaidAdapter(){return this.M},setCompanionBackfill:noopFunc,setAutoPlayAdBreaks(a){this.K=a},setCookiesEnabled(c){this.c=!!c},setDisableCustomPlaybackForIOS10Plus(i){this.i=!!i},setDisableFlashAds:noopFunc,setFeatureFlags(f){this.f=!!f},setIsVpaidAdapter(a){this.M=a},setLocale(l){this.l=!!l},setNumRedirects(r){this.r=!!r},setPageCorrelator(a){this.R=a},setPlayerType(t){this.t=!!t},setPlayerVersion(v){this.v=!!v},setPpid(p){this.p=!!p},setVpaidMode(a){this.C=a},setSessionId:noopFunc,setStreamCorrelator:noopFunc,setVpaidAllowed:noopFunc,CompanionBackfillMode:{ALWAYS:"always",ON_MASTER_AD:"on_master_ad"},VpaidMode:{DISABLED:0,ENABLED:1,INSECURE:2}};var EventHandler=function(){this.listeners=new Map,this._dispatch=function(e){var listeners=this.listeners.get(e.type);listeners=listeners?listeners.values():[];for(var _i=0,_Array$from=Array.from(listeners);_i<_Array$from.length;_i++){var listener=_Array$from[_i];try{listener(e)}catch(r){logMessage(source,r)}}},this.addEventListener=function(types,callback,options,context){Array.isArray(types)||(types=[types]);for(var i=0;i<types.length;i+=1){var type=types[i];this.listeners.has(type)||this.listeners.set(type,new Map),this.listeners.get(type).set(callback,callback.bind(context||this))}},this.removeEventListener=function(types,callback){Array.isArray(types)||(types=[types]);for(var i=0;i<types.length;i+=1){var _this$listeners$get,type=types[i];null===(_this$listeners$get=this.listeners.get(type))||void 0===_this$listeners$get||_this$listeners$get.delete(callback)}}},AdsManager=new EventHandler;AdsManager.volume=1,AdsManager.collapse=noopFunc,AdsManager.configureAdsManager=noopFunc,AdsManager.destroy=noopFunc,AdsManager.discardAdBreak=noopFunc,AdsManager.expand=noopFunc,AdsManager.focus=noopFunc,AdsManager.getAdSkippableState=function(){return!1},AdsManager.getCuePoints=function(){return[0]},AdsManager.getCurrentAd=function(){return currentAd},AdsManager.getCurrentAdCuePoints=function(){return[]},AdsManager.getRemainingTime=function(){return 0},AdsManager.getVolume=function(){return this.volume},AdsManager.init=noopFunc,AdsManager.isCustomClickTrackingUsed=function(){return!1},AdsManager.isCustomPlaybackUsed=function(){return!1},AdsManager.pause=noopFunc,AdsManager.requestNextAdBreak=noopFunc,AdsManager.resize=noopFunc,AdsManager.resume=noopFunc,AdsManager.setVolume=function(v){this.volume=v},AdsManager.skip=noopFunc,AdsManager.start=function(){for(var _i2=0,_arr=[AdEvent.Type.ALL_ADS_COMPLETED,AdEvent.Type.CONTENT_RESUME_REQUESTED];_i2<_arr.length;_i2++){var type=_arr[_i2];try{this._dispatch(new ima.AdEvent(type))}catch(e){logMessage(source,e)}}},AdsManager.stop=noopFunc,AdsManager.updateAdsRenderingSettings=noopFunc;var manager=Object.create(AdsManager),AdsManagerLoadedEvent=function(type,adsRequest,userRequestContext){this.type=type,this.adsRequest=adsRequest,this.userRequestContext=userRequestContext};AdsManagerLoadedEvent.prototype={getAdsManager:function(){return manager},getUserRequestContext(){return this.userRequestContext?this.userRequestContext:{}}},AdsManagerLoadedEvent.Type={ADS_MANAGER_LOADED:"adsManagerLoaded"};var AdsLoader=EventHandler;AdsLoader.prototype.settings=new ImaSdkSettings,AdsLoader.prototype.contentComplete=noopFunc,AdsLoader.prototype.destroy=noopFunc,AdsLoader.prototype.getSettings=function(){return this.settings},AdsLoader.prototype.getVersion=function(){return"3.453.0"},AdsLoader.prototype.requestAds=function(adsRequest,userRequestContext){var _this=this;requestAnimationFrame((function(){var{ADS_MANAGER_LOADED:ADS_MANAGER_LOADED}=AdsManagerLoadedEvent.Type,event=new ima.AdsManagerLoadedEvent(ADS_MANAGER_LOADED,adsRequest,userRequestContext);_this._dispatch(event)}));var e=new ima.AdError("adPlayError",1205,1205,"The browser prevented playback initiated without user interaction.",adsRequest,userRequestContext);requestAnimationFrame((function(){_this._dispatch(new ima.AdErrorEvent(e))}))};var AdsRenderingSettings=noopFunc,AdsRequest=function(){};AdsRequest.prototype={setAdWillAutoPlay:noopFunc,setAdWillPlayMuted:noopFunc,setContinuousPlayback:noopFunc};var AdPodInfo=function(){};AdPodInfo.prototype={getAdPosition:function(){return 1},getIsBumper:function(){return!1},getMaxDuration:function(){return-1},getPodIndex:function(){return 1},getTimeOffset:function(){return 0},getTotalAds:function(){return 1}};var UniversalAdIdInfo=function(){};UniversalAdIdInfo.prototype.getAdIdRegistry=function(){return""},UniversalAdIdInfo.prototype.getAdIsValue=function(){return""};var Ad=function(){};Ad.prototype={pi:new AdPodInfo,getAdId:function(){return""},getAdPodInfo(){return this.pi},getAdSystem:function(){return""},getAdvertiserName:function(){return""},getApiFramework:function(){return null},getCompanionAds:function(){return[]},getContentType:function(){return""},getCreativeAdId:function(){return""},getDealId:function(){return""},getDescription:function(){return""},getDuration:function(){return 8.5},getHeight:function(){return 0},getMediaUrl:function(){return null},getMinSuggestedDuration:function(){return-2},getSkipTimeOffset:function(){return-1},getSurveyUrl:function(){return null},getTitle:function(){return""},getTraffickingParametersString:function(){return""},getUiElements:function(){return[""]},getUniversalAdIdRegistry:function(){return"unknown"},getUniversalAdIds:function(){return[new UniversalAdIdInfo]},getUniversalAdIdValue:function(){return"unknown"},getVastMediaBitrate:function(){return 0},getVastMediaHeight:function(){return 0},getVastMediaWidth:function(){return 0},getWidth:function(){return 0},getWrapperAdIds:function(){return[""]},getWrapperAdSystems:function(){return[""]},getWrapperCreativeIds:function(){return[""]},isLinear:function(){return!0},isSkippable:()=>!0};var CompanionAd=function(){};CompanionAd.prototype={getAdSlotId:function(){return""},getContent:function(){return""},getContentType:function(){return""},getHeight:function(){return 1},getWidth:function(){return 1}};var AdError=function(type,code,vast,message,adsRequest,userRequestContext){this.errorCode=code,this.message=message,this.type=type,this.adsRequest=adsRequest,this.userRequestContext=userRequestContext,this.getErrorCode=function(){return this.errorCode},this.getInnerError=function(){return null},this.getMessage=function(){return this.message},this.getType=function(){return this.type},this.getVastErrorCode=function(){return this.vastErrorCode},this.toString=function(){return`AdError ${this.errorCode}: ${this.message}`}};AdError.ErrorCode={},AdError.Type={};var currentAd=function(){try{for(var _i3=0,_Object$values=Object.values(window.vidible._getContexts());_i3<_Object$values.length;_i3++){var _ctx$getPlayer;if(null!==(_ctx$getPlayer=_Object$values[_i3].getPlayer())&&void 0!==_ctx$getPlayer&&null!==(_ctx$getPlayer=_ctx$getPlayer.div)&&void 0!==_ctx$getPlayer&&_ctx$getPlayer.innerHTML.includes("www.engadget.com"))return!0}}catch(e){}return!1}()?void 0:new Ad,AdEvent=function(type){this.type=type};AdEvent.prototype={getAd:function(){return currentAd},getAdData:function(){}},AdEvent.Type={AD_BREAK_READY:"adBreakReady",AD_BUFFERING:"adBuffering",AD_CAN_PLAY:"adCanPlay",AD_METADATA:"adMetadata",AD_PROGRESS:"adProgress",ALL_ADS_COMPLETED:"allAdsCompleted",CLICK:"click",COMPLETE:"complete",CONTENT_PAUSE_REQUESTED:"contentPauseRequested",CONTENT_RESUME_REQUESTED:"contentResumeRequested",DURATION_CHANGE:"durationChange",EXPANDED_CHANGED:"expandedChanged",FIRST_QUARTILE:"firstQuartile",IMPRESSION:"impression",INTERACTION:"interaction",LINEAR_CHANGE:"linearChange",LINEAR_CHANGED:"linearChanged",LOADED:"loaded",LOG:"log",MIDPOINT:"midpoint",PAUSED:"pause",RESUMED:"resume",SKIPPABLE_STATE_CHANGED:"skippableStateChanged",SKIPPED:"skip",STARTED:"start",THIRD_QUARTILE:"thirdQuartile",USER_CLOSE:"userClose",VIDEO_CLICKED:"videoClicked",VIDEO_ICON_CLICKED:"videoIconClicked",VIEWABLE_IMPRESSION:"viewable_impression",VOLUME_CHANGED:"volumeChange",VOLUME_MUTED:"mute"};var AdErrorEvent=function(error){this.error=error,this.type="adError",this.getError=function(){return this.error},this.getUserRequestContext=function(){var _this$error;return null!==(_this$error=this.error)&&void 0!==_this$error&&_this$error.userRequestContext?this.error.userRequestContext:{}}};AdErrorEvent.Type={AD_ERROR:"adError"};var CustomContentLoadedEvent=function(){};CustomContentLoadedEvent.Type={CUSTOM_CONTENT_LOADED:"deprecated-event"};var CompanionAdSelectionSettings=function(){};CompanionAdSelectionSettings.CreativeType={ALL:"All",FLASH:"Flash",IMAGE:"Image"},CompanionAdSelectionSettings.ResourceType={ALL:"All",HTML:"Html",IFRAME:"IFrame",STATIC:"Static"},CompanionAdSelectionSettings.SizeCriteria={IGNORE:"IgnoreSize",SELECT_EXACT_MATCH:"SelectExactMatch",SELECT_NEAR_MATCH:"SelectNearMatch"};var AdCuePoints=function(){};AdCuePoints.prototype={getCuePoints:function(){return[]},getAdIdRegistry:function(){return""},getAdIdValue:function(){return""}};var AdProgressData=noopFunc;Object.assign(ima,{AdCuePoints:AdCuePoints,AdDisplayContainer:AdDisplayContainer,AdError:AdError,AdErrorEvent:AdErrorEvent,AdEvent:AdEvent,AdPodInfo:AdPodInfo,AdProgressData:AdProgressData,AdsLoader:AdsLoader,AdsManager:manager,AdsManagerLoadedEvent:AdsManagerLoadedEvent,AdsRenderingSettings:AdsRenderingSettings,AdsRequest:AdsRequest,CompanionAd:CompanionAd,CompanionAdSelectionSettings:CompanionAdSelectionSettings,CustomContentLoadedEvent:CustomContentLoadedEvent,gptProxyInstance:{},ImaSdkSettings:ImaSdkSettings,OmidAccessMode:{DOMAIN:"domain",FULL:"full",LIMITED:"limited"},OmidVerificationVendor:{1:"OTHER",2:"MOAT",3:"DOUBLEVERIFY",4:"INTEGRAL_AD_SCIENCE",5:"PIXELATE",6:"NIELSEN",7:"COMSCORE",8:"MEETRICS",9:"GOOGLE",OTHER:1,MOAT:2,DOUBLEVERIFY:3,INTEGRAL_AD_SCIENCE:4,PIXELATE:5,NIELSEN:6,COMSCORE:7,MEETRICS:8,GOOGLE:9},settings:new ImaSdkSettings,UiElements:{AD_ATTRIBUTION:"adAttribution",COUNTDOWN:"countdown"},UniversalAdIdInfo:UniversalAdIdInfo,VERSION:"3.453.0",ViewMode:{FULLSCREEN:"fullscreen",NORMAL:"normal"}}),window.google||(window.google={}),null!==(_window$google$ima=window.google.ima)&&void 0!==_window$google$ima&&_window$google$ima.dai&&(ima.dai=window.google.ima.dai),window.google.ima=ima,function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source)}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: [
                'googlesyndication-adsbygoogle',
                'ubo-googlesyndication_adsbygoogle.js',
                'googlesyndication_adsbygoogle.js',
            ],
            scriptlet: 'function GoogleSyndicationAdsByGoogle(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source){window.adsbygoogle={loaded:!0,push(arg){if(void 0===this.length&&(this.length=0,this.length+=1),null!==arg&&arg instanceof Object&&"Object"===arg.constructor.name)for(var _i=0,_Object$keys=Object.keys(arg);_i<_Object$keys.length;_i++){var key=_Object$keys[_i];if("function"==typeof arg[key])try{arg[key].call(this,{})}catch(_unused){}}}};for(var adElems=document.querySelectorAll(".adsbygoogle"),css="height:1px!important;max-height:1px!important;max-width:1px!important;width:1px!important;",executed=!1,i=0;i<adElems.length;i+=1){var adElemChildNodes=adElems[i].childNodes,childNodesQuantity=adElemChildNodes.length,areIframesDefined=!1;if(childNodesQuantity>0&&(areIframesDefined=2===childNodesQuantity&&"iframe"===adElemChildNodes[0].nodeName.toLowerCase()&&adElemChildNodes[0].id.includes("aswift_")&&"iframe"===adElemChildNodes[1].nodeName.toLowerCase()&&adElemChildNodes[1].id.includes("google_ads_iframe_")),!areIframesDefined){adElems[i].setAttribute("data-adsbygoogle-status","done");var aswiftIframe=document.createElement("iframe");aswiftIframe.id=`aswift_${i}`,aswiftIframe.style=css,adElems[i].appendChild(aswiftIframe);var innerAswiftIframe=document.createElement("iframe");aswiftIframe.contentWindow.document.body.appendChild(innerAswiftIframe);var googleadsIframe=document.createElement("iframe");googleadsIframe.id=`google_ads_iframe_${i}`,googleadsIframe.style=css,adElems[i].appendChild(googleadsIframe);var innerGoogleadsIframe=document.createElement("iframe");googleadsIframe.contentWindow.document.body.appendChild(innerGoogleadsIframe),executed=!0}}executed&&function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source)}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['googletagservices-gpt', 'ubo-googletagservices_gpt.js', 'googletagservices_gpt.js'],
            scriptlet: 'function GoogleTagServicesGpt(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function noopFunc(){}function noopThis(){return this}function noopNull(){return null}function noopArray(){return[]}function noopStr(){return""}function trueFunc(){return!0}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source){var slots=new Map,slotsById=new Map,slotsPerPath=new Map,slotCreatives=new Map,eventCallbacks=new Map,gTargeting=new Map,addEventListener=function(name,listener){return eventCallbacks.has(name)||eventCallbacks.set(name,new Set),eventCallbacks.get(name).add(listener),this},removeEventListener=function(name,listener){return!!eventCallbacks.has(name)&&eventCallbacks.get(name).delete(listener)},fireSlotEvent=function(name,slot){return new Promise((function(resolve){requestAnimationFrame((function(){for(var size=[0,0],callbacksSet=eventCallbacks.get(name)||[],callbackArray=Array.from(callbacksSet),i=0;i<callbackArray.length;i+=1)callbackArray[i]({isEmpty:!0,size:size,slot:slot});resolve()}))}))},displaySlot=function(slot){if(slot){var id=slot.getSlotElementId();if(document.getElementById(id)){var parent=document.getElementById(id);parent&&parent.appendChild(document.createElement("div")),function(slot){for(var node=document.getElementById(slot.getSlotElementId());null!=node&&node.lastChild;)node.lastChild.remove()}(slot),function(slot){var _document$getElementB,eid=`google_ads_iframe_${slot.getId()}`;null===(_document$getElementB=document.getElementById(eid))||void 0===_document$getElementB||_document$getElementB.remove();var node=document.getElementById(slot.getSlotElementId());if(node){var f=document.createElement("iframe");f.id=eid,f.srcdoc="<body></body>",f.style="position:absolute; width:0; height:0; left:0; right:0; z-index:-1; border:0",f.setAttribute("width",0),f.setAttribute("height",0),f.setAttribute("data-load-complete",!0),f.setAttribute("data-google-container-id",!0),f.setAttribute("sandbox",""),node.appendChild(f)}}(slot),fireSlotEvent("slotRenderEnded",slot),fireSlotEvent("slotRequested",slot),fireSlotEvent("slotResponseReceived",slot),fireSlotEvent("slotOnload",slot),fireSlotEvent("impressionViewable",slot)}}},companionAdsService={addEventListener:addEventListener,removeEventListener:removeEventListener,enableSyncLoading:noopFunc,setRefreshUnfilledSlots:noopFunc,getSlots:noopArray},contentService={addEventListener:addEventListener,removeEventListener:removeEventListener,setContent:noopFunc};function PassbackSlot(){}function SizeMappingBuilder(){}PassbackSlot.prototype.display=noopFunc,PassbackSlot.prototype.get=noopNull,PassbackSlot.prototype.set=noopThis,PassbackSlot.prototype.setClickUrl=noopThis,PassbackSlot.prototype.setTagForChildDirectedTreatment=noopThis,PassbackSlot.prototype.setTargeting=noopThis,PassbackSlot.prototype.updateTargetingFromMap=noopThis,SizeMappingBuilder.prototype.addSize=noopThis,SizeMappingBuilder.prototype.build=noopNull;var getTargetingValue=function(v){if("string"==typeof v)return[v];try{return Array.prototype.flat.call(v)}catch(_unused){}return[]},defineSlot=function(adUnitPath,creatives,optDiv){var _document$getElementB2;if(slotsById.has(optDiv))return null===(_document$getElementB2=document.getElementById(optDiv))||void 0===_document$getElementB2||_document$getElementB2.remove(),slotsById.get(optDiv);var attributes=new Map,targeting=new Map,exclusions=new Set,response={advertiserId:void 0,campaignId:void 0,creativeId:void 0,creativeTemplateId:void 0,lineItemId:void 0},sizes=[{getHeight:function(){return 2},getWidth:function(){return 2}}],num=(slotsPerPath.get(adUnitPath)||0)+1;slotsPerPath.set(adUnitPath,num);var id=`${adUnitPath}_${num}`,clickUrl="",collapseEmptyDiv=null,services=new Set,slot={addService:e=>(services.add(e),slot),clearCategoryExclusions:noopThis,clearTargeting(k){void 0===k?targeting.clear():targeting.delete(k)},defineSizeMapping(mapping){return slotCreatives.set(optDiv,mapping),this},get:function(k){return attributes.get(k)},getAdUnitPath:function(){return adUnitPath},getAttributeKeys:function(){return Array.from(attributes.keys())},getCategoryExclusions:function(){return Array.from(exclusions)},getClickUrl:function(){return clickUrl},getCollapseEmptyDiv:function(){return collapseEmptyDiv},getContentUrl:function(){return""},getDivStartsCollapsed:function(){return null},getDomId:function(){return optDiv},getEscapedQemQueryId:function(){return""},getFirstLook:function(){return 0},getId:function(){return id},getHtml:function(){return""},getName:function(){return id},getOutOfPage:function(){return!1},getResponseInformation:function(){return response},getServices:function(){return Array.from(services)},getSizes:function(){return sizes},getSlotElementId:function(){return optDiv},getSlotId:function(){return slot},getTargeting:function(k){return targeting.get(k)||gTargeting.get(k)||[]},getTargetingKeys:function(){return Array.from(new Set(Array.of(...gTargeting.keys(),...targeting.keys())))},getTargetingMap:function(){return Object.assign(Object.fromEntries(gTargeting.entries()),Object.fromEntries(targeting.entries()))},set:(k,v)=>(attributes.set(k,v),slot),setCategoryExclusion:e=>(exclusions.add(e),slot),setClickUrl:u=>(clickUrl=u,slot),setCollapseEmptyDiv:v=>(collapseEmptyDiv=!!v,slot),setSafeFrameConfig:noopThis,setTagForChildDirectedTreatment:noopThis,setTargeting:(k,v)=>(targeting.set(k,getTargetingValue(v)),slot),toString:function(){return id},updateTargetingFromMap:map=>(function(targeting,map){if("object"==typeof map)for(var key in map)Object.prototype.hasOwnProperty.call(map,key)&&targeting.set(key,getTargetingValue(map[key]))}(targeting,map),slot)};return slots.set(adUnitPath,slot),slotsById.set(optDiv,slot),slotCreatives.set(optDiv,creatives),slot},pubAdsService={addEventListener:addEventListener,removeEventListener:removeEventListener,clear:noopFunc,clearCategoryExclusions:noopThis,clearTagForChildDirectedTreatment:noopThis,clearTargeting(k){void 0===k?gTargeting.clear():gTargeting.delete(k)},collapseEmptyDivs:noopFunc,defineOutOfPagePassback:()=>new PassbackSlot,definePassback:()=>new PassbackSlot,disableInitialLoad:noopFunc,display:noopFunc,enableAsyncRendering:noopFunc,enableLazyLoad:noopFunc,enableSingleRequest:noopFunc,enableSyncRendering:noopFunc,enableVideoAds:noopFunc,get:noopNull,getAttributeKeys:noopArray,getTargeting:noopArray,getTargetingKeys:noopArray,getSlots:noopArray,isInitialLoadDisabled:trueFunc,refresh:noopFunc,set:noopThis,setCategoryExclusion:noopThis,setCentering:noopFunc,setCookieOptions:noopThis,setForceSafeFrame:noopThis,setLocation:noopThis,setPrivacySettings:noopThis,setPublisherProvidedId:noopThis,setRequestNonPersonalizedAds:noopThis,setSafeFrameConfig:noopThis,setTagForChildDirectedTreatment:noopThis,setTargeting:noopThis,setVideoContent:noopThis,updateCorrelator:noopFunc},{googletag:googletag={}}=window,{cmd:cmd=[]}=googletag;for(googletag.apiReady=!0,googletag.cmd=[],googletag.cmd.push=function(a){try{a()}catch(ex){}return 1},googletag.companionAds=function(){return companionAdsService},googletag.content=function(){return contentService},googletag.defineOutOfPageSlot=defineSlot,googletag.defineSlot=defineSlot,googletag.destroySlots=function(){slots.clear(),slotsById.clear()},googletag.disablePublisherConsole=noopFunc,googletag.display=function(arg){var id;id=null!=arg&&arg.getSlotElementId?arg.getSlotElementId():null!=arg&&arg.nodeType?arg.id:String(arg),displaySlot(slotsById.get(id))},googletag.enableServices=noopFunc,googletag.getVersion=noopStr,googletag.pubads=function(){return pubAdsService},googletag.pubadsReady=!0,googletag.setAdIframeTitle=noopFunc,googletag.sizeMapping=function(){return new SizeMappingBuilder},window.googletag=googletag;0!==cmd.length;)googletag.cmd.push(cmd.shift());!function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source)}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['matomo'],
            scriptlet: 'function Matomo(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function noopFunc(){}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source){var Tracker=function(){};Tracker.prototype.setDoNotTrack=noopFunc,Tracker.prototype.setDomains=noopFunc,Tracker.prototype.setCustomDimension=noopFunc,Tracker.prototype.trackPageView=noopFunc;var AsyncTracker=function(){};AsyncTracker.prototype.addListener=noopFunc;var matomoWrapper={getTracker:Tracker,getAsyncTracker:AsyncTracker};window.Piwik=matomoWrapper,function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source)}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['naver-wcslog'],
            scriptlet: 'function NaverWcslog(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function noopFunc(){}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source){window.wcs_add={},window.wcs_do=noopFunc,window.wcs={inflow:noopFunc},function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source)}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['pardot-1.0'],
            scriptlet: 'function Pardot(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function noopFunc(){}function noopStr(){return""}function noopNull(){return null}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source){function piTracker(){window.pi={tracker:{visitor_id:"",visitor_id_sign:"",pi_opt_in:"",campaign_id:""}},window.piScriptNum+=1}window.piVersion="1.0.2",window.piScriptNum=0,window.piScriptObj=[],window.checkNamespace=noopFunc,window.getPardotUrl=noopStr,window.piGetParameter=noopNull,window.piSetCookie=noopFunc,window.piGetCookie=noopStr,window.piResponse=noopFunc,window.piTracker=piTracker,piTracker(),function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source)}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['prebid'],
            scriptlet: 'function Prebid(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function noopStr(){return""}function noopArray(){return[]}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source){var pushFunction=function(arg){if("function"==typeof arg)try{arg.call()}catch(ex){}},pbjsWrapper={addAdUnits(){},adServers:{dfp:{buildVideoUrl:noopStr}},adUnits:[],aliasBidder(){},cmd:[],enableAnalytics(){},getHighestCpmBids:noopArray,libLoaded:!0,que:[],requestBids(arg){if(arg instanceof Object&&arg.bidsBackHandler)try{arg.bidsBackHandler.call()}catch(ex){}},removeAdUnit(){},setBidderConfig(){},setConfig(){},setTargetingForGPTAsync(){}};pbjsWrapper.cmd.push=pushFunction,pbjsWrapper.que.push=pushFunction,window.pbjs=pbjsWrapper,function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source)}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['scorecardresearch-beacon', 'ubo-scorecardresearch_beacon.js', 'scorecardresearch_beacon.js'],
            scriptlet: 'function ScoreCardResearchBeacon(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source){window.COMSCORE={purge(){window._comscore=[]},beacon(){}},function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source)}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: [
                'abort-current-inline-script',
                'abort-current-script.js',
                'ubo-abort-current-script.js',
                'acs.js',
                'ubo-acs.js',
                'ubo-abort-current-script',
                'ubo-acs',
                'abort-current-inline-script.js',
                'ubo-abort-current-inline-script.js',
                'acis.js',
                'ubo-acis.js',
                'ubo-abort-current-inline-script',
                'ubo-acis',
                'abp-abort-current-inline-script',
            ],
            scriptlet: 'function abortCurrentInlineScript(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function randomId(){return Math.random().toString(36).slice(2,9)}function getPropertyInChain(e,r){var n=r.indexOf(".");if(-1===n)return{base:e,prop:r};var i=r.slice(0,n);if(null===e)return{base:e,prop:i,chain:r};var t=e[i];return r=r.slice(n+1),(e instanceof Object||"object"==typeof e)&&function(t){return 0===Object.keys(t).length&&!t.prototype}(e)||null===t?{base:e,prop:i,chain:r}:void 0!==t?getPropertyInChain(t,r):(Object.defineProperty(e,i,{configurable:!0}),{base:e,prop:i,chain:r})}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,property,search){var r,n,searchRegexp=function(e){var r=e||"",t="/";if(""===r)return new RegExp(".?");var n,i,s=r.lastIndexOf(t),a=r.substring(s+1),g=r.substring(0,s+1),u=(i=a,(n=g).startsWith(t)&&n.endsWith(t)&&!n.endsWith("\\\\/")&&function(e){if(!e)return!1;try{return new RegExp("",e),!0}catch(e){return!1}}(i)?i:"");if(r.startsWith(t)&&r.endsWith(t)||u)return new RegExp((u?g:r).slice(1,-1),u);var c=r.replace(/\\\\\'/g,"\'").replace(/\\\\"/g,\'"\').replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&");return new RegExp(c)}(search),rid=randomId(),getCurrentScript=function(){if("currentScript"in document)return document.currentScript;var scripts=document.getElementsByTagName("script");return scripts[scripts.length-1]},ourScript=getCurrentScript(),abort=function(){var _scriptEl$src,scriptEl=getCurrentScript();if(scriptEl){var content=scriptEl.textContent;try{content=Object.getOwnPropertyDescriptor(Node.prototype,"textContent").get.call(scriptEl)}catch(e){}if(0===content.length&&void 0!==scriptEl.src&&null!==(_scriptEl$src=scriptEl.src)&&void 0!==_scriptEl$src&&_scriptEl$src.startsWith("data:text/javascript;base64,")){var encodedContent=scriptEl.src.slice(28);content=window.atob(encodedContent)}if(scriptEl instanceof HTMLScriptElement&&content.length>0&&scriptEl!==ourScript&&searchRegexp.test(content))throw function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source),new ReferenceError(rid)}},_setChainPropAccess=function(owner,property){var chainInfo=getPropertyInChain(owner,property),{base:base}=chainInfo,{prop:prop,chain:chain}=chainInfo;if(base instanceof Object!=0||null!==base)if(chain)Object.defineProperty(owner,prop,{get:function(){return base},set:function(a){base=a,a instanceof Object&&_setChainPropAccess(a,chain)}});else{var currentValue=base[prop],origDescriptor=Object.getOwnPropertyDescriptor(base,prop);origDescriptor instanceof Object!=0&&origDescriptor.get instanceof Function!=0||(currentValue=base[prop],origDescriptor=void 0);var e,r,t,c,descriptorWrapper=Object.assign({isAbortingSuspended:!1,isolateCallback(r){this.isAbortingSuspended=!0;try{for(var e=arguments.length,n=new Array(e>1?e-1:0),t=1;t<e;t++)n[t-1]=arguments[t];var i=r(...n);return this.isAbortingSuspended=!1,i}catch(r){var s=randomId();throw this.isAbortingSuspended=!1,new ReferenceError(s)}}},{currentValue:currentValue,get(){return this.isAbortingSuspended||this.isolateCallback(abort),origDescriptor instanceof Object?origDescriptor.get.call(base):this.currentValue},set(newValue){this.isAbortingSuspended||this.isolateCallback(abort),origDescriptor instanceof Object?origDescriptor.set.call(base,newValue):this.currentValue=newValue}});e=base,r=prop,t={get:()=>descriptorWrapper.get.call(descriptorWrapper),set(newValue){descriptorWrapper.set.call(descriptorWrapper,newValue)}},(c=Object.getOwnPropertyDescriptor(e,r))&&!c.configurable||Object.defineProperty(e,r,t)}else{var props=property.split("."),propIndex=props.indexOf(prop),baseName=props[propIndex-1];!function(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}(source,`The scriptlet had been executed before the ${baseName} was loaded.`)}};_setChainPropAccess(window,property),window.onerror=(r=rid,n=window.onerror,function(e){if("string"==typeof e&&e.includes(r))return!0;if(n instanceof Function){for(var t=arguments.length,o=new Array(t>1?t-1:0),i=1;i<t;i++)o[i-1]=arguments[i];return n.apply(window,[e,...o])}return!1}).bind()}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: [
                'abort-on-property-read',
                'abort-on-property-read.js',
                'ubo-abort-on-property-read.js',
                'aopr.js',
                'ubo-aopr.js',
                'ubo-abort-on-property-read',
                'ubo-aopr',
                'abp-abort-on-property-read',
            ],
            scriptlet: 'function abortOnPropertyRead(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function getPropertyInChain(e,r){var n=r.indexOf(".");if(-1===n)return{base:e,prop:r};var i=r.slice(0,n);if(null===e)return{base:e,prop:i,chain:r};var t=e[i];return r=r.slice(n+1),(e instanceof Object||"object"==typeof e)&&function(t){return 0===Object.keys(t).length&&!t.prototype}(e)||null===t?{base:e,prop:i,chain:r}:void 0!==t?getPropertyInChain(t,r):(Object.defineProperty(e,i,{configurable:!0}),{base:e,prop:i,chain:r})}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,property){if(property){var r,n,rid=Math.random().toString(36).slice(2,9),abort=function(){throw function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source),new ReferenceError(rid)},_setChainPropAccess=function(owner,property){var e,r,t,c,chainInfo=getPropertyInChain(owner,property),{base:base}=chainInfo,{prop:prop,chain:chain}=chainInfo;chain?Object.defineProperty(owner,prop,{get:function(){return base},set:function(a){base=a,a instanceof Object&&_setChainPropAccess(a,chain)}}):(e=base,r=prop,t={get:abort,set:function(){}},(c=Object.getOwnPropertyDescriptor(e,r))&&!c.configurable||Object.defineProperty(e,r,t))};_setChainPropAccess(window,property),window.onerror=(r=rid,n=window.onerror,function(e){if("string"==typeof e&&e.includes(r))return!0;if(n instanceof Function){for(var t=arguments.length,o=new Array(t>1?t-1:0),i=1;i<t;i++)o[i-1]=arguments[i];return n.apply(window,[e,...o])}return!1}).bind()}}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: [
                'abort-on-property-write',
                'abort-on-property-write.js',
                'ubo-abort-on-property-write.js',
                'aopw.js',
                'ubo-aopw.js',
                'ubo-abort-on-property-write',
                'ubo-aopw',
                'abp-abort-on-property-write',
            ],
            scriptlet: 'function abortOnPropertyWrite(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function getPropertyInChain(e,r){var n=r.indexOf(".");if(-1===n)return{base:e,prop:r};var i=r.slice(0,n);if(null===e)return{base:e,prop:i,chain:r};var t=e[i];return r=r.slice(n+1),(e instanceof Object||"object"==typeof e)&&function(t){return 0===Object.keys(t).length&&!t.prototype}(e)||null===t?{base:e,prop:i,chain:r}:void 0!==t?getPropertyInChain(t,r):(Object.defineProperty(e,i,{configurable:!0}),{base:e,prop:i,chain:r})}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,property){if(property){var r,n,rid=Math.random().toString(36).slice(2,9),abort=function(){throw function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source),new ReferenceError(rid)},_setChainPropAccess=function(owner,property){var e,r,t,c,chainInfo=getPropertyInChain(owner,property),{base:base}=chainInfo,{prop:prop,chain:chain}=chainInfo;chain?Object.defineProperty(owner,prop,{get:function(){return base},set:function(a){base=a,a instanceof Object&&_setChainPropAccess(a,chain)}}):(e=base,r=prop,t={set:abort},(c=Object.getOwnPropertyDescriptor(e,r))&&!c.configurable||Object.defineProperty(e,r,t))};_setChainPropAccess(window,property),window.onerror=(r=rid,n=window.onerror,function(e){if("string"==typeof e&&e.includes(r))return!0;if(n instanceof Function){for(var t=arguments.length,o=new Array(t>1?t-1:0),i=1;i<t;i++)o[i-1]=arguments[i];return n.apply(window,[e,...o])}return!1}).bind()}}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: [
                'abort-on-stack-trace',
                'abort-on-stack-trace.js',
                'ubo-abort-on-stack-trace.js',
                'aost.js',
                'ubo-aost.js',
                'ubo-abort-on-stack-trace',
                'ubo-aost',
                'abp-abort-on-stack-trace',
            ],
            scriptlet: 'function abortOnStackTrace(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function randomId(){return Math.random().toString(36).slice(2,9)}function getPropertyInChain(e,r){var n=r.indexOf(".");if(-1===n)return{base:e,prop:r};var i=r.slice(0,n);if(null===e)return{base:e,prop:i,chain:r};var t=e[i];return r=r.slice(n+1),(e instanceof Object||"object"==typeof e)&&function(t){return 0===Object.keys(t).length&&!t.prototype}(e)||null===t?{base:e,prop:i,chain:r}:void 0!==t?getPropertyInChain(t,r):(Object.defineProperty(e,i,{configurable:!0}),{base:e,prop:i,chain:r})}function matchStackTrace(e,t){if(!e||""===e)return!0;var r=function(){try{for(var r=[],e=1;e<10;e+=1){var a=`$${e}`;if(!RegExp[a])break;r.push(RegExp[a])}return r}catch(r){return[]}}();if(function(t,i){var r="inlineScript",n="injectedScript",isInlineScript=function(t){return t.includes(r)},isInjectedScript=function(t){return t.includes(n)};if(!isInlineScript(t)&&!isInjectedScript(t))return!1;var e=window.location.href,s=e.indexOf("#");-1!==s&&(e=e.slice(0,s));var c=i.split("\\n").slice(2).map((function(t){return t.trim()})).map((function(t){var i,s=/(.*?@)?(\\S+)(:\\d+)(:\\d+)\\)?$/.exec(t);if(s){var c,l,a=s[2],u=s[3],o=s[4];if(null!==(c=a)&&void 0!==c&&c.startsWith("(")&&(a=a.slice(1)),null!==(l=a)&&void 0!==l&&l.startsWith("<anonymous>")){var d;a=n;var f=void 0!==s[1]?s[1].slice(0,-1):t.slice(0,s.index).trim();null!==(d=f)&&void 0!==d&&d.startsWith("at")&&(f=f.slice(2).trim()),i=`${f} ${a}${u}${o}`.trim()}else i=a===e?`${r}${u}${o}`.trim():`${a}${u}${o}`.trim()}else i=t;return i}));if(c)for(var l=0;l<c.length;l+=1){if(isInlineScript(t)&&c[l].startsWith(r)&&c[l].match(toRegExp(t)))return!0;if(isInjectedScript(t)&&c[l].startsWith(n)&&c[l].match(toRegExp(t)))return!0}return!1}(e,t))return r.length&&r[0]!==RegExp.$1&&restoreRegExpValues(r),!0;var n=toRegExp(e),a=t.split("\\n").slice(2).map((function(e){return e.trim()})).join("\\n");return r.length&&r[0]!==RegExp.$1&&restoreRegExpValues(r),function(){var t=Object.getOwnPropertyDescriptor(RegExp.prototype,"test"),e=null==t?void 0:t.value;if(t&&"function"==typeof t.value)return e;throw new Error("RegExp.prototype.test is not a function")}().call(n,a)}function toRegExp(e){var r=e||"",t="/";if(""===r)return new RegExp(".?");var n,i,s=r.lastIndexOf(t),a=r.substring(s+1),g=r.substring(0,s+1),u=(i=a,(n=g).startsWith(t)&&n.endsWith(t)&&!n.endsWith("\\\\/")&&function(e){if(!e)return!1;try{return new RegExp("",e),!0}catch(e){return!1}}(i)?i:"");if(r.startsWith(t)&&r.endsWith(t)||u)return new RegExp((u?g:r).slice(1,-1),u);var c=r.replace(/\\\\\'/g,"\'").replace(/\\\\"/g,\'"\').replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&");return new RegExp(c)}function restoreRegExpValues(e){if(e.length)try{var r;r=1===e.length?`(${e[0]})`:e.reduce((function(e,r,t){return 1===t?`(${e}),(${r})`:`${e},(${r})`}));var t=new RegExp(r);e.toString().replace(t,"")}catch(e){var n=`Failed to restore RegExp values: ${e}`;console.log(n)}}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,property,stack){if(property&&stack){var r,n,rid=randomId(),abort=function(){throw function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source),new ReferenceError(rid)},_setChainPropAccess=function(owner,property){var chainInfo=getPropertyInChain(owner,property),{base:base}=chainInfo,{prop:prop,chain:chain}=chainInfo;if(chain)Object.defineProperty(owner,prop,{get:function(){return base},set:function(a){base=a,a instanceof Object&&_setChainPropAccess(a,chain)}});else if(stack.match(/^(inlineScript|injectedScript)$/)||function(e){var t,n=function(e){return e.replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&")}(e);"/"===e[0]&&"/"===e[e.length-1]&&(n=e.slice(1,-1));try{t=new RegExp(n),t=!0}catch(e){t=!1}return t}(stack)){var e,r,t,c,descriptorWrapper=Object.assign({isAbortingSuspended:!1,isolateCallback(r){this.isAbortingSuspended=!0;try{for(var e=arguments.length,n=new Array(e>1?e-1:0),t=1;t<e;t++)n[t-1]=arguments[t];var i=r(...n);return this.isAbortingSuspended=!1,i}catch(r){var s=randomId();throw this.isAbortingSuspended=!1,new ReferenceError(s)}}},{value:base[prop],get(){return!this.isAbortingSuspended&&this.isolateCallback(matchStackTrace,stack,(new Error).stack)&&abort(),this.value},set(newValue){!this.isAbortingSuspended&&this.isolateCallback(matchStackTrace,stack,(new Error).stack)&&abort(),this.value=newValue}});e=base,r=prop,t={get:()=>descriptorWrapper.get.call(descriptorWrapper),set(newValue){descriptorWrapper.set.call(descriptorWrapper,newValue)}},(c=Object.getOwnPropertyDescriptor(e,r))&&!c.configurable||Object.defineProperty(e,r,t)}else!function(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}(source,`Invalid parameter: ${stack}`)};_setChainPropAccess(window,property),window.onerror=(r=rid,n=window.onerror,function(e){if("string"==typeof e&&e.includes(r))return!0;if(n instanceof Function){for(var t=arguments.length,o=new Array(t>1?t-1:0),i=1;i<t;i++)o[i-1]=arguments[i];return n.apply(window,[e,...o])}return!1}).bind()}}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: [
                'adjust-setInterval',
                'nano-setInterval-booster.js',
                'ubo-nano-setInterval-booster.js',
                'nano-sib.js',
                'ubo-nano-sib.js',
                'adjust-setInterval.js',
                'ubo-adjust-setInterval.js',
                'ubo-nano-setInterval-booster',
                'ubo-nano-sib',
                'ubo-adjust-setInterval',
            ],
            scriptlet: 'function adjustSetInterval(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function nativeIsNaN(N){return(Number.isNaN||window.isNaN)(N)}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,matchCallback,matchDelay,boost){var nativeSetInterval=window.setInterval,matchRegexp=function(e){var r=e||"",t="/";if(""===r)return new RegExp(".?");var n,i,s=r.lastIndexOf(t),a=r.substring(s+1),g=r.substring(0,s+1),u=(i=a,(n=g).startsWith(t)&&n.endsWith(t)&&!n.endsWith("\\\\/")&&function(e){if(!e)return!1;try{return new RegExp("",e),!0}catch(e){return!1}}(i)?i:"");if(r.startsWith(t)&&r.endsWith(t)||u)return new RegExp((u?g:r).slice(1,-1),u);var c=r.replace(/\\\\\'/g,"\'").replace(/\\\\"/g,\'"\').replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&");return new RegExp(c)}(matchCallback);window.setInterval=function(callback,delay){if((n=callback)instanceof Function||"string"==typeof n)matchRegexp.test(callback.toString())&&(e=delay,function(n){return"*"===n}(a=matchDelay)||e===function(a){var e=parseInt(a,10);return nativeIsNaN(e)?1e3:e}(a))&&(delay*=function(t){var e=parseFloat(t),i=nativeIsNaN(e)||!function(i){return(Number.isFinite||window.isFinite)(i)}(e)?.05:e;return i<.001&&(i=.001),i>50&&(i=50),i}(boost),function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source));else{var message=`Scriptlet can\'t be applied because of invalid callback: \'${String(callback)}\'`;!function(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}(source,message)}for(var a,e,n,_len=arguments.length,args=new Array(_len>2?_len-2:0),_key=2;_key<_len;_key++)args[_key-2]=arguments[_key];return nativeSetInterval.apply(window,[callback,delay,...args])}}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: [
                'adjust-setTimeout',
                'adjust-setTimeout.js',
                'ubo-adjust-setTimeout.js',
                'nano-setTimeout-booster.js',
                'ubo-nano-setTimeout-booster.js',
                'nano-stb.js',
                'ubo-nano-stb.js',
                'ubo-adjust-setTimeout',
                'ubo-nano-setTimeout-booster',
                'ubo-nano-stb',
            ],
            scriptlet: 'function adjustSetTimeout(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function nativeIsNaN(N){return(Number.isNaN||window.isNaN)(N)}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,matchCallback,matchDelay,boost){var nativeSetTimeout=window.setTimeout,matchRegexp=function(e){var r=e||"",t="/";if(""===r)return new RegExp(".?");var n,i,s=r.lastIndexOf(t),a=r.substring(s+1),g=r.substring(0,s+1),u=(i=a,(n=g).startsWith(t)&&n.endsWith(t)&&!n.endsWith("\\\\/")&&function(e){if(!e)return!1;try{return new RegExp("",e),!0}catch(e){return!1}}(i)?i:"");if(r.startsWith(t)&&r.endsWith(t)||u)return new RegExp((u?g:r).slice(1,-1),u);var c=r.replace(/\\\\\'/g,"\'").replace(/\\\\"/g,\'"\').replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&");return new RegExp(c)}(matchCallback);window.setTimeout=function(callback,delay){if((n=callback)instanceof Function||"string"==typeof n)matchRegexp.test(callback.toString())&&(e=delay,function(n){return"*"===n}(a=matchDelay)||e===function(a){var e=parseInt(a,10);return nativeIsNaN(e)?1e3:e}(a))&&(delay*=function(t){var e=parseFloat(t),i=nativeIsNaN(e)||!function(i){return(Number.isFinite||window.isFinite)(i)}(e)?.05:e;return i<.001&&(i=.001),i>50&&(i=50),i}(boost),function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source));else{var message=`Scriptlet can\'t be applied because of invalid callback: \'${String(callback)}\'`;!function(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}(source,message)}for(var a,e,n,_len=arguments.length,args=new Array(_len>2?_len-2:0),_key=2;_key<_len;_key++)args[_key-2]=arguments[_key];return nativeSetTimeout.apply(window,[callback,delay,...args])}}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['call-nothrow', 'call-nothrow.js', 'ubo-call-nothrow.js', 'ubo-call-nothrow'],
            scriptlet: 'function callNoThrow(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function getPropertyInChain(e,r){var n=r.indexOf(".");if(-1===n)return{base:e,prop:r};var i=r.slice(0,n);if(null===e)return{base:e,prop:i,chain:r};var t=e[i];return r=r.slice(n+1),(e instanceof Object||"object"==typeof e)&&function(t){return 0===Object.keys(t).length&&!t.prototype}(e)||null===t?{base:e,prop:i,chain:r}:void 0!==t?getPropertyInChain(t,r):(Object.defineProperty(e,i,{configurable:!0}),{base:e,prop:i,chain:r})}function logMessage(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,functionName){if(functionName){var{base:base,prop:prop}=getPropertyInChain(window,functionName);if(base&&prop&&"function"==typeof base[prop]){var objectHandler={apply:function(){var result;try{result=Reflect.apply(...arguments)}catch(e){var _message=`Error calling ${functionName}: ${e.message}`;logMessage(source,_message)}return function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source),result}};base[prop]=new Proxy(base[prop],objectHandler)}else logMessage(source,`${functionName} is not a function`)}}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['debug-current-inline-script'],
            scriptlet: 'function debugCurrentInlineScript(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function getPropertyInChain(e,r){var n=r.indexOf(".");if(-1===n)return{base:e,prop:r};var i=r.slice(0,n);if(null===e)return{base:e,prop:i,chain:r};var t=e[i];return r=r.slice(n+1),(e instanceof Object||"object"==typeof e)&&function(t){return 0===Object.keys(t).length&&!t.prototype}(e)||null===t?{base:e,prop:i,chain:r}:void 0!==t?getPropertyInChain(t,r):(Object.defineProperty(e,i,{configurable:!0}),{base:e,prop:i,chain:r})}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,property,search){var r,n,searchRegexp=function(e){var r=e||"",t="/";if(""===r)return new RegExp(".?");var n,i,s=r.lastIndexOf(t),a=r.substring(s+1),g=r.substring(0,s+1),u=(i=a,(n=g).startsWith(t)&&n.endsWith(t)&&!n.endsWith("\\\\/")&&function(e){if(!e)return!1;try{return new RegExp("",e),!0}catch(e){return!1}}(i)?i:"");if(r.startsWith(t)&&r.endsWith(t)||u)return new RegExp((u?g:r).slice(1,-1),u);var c=r.replace(/\\\\\'/g,"\'").replace(/\\\\"/g,\'"\').replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&");return new RegExp(c)}(search),rid=Math.random().toString(36).slice(2,9),getCurrentScript=function(){if("currentScript"in document)return document.currentScript;var scripts=document.getElementsByTagName("script");return scripts[scripts.length-1]},ourScript=getCurrentScript(),abort=function(){var scriptEl=getCurrentScript();if(scriptEl){var content=scriptEl.textContent;try{content=Object.getOwnPropertyDescriptor(Node.prototype,"textContent").get.call(scriptEl)}catch(e){}if(scriptEl instanceof HTMLScriptElement&&content.length>0&&scriptEl!==ourScript&&searchRegexp.test(content)){!function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source);debugger}}},_setChainPropAccess=function(owner,property){var chainInfo=getPropertyInChain(owner,property),{base:base}=chainInfo,{prop:prop,chain:chain}=chainInfo;if(base instanceof Object!=0||null!==base)if(chain)Object.defineProperty(owner,prop,{get:function(){return base},set:function(a){base=a,a instanceof Object&&_setChainPropAccess(a,chain)}});else{var e,r,t,c,currentValue=base[prop];e=base,r=prop,t={set:function(value){abort(),currentValue=value},get:function(){return abort(),currentValue}},(c=Object.getOwnPropertyDescriptor(e,r))&&!c.configurable||Object.defineProperty(e,r,t)}else{var props=property.split("."),propIndex=props.indexOf(prop);!function(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}(`The scriptlet had been executed before the ${props[propIndex-1]} was loaded.`,source.verbose)}};_setChainPropAccess(window,property),window.onerror=(r=rid,n=window.onerror,function(e){if("string"==typeof e&&e.includes(r))return!0;if(n instanceof Function){for(var t=arguments.length,o=new Array(t>1?t-1:0),i=1;i<t;i++)o[i-1]=arguments[i];return n.apply(window,[e,...o])}return!1}).bind()}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['debug-on-property-read'],
            scriptlet: 'function debugOnPropertyRead(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function getPropertyInChain(e,r){var n=r.indexOf(".");if(-1===n)return{base:e,prop:r};var i=r.slice(0,n);if(null===e)return{base:e,prop:i,chain:r};var t=e[i];return r=r.slice(n+1),(e instanceof Object||"object"==typeof e)&&function(t){return 0===Object.keys(t).length&&!t.prototype}(e)||null===t?{base:e,prop:i,chain:r}:void 0!==t?getPropertyInChain(t,r):(Object.defineProperty(e,i,{configurable:!0}),{base:e,prop:i,chain:r})}function noopFunc(){}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,property){if(property){var r,n,rid=Math.random().toString(36).slice(2,9),abort=function(){!function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source);debugger},_setChainPropAccess=function(owner,property){var e,r,t,c,chainInfo=getPropertyInChain(owner,property),{base:base}=chainInfo,{prop:prop,chain:chain}=chainInfo;chain?Object.defineProperty(owner,prop,{get:function(){return base},set:function(a){base=a,a instanceof Object&&_setChainPropAccess(a,chain)}}):(e=base,r=prop,t={get:abort,set:noopFunc},(c=Object.getOwnPropertyDescriptor(e,r))&&!c.configurable||Object.defineProperty(e,r,t))};_setChainPropAccess(window,property),window.onerror=(r=rid,n=window.onerror,function(e){if("string"==typeof e&&e.includes(r))return!0;if(n instanceof Function){for(var t=arguments.length,o=new Array(t>1?t-1:0),i=1;i<t;i++)o[i-1]=arguments[i];return n.apply(window,[e,...o])}return!1}).bind()}}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['debug-on-property-write'],
            scriptlet: 'function debugOnPropertyWrite(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function getPropertyInChain(e,r){var n=r.indexOf(".");if(-1===n)return{base:e,prop:r};var i=r.slice(0,n);if(null===e)return{base:e,prop:i,chain:r};var t=e[i];return r=r.slice(n+1),(e instanceof Object||"object"==typeof e)&&function(t){return 0===Object.keys(t).length&&!t.prototype}(e)||null===t?{base:e,prop:i,chain:r}:void 0!==t?getPropertyInChain(t,r):(Object.defineProperty(e,i,{configurable:!0}),{base:e,prop:i,chain:r})}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,property){if(property){var r,n,rid=Math.random().toString(36).slice(2,9),abort=function(){!function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source);debugger},_setChainPropAccess=function(owner,property){var e,r,t,c,chainInfo=getPropertyInChain(owner,property),{base:base}=chainInfo,{prop:prop,chain:chain}=chainInfo;chain?Object.defineProperty(owner,prop,{get:function(){return base},set:function(a){base=a,a instanceof Object&&_setChainPropAccess(a,chain)}}):(e=base,r=prop,t={set:abort},(c=Object.getOwnPropertyDescriptor(e,r))&&!c.configurable||Object.defineProperty(e,r,t))};_setChainPropAccess(window,property),window.onerror=(r=rid,n=window.onerror,function(e){if("string"==typeof e&&e.includes(r))return!0;if(n instanceof Function){for(var t=arguments.length,o=new Array(t>1?t-1:0),i=1;i<t;i++)o[i-1]=arguments[i];return n.apply(window,[e,...o])}return!1}).bind()}}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['dir-string'],
            scriptlet: 'function dirString(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,times){var{dir:dir}=console;console.dir=function(object){"function"==typeof dir&&dir.call(this,object),function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source)}}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: [
                'disable-newtab-links',
                'disable-newtab-links.js',
                'ubo-disable-newtab-links.js',
                'ubo-disable-newtab-links',
            ],
            scriptlet: 'function disableNewtabLinks(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function hit(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source){document.addEventListener("click",(function(ev){for(var{target:target}=ev;null!==target;){if("a"===target.localName&&target.hasAttribute("target")){ev.stopPropagation(),ev.preventDefault(),hit(source);break}target=target.parentNode}}))}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['evaldata-prune', 'evaldata-prune.js', 'ubo-evaldata-prune.js', 'ubo-evaldata-prune'],
            scriptlet: 'function evalDataPrune(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function hit(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}function getWildcardPropertyInChain(r,e){var a=arguments.length>2&&void 0!==arguments[2]&&arguments[2],i=arguments.length>3&&void 0!==arguments[3]?arguments[3]:[],t=arguments.length>4?arguments[4]:void 0,o=e.indexOf(".");if(-1===o){if("*"===e||"[]"===e){for(var n in r)if(Object.prototype.hasOwnProperty.call(r,n))if(void 0!==t){var s=r[n];"string"==typeof s&&t instanceof RegExp?t.test(s)&&i.push({base:r,prop:n}):s===t&&i.push({base:r,prop:n})}else i.push({base:r,prop:n})}else if(void 0!==t){var p=r[e];"string"==typeof p&&t instanceof RegExp?t.test(p)&&i.push({base:r,prop:e}):r[e]===t&&i.push({base:r,prop:e})}else i.push({base:r,prop:e});return i}var c=e.slice(0,o);if("[]"===c&&Array.isArray(r)||"*"===c&&r instanceof Object||"[-]"===c&&Array.isArray(r)||"{-}"===c&&r instanceof Object){var f=e.slice(o+1),y=Object.keys(r);if("{-}"===c||"[-]"===c){var h=Array.isArray(r)?"array":"object";return("{-}"!==c||"object"!==h)&&("[-]"!==c||"array"!==h)||y.forEach((function(e){(function(t,r,e){var n=r.split("."),_check=function(t,r){if(null==t)return!1;if(0===r.length)return void 0===e||("string"==typeof t&&e instanceof RegExp?e.test(t):t===e);var n=r[0],i=r.slice(1);if("*"===n||"[]"===n){if(Array.isArray(t))return t.some((function(t){return _check(t,i)}));if("object"==typeof t&&null!==t)return Object.keys(t).some((function(r){return _check(t[r],i)}))}return!!Object.prototype.hasOwnProperty.call(t,n)&&_check(t[n],i)};return _check(t,n)})(r[e],f,t)&&i.push({base:r,prop:e})})),i}y.forEach((function(e){getWildcardPropertyInChain(r[e],f,a,i,t)}))}Array.isArray(r)&&r.forEach((function(r){void 0!==r&&getWildcardPropertyInChain(r,e,a,i,t)}));var d=r[c];return e=e.slice(o+1),void 0!==d&&getWildcardPropertyInChain(d,e,a,i,t),i}function logMessage(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}function toRegExp(e){var r=e||"",t="/";if(""===r)return new RegExp(".?");var n,i,s=r.lastIndexOf(t),a=r.substring(s+1),g=r.substring(0,s+1),u=(i=a,(n=g).startsWith(t)&&n.endsWith(t)&&!n.endsWith("\\\\/")&&function(e){if(!e)return!1;try{return new RegExp("",e),!0}catch(e){return!1}}(i)?i:"");if(r.startsWith(t)&&r.endsWith(t)||u)return new RegExp((u?g:r).slice(1,-1),u);var c=r.replace(/\\\\\'/g,"\'").replace(/\\\\"/g,\'"\').replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&");return new RegExp(c)}function getPrunePath(t){var r=".[=].";if("string"==typeof t&&void 0!==t&&""!==t){var e=function(t){for(var e=[],n="",i=0,o=!1,s=!1;i<t.length;){var a=t[i];if(o)n+=a,"\\\\"===a?s=!s:("/"!==a||s||(o=!1),s=!1),i+=1;else{if(" "===a||"\\n"===a||"\\t"===a||"\\r"===a||"\\f"===a||"\\v"===a){for(;i<t.length&&/\\s/.test(t[i]);)i+=1;""!==n&&(e.push(n),n="");continue}if(t.startsWith(r,i)){if(n+=r,"/"===t[i+=5]){o=!0,s=!1,n+="/",i+=1;continue}continue}n+=a,i+=1}}return""!==n&&e.push(n),e}(t),n=e.map((function(t){var e=t.split(r),n=e[0],i=e[1];return void 0!==i?("true"===i?i=!0:"false"===i?i=!1:i.startsWith("/")?i=toRegExp(i):"string"==typeof i&&/^\\d+$/.test(i)&&(i=parseFloat(i)),{path:n,value:i}):{path:n}}));return console.log("parts",n),n}return[]}function restoreRegExpValues(e){if(e.length)try{var r;r=1===e.length?`(${e[0]})`:e.reduce((function(e,r,t){return 1===t?`(${e}),(${r})`:`${e},(${r})`}));var t=new RegExp(r);e.toString().replace(t,"")}catch(e){var n=`Failed to restore RegExp values: ${e}`;console.log(n)}}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,propsToRemove,requiredInitialProps,stack){var prunePaths=getPrunePath(propsToRemove),requiredPaths=getPrunePath(requiredInitialProps),nativeObjects={nativeStringify:window.JSON.stringify},evalHandler={apply:function(target,thisArg,args){var data=Reflect.apply(target,thisArg,args);return"object"==typeof data&&(data=function(e,r,n,a,t,i){var{nativeStringify:o}=i;if(0===n.length&&0===a.length)return logMessage(e,`${window.location.hostname}\\n${o(r,null,2)}\\nStack trace:\\n${(new Error).stack}`,!0),r&&"object"==typeof r&&logMessage(e,r,!0,!1),r;try{if(!1===function(n,t,r,e,a,i){if(!t)return!1;var o,{nativeStringify:u}=i,c=r.map((function(n){return n.path})),f=e.map((function(n){return n.path}));if(0===c.length&&f.length>0){var g=u(t);if(toRegExp(f.join("")).test(g))return logMessage(n,`${window.location.hostname}\\n${u(t,null,2)}\\nStack trace:\\n${(new Error).stack}`,!0),t&&"object"==typeof t&&logMessage(n,t,!0,!1),o=!1}if(a&&!function(e,t){if(!e||""===e)return!0;var r=function(){try{for(var r=[],e=1;e<10;e+=1){var a=`$${e}`;if(!RegExp[a])break;r.push(RegExp[a])}return r}catch(r){return[]}}();if(function(t,i){var r="inlineScript",n="injectedScript",isInlineScript=function(t){return t.includes(r)},isInjectedScript=function(t){return t.includes(n)};if(!isInlineScript(t)&&!isInjectedScript(t))return!1;var e=window.location.href,s=e.indexOf("#");-1!==s&&(e=e.slice(0,s));var c=i.split("\\n").slice(2).map((function(t){return t.trim()})).map((function(t){var i,s=/(.*?@)?(\\S+)(:\\d+)(:\\d+)\\)?$/.exec(t);if(s){var c,l,a=s[2],u=s[3],o=s[4];if(null!==(c=a)&&void 0!==c&&c.startsWith("(")&&(a=a.slice(1)),null!==(l=a)&&void 0!==l&&l.startsWith("<anonymous>")){var d;a=n;var f=void 0!==s[1]?s[1].slice(0,-1):t.slice(0,s.index).trim();null!==(d=f)&&void 0!==d&&d.startsWith("at")&&(f=f.slice(2).trim()),i=`${f} ${a}${u}${o}`.trim()}else i=a===e?`${r}${u}${o}`.trim():`${a}${u}${o}`.trim()}else i=t;return i}));if(c)for(var l=0;l<c.length;l+=1){if(isInlineScript(t)&&c[l].startsWith(r)&&c[l].match(toRegExp(t)))return!0;if(isInjectedScript(t)&&c[l].startsWith(n)&&c[l].match(toRegExp(t)))return!0}return!1}(e,t))return r.length&&r[0]!==RegExp.$1&&restoreRegExpValues(r),!0;var n=toRegExp(e),a=t.split("\\n").slice(2).map((function(e){return e.trim()})).join("\\n");return r.length&&r[0]!==RegExp.$1&&restoreRegExpValues(r),function(){var t=Object.getOwnPropertyDescriptor(RegExp.prototype,"test"),e=null==t?void 0:t.value;if(t&&"function"==typeof t.value)return e;throw new Error("RegExp.prototype.test is not a function")}().call(n,a)}(a,(new Error).stack||""))return o=!1;for(var s,l=[".*.","*.",".*",".[].","[].",".[]"],_loop=function(){var n=f[p],r=n.split(".").pop(),e=l.some((function(t){return n.includes(t)})),a=getWildcardPropertyInChain(t,n,e);if(!a.length)return{v:o=!1};o=!e;for(var i=0;i<a.length;i+=1){var u="string"==typeof r&&void 0!==a[i].base[r];o=e?u||o:u&&o}},p=0;p<f.length;p+=1)if(s=_loop())return s.v;return o}(e,r,n,a,t,i))return r;n.forEach((function(n){for(var a=n.path,t=n.value,i=getWildcardPropertyInChain(r,a,!0,[],t),o=i.length-1;o>=0;o-=1){var s=i[o];if(void 0!==s&&s.base)if(hit(e),Array.isArray(s.base))try{var l=Number(s.prop);if(Number.isNaN(l))continue;s.base.splice(l,1)}catch(e){console.error("Error while deleting array element",e)}else delete s.base[s.prop]}}))}catch(r){logMessage(e,r)}return r}(source,data,prunePaths,requiredPaths,stack,nativeObjects)),data}};window.eval=new Proxy(window.eval,evalHandler)}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['hide-in-shadow-dom'],
            scriptlet: 'function hideInShadowDom(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function findHostElements(o){var n=[];return o&&o.querySelectorAll("*").forEach((function(o){o.shadowRoot&&n.push(o)})),n}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,selector,baseSelector){if(Element.prototype.attachShadow){var hideHandler=function(){for(var hostElements=baseSelector?document.querySelectorAll(baseSelector):findHostElements(document.documentElement),_loop=function(){var isHidden=!1,{targets:targets,innerHosts:innerHosts}=function(e,t){var c=[],l=[];t.forEach((function(t){var o=t.querySelectorAll(e);c=c.concat([].slice.call(o));var r=t.shadowRoot,a=r.querySelectorAll(e);c=c.concat([].slice.call(a)),l.push(findHostElements(r))}));var o=function(r){var n=[];r.forEach((function(r){return n.push(r)}));for(var t=[];n.length;){var u=n.pop();Array.isArray(u)?u.forEach((function(r){return n.push(r)})):t.push(u)}return t.reverse()}(l);return{targets:c,innerHosts:o}}(selector,hostElements);targets.forEach((function(targetEl){targetEl.style.cssText="display:none!important;",isHidden=!0})),isHidden&&function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source),hostElements=innerHosts};0!==hostElements.length;)_loop()};hideHandler(),function(t){var e=arguments.length>1&&void 0!==arguments[1]&&arguments[1],n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:[],i=new MutationObserver(function(n,t){var r,e=!1,_wrapper=function(){for(var o=arguments.length,u=new Array(o),f=0;f<o;f++)u[f]=arguments[f];e?r=u:(n(...u),e=!0,setTimeout((function(){e=!1,r&&(_wrapper(...r),r=null)}),t))};return _wrapper}((function(){disconnect(),t(),connect()}),20)),connect=function(){n.length>0?i.observe(document.documentElement,{childList:!0,subtree:!0,attributes:e,attributeFilter:n}):i.observe(document.documentElement,{childList:!0,subtree:!0,attributes:e})},disconnect=function(){i.disconnect()};connect()}(hideHandler,!0)}}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['href-sanitizer', 'href-sanitizer.js', 'ubo-href-sanitizer.js', 'ubo-href-sanitizer'],
            scriptlet: 'function hrefSanitizer(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function logMessage(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,selector){var attribute=arguments.length>2&&void 0!==arguments[2]?arguments[2]:"text",transform=arguments.length>3&&void 0!==arguments[3]?arguments[3]:"";if(selector){var BASE64_DECODE_TRANSFORM_MARKER=new Set(["base64decode","-base64"]),regexpNotValidAtStart=/^[^!-~\\xAA\\xB5\\xBA\\xC0-\\xD6\\xD8-\\xF6\\xF8-\\u02C1\\u02C6-\\u02D1\\u02E0-\\u02E4\\u02EC\\u02EE\\u0370-\\u0374\\u0376\\u0377\\u037A-\\u037D\\u037F\\u0386\\u0388-\\u038A\\u038C\\u038E-\\u03A1\\u03A3-\\u03F5\\u03F7-\\u0481\\u048A-\\u052F\\u0531-\\u0556\\u0559\\u0560-\\u0588\\u05D0-\\u05EA\\u05EF-\\u05F2\\u0620-\\u064A\\u066E\\u066F\\u0671-\\u06D3\\u06D5\\u06E5\\u06E6\\u06EE\\u06EF\\u06FA-\\u06FC\\u06FF\\u0710\\u0712-\\u072F\\u074D-\\u07A5\\u07B1\\u07CA-\\u07EA\\u07F4\\u07F5\\u07FA\\u0800-\\u0815\\u081A\\u0824\\u0828\\u0840-\\u0858\\u0860-\\u086A\\u0870-\\u0887\\u0889-\\u088E\\u08A0-\\u08C9\\u0904-\\u0939\\u093D\\u0950\\u0958-\\u0961\\u0971-\\u0980\\u0985-\\u098C\\u098F\\u0990\\u0993-\\u09A8\\u09AA-\\u09B0\\u09B2\\u09B6-\\u09B9\\u09BD\\u09CE\\u09DC\\u09DD\\u09DF-\\u09E1\\u09F0\\u09F1\\u09FC\\u0A05-\\u0A0A\\u0A0F\\u0A10\\u0A13-\\u0A28\\u0A2A-\\u0A30\\u0A32\\u0A33\\u0A35\\u0A36\\u0A38\\u0A39\\u0A59-\\u0A5C\\u0A5E\\u0A72-\\u0A74\\u0A85-\\u0A8D\\u0A8F-\\u0A91\\u0A93-\\u0AA8\\u0AAA-\\u0AB0\\u0AB2\\u0AB3\\u0AB5-\\u0AB9\\u0ABD\\u0AD0\\u0AE0\\u0AE1\\u0AF9\\u0B05-\\u0B0C\\u0B0F\\u0B10\\u0B13-\\u0B28\\u0B2A-\\u0B30\\u0B32\\u0B33\\u0B35-\\u0B39\\u0B3D\\u0B5C\\u0B5D\\u0B5F-\\u0B61\\u0B71\\u0B83\\u0B85-\\u0B8A\\u0B8E-\\u0B90\\u0B92-\\u0B95\\u0B99\\u0B9A\\u0B9C\\u0B9E\\u0B9F\\u0BA3\\u0BA4\\u0BA8-\\u0BAA\\u0BAE-\\u0BB9\\u0BD0\\u0C05-\\u0C0C\\u0C0E-\\u0C10\\u0C12-\\u0C28\\u0C2A-\\u0C39\\u0C3D\\u0C58-\\u0C5A\\u0C5D\\u0C60\\u0C61\\u0C80\\u0C85-\\u0C8C\\u0C8E-\\u0C90\\u0C92-\\u0CA8\\u0CAA-\\u0CB3\\u0CB5-\\u0CB9\\u0CBD\\u0CDD\\u0CDE\\u0CE0\\u0CE1\\u0CF1\\u0CF2\\u0D04-\\u0D0C\\u0D0E-\\u0D10\\u0D12-\\u0D3A\\u0D3D\\u0D4E\\u0D54-\\u0D56\\u0D5F-\\u0D61\\u0D7A-\\u0D7F\\u0D85-\\u0D96\\u0D9A-\\u0DB1\\u0DB3-\\u0DBB\\u0DBD\\u0DC0-\\u0DC6\\u0E01-\\u0E30\\u0E32\\u0E33\\u0E40-\\u0E46\\u0E81\\u0E82\\u0E84\\u0E86-\\u0E8A\\u0E8C-\\u0EA3\\u0EA5\\u0EA7-\\u0EB0\\u0EB2\\u0EB3\\u0EBD\\u0EC0-\\u0EC4\\u0EC6\\u0EDC-\\u0EDF\\u0F00\\u0F40-\\u0F47\\u0F49-\\u0F6C\\u0F88-\\u0F8C\\u1000-\\u102A\\u103F\\u1050-\\u1055\\u105A-\\u105D\\u1061\\u1065\\u1066\\u106E-\\u1070\\u1075-\\u1081\\u108E\\u10A0-\\u10C5\\u10C7\\u10CD\\u10D0-\\u10FA\\u10FC-\\u1248\\u124A-\\u124D\\u1250-\\u1256\\u1258\\u125A-\\u125D\\u1260-\\u1288\\u128A-\\u128D\\u1290-\\u12B0\\u12B2-\\u12B5\\u12B8-\\u12BE\\u12C0\\u12C2-\\u12C5\\u12C8-\\u12D6\\u12D8-\\u1310\\u1312-\\u1315\\u1318-\\u135A\\u1380-\\u138F\\u13A0-\\u13F5\\u13F8-\\u13FD\\u1401-\\u166C\\u166F-\\u167F\\u1681-\\u169A\\u16A0-\\u16EA\\u16F1-\\u16F8\\u1700-\\u1711\\u171F-\\u1731\\u1740-\\u1751\\u1760-\\u176C\\u176E-\\u1770\\u1780-\\u17B3\\u17D7\\u17DC\\u1820-\\u1878\\u1880-\\u1884\\u1887-\\u18A8\\u18AA\\u18B0-\\u18F5\\u1900-\\u191E\\u1950-\\u196D\\u1970-\\u1974\\u1980-\\u19AB\\u19B0-\\u19C9\\u1A00-\\u1A16\\u1A20-\\u1A54\\u1AA7\\u1B05-\\u1B33\\u1B45-\\u1B4C\\u1B83-\\u1BA0\\u1BAE\\u1BAF\\u1BBA-\\u1BE5\\u1C00-\\u1C23\\u1C4D-\\u1C4F\\u1C5A-\\u1C7D\\u1C80-\\u1C8A\\u1C90-\\u1CBA\\u1CBD-\\u1CBF\\u1CE9-\\u1CEC\\u1CEE-\\u1CF3\\u1CF5\\u1CF6\\u1CFA\\u1D00-\\u1DBF\\u1E00-\\u1F15\\u1F18-\\u1F1D\\u1F20-\\u1F45\\u1F48-\\u1F4D\\u1F50-\\u1F57\\u1F59\\u1F5B\\u1F5D\\u1F5F-\\u1F7D\\u1F80-\\u1FB4\\u1FB6-\\u1FBC\\u1FBE\\u1FC2-\\u1FC4\\u1FC6-\\u1FCC\\u1FD0-\\u1FD3\\u1FD6-\\u1FDB\\u1FE0-\\u1FEC\\u1FF2-\\u1FF4\\u1FF6-\\u1FFC\\u2071\\u207F\\u2090-\\u209C\\u2102\\u2107\\u210A-\\u2113\\u2115\\u2119-\\u211D\\u2124\\u2126\\u2128\\u212A-\\u212D\\u212F-\\u2139\\u213C-\\u213F\\u2145-\\u2149\\u214E\\u2183\\u2184\\u2C00-\\u2CE4\\u2CEB-\\u2CEE\\u2CF2\\u2CF3\\u2D00-\\u2D25\\u2D27\\u2D2D\\u2D30-\\u2D67\\u2D6F\\u2D80-\\u2D96\\u2DA0-\\u2DA6\\u2DA8-\\u2DAE\\u2DB0-\\u2DB6\\u2DB8-\\u2DBE\\u2DC0-\\u2DC6\\u2DC8-\\u2DCE\\u2DD0-\\u2DD6\\u2DD8-\\u2DDE\\u2E2F\\u3005\\u3006\\u3031-\\u3035\\u303B\\u303C\\u3041-\\u3096\\u309D-\\u309F\\u30A1-\\u30FA\\u30FC-\\u30FF\\u3105-\\u312F\\u3131-\\u318E\\u31A0-\\u31BF\\u31F0-\\u31FF\\u3400-\\u4DBF\\u4E00-\\uA48C\\uA4D0-\\uA4FD\\uA500-\\uA60C\\uA610-\\uA61F\\uA62A\\uA62B\\uA640-\\uA66E\\uA67F-\\uA69D\\uA6A0-\\uA6E5\\uA717-\\uA71F\\uA722-\\uA788\\uA78B-\\uA7CD\\uA7D0\\uA7D1\\uA7D3\\uA7D5-\\uA7DC\\uA7F2-\\uA801\\uA803-\\uA805\\uA807-\\uA80A\\uA80C-\\uA822\\uA840-\\uA873\\uA882-\\uA8B3\\uA8F2-\\uA8F7\\uA8FB\\uA8FD\\uA8FE\\uA90A-\\uA925\\uA930-\\uA946\\uA960-\\uA97C\\uA984-\\uA9B2\\uA9CF\\uA9E0-\\uA9E4\\uA9E6-\\uA9EF\\uA9FA-\\uA9FE\\uAA00-\\uAA28\\uAA40-\\uAA42\\uAA44-\\uAA4B\\uAA60-\\uAA76\\uAA7A\\uAA7E-\\uAAAF\\uAAB1\\uAAB5\\uAAB6\\uAAB9-\\uAABD\\uAAC0\\uAAC2\\uAADB-\\uAADD\\uAAE0-\\uAAEA\\uAAF2-\\uAAF4\\uAB01-\\uAB06\\uAB09-\\uAB0E\\uAB11-\\uAB16\\uAB20-\\uAB26\\uAB28-\\uAB2E\\uAB30-\\uAB5A\\uAB5C-\\uAB69\\uAB70-\\uABE2\\uAC00-\\uD7A3\\uD7B0-\\uD7C6\\uD7CB-\\uD7FB\\uF900-\\uFA6D\\uFA70-\\uFAD9\\uFB00-\\uFB06\\uFB13-\\uFB17\\uFB1D\\uFB1F-\\uFB28\\uFB2A-\\uFB36\\uFB38-\\uFB3C\\uFB3E\\uFB40\\uFB41\\uFB43\\uFB44\\uFB46-\\uFBB1\\uFBD3-\\uFD3D\\uFD50-\\uFD8F\\uFD92-\\uFDC7\\uFDF0-\\uFDFB\\uFE70-\\uFE74\\uFE76-\\uFEFC\\uFF21-\\uFF3A\\uFF41-\\uFF5A\\uFF66-\\uFFBE\\uFFC2-\\uFFC7\\uFFCA-\\uFFCF\\uFFD2-\\uFFD7\\uFFDA-\\uFFDC\\u{10000}-\\u{1000B}\\u{1000D}-\\u{10026}\\u{10028}-\\u{1003A}\\u{1003C}\\u{1003D}\\u{1003F}-\\u{1004D}\\u{10050}-\\u{1005D}\\u{10080}-\\u{100FA}\\u{10280}-\\u{1029C}\\u{102A0}-\\u{102D0}\\u{10300}-\\u{1031F}\\u{1032D}-\\u{10340}\\u{10342}-\\u{10349}\\u{10350}-\\u{10375}\\u{10380}-\\u{1039D}\\u{103A0}-\\u{103C3}\\u{103C8}-\\u{103CF}\\u{10400}-\\u{1049D}\\u{104B0}-\\u{104D3}\\u{104D8}-\\u{104FB}\\u{10500}-\\u{10527}\\u{10530}-\\u{10563}\\u{10570}-\\u{1057A}\\u{1057C}-\\u{1058A}\\u{1058C}-\\u{10592}\\u{10594}\\u{10595}\\u{10597}-\\u{105A1}\\u{105A3}-\\u{105B1}\\u{105B3}-\\u{105B9}\\u{105BB}\\u{105BC}\\u{105C0}-\\u{105F3}\\u{10600}-\\u{10736}\\u{10740}-\\u{10755}\\u{10760}-\\u{10767}\\u{10780}-\\u{10785}\\u{10787}-\\u{107B0}\\u{107B2}-\\u{107BA}\\u{10800}-\\u{10805}\\u{10808}\\u{1080A}-\\u{10835}\\u{10837}\\u{10838}\\u{1083C}\\u{1083F}-\\u{10855}\\u{10860}-\\u{10876}\\u{10880}-\\u{1089E}\\u{108E0}-\\u{108F2}\\u{108F4}\\u{108F5}\\u{10900}-\\u{10915}\\u{10920}-\\u{10939}\\u{10980}-\\u{109B7}\\u{109BE}\\u{109BF}\\u{10A00}\\u{10A10}-\\u{10A13}\\u{10A15}-\\u{10A17}\\u{10A19}-\\u{10A35}\\u{10A60}-\\u{10A7C}\\u{10A80}-\\u{10A9C}\\u{10AC0}-\\u{10AC7}\\u{10AC9}-\\u{10AE4}\\u{10B00}-\\u{10B35}\\u{10B40}-\\u{10B55}\\u{10B60}-\\u{10B72}\\u{10B80}-\\u{10B91}\\u{10C00}-\\u{10C48}\\u{10C80}-\\u{10CB2}\\u{10CC0}-\\u{10CF2}\\u{10D00}-\\u{10D23}\\u{10D4A}-\\u{10D65}\\u{10D6F}-\\u{10D85}\\u{10E80}-\\u{10EA9}\\u{10EB0}\\u{10EB1}\\u{10EC2}-\\u{10EC4}\\u{10F00}-\\u{10F1C}\\u{10F27}\\u{10F30}-\\u{10F45}\\u{10F70}-\\u{10F81}\\u{10FB0}-\\u{10FC4}\\u{10FE0}-\\u{10FF6}\\u{11003}-\\u{11037}\\u{11071}\\u{11072}\\u{11075}\\u{11083}-\\u{110AF}\\u{110D0}-\\u{110E8}\\u{11103}-\\u{11126}\\u{11144}\\u{11147}\\u{11150}-\\u{11172}\\u{11176}\\u{11183}-\\u{111B2}\\u{111C1}-\\u{111C4}\\u{111DA}\\u{111DC}\\u{11200}-\\u{11211}\\u{11213}-\\u{1122B}\\u{1123F}\\u{11240}\\u{11280}-\\u{11286}\\u{11288}\\u{1128A}-\\u{1128D}\\u{1128F}-\\u{1129D}\\u{1129F}-\\u{112A8}\\u{112B0}-\\u{112DE}\\u{11305}-\\u{1130C}\\u{1130F}\\u{11310}\\u{11313}-\\u{11328}\\u{1132A}-\\u{11330}\\u{11332}\\u{11333}\\u{11335}-\\u{11339}\\u{1133D}\\u{11350}\\u{1135D}-\\u{11361}\\u{11380}-\\u{11389}\\u{1138B}\\u{1138E}\\u{11390}-\\u{113B5}\\u{113B7}\\u{113D1}\\u{113D3}\\u{11400}-\\u{11434}\\u{11447}-\\u{1144A}\\u{1145F}-\\u{11461}\\u{11480}-\\u{114AF}\\u{114C4}\\u{114C5}\\u{114C7}\\u{11580}-\\u{115AE}\\u{115D8}-\\u{115DB}\\u{11600}-\\u{1162F}\\u{11644}\\u{11680}-\\u{116AA}\\u{116B8}\\u{11700}-\\u{1171A}\\u{11740}-\\u{11746}\\u{11800}-\\u{1182B}\\u{118A0}-\\u{118DF}\\u{118FF}-\\u{11906}\\u{11909}\\u{1190C}-\\u{11913}\\u{11915}\\u{11916}\\u{11918}-\\u{1192F}\\u{1193F}\\u{11941}\\u{119A0}-\\u{119A7}\\u{119AA}-\\u{119D0}\\u{119E1}\\u{119E3}\\u{11A00}\\u{11A0B}-\\u{11A32}\\u{11A3A}\\u{11A50}\\u{11A5C}-\\u{11A89}\\u{11A9D}\\u{11AB0}-\\u{11AF8}\\u{11BC0}-\\u{11BE0}\\u{11C00}-\\u{11C08}\\u{11C0A}-\\u{11C2E}\\u{11C40}\\u{11C72}-\\u{11C8F}\\u{11D00}-\\u{11D06}\\u{11D08}\\u{11D09}\\u{11D0B}-\\u{11D30}\\u{11D46}\\u{11D60}-\\u{11D65}\\u{11D67}\\u{11D68}\\u{11D6A}-\\u{11D89}\\u{11D98}\\u{11EE0}-\\u{11EF2}\\u{11F02}\\u{11F04}-\\u{11F10}\\u{11F12}-\\u{11F33}\\u{11FB0}\\u{12000}-\\u{12399}\\u{12480}-\\u{12543}\\u{12F90}-\\u{12FF0}\\u{13000}-\\u{1342F}\\u{13441}-\\u{13446}\\u{13460}-\\u{143FA}\\u{14400}-\\u{14646}\\u{16100}-\\u{1611D}\\u{16800}-\\u{16A38}\\u{16A40}-\\u{16A5E}\\u{16A70}-\\u{16ABE}\\u{16AD0}-\\u{16AED}\\u{16B00}-\\u{16B2F}\\u{16B40}-\\u{16B43}\\u{16B63}-\\u{16B77}\\u{16B7D}-\\u{16B8F}\\u{16D40}-\\u{16D6C}\\u{16E40}-\\u{16E7F}\\u{16F00}-\\u{16F4A}\\u{16F50}\\u{16F93}-\\u{16F9F}\\u{16FE0}\\u{16FE1}\\u{16FE3}\\u{17000}-\\u{187F7}\\u{18800}-\\u{18CD5}\\u{18CFF}-\\u{18D08}\\u{1AFF0}-\\u{1AFF3}\\u{1AFF5}-\\u{1AFFB}\\u{1AFFD}\\u{1AFFE}\\u{1B000}-\\u{1B122}\\u{1B132}\\u{1B150}-\\u{1B152}\\u{1B155}\\u{1B164}-\\u{1B167}\\u{1B170}-\\u{1B2FB}\\u{1BC00}-\\u{1BC6A}\\u{1BC70}-\\u{1BC7C}\\u{1BC80}-\\u{1BC88}\\u{1BC90}-\\u{1BC99}\\u{1D400}-\\u{1D454}\\u{1D456}-\\u{1D49C}\\u{1D49E}\\u{1D49F}\\u{1D4A2}\\u{1D4A5}\\u{1D4A6}\\u{1D4A9}-\\u{1D4AC}\\u{1D4AE}-\\u{1D4B9}\\u{1D4BB}\\u{1D4BD}-\\u{1D4C3}\\u{1D4C5}-\\u{1D505}\\u{1D507}-\\u{1D50A}\\u{1D50D}-\\u{1D514}\\u{1D516}-\\u{1D51C}\\u{1D51E}-\\u{1D539}\\u{1D53B}-\\u{1D53E}\\u{1D540}-\\u{1D544}\\u{1D546}\\u{1D54A}-\\u{1D550}\\u{1D552}-\\u{1D6A5}\\u{1D6A8}-\\u{1D6C0}\\u{1D6C2}-\\u{1D6DA}\\u{1D6DC}-\\u{1D6FA}\\u{1D6FC}-\\u{1D714}\\u{1D716}-\\u{1D734}\\u{1D736}-\\u{1D74E}\\u{1D750}-\\u{1D76E}\\u{1D770}-\\u{1D788}\\u{1D78A}-\\u{1D7A8}\\u{1D7AA}-\\u{1D7C2}\\u{1D7C4}-\\u{1D7CB}\\u{1DF00}-\\u{1DF1E}\\u{1DF25}-\\u{1DF2A}\\u{1E030}-\\u{1E06D}\\u{1E100}-\\u{1E12C}\\u{1E137}-\\u{1E13D}\\u{1E14E}\\u{1E290}-\\u{1E2AD}\\u{1E2C0}-\\u{1E2EB}\\u{1E4D0}-\\u{1E4EB}\\u{1E5D0}-\\u{1E5ED}\\u{1E5F0}\\u{1E7E0}-\\u{1E7E6}\\u{1E7E8}-\\u{1E7EB}\\u{1E7ED}\\u{1E7EE}\\u{1E7F0}-\\u{1E7FE}\\u{1E800}-\\u{1E8C4}\\u{1E900}-\\u{1E943}\\u{1E94B}\\u{1EE00}-\\u{1EE03}\\u{1EE05}-\\u{1EE1F}\\u{1EE21}\\u{1EE22}\\u{1EE24}\\u{1EE27}\\u{1EE29}-\\u{1EE32}\\u{1EE34}-\\u{1EE37}\\u{1EE39}\\u{1EE3B}\\u{1EE42}\\u{1EE47}\\u{1EE49}\\u{1EE4B}\\u{1EE4D}-\\u{1EE4F}\\u{1EE51}\\u{1EE52}\\u{1EE54}\\u{1EE57}\\u{1EE59}\\u{1EE5B}\\u{1EE5D}\\u{1EE5F}\\u{1EE61}\\u{1EE62}\\u{1EE64}\\u{1EE67}-\\u{1EE6A}\\u{1EE6C}-\\u{1EE72}\\u{1EE74}-\\u{1EE77}\\u{1EE79}-\\u{1EE7C}\\u{1EE7E}\\u{1EE80}-\\u{1EE89}\\u{1EE8B}-\\u{1EE9B}\\u{1EEA1}-\\u{1EEA3}\\u{1EEA5}-\\u{1EEA9}\\u{1EEAB}-\\u{1EEBB}\\u{20000}-\\u{2A6DF}\\u{2A700}-\\u{2B739}\\u{2B740}-\\u{2B81D}\\u{2B820}-\\u{2CEA1}\\u{2CEB0}-\\u{2EBE0}\\u{2EBF0}-\\u{2EE5D}\\u{2F800}-\\u{2FA1D}\\u{30000}-\\u{3134A}\\u{31350}-\\u{323AF}]+/u,regexpNotValidAtEnd=/[^!-~\\xAA\\xB5\\xBA\\xC0-\\xD6\\xD8-\\xF6\\xF8-\\u02C1\\u02C6-\\u02D1\\u02E0-\\u02E4\\u02EC\\u02EE\\u0370-\\u0374\\u0376\\u0377\\u037A-\\u037D\\u037F\\u0386\\u0388-\\u038A\\u038C\\u038E-\\u03A1\\u03A3-\\u03F5\\u03F7-\\u0481\\u048A-\\u052F\\u0531-\\u0556\\u0559\\u0560-\\u0588\\u05D0-\\u05EA\\u05EF-\\u05F2\\u0620-\\u064A\\u066E\\u066F\\u0671-\\u06D3\\u06D5\\u06E5\\u06E6\\u06EE\\u06EF\\u06FA-\\u06FC\\u06FF\\u0710\\u0712-\\u072F\\u074D-\\u07A5\\u07B1\\u07CA-\\u07EA\\u07F4\\u07F5\\u07FA\\u0800-\\u0815\\u081A\\u0824\\u0828\\u0840-\\u0858\\u0860-\\u086A\\u0870-\\u0887\\u0889-\\u088E\\u08A0-\\u08C9\\u0904-\\u0939\\u093D\\u0950\\u0958-\\u0961\\u0971-\\u0980\\u0985-\\u098C\\u098F\\u0990\\u0993-\\u09A8\\u09AA-\\u09B0\\u09B2\\u09B6-\\u09B9\\u09BD\\u09CE\\u09DC\\u09DD\\u09DF-\\u09E1\\u09F0\\u09F1\\u09FC\\u0A05-\\u0A0A\\u0A0F\\u0A10\\u0A13-\\u0A28\\u0A2A-\\u0A30\\u0A32\\u0A33\\u0A35\\u0A36\\u0A38\\u0A39\\u0A59-\\u0A5C\\u0A5E\\u0A72-\\u0A74\\u0A85-\\u0A8D\\u0A8F-\\u0A91\\u0A93-\\u0AA8\\u0AAA-\\u0AB0\\u0AB2\\u0AB3\\u0AB5-\\u0AB9\\u0ABD\\u0AD0\\u0AE0\\u0AE1\\u0AF9\\u0B05-\\u0B0C\\u0B0F\\u0B10\\u0B13-\\u0B28\\u0B2A-\\u0B30\\u0B32\\u0B33\\u0B35-\\u0B39\\u0B3D\\u0B5C\\u0B5D\\u0B5F-\\u0B61\\u0B71\\u0B83\\u0B85-\\u0B8A\\u0B8E-\\u0B90\\u0B92-\\u0B95\\u0B99\\u0B9A\\u0B9C\\u0B9E\\u0B9F\\u0BA3\\u0BA4\\u0BA8-\\u0BAA\\u0BAE-\\u0BB9\\u0BD0\\u0C05-\\u0C0C\\u0C0E-\\u0C10\\u0C12-\\u0C28\\u0C2A-\\u0C39\\u0C3D\\u0C58-\\u0C5A\\u0C5D\\u0C60\\u0C61\\u0C80\\u0C85-\\u0C8C\\u0C8E-\\u0C90\\u0C92-\\u0CA8\\u0CAA-\\u0CB3\\u0CB5-\\u0CB9\\u0CBD\\u0CDD\\u0CDE\\u0CE0\\u0CE1\\u0CF1\\u0CF2\\u0D04-\\u0D0C\\u0D0E-\\u0D10\\u0D12-\\u0D3A\\u0D3D\\u0D4E\\u0D54-\\u0D56\\u0D5F-\\u0D61\\u0D7A-\\u0D7F\\u0D85-\\u0D96\\u0D9A-\\u0DB1\\u0DB3-\\u0DBB\\u0DBD\\u0DC0-\\u0DC6\\u0E01-\\u0E30\\u0E32\\u0E33\\u0E40-\\u0E46\\u0E81\\u0E82\\u0E84\\u0E86-\\u0E8A\\u0E8C-\\u0EA3\\u0EA5\\u0EA7-\\u0EB0\\u0EB2\\u0EB3\\u0EBD\\u0EC0-\\u0EC4\\u0EC6\\u0EDC-\\u0EDF\\u0F00\\u0F40-\\u0F47\\u0F49-\\u0F6C\\u0F88-\\u0F8C\\u1000-\\u102A\\u103F\\u1050-\\u1055\\u105A-\\u105D\\u1061\\u1065\\u1066\\u106E-\\u1070\\u1075-\\u1081\\u108E\\u10A0-\\u10C5\\u10C7\\u10CD\\u10D0-\\u10FA\\u10FC-\\u1248\\u124A-\\u124D\\u1250-\\u1256\\u1258\\u125A-\\u125D\\u1260-\\u1288\\u128A-\\u128D\\u1290-\\u12B0\\u12B2-\\u12B5\\u12B8-\\u12BE\\u12C0\\u12C2-\\u12C5\\u12C8-\\u12D6\\u12D8-\\u1310\\u1312-\\u1315\\u1318-\\u135A\\u1380-\\u138F\\u13A0-\\u13F5\\u13F8-\\u13FD\\u1401-\\u166C\\u166F-\\u167F\\u1681-\\u169A\\u16A0-\\u16EA\\u16F1-\\u16F8\\u1700-\\u1711\\u171F-\\u1731\\u1740-\\u1751\\u1760-\\u176C\\u176E-\\u1770\\u1780-\\u17B3\\u17D7\\u17DC\\u1820-\\u1878\\u1880-\\u1884\\u1887-\\u18A8\\u18AA\\u18B0-\\u18F5\\u1900-\\u191E\\u1950-\\u196D\\u1970-\\u1974\\u1980-\\u19AB\\u19B0-\\u19C9\\u1A00-\\u1A16\\u1A20-\\u1A54\\u1AA7\\u1B05-\\u1B33\\u1B45-\\u1B4C\\u1B83-\\u1BA0\\u1BAE\\u1BAF\\u1BBA-\\u1BE5\\u1C00-\\u1C23\\u1C4D-\\u1C4F\\u1C5A-\\u1C7D\\u1C80-\\u1C8A\\u1C90-\\u1CBA\\u1CBD-\\u1CBF\\u1CE9-\\u1CEC\\u1CEE-\\u1CF3\\u1CF5\\u1CF6\\u1CFA\\u1D00-\\u1DBF\\u1E00-\\u1F15\\u1F18-\\u1F1D\\u1F20-\\u1F45\\u1F48-\\u1F4D\\u1F50-\\u1F57\\u1F59\\u1F5B\\u1F5D\\u1F5F-\\u1F7D\\u1F80-\\u1FB4\\u1FB6-\\u1FBC\\u1FBE\\u1FC2-\\u1FC4\\u1FC6-\\u1FCC\\u1FD0-\\u1FD3\\u1FD6-\\u1FDB\\u1FE0-\\u1FEC\\u1FF2-\\u1FF4\\u1FF6-\\u1FFC\\u2071\\u207F\\u2090-\\u209C\\u2102\\u2107\\u210A-\\u2113\\u2115\\u2119-\\u211D\\u2124\\u2126\\u2128\\u212A-\\u212D\\u212F-\\u2139\\u213C-\\u213F\\u2145-\\u2149\\u214E\\u2183\\u2184\\u2C00-\\u2CE4\\u2CEB-\\u2CEE\\u2CF2\\u2CF3\\u2D00-\\u2D25\\u2D27\\u2D2D\\u2D30-\\u2D67\\u2D6F\\u2D80-\\u2D96\\u2DA0-\\u2DA6\\u2DA8-\\u2DAE\\u2DB0-\\u2DB6\\u2DB8-\\u2DBE\\u2DC0-\\u2DC6\\u2DC8-\\u2DCE\\u2DD0-\\u2DD6\\u2DD8-\\u2DDE\\u2E2F\\u3005\\u3006\\u3031-\\u3035\\u303B\\u303C\\u3041-\\u3096\\u309D-\\u309F\\u30A1-\\u30FA\\u30FC-\\u30FF\\u3105-\\u312F\\u3131-\\u318E\\u31A0-\\u31BF\\u31F0-\\u31FF\\u3400-\\u4DBF\\u4E00-\\uA48C\\uA4D0-\\uA4FD\\uA500-\\uA60C\\uA610-\\uA61F\\uA62A\\uA62B\\uA640-\\uA66E\\uA67F-\\uA69D\\uA6A0-\\uA6E5\\uA717-\\uA71F\\uA722-\\uA788\\uA78B-\\uA7CD\\uA7D0\\uA7D1\\uA7D3\\uA7D5-\\uA7DC\\uA7F2-\\uA801\\uA803-\\uA805\\uA807-\\uA80A\\uA80C-\\uA822\\uA840-\\uA873\\uA882-\\uA8B3\\uA8F2-\\uA8F7\\uA8FB\\uA8FD\\uA8FE\\uA90A-\\uA925\\uA930-\\uA946\\uA960-\\uA97C\\uA984-\\uA9B2\\uA9CF\\uA9E0-\\uA9E4\\uA9E6-\\uA9EF\\uA9FA-\\uA9FE\\uAA00-\\uAA28\\uAA40-\\uAA42\\uAA44-\\uAA4B\\uAA60-\\uAA76\\uAA7A\\uAA7E-\\uAAAF\\uAAB1\\uAAB5\\uAAB6\\uAAB9-\\uAABD\\uAAC0\\uAAC2\\uAADB-\\uAADD\\uAAE0-\\uAAEA\\uAAF2-\\uAAF4\\uAB01-\\uAB06\\uAB09-\\uAB0E\\uAB11-\\uAB16\\uAB20-\\uAB26\\uAB28-\\uAB2E\\uAB30-\\uAB5A\\uAB5C-\\uAB69\\uAB70-\\uABE2\\uAC00-\\uD7A3\\uD7B0-\\uD7C6\\uD7CB-\\uD7FB\\uF900-\\uFA6D\\uFA70-\\uFAD9\\uFB00-\\uFB06\\uFB13-\\uFB17\\uFB1D\\uFB1F-\\uFB28\\uFB2A-\\uFB36\\uFB38-\\uFB3C\\uFB3E\\uFB40\\uFB41\\uFB43\\uFB44\\uFB46-\\uFBB1\\uFBD3-\\uFD3D\\uFD50-\\uFD8F\\uFD92-\\uFDC7\\uFDF0-\\uFDFB\\uFE70-\\uFE74\\uFE76-\\uFEFC\\uFF21-\\uFF3A\\uFF41-\\uFF5A\\uFF66-\\uFFBE\\uFFC2-\\uFFC7\\uFFCA-\\uFFCF\\uFFD2-\\uFFD7\\uFFDA-\\uFFDC\\u{10000}-\\u{1000B}\\u{1000D}-\\u{10026}\\u{10028}-\\u{1003A}\\u{1003C}\\u{1003D}\\u{1003F}-\\u{1004D}\\u{10050}-\\u{1005D}\\u{10080}-\\u{100FA}\\u{10280}-\\u{1029C}\\u{102A0}-\\u{102D0}\\u{10300}-\\u{1031F}\\u{1032D}-\\u{10340}\\u{10342}-\\u{10349}\\u{10350}-\\u{10375}\\u{10380}-\\u{1039D}\\u{103A0}-\\u{103C3}\\u{103C8}-\\u{103CF}\\u{10400}-\\u{1049D}\\u{104B0}-\\u{104D3}\\u{104D8}-\\u{104FB}\\u{10500}-\\u{10527}\\u{10530}-\\u{10563}\\u{10570}-\\u{1057A}\\u{1057C}-\\u{1058A}\\u{1058C}-\\u{10592}\\u{10594}\\u{10595}\\u{10597}-\\u{105A1}\\u{105A3}-\\u{105B1}\\u{105B3}-\\u{105B9}\\u{105BB}\\u{105BC}\\u{105C0}-\\u{105F3}\\u{10600}-\\u{10736}\\u{10740}-\\u{10755}\\u{10760}-\\u{10767}\\u{10780}-\\u{10785}\\u{10787}-\\u{107B0}\\u{107B2}-\\u{107BA}\\u{10800}-\\u{10805}\\u{10808}\\u{1080A}-\\u{10835}\\u{10837}\\u{10838}\\u{1083C}\\u{1083F}-\\u{10855}\\u{10860}-\\u{10876}\\u{10880}-\\u{1089E}\\u{108E0}-\\u{108F2}\\u{108F4}\\u{108F5}\\u{10900}-\\u{10915}\\u{10920}-\\u{10939}\\u{10980}-\\u{109B7}\\u{109BE}\\u{109BF}\\u{10A00}\\u{10A10}-\\u{10A13}\\u{10A15}-\\u{10A17}\\u{10A19}-\\u{10A35}\\u{10A60}-\\u{10A7C}\\u{10A80}-\\u{10A9C}\\u{10AC0}-\\u{10AC7}\\u{10AC9}-\\u{10AE4}\\u{10B00}-\\u{10B35}\\u{10B40}-\\u{10B55}\\u{10B60}-\\u{10B72}\\u{10B80}-\\u{10B91}\\u{10C00}-\\u{10C48}\\u{10C80}-\\u{10CB2}\\u{10CC0}-\\u{10CF2}\\u{10D00}-\\u{10D23}\\u{10D4A}-\\u{10D65}\\u{10D6F}-\\u{10D85}\\u{10E80}-\\u{10EA9}\\u{10EB0}\\u{10EB1}\\u{10EC2}-\\u{10EC4}\\u{10F00}-\\u{10F1C}\\u{10F27}\\u{10F30}-\\u{10F45}\\u{10F70}-\\u{10F81}\\u{10FB0}-\\u{10FC4}\\u{10FE0}-\\u{10FF6}\\u{11003}-\\u{11037}\\u{11071}\\u{11072}\\u{11075}\\u{11083}-\\u{110AF}\\u{110D0}-\\u{110E8}\\u{11103}-\\u{11126}\\u{11144}\\u{11147}\\u{11150}-\\u{11172}\\u{11176}\\u{11183}-\\u{111B2}\\u{111C1}-\\u{111C4}\\u{111DA}\\u{111DC}\\u{11200}-\\u{11211}\\u{11213}-\\u{1122B}\\u{1123F}\\u{11240}\\u{11280}-\\u{11286}\\u{11288}\\u{1128A}-\\u{1128D}\\u{1128F}-\\u{1129D}\\u{1129F}-\\u{112A8}\\u{112B0}-\\u{112DE}\\u{11305}-\\u{1130C}\\u{1130F}\\u{11310}\\u{11313}-\\u{11328}\\u{1132A}-\\u{11330}\\u{11332}\\u{11333}\\u{11335}-\\u{11339}\\u{1133D}\\u{11350}\\u{1135D}-\\u{11361}\\u{11380}-\\u{11389}\\u{1138B}\\u{1138E}\\u{11390}-\\u{113B5}\\u{113B7}\\u{113D1}\\u{113D3}\\u{11400}-\\u{11434}\\u{11447}-\\u{1144A}\\u{1145F}-\\u{11461}\\u{11480}-\\u{114AF}\\u{114C4}\\u{114C5}\\u{114C7}\\u{11580}-\\u{115AE}\\u{115D8}-\\u{115DB}\\u{11600}-\\u{1162F}\\u{11644}\\u{11680}-\\u{116AA}\\u{116B8}\\u{11700}-\\u{1171A}\\u{11740}-\\u{11746}\\u{11800}-\\u{1182B}\\u{118A0}-\\u{118DF}\\u{118FF}-\\u{11906}\\u{11909}\\u{1190C}-\\u{11913}\\u{11915}\\u{11916}\\u{11918}-\\u{1192F}\\u{1193F}\\u{11941}\\u{119A0}-\\u{119A7}\\u{119AA}-\\u{119D0}\\u{119E1}\\u{119E3}\\u{11A00}\\u{11A0B}-\\u{11A32}\\u{11A3A}\\u{11A50}\\u{11A5C}-\\u{11A89}\\u{11A9D}\\u{11AB0}-\\u{11AF8}\\u{11BC0}-\\u{11BE0}\\u{11C00}-\\u{11C08}\\u{11C0A}-\\u{11C2E}\\u{11C40}\\u{11C72}-\\u{11C8F}\\u{11D00}-\\u{11D06}\\u{11D08}\\u{11D09}\\u{11D0B}-\\u{11D30}\\u{11D46}\\u{11D60}-\\u{11D65}\\u{11D67}\\u{11D68}\\u{11D6A}-\\u{11D89}\\u{11D98}\\u{11EE0}-\\u{11EF2}\\u{11F02}\\u{11F04}-\\u{11F10}\\u{11F12}-\\u{11F33}\\u{11FB0}\\u{12000}-\\u{12399}\\u{12480}-\\u{12543}\\u{12F90}-\\u{12FF0}\\u{13000}-\\u{1342F}\\u{13441}-\\u{13446}\\u{13460}-\\u{143FA}\\u{14400}-\\u{14646}\\u{16100}-\\u{1611D}\\u{16800}-\\u{16A38}\\u{16A40}-\\u{16A5E}\\u{16A70}-\\u{16ABE}\\u{16AD0}-\\u{16AED}\\u{16B00}-\\u{16B2F}\\u{16B40}-\\u{16B43}\\u{16B63}-\\u{16B77}\\u{16B7D}-\\u{16B8F}\\u{16D40}-\\u{16D6C}\\u{16E40}-\\u{16E7F}\\u{16F00}-\\u{16F4A}\\u{16F50}\\u{16F93}-\\u{16F9F}\\u{16FE0}\\u{16FE1}\\u{16FE3}\\u{17000}-\\u{187F7}\\u{18800}-\\u{18CD5}\\u{18CFF}-\\u{18D08}\\u{1AFF0}-\\u{1AFF3}\\u{1AFF5}-\\u{1AFFB}\\u{1AFFD}\\u{1AFFE}\\u{1B000}-\\u{1B122}\\u{1B132}\\u{1B150}-\\u{1B152}\\u{1B155}\\u{1B164}-\\u{1B167}\\u{1B170}-\\u{1B2FB}\\u{1BC00}-\\u{1BC6A}\\u{1BC70}-\\u{1BC7C}\\u{1BC80}-\\u{1BC88}\\u{1BC90}-\\u{1BC99}\\u{1D400}-\\u{1D454}\\u{1D456}-\\u{1D49C}\\u{1D49E}\\u{1D49F}\\u{1D4A2}\\u{1D4A5}\\u{1D4A6}\\u{1D4A9}-\\u{1D4AC}\\u{1D4AE}-\\u{1D4B9}\\u{1D4BB}\\u{1D4BD}-\\u{1D4C3}\\u{1D4C5}-\\u{1D505}\\u{1D507}-\\u{1D50A}\\u{1D50D}-\\u{1D514}\\u{1D516}-\\u{1D51C}\\u{1D51E}-\\u{1D539}\\u{1D53B}-\\u{1D53E}\\u{1D540}-\\u{1D544}\\u{1D546}\\u{1D54A}-\\u{1D550}\\u{1D552}-\\u{1D6A5}\\u{1D6A8}-\\u{1D6C0}\\u{1D6C2}-\\u{1D6DA}\\u{1D6DC}-\\u{1D6FA}\\u{1D6FC}-\\u{1D714}\\u{1D716}-\\u{1D734}\\u{1D736}-\\u{1D74E}\\u{1D750}-\\u{1D76E}\\u{1D770}-\\u{1D788}\\u{1D78A}-\\u{1D7A8}\\u{1D7AA}-\\u{1D7C2}\\u{1D7C4}-\\u{1D7CB}\\u{1DF00}-\\u{1DF1E}\\u{1DF25}-\\u{1DF2A}\\u{1E030}-\\u{1E06D}\\u{1E100}-\\u{1E12C}\\u{1E137}-\\u{1E13D}\\u{1E14E}\\u{1E290}-\\u{1E2AD}\\u{1E2C0}-\\u{1E2EB}\\u{1E4D0}-\\u{1E4EB}\\u{1E5D0}-\\u{1E5ED}\\u{1E5F0}\\u{1E7E0}-\\u{1E7E6}\\u{1E7E8}-\\u{1E7EB}\\u{1E7ED}\\u{1E7EE}\\u{1E7F0}-\\u{1E7FE}\\u{1E800}-\\u{1E8C4}\\u{1E900}-\\u{1E943}\\u{1E94B}\\u{1EE00}-\\u{1EE03}\\u{1EE05}-\\u{1EE1F}\\u{1EE21}\\u{1EE22}\\u{1EE24}\\u{1EE27}\\u{1EE29}-\\u{1EE32}\\u{1EE34}-\\u{1EE37}\\u{1EE39}\\u{1EE3B}\\u{1EE42}\\u{1EE47}\\u{1EE49}\\u{1EE4B}\\u{1EE4D}-\\u{1EE4F}\\u{1EE51}\\u{1EE52}\\u{1EE54}\\u{1EE57}\\u{1EE59}\\u{1EE5B}\\u{1EE5D}\\u{1EE5F}\\u{1EE61}\\u{1EE62}\\u{1EE64}\\u{1EE67}-\\u{1EE6A}\\u{1EE6C}-\\u{1EE72}\\u{1EE74}-\\u{1EE77}\\u{1EE79}-\\u{1EE7C}\\u{1EE7E}\\u{1EE80}-\\u{1EE89}\\u{1EE8B}-\\u{1EE9B}\\u{1EEA1}-\\u{1EEA3}\\u{1EEA5}-\\u{1EEA9}\\u{1EEAB}-\\u{1EEBB}\\u{20000}-\\u{2A6DF}\\u{2A700}-\\u{2B739}\\u{2B740}-\\u{2B81D}\\u{2B820}-\\u{2CEA1}\\u{2CEB0}-\\u{2EBE0}\\u{2EBF0}-\\u{2EE5D}\\u{2F800}-\\u{2FA1D}\\u{30000}-\\u{3134A}\\u{31350}-\\u{323AF}]+$/u,isValidURL=function(url){try{return new URL(url),!0}catch(_unused){return!1}},_extractURLFromObject=function(obj){for(var key in obj)if(Object.prototype.hasOwnProperty.call(obj,key)){var value=obj[key];if("string"==typeof value&&isValidURL(value))return value;if("object"==typeof value&&null!==value){var result=_extractURLFromObject(value);if(result)return result}}return null},decodeBase64SeveralTimes=function(text,times){for(var content,result=text,i=0;i<times;i+=1)try{result=atob(result)}catch(e){if(result===text)return""}if(isValidURL(result))return result;if((content=result).startsWith("{")&&content.endsWith("}"))try{var parsedResult=JSON.parse(result);return _extractURLFromObject(parsedResult)}catch(ex){return""}return logMessage(source,`Failed to decode base64 string: ${text}`),""},decodeBase64URL=function(url){var{search:search,hash:hash}=new URL(url,document.location.href);return search.length>0?function(search){var decodedParam,validEncodedParam,searchString=search.replace("?","");return searchString.includes("&")?(searchString.split("&").forEach((function(param){(decodedParam=decodeBase64SeveralTimes(param,10))&&decodedParam.length>0&&(validEncodedParam=decodedParam)})),validEncodedParam):decodeBase64SeveralTimes(searchString,10)}(search):hash.length>0?function(hash){var validEncodedHash="";return hash.includes("#!")?validEncodedHash=hash.replace("#!",""):hash.includes("#")&&(validEncodedHash=hash.replace("#","")),validEncodedHash?decodeBase64SeveralTimes(validEncodedHash,10):""}(hash):(logMessage(source,`Failed to execute base64 from URL: ${url}`),null)},sanitize=function(elementSelector){var elements;try{elements=document.querySelectorAll(elementSelector)}catch(e){return void logMessage(source,`Invalid selector "${elementSelector}"`)}elements.forEach((function(elem){try{if("a"!==(element=elem).nodeName.toLowerCase()||!element.hasAttribute("href"))return void logMessage(source,`${elem} is not a valid element to sanitize`);var newHref=function(anchor,attr){if("text"===attr)return anchor.textContent?anchor.textContent.replace(regexpNotValidAtStart,"").replace(regexpNotValidAtEnd,""):"";if(attr.startsWith("?"))try{return new URL(anchor.href,document.location.href).searchParams.get(attr.slice(1))||""}catch(ex){return logMessage(source,`Cannot retrieve the parameter \'${attr.slice(1)}\' from the URL \'${anchor.href}`),""}return attr.startsWith("[")&&attr.endsWith("]")&&anchor.getAttribute(attr.slice(1,-1))||""}(elem,attribute);if(transform)switch(!0){case BASE64_DECODE_TRANSFORM_MARKER.has(transform):newHref=isValidURL(href=newHref)?decodeBase64URL(href)||"":decodeBase64SeveralTimes(href,10)||"";break;case"removeHash"===transform:newHref=(urlObj=new URL(newHref,window.location.origin)).hash?(urlObj.hash="",urlObj.toString()):"";break;case transform.startsWith("removeParam"):newHref=function(url,transformValue){var urlObj=new URL(url,window.location.origin),paramNamesToRemoveStr=transformValue.split(":")[1];if(!paramNamesToRemoveStr)return urlObj.search="",urlObj.toString();var initSearchParamsLength=urlObj.searchParams.toString().length;return paramNamesToRemoveStr.split(",").forEach((function(param){urlObj.searchParams.has(param)&&urlObj.searchParams.delete(param)})),initSearchParamsLength===urlObj.searchParams.toString().length?"":urlObj.toString()}(newHref,transform);break;default:return void logMessage(source,`Invalid transform option: "${transform}"`)}var newValidHref=function(text){if(!text)return null;try{var{href:href,protocol:protocol}=new URL(text,document.location.href);return"http:"!==protocol&&"https:"!==protocol?(logMessage(source,`Protocol not allowed: "${protocol}", from URL: "${href}"`),null):href}catch(_unused2){return null}}(newHref);if(!newValidHref)return void logMessage(source,`Invalid URL: ${newHref}`);var oldHref=elem.href;elem.setAttribute("href",newValidHref),newValidHref!==oldHref&&logMessage(source,`Sanitized "${oldHref}" to "${newValidHref}".`)}catch(ex){logMessage(source,`Failed to sanitize ${elem}.`)}var urlObj,href,element})),function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source)},run=function(){sanitize(selector),function(t){var e=arguments.length>1&&void 0!==arguments[1]&&arguments[1],n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:[],i=new MutationObserver(function(n,t){var r,e=!1,_wrapper=function(){for(var o=arguments.length,u=new Array(o),f=0;f<o;f++)u[f]=arguments[f];e?r=u:(n(...u),e=!0,setTimeout((function(){e=!1,r&&(_wrapper(...r),r=null)}),t))};return _wrapper}((function(){disconnect(),t(),connect()}),20)),connect=function(){n.length>0?i.observe(document.documentElement,{childList:!0,subtree:!0,attributes:e,attributeFilter:n}):i.observe(document.documentElement,{childList:!0,subtree:!0,attributes:e})},disconnect=function(){i.disconnect()};connect()}((function(){return sanitize(selector)}),!0)};"loading"===document.readyState?window.addEventListener("DOMContentLoaded",run,{once:!0}):run()}else logMessage(source,"Selector is required.")}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['inject-css-in-shadow-dom'],
            scriptlet: 'function injectCssInShadowDom(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function hit(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}function logMessage(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,cssRule){var hostSelector=arguments.length>2&&void 0!==arguments[2]?arguments[2]:"",cssInjectionMethod=arguments.length>3&&void 0!==arguments[3]?arguments[3]:"adoptedStyleSheets";if(Element.prototype.attachShadow&&"undefined"!=typeof Proxy&&"undefined"!=typeof Reflect)if("adoptedStyleSheets"===cssInjectionMethod||"styleTag"===cssInjectionMethod)if(cssRule.match(/(url|image-set)\\(.*\\)/i))logMessage(source,\'"url()" function is not allowed for css rules\');else{var t,a,e,o,injectStyleTag=function(shadowRoot){try{var styleTag=document.createElement("style");styleTag.innerText=cssRule,shadowRoot.appendChild(styleTag),hit(source)}catch(error){logMessage(source,`Unable to inject style tag due to: \\n\'${error.message}\'`)}};t=window,a=hostSelector,e=function(shadowRoot){"adoptedStyleSheets"===cssInjectionMethod?function(shadowRoot){try{var stylesheet=new CSSStyleSheet;try{stylesheet.insertRule(cssRule)}catch(e){return void logMessage(source,`Unable to apply the rule \'${cssRule}\' due to: \\n\'${e.message}\'`)}shadowRoot.adoptedStyleSheets=[...shadowRoot.adoptedStyleSheets,stylesheet],hit(source)}catch(error){logMessage(source,`Unable to inject adopted style sheet due to: \\n\'${error.message}\'`),injectStyleTag(shadowRoot)}}(shadowRoot):"styleTag"===cssInjectionMethod&&injectStyleTag(shadowRoot)},o={apply:function(t,o,c){var h=Reflect.apply(t,o,c);return o&&o.matches(a||"*")&&e(h),h}},t.Element.prototype.attachShadow=new Proxy(t.Element.prototype.attachShadow,o)}else logMessage(source,`Unknown cssInjectionMethod: ${cssInjectionMethod}`)}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: [
                'json-prune-fetch-response',
                'json-prune-fetch-response.js',
                'ubo-json-prune-fetch-response.js',
                'ubo-json-prune-fetch-response',
            ],
            scriptlet: 'function jsonPruneFetchResponse(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function hit(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}function logMessage(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}function objectToString(t){return t&&"object"==typeof t?function(t){return 0===Object.keys(t).length&&!t.prototype}(t)?"{}":Object.entries(t).map((function(t){var n=t[0],e=t[1],o=e;return e instanceof Object&&(o=`{ ${objectToString(e)} }`),`${n}:"${o}"`})).join(" "):String(t)}function getPrunePath(t){var r=".[=].";if("string"==typeof t&&void 0!==t&&""!==t){var e=function(t){for(var e=[],n="",i=0,o=!1,s=!1;i<t.length;){var a=t[i];if(o)n+=a,"\\\\"===a?s=!s:("/"!==a||s||(o=!1),s=!1),i+=1;else{if(" "===a||"\\n"===a||"\\t"===a||"\\r"===a||"\\f"===a||"\\v"===a){for(;i<t.length&&/\\s/.test(t[i]);)i+=1;""!==n&&(e.push(n),n="");continue}if(t.startsWith(r,i)){if(n+=r,"/"===t[i+=5]){o=!0,s=!1,n+="/",i+=1;continue}continue}n+=a,i+=1}}return""!==n&&e.push(n),e}(t),n=e.map((function(t){var e=t.split(r),n=e[0],i=e[1];return void 0!==i?("true"===i?i=!0:"false"===i?i=!1:i.startsWith("/")?i=toRegExp(i):"string"==typeof i&&/^\\d+$/.test(i)&&(i=parseFloat(i)),{path:n,value:i}):{path:n}}));return console.log("parts",n),n}return[]}function toRegExp(e){var r=e||"",t="/";if(""===r)return new RegExp(".?");var n,i,s=r.lastIndexOf(t),a=r.substring(s+1),g=r.substring(0,s+1),u=(i=a,(n=g).startsWith(t)&&n.endsWith(t)&&!n.endsWith("\\\\/")&&function(e){if(!e)return!1;try{return new RegExp("",e),!0}catch(e){return!1}}(i)?i:"");if(r.startsWith(t)&&r.endsWith(t)||u)return new RegExp((u?g:r).slice(1,-1),u);var c=r.replace(/\\\\\'/g,"\'").replace(/\\\\"/g,\'"\').replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&");return new RegExp(c)}function getWildcardPropertyInChain(r,e){var a=arguments.length>2&&void 0!==arguments[2]&&arguments[2],i=arguments.length>3&&void 0!==arguments[3]?arguments[3]:[],t=arguments.length>4?arguments[4]:void 0,o=e.indexOf(".");if(-1===o){if("*"===e||"[]"===e){for(var n in r)if(Object.prototype.hasOwnProperty.call(r,n))if(void 0!==t){var s=r[n];"string"==typeof s&&t instanceof RegExp?t.test(s)&&i.push({base:r,prop:n}):s===t&&i.push({base:r,prop:n})}else i.push({base:r,prop:n})}else if(void 0!==t){var p=r[e];"string"==typeof p&&t instanceof RegExp?t.test(p)&&i.push({base:r,prop:e}):r[e]===t&&i.push({base:r,prop:e})}else i.push({base:r,prop:e});return i}var c=e.slice(0,o);if("[]"===c&&Array.isArray(r)||"*"===c&&r instanceof Object||"[-]"===c&&Array.isArray(r)||"{-}"===c&&r instanceof Object){var f=e.slice(o+1),y=Object.keys(r);if("{-}"===c||"[-]"===c){var h=Array.isArray(r)?"array":"object";return("{-}"!==c||"object"!==h)&&("[-]"!==c||"array"!==h)||y.forEach((function(e){(function(t,r,e){var n=r.split("."),_check=function(t,r){if(null==t)return!1;if(0===r.length)return void 0===e||("string"==typeof t&&e instanceof RegExp?e.test(t):t===e);var n=r[0],i=r.slice(1);if("*"===n||"[]"===n){if(Array.isArray(t))return t.some((function(t){return _check(t,i)}));if("object"==typeof t&&null!==t)return Object.keys(t).some((function(r){return _check(t[r],i)}))}return!!Object.prototype.hasOwnProperty.call(t,n)&&_check(t[n],i)};return _check(t,n)})(r[e],f,t)&&i.push({base:r,prop:e})})),i}y.forEach((function(e){getWildcardPropertyInChain(r[e],f,a,i,t)}))}Array.isArray(r)&&r.forEach((function(r){void 0!==r&&getWildcardPropertyInChain(r,e,a,i,t)}));var d=r[c];return e=e.slice(o+1),void 0!==d&&getWildcardPropertyInChain(d,e,a,i,t),i}function restoreRegExpValues(e){if(e.length)try{var r;r=1===e.length?`(${e[0]})`:e.reduce((function(e,r,t){return 1===t?`(${e}),(${r})`:`${e},(${r})`}));var t=new RegExp(r);e.toString().replace(t,"")}catch(e){var n=`Failed to restore RegExp values: ${e}`;console.log(n)}}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,propsToRemove,obligatoryProps){var propsToMatch=arguments.length>3&&void 0!==arguments[3]?arguments[3]:"",stack=arguments.length>4&&void 0!==arguments[4]?arguments[4]:"";if("undefined"!=typeof fetch&&"undefined"!=typeof Proxy&&"undefined"!=typeof Response){var prunePaths=getPrunePath(propsToRemove),requiredPaths=getPrunePath(obligatoryProps),nativeStringify=window.JSON.stringify,nativeRequestClone=window.Request.prototype.clone,nativeResponseClone=window.Response.prototype.clone,nativeFetch=window.fetch,fetchHandler={apply:async function(target,thisArg,args){var originalResponse,clonedResponse,json,fetchData=function(e,t){var a,c,n={},r=e[0];if(r instanceof Request){var f=function(t){var e=["url","method","headers","body","credentials","cache","redirect","referrer","referrerPolicy","integrity","keepalive","signal","mode"].map((function(e){return[e,t[e]]}));return Object.fromEntries(e)}(t.call(r));a=f.url,c=f}else a=r,c=e[1];return n.url=a,c instanceof Object&&Object.keys(c).forEach((function(e){n[e]=c[e]})),n}(args,nativeRequestClone);if(!function(e,t,r){if(""===t||"*"===t)return!0;var a,s=function(e){var r={};return e.split(" ").forEach((function(e){var n=e.indexOf(":"),i=e.slice(0,n);if(function(e){return["url","method","headers","body","credentials","cache","redirect","referrer","referrerPolicy","integrity","keepalive","signal","mode"].includes(e)}(i)){var s=e.slice(n+1);r[i]=s}else r.url=e})),r}(t);if(function(t){return Object.values(t).every((function(t){return function(e){var t,n=function(e){return e.replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&")}(e);"/"===e[0]&&"/"===e[e.length-1]&&(n=e.slice(1,-1));try{t=new RegExp(n),t=!0}catch(e){t=!1}return t}(t)}))}(s)){var n=function(t){var a={};return Object.keys(t).forEach((function(c){a[c]=toRegExp(t[c])})),a}(s);a=Object.keys(n).every((function(e){var t=n[e],a=r[e];return Object.prototype.hasOwnProperty.call(r,e)&&"string"==typeof a&&(null==t?void 0:t.test(a))}))}else logMessage(e,`Invalid parameter: ${t}`),a=!1;return a}(source,propsToMatch,fetchData))return Reflect.apply(target,thisArg,args);try{originalResponse=await nativeFetch.apply(null,args),clonedResponse=nativeResponseClone.call(originalResponse)}catch(_unused){return logMessage(source,`Could not make an original fetch request: ${fetchData.url}`),Reflect.apply(target,thisArg,args)}try{json=await originalResponse.json()}catch(e){var message=`Response body can\'t be converted to json: ${objectToString(fetchData)}`;return logMessage(source,message),clonedResponse}var modifiedJson=function(e,r,n,a,t,i){var{nativeStringify:o}=i;if(0===n.length&&0===a.length)return logMessage(e,`${window.location.hostname}\\n${o(r,null,2)}\\nStack trace:\\n${(new Error).stack}`,!0),r&&"object"==typeof r&&logMessage(e,r,!0,!1),r;try{if(!1===function(n,t,r,e,a,i){if(!t)return!1;var o,{nativeStringify:u}=i,c=r.map((function(n){return n.path})),f=e.map((function(n){return n.path}));if(0===c.length&&f.length>0){var g=u(t);if(toRegExp(f.join("")).test(g))return logMessage(n,`${window.location.hostname}\\n${u(t,null,2)}\\nStack trace:\\n${(new Error).stack}`,!0),t&&"object"==typeof t&&logMessage(n,t,!0,!1),o=!1}if(a&&!function(e,t){if(!e||""===e)return!0;var r=function(){try{for(var r=[],e=1;e<10;e+=1){var a=`$${e}`;if(!RegExp[a])break;r.push(RegExp[a])}return r}catch(r){return[]}}();if(function(t,i){var r="inlineScript",n="injectedScript",isInlineScript=function(t){return t.includes(r)},isInjectedScript=function(t){return t.includes(n)};if(!isInlineScript(t)&&!isInjectedScript(t))return!1;var e=window.location.href,s=e.indexOf("#");-1!==s&&(e=e.slice(0,s));var c=i.split("\\n").slice(2).map((function(t){return t.trim()})).map((function(t){var i,s=/(.*?@)?(\\S+)(:\\d+)(:\\d+)\\)?$/.exec(t);if(s){var c,l,a=s[2],u=s[3],o=s[4];if(null!==(c=a)&&void 0!==c&&c.startsWith("(")&&(a=a.slice(1)),null!==(l=a)&&void 0!==l&&l.startsWith("<anonymous>")){var d;a=n;var f=void 0!==s[1]?s[1].slice(0,-1):t.slice(0,s.index).trim();null!==(d=f)&&void 0!==d&&d.startsWith("at")&&(f=f.slice(2).trim()),i=`${f} ${a}${u}${o}`.trim()}else i=a===e?`${r}${u}${o}`.trim():`${a}${u}${o}`.trim()}else i=t;return i}));if(c)for(var l=0;l<c.length;l+=1){if(isInlineScript(t)&&c[l].startsWith(r)&&c[l].match(toRegExp(t)))return!0;if(isInjectedScript(t)&&c[l].startsWith(n)&&c[l].match(toRegExp(t)))return!0}return!1}(e,t))return r.length&&r[0]!==RegExp.$1&&restoreRegExpValues(r),!0;var n=toRegExp(e),a=t.split("\\n").slice(2).map((function(e){return e.trim()})).join("\\n");return r.length&&r[0]!==RegExp.$1&&restoreRegExpValues(r),function(){var t=Object.getOwnPropertyDescriptor(RegExp.prototype,"test"),e=null==t?void 0:t.value;if(t&&"function"==typeof t.value)return e;throw new Error("RegExp.prototype.test is not a function")}().call(n,a)}(a,(new Error).stack||""))return o=!1;for(var s,l=[".*.","*.",".*",".[].","[].",".[]"],_loop=function(){var n=f[p],r=n.split(".").pop(),e=l.some((function(t){return n.includes(t)})),a=getWildcardPropertyInChain(t,n,e);if(!a.length)return{v:o=!1};o=!e;for(var i=0;i<a.length;i+=1){var u="string"==typeof r&&void 0!==a[i].base[r];o=e?u||o:u&&o}},p=0;p<f.length;p+=1)if(s=_loop())return s.v;return o}(e,r,n,a,t,i))return r;n.forEach((function(n){for(var a=n.path,t=n.value,i=getWildcardPropertyInChain(r,a,!0,[],t),o=i.length-1;o>=0;o-=1){var s=i[o];if(void 0!==s&&s.base)if(hit(e),Array.isArray(s.base))try{var l=Number(s.prop);if(Number.isNaN(l))continue;s.base.splice(l,1)}catch(e){console.error("Error while deleting array element",e)}else delete s.base[s.prop]}}))}catch(r){logMessage(e,r)}return r}(source,json,prunePaths,requiredPaths,stack,{nativeStringify:nativeStringify,nativeRequestClone:nativeRequestClone,nativeResponseClone:nativeResponseClone,nativeFetch:nativeFetch}),forgedResponse=function(e,t){var{bodyUsed:s,headers:r,ok:u,redirected:a,status:d,statusText:o,type:l,url:n}=e,v=new Response(t,{status:d,statusText:o,headers:r});return Object.defineProperties(v,{url:{value:n},type:{value:l},ok:{value:u},bodyUsed:{value:s},redirected:{value:a}}),v}(originalResponse,nativeStringify(modifiedJson));return hit(source),forgedResponse}};window.fetch=new Proxy(window.fetch,fetchHandler)}}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['json-prune', 'json-prune.js', 'ubo-json-prune.js', 'ubo-json-prune', 'abp-json-prune'],
            scriptlet: 'function jsonPrune(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function hit(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}function matchStackTrace(e,t){if(!e||""===e)return!0;var r=function(){try{for(var r=[],e=1;e<10;e+=1){var a=`$${e}`;if(!RegExp[a])break;r.push(RegExp[a])}return r}catch(r){return[]}}();if(function(t,i){var r="inlineScript",n="injectedScript",isInlineScript=function(t){return t.includes(r)},isInjectedScript=function(t){return t.includes(n)};if(!isInlineScript(t)&&!isInjectedScript(t))return!1;var e=window.location.href,s=e.indexOf("#");-1!==s&&(e=e.slice(0,s));var c=i.split("\\n").slice(2).map((function(t){return t.trim()})).map((function(t){var i,s=/(.*?@)?(\\S+)(:\\d+)(:\\d+)\\)?$/.exec(t);if(s){var c,l,a=s[2],u=s[3],o=s[4];if(null!==(c=a)&&void 0!==c&&c.startsWith("(")&&(a=a.slice(1)),null!==(l=a)&&void 0!==l&&l.startsWith("<anonymous>")){var d;a=n;var f=void 0!==s[1]?s[1].slice(0,-1):t.slice(0,s.index).trim();null!==(d=f)&&void 0!==d&&d.startsWith("at")&&(f=f.slice(2).trim()),i=`${f} ${a}${u}${o}`.trim()}else i=a===e?`${r}${u}${o}`.trim():`${a}${u}${o}`.trim()}else i=t;return i}));if(c)for(var l=0;l<c.length;l+=1){if(isInlineScript(t)&&c[l].startsWith(r)&&c[l].match(toRegExp(t)))return!0;if(isInjectedScript(t)&&c[l].startsWith(n)&&c[l].match(toRegExp(t)))return!0}return!1}(e,t))return r.length&&r[0]!==RegExp.$1&&restoreRegExpValues(r),!0;var n=toRegExp(e),a=t.split("\\n").slice(2).map((function(e){return e.trim()})).join("\\n");return r.length&&r[0]!==RegExp.$1&&restoreRegExpValues(r),function(){var t=Object.getOwnPropertyDescriptor(RegExp.prototype,"test"),e=null==t?void 0:t.value;if(t&&"function"==typeof t.value)return e;throw new Error("RegExp.prototype.test is not a function")}().call(n,a)}function getWildcardPropertyInChain(r,e){var a=arguments.length>2&&void 0!==arguments[2]&&arguments[2],i=arguments.length>3&&void 0!==arguments[3]?arguments[3]:[],t=arguments.length>4?arguments[4]:void 0,o=e.indexOf(".");if(-1===o){if("*"===e||"[]"===e){for(var n in r)if(Object.prototype.hasOwnProperty.call(r,n))if(void 0!==t){var s=r[n];"string"==typeof s&&t instanceof RegExp?t.test(s)&&i.push({base:r,prop:n}):s===t&&i.push({base:r,prop:n})}else i.push({base:r,prop:n})}else if(void 0!==t){var p=r[e];"string"==typeof p&&t instanceof RegExp?t.test(p)&&i.push({base:r,prop:e}):r[e]===t&&i.push({base:r,prop:e})}else i.push({base:r,prop:e});return i}var c=e.slice(0,o);if("[]"===c&&Array.isArray(r)||"*"===c&&r instanceof Object||"[-]"===c&&Array.isArray(r)||"{-}"===c&&r instanceof Object){var f=e.slice(o+1),y=Object.keys(r);if("{-}"===c||"[-]"===c){var h=Array.isArray(r)?"array":"object";return("{-}"!==c||"object"!==h)&&("[-]"!==c||"array"!==h)||y.forEach((function(e){(function(t,r,e){var n=r.split("."),_check=function(t,r){if(null==t)return!1;if(0===r.length)return void 0===e||("string"==typeof t&&e instanceof RegExp?e.test(t):t===e);var n=r[0],i=r.slice(1);if("*"===n||"[]"===n){if(Array.isArray(t))return t.some((function(t){return _check(t,i)}));if("object"==typeof t&&null!==t)return Object.keys(t).some((function(r){return _check(t[r],i)}))}return!!Object.prototype.hasOwnProperty.call(t,n)&&_check(t[n],i)};return _check(t,n)})(r[e],f,t)&&i.push({base:r,prop:e})})),i}y.forEach((function(e){getWildcardPropertyInChain(r[e],f,a,i,t)}))}Array.isArray(r)&&r.forEach((function(r){void 0!==r&&getWildcardPropertyInChain(r,e,a,i,t)}));var d=r[c];return e=e.slice(o+1),void 0!==d&&getWildcardPropertyInChain(d,e,a,i,t),i}function logMessage(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}function jsonPruner(e,r,n,a,t,i){var{nativeStringify:o}=i;if(0===n.length&&0===a.length)return logMessage(e,`${window.location.hostname}\\n${o(r,null,2)}\\nStack trace:\\n${(new Error).stack}`,!0),r&&"object"==typeof r&&logMessage(e,r,!0,!1),r;try{if(!1===function(n,t,r,e,a,i){if(!t)return!1;var o,{nativeStringify:u}=i,c=r.map((function(n){return n.path})),f=e.map((function(n){return n.path}));if(0===c.length&&f.length>0){var g=u(t);if(toRegExp(f.join("")).test(g))return logMessage(n,`${window.location.hostname}\\n${u(t,null,2)}\\nStack trace:\\n${(new Error).stack}`,!0),t&&"object"==typeof t&&logMessage(n,t,!0,!1),o=!1}if(a&&!matchStackTrace(a,(new Error).stack||""))return o=!1;for(var s,l=[".*.","*.",".*",".[].","[].",".[]"],_loop=function(){var n=f[p],r=n.split(".").pop(),e=l.some((function(t){return n.includes(t)})),a=getWildcardPropertyInChain(t,n,e);if(!a.length)return{v:o=!1};o=!e;for(var i=0;i<a.length;i+=1){var u="string"==typeof r&&void 0!==a[i].base[r];o=e?u||o:u&&o}},p=0;p<f.length;p+=1)if(s=_loop())return s.v;return o}(e,r,n,a,t,i))return r;n.forEach((function(n){for(var a=n.path,t=n.value,i=getWildcardPropertyInChain(r,a,!0,[],t),o=i.length-1;o>=0;o-=1){var s=i[o];if(void 0!==s&&s.base)if(hit(e),Array.isArray(s.base))try{var l=Number(s.prop);if(Number.isNaN(l))continue;s.base.splice(l,1)}catch(e){console.error("Error while deleting array element",e)}else delete s.base[s.prop]}}))}catch(r){logMessage(e,r)}return r}function getPrunePath(t){var r=".[=].";if("string"==typeof t&&void 0!==t&&""!==t){var e=function(t){for(var e=[],n="",i=0,o=!1,s=!1;i<t.length;){var a=t[i];if(o)n+=a,"\\\\"===a?s=!s:("/"!==a||s||(o=!1),s=!1),i+=1;else{if(" "===a||"\\n"===a||"\\t"===a||"\\r"===a||"\\f"===a||"\\v"===a){for(;i<t.length&&/\\s/.test(t[i]);)i+=1;""!==n&&(e.push(n),n="");continue}if(t.startsWith(r,i)){if(n+=r,"/"===t[i+=5]){o=!0,s=!1,n+="/",i+=1;continue}continue}n+=a,i+=1}}return""!==n&&e.push(n),e}(t),n=e.map((function(t){var e=t.split(r),n=e[0],i=e[1];return void 0!==i?("true"===i?i=!0:"false"===i?i=!1:i.startsWith("/")?i=toRegExp(i):"string"==typeof i&&/^\\d+$/.test(i)&&(i=parseFloat(i)),{path:n,value:i}):{path:n}}));return console.log("parts",n),n}return[]}function toRegExp(e){var r=e||"",t="/";if(""===r)return new RegExp(".?");var n,i,s=r.lastIndexOf(t),a=r.substring(s+1),g=r.substring(0,s+1),u=(i=a,(n=g).startsWith(t)&&n.endsWith(t)&&!n.endsWith("\\\\/")&&function(e){if(!e)return!1;try{return new RegExp("",e),!0}catch(e){return!1}}(i)?i:"");if(r.startsWith(t)&&r.endsWith(t)||u)return new RegExp((u?g:r).slice(1,-1),u);var c=r.replace(/\\\\\'/g,"\'").replace(/\\\\"/g,\'"\').replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&");return new RegExp(c)}function restoreRegExpValues(e){if(e.length)try{var r;r=1===e.length?`(${e[0]})`:e.reduce((function(e,r,t){return 1===t?`(${e}),(${r})`:`${e},(${r})`}));var t=new RegExp(r);e.toString().replace(t,"")}catch(e){var n=`Failed to restore RegExp values: ${e}`;console.log(n)}}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,propsToRemove,requiredInitialProps){var stack=arguments.length>3&&void 0!==arguments[3]?arguments[3]:"",prunePaths=getPrunePath(propsToRemove),requiredPaths=getPrunePath(requiredInitialProps),nativeObjects={nativeStringify:window.JSON.stringify},nativeJSONParse=JSON.parse,jsonParseWrapper=function(){for(var _len=arguments.length,args=new Array(_len),_key=0;_key<_len;_key++)args[_key]=arguments[_key];var root=nativeJSONParse.apply(JSON,args);return jsonPruner(source,root,prunePaths,requiredPaths,stack,nativeObjects)};jsonParseWrapper.toString=nativeJSONParse.toString.bind(nativeJSONParse),JSON.parse=jsonParseWrapper;var nativeResponseJson=Response.prototype.json;"undefined"!=typeof Response&&(Response.prototype.json=function(){return nativeResponseJson.apply(this).then((function(obj){return jsonPruner(source,obj,prunePaths,requiredPaths,stack,nativeObjects)}))})}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: [
                'json-prune-xhr-response',
                'json-prune-xhr-response.js',
                'ubo-json-prune-xhr-response.js',
                'ubo-json-prune-xhr-response',
            ],
            scriptlet: 'function jsonPruneXhrResponse(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function hit(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}function logMessage(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}function toRegExp(e){var r=e||"",t="/";if(""===r)return new RegExp(".?");var n,i,s=r.lastIndexOf(t),a=r.substring(s+1),g=r.substring(0,s+1),u=(i=a,(n=g).startsWith(t)&&n.endsWith(t)&&!n.endsWith("\\\\/")&&function(e){if(!e)return!1;try{return new RegExp("",e),!0}catch(e){return!1}}(i)?i:"");if(r.startsWith(t)&&r.endsWith(t)||u)return new RegExp((u?g:r).slice(1,-1),u);var c=r.replace(/\\\\\'/g,"\'").replace(/\\\\"/g,\'"\').replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&");return new RegExp(c)}function getPrunePath(t){var r=".[=].";if("string"==typeof t&&void 0!==t&&""!==t){var e=function(t){for(var e=[],n="",i=0,o=!1,s=!1;i<t.length;){var a=t[i];if(o)n+=a,"\\\\"===a?s=!s:("/"!==a||s||(o=!1),s=!1),i+=1;else{if(" "===a||"\\n"===a||"\\t"===a||"\\r"===a||"\\f"===a||"\\v"===a){for(;i<t.length&&/\\s/.test(t[i]);)i+=1;""!==n&&(e.push(n),n="");continue}if(t.startsWith(r,i)){if(n+=r,"/"===t[i+=5]){o=!0,s=!1,n+="/",i+=1;continue}continue}n+=a,i+=1}}return""!==n&&e.push(n),e}(t),n=e.map((function(t){var e=t.split(r),n=e[0],i=e[1];return void 0!==i?("true"===i?i=!0:"false"===i?i=!1:i.startsWith("/")?i=toRegExp(i):"string"==typeof i&&/^\\d+$/.test(i)&&(i=parseFloat(i)),{path:n,value:i}):{path:n}}));return console.log("parts",n),n}return[]}function getXhrData(r,t,a,e,n){return{method:r,url:t,async:a,user:e,password:n}}function matchStackTrace(e,t){if(!e||""===e)return!0;var r=function(){try{for(var r=[],e=1;e<10;e+=1){var a=`$${e}`;if(!RegExp[a])break;r.push(RegExp[a])}return r}catch(r){return[]}}();if(function(t,i){var r="inlineScript",n="injectedScript",isInlineScript=function(t){return t.includes(r)},isInjectedScript=function(t){return t.includes(n)};if(!isInlineScript(t)&&!isInjectedScript(t))return!1;var e=window.location.href,s=e.indexOf("#");-1!==s&&(e=e.slice(0,s));var c=i.split("\\n").slice(2).map((function(t){return t.trim()})).map((function(t){var i,s=/(.*?@)?(\\S+)(:\\d+)(:\\d+)\\)?$/.exec(t);if(s){var c,l,a=s[2],u=s[3],o=s[4];if(null!==(c=a)&&void 0!==c&&c.startsWith("(")&&(a=a.slice(1)),null!==(l=a)&&void 0!==l&&l.startsWith("<anonymous>")){var d;a=n;var f=void 0!==s[1]?s[1].slice(0,-1):t.slice(0,s.index).trim();null!==(d=f)&&void 0!==d&&d.startsWith("at")&&(f=f.slice(2).trim()),i=`${f} ${a}${u}${o}`.trim()}else i=a===e?`${r}${u}${o}`.trim():`${a}${u}${o}`.trim()}else i=t;return i}));if(c)for(var l=0;l<c.length;l+=1){if(isInlineScript(t)&&c[l].startsWith(r)&&c[l].match(toRegExp(t)))return!0;if(isInjectedScript(t)&&c[l].startsWith(n)&&c[l].match(toRegExp(t)))return!0}return!1}(e,t))return r.length&&r[0]!==RegExp.$1&&restoreRegExpValues(r),!0;var n=toRegExp(e),a=t.split("\\n").slice(2).map((function(e){return e.trim()})).join("\\n");return r.length&&r[0]!==RegExp.$1&&restoreRegExpValues(r),function(){var t=Object.getOwnPropertyDescriptor(RegExp.prototype,"test"),e=null==t?void 0:t.value;if(t&&"function"==typeof t.value)return e;throw new Error("RegExp.prototype.test is not a function")}().call(n,a)}function getWildcardPropertyInChain(r,e){var a=arguments.length>2&&void 0!==arguments[2]&&arguments[2],i=arguments.length>3&&void 0!==arguments[3]?arguments[3]:[],t=arguments.length>4?arguments[4]:void 0,o=e.indexOf(".");if(-1===o){if("*"===e||"[]"===e){for(var n in r)if(Object.prototype.hasOwnProperty.call(r,n))if(void 0!==t){var s=r[n];"string"==typeof s&&t instanceof RegExp?t.test(s)&&i.push({base:r,prop:n}):s===t&&i.push({base:r,prop:n})}else i.push({base:r,prop:n})}else if(void 0!==t){var p=r[e];"string"==typeof p&&t instanceof RegExp?t.test(p)&&i.push({base:r,prop:e}):r[e]===t&&i.push({base:r,prop:e})}else i.push({base:r,prop:e});return i}var c=e.slice(0,o);if("[]"===c&&Array.isArray(r)||"*"===c&&r instanceof Object||"[-]"===c&&Array.isArray(r)||"{-}"===c&&r instanceof Object){var f=e.slice(o+1),y=Object.keys(r);if("{-}"===c||"[-]"===c){var h=Array.isArray(r)?"array":"object";return("{-}"!==c||"object"!==h)&&("[-]"!==c||"array"!==h)||y.forEach((function(e){(function(t,r,e){var n=r.split("."),_check=function(t,r){if(null==t)return!1;if(0===r.length)return void 0===e||("string"==typeof t&&e instanceof RegExp?e.test(t):t===e);var n=r[0],i=r.slice(1);if("*"===n||"[]"===n){if(Array.isArray(t))return t.some((function(t){return _check(t,i)}));if("object"==typeof t&&null!==t)return Object.keys(t).some((function(r){return _check(t[r],i)}))}return!!Object.prototype.hasOwnProperty.call(t,n)&&_check(t[n],i)};return _check(t,n)})(r[e],f,t)&&i.push({base:r,prop:e})})),i}y.forEach((function(e){getWildcardPropertyInChain(r[e],f,a,i,t)}))}Array.isArray(r)&&r.forEach((function(r){void 0!==r&&getWildcardPropertyInChain(r,e,a,i,t)}));var d=r[c];return e=e.slice(o+1),void 0!==d&&getWildcardPropertyInChain(d,e,a,i,t),i}function restoreRegExpValues(e){if(e.length)try{var r;r=1===e.length?`(${e[0]})`:e.reduce((function(e,r,t){return 1===t?`(${e}),(${r})`:`${e},(${r})`}));var t=new RegExp(r);e.toString().replace(t,"")}catch(e){var n=`Failed to restore RegExp values: ${e}`;console.log(n)}}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,propsToRemove,obligatoryProps){var propsToMatch=arguments.length>3&&void 0!==arguments[3]?arguments[3]:"",stack=arguments.length>4&&void 0!==arguments[4]?arguments[4]:"";if("undefined"!=typeof Proxy){var xhrData,shouldLog=!propsToRemove&&!obligatoryProps,prunePaths=getPrunePath(propsToRemove),requiredPaths=getPrunePath(obligatoryProps),nativeParse=window.JSON.parse,nativeStringify=window.JSON.stringify,nativeOpen=window.XMLHttpRequest.prototype.open,nativeSend=window.XMLHttpRequest.prototype.send,setRequestHeaderHandler={apply:function(setRequestHeader,thisArgument,argsList){return thisArgument.collectedHeaders.push(argsList),Reflect.apply(setRequestHeader,thisArgument,argsList)}},openHandler={apply:function(target,thisArg,args){return xhrData=getXhrData.apply(null,args),(function(e,t,r){if(""===t||"*"===t)return!0;var a,s=function(e){var r={};return e.split(" ").forEach((function(e){var n=e.indexOf(":"),i=e.slice(0,n);if(function(e){return["url","method","headers","body","credentials","cache","redirect","referrer","referrerPolicy","integrity","keepalive","signal","mode"].includes(e)}(i)){var s=e.slice(n+1);r[i]=s}else r.url=e})),r}(t);if(function(t){return Object.values(t).every((function(t){return function(e){var t,n=function(e){return e.replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&")}(e);"/"===e[0]&&"/"===e[e.length-1]&&(n=e.slice(1,-1));try{t=new RegExp(n),t=!0}catch(e){t=!1}return t}(t)}))}(s)){var n=function(t){var a={};return Object.keys(t).forEach((function(c){a[c]=toRegExp(t[c])})),a}(s);a=Object.keys(n).every((function(e){var t=n[e],a=r[e];return Object.prototype.hasOwnProperty.call(r,e)&&"string"==typeof a&&(null==t?void 0:t.test(a))}))}else logMessage(e,`Invalid parameter: ${t}`),a=!1;return a}(source,propsToMatch,xhrData)||shouldLog)&&(thisArg.xhrShouldBePruned=!0,thisArg.headersReceived=!!thisArg.headersReceived),thisArg.xhrShouldBePruned&&!thisArg.headersReceived&&(thisArg.headersReceived=!0,thisArg.collectedHeaders=[],thisArg.setRequestHeader=new Proxy(thisArg.setRequestHeader,setRequestHeaderHandler)),Reflect.apply(target,thisArg,args)}},sendHandler={apply:function(target,thisArg,args){var stackTrace=(new Error).stack||"";if(!thisArg.xhrShouldBePruned||stack&&!matchStackTrace(stack,stackTrace))return Reflect.apply(target,thisArg,args);var forgedRequest=new XMLHttpRequest;forgedRequest.addEventListener("readystatechange",(function(){if(4===forgedRequest.readyState){var{readyState:readyState,response:response,responseText:responseText,responseURL:responseURL,responseXML:responseXML,status:status,statusText:statusText}=forgedRequest,content=responseText||response;if("string"==typeof content||"object"==typeof content){var modifiedContent;if("string"==typeof content)try{var jsonContent=nativeParse(content);if(shouldLog)logMessage(source,`${window.location.hostname}\\n${nativeStringify(jsonContent,null,2)}\\nStack trace:\\n${stackTrace}`,!0),logMessage(source,jsonContent,!0,!1),modifiedContent=content;else{modifiedContent=function(e,r,n,a,t,i){var{nativeStringify:o}=i;if(0===n.length&&0===a.length)return logMessage(e,`${window.location.hostname}\\n${o(r,null,2)}\\nStack trace:\\n${(new Error).stack}`,!0),r&&"object"==typeof r&&logMessage(e,r,!0,!1),r;try{if(!1===function(n,t,r,e,a,i){if(!t)return!1;var o,{nativeStringify:u}=i,c=r.map((function(n){return n.path})),f=e.map((function(n){return n.path}));if(0===c.length&&f.length>0){var g=u(t);if(toRegExp(f.join("")).test(g))return logMessage(n,`${window.location.hostname}\\n${u(t,null,2)}\\nStack trace:\\n${(new Error).stack}`,!0),t&&"object"==typeof t&&logMessage(n,t,!0,!1),o=!1}if(a&&!matchStackTrace(a,(new Error).stack||""))return o=!1;for(var s,l=[".*.","*.",".*",".[].","[].",".[]"],_loop=function(){var n=f[p],r=n.split(".").pop(),e=l.some((function(t){return n.includes(t)})),a=getWildcardPropertyInChain(t,n,e);if(!a.length)return{v:o=!1};o=!e;for(var i=0;i<a.length;i+=1){var u="string"==typeof r&&void 0!==a[i].base[r];o=e?u||o:u&&o}},p=0;p<f.length;p+=1)if(s=_loop())return s.v;return o}(e,r,n,a,t,i))return r;n.forEach((function(n){for(var a=n.path,t=n.value,i=getWildcardPropertyInChain(r,a,!0,[],t),o=i.length-1;o>=0;o-=1){var s=i[o];if(void 0!==s&&s.base)if(hit(e),Array.isArray(s.base))try{var l=Number(s.prop);if(Number.isNaN(l))continue;s.base.splice(l,1)}catch(e){console.error("Error while deleting array element",e)}else delete s.base[s.prop]}}))}catch(r){logMessage(e,r)}return r}(source,jsonContent,prunePaths,requiredPaths,stack="",{nativeStringify:nativeStringify});try{var{responseType:responseType}=thisArg;switch(responseType){case"":case"text":modifiedContent=nativeStringify(modifiedContent);break;case"arraybuffer":modifiedContent=(new TextEncoder).encode(nativeStringify(modifiedContent)).buffer;break;case"blob":modifiedContent=new Blob([nativeStringify(modifiedContent)])}}catch(error){logMessage(source,`Response body cannot be converted to reponse type: \'${content}\'`),modifiedContent=content}}}catch(error){logMessage(source,`Response body cannot be converted to json: \'${content}\'`),modifiedContent=content}Object.defineProperties(thisArg,{readyState:{value:readyState,writable:!1},responseURL:{value:responseURL,writable:!1},responseXML:{value:responseXML,writable:!1},status:{value:status,writable:!1},statusText:{value:statusText,writable:!1},response:{value:modifiedContent,writable:!1},responseText:{value:modifiedContent,writable:!1}}),setTimeout((function(){var stateEvent=new Event("readystatechange");thisArg.dispatchEvent(stateEvent);var loadEvent=new Event("load");thisArg.dispatchEvent(loadEvent);var loadEndEvent=new Event("loadend");thisArg.dispatchEvent(loadEndEvent)}),1),hit(source)}}})),nativeOpen.apply(forgedRequest,[xhrData.method,xhrData.url,Boolean(xhrData.async)]),thisArg.collectedHeaders.forEach((function(header){forgedRequest.setRequestHeader(header[0],header[1])})),thisArg.collectedHeaders=[];try{nativeSend.call(forgedRequest,args)}catch(_unused){return Reflect.apply(target,thisArg,args)}}};XMLHttpRequest.prototype.open=new Proxy(XMLHttpRequest.prototype.open,openHandler),XMLHttpRequest.prototype.send=new Proxy(XMLHttpRequest.prototype.send,sendHandler)}}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: [
                'log-addEventListener',
                'addEventListener-logger.js',
                'ubo-addEventListener-logger.js',
                'aell.js',
                'ubo-aell.js',
                'ubo-addEventListener-logger',
                'ubo-aell',
            ],
            scriptlet: 'function logAddEventListener(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function convertTypeToString(n){return void 0===n?"undefined":"object"==typeof n?null===n?"null":objectToString(n):String(n)}function logMessage(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}function objectToString(t){return t&&"object"==typeof t?function(t){return 0===Object.keys(t).length&&!t.prototype}(t)?"{}":Object.entries(t).map((function(t){var n=t[0],e=t[1],o=e;return e instanceof Object&&(o=`{ ${objectToString(e)} }`),`${n}:"${o}"`})).join(" "):String(t)}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source){var nativeAddEventListener=window.EventTarget.prototype.addEventListener;function addEventListenerWrapper(type,listener){var _this$constructor,n;if(null!=type&&(void 0!==(n=listener)&&("function"==typeof n||"object"==typeof n&&null!==n&&"handleEvent"in n&&"function"==typeof n.handleEvent))){var targetElement,targetElementInfo,listenerInfo=function(n){return"function"==typeof n?n.toString():n.handleEvent.toString()}(listener);this&&(this instanceof Window?targetElementInfo="window":this instanceof Document?targetElementInfo="document":this instanceof Element&&(targetElement=this,targetElementInfo=function(e){if(!(e&&e instanceof Element&&e.attributes&&e.nodeName))return"";for(var t=e.attributes,n=e.nodeName.toLowerCase(),a=0;a<t.length;a+=1){var r=t[a];n+=`[${r.name}="${r.value}"]`}return n}(this))),targetElementInfo?(logMessage(source,`addEventListener("${type}", ${listenerInfo})\\nElement: ${targetElementInfo}`,!0),targetElement&&console.log("log-addEventListener Element:",targetElement)):logMessage(source,`addEventListener("${type}", ${listenerInfo})`,!0),function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source)}else{var _message2=`Invalid event type or listener passed to addEventListener:\\n        type: ${convertTypeToString(type)}\\n        listener: ${convertTypeToString(listener)}`;logMessage(source,_message2,!0)}var context=this;this&&"Window"===(null===(_this$constructor=this.constructor)||void 0===_this$constructor?void 0:_this$constructor.name)&&this!==window&&(context=window);for(var _len=arguments.length,args=new Array(_len>2?_len-2:0),_key=2;_key<_len;_key++)args[_key-2]=arguments[_key];return nativeAddEventListener.apply(context,[type,listener,...args])}var descriptor={configurable:!0,set:function(){},get:function(){return addEventListenerWrapper}};Object.defineProperty(window.EventTarget.prototype,"addEventListener",descriptor),Object.defineProperty(window,"addEventListener",descriptor),Object.defineProperty(document,"addEventListener",descriptor)}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['log-eval'],
            scriptlet: 'function logEval(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function hit(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}function logMessage(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source){var nativeEval=window.eval;window.eval=function(str){return hit(source),logMessage(source,`eval("${str}")`,!0),nativeEval(str)};var nativeFunction=window.Function;function FunctionWrapper(){hit(source);for(var _len=arguments.length,args=new Array(_len),_key=0;_key<_len;_key++)args[_key]=arguments[_key];return logMessage(source,`new Function(${args.join(", ")})`,!0),nativeFunction.apply(this,[...args])}FunctionWrapper.prototype=Object.create(nativeFunction.prototype),FunctionWrapper.prototype.constructor=FunctionWrapper,window.Function=FunctionWrapper}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['log', 'abp-log'],
            scriptlet: 'function log(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(){for(var _len=arguments.length,args=new Array(_len),_key=0;_key<_len;_key++)args[_key]=arguments[_key];console.log(args)}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['log-on-stack-trace'],
            scriptlet: 'function logOnStackTrace(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function getPropertyInChain(e,r){var n=r.indexOf(".");if(-1===n)return{base:e,prop:r};var i=r.slice(0,n);if(null===e)return{base:e,prop:i,chain:r};var t=e[i];return r=r.slice(n+1),(e instanceof Object||"object"==typeof e)&&function(t){return 0===Object.keys(t).length&&!t.prototype}(e)||null===t?{base:e,prop:i,chain:r}:void 0!==t?getPropertyInChain(t,r):(Object.defineProperty(e,i,{configurable:!0}),{base:e,prop:i,chain:r})}function hit(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}function logMessage(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,property){if(property){var refineStackTrace=function(stackString){var regExpValues=function(){try{for(var r=[],e=1;e<10;e+=1){var a=`$${e}`;if(!RegExp[a])break;r.push(RegExp[a])}return r}catch(r){return[]}}(),logInfoArray=stackString.split("\\n").slice(2).map((function(line){return line.replace(/ {4}at /,"")})).map((function(line){var funcName,funcFullPath,reg=/\\(([^\\)]+)\\)/,regFirefox=/(.*?@)(\\S+)(:\\d+):\\d+\\)?$/;return line.match(reg)?(funcName=line.split(" ").slice(0,-1).join(" "),funcFullPath=line.match(reg)[1]):line.match(regFirefox)?(funcName=line.split("@").slice(0,-1).join(" "),funcFullPath=line.match(regFirefox)[2]):(funcName="function name is not available",funcFullPath=line),[funcName,funcFullPath]})),logInfoObject={};return logInfoArray.forEach((function(pair){logInfoObject[pair[0]]=pair[1]})),regExpValues.length&&regExpValues[0]!==RegExp.$1&&function(e){if(e.length)try{var r="";r=1===e.length?`(${e[0]})`:e.reduce((function(e,r,t){return 1===t?`(${e}),(${r})`:`${e},(${r})`}));var t=new RegExp(r);e.toString().replace(t,"")}catch(e){var n=`Failed to restore RegExp values: ${e}`;console.log(n)}}(regExpValues),logInfoObject},_setChainPropAccess=function(owner,property){var chainInfo=getPropertyInChain(owner,property),{base:base}=chainInfo,{prop:prop,chain:chain}=chainInfo;if(chain)Object.defineProperty(owner,prop,{get:function(){return base},set:function(a){base=a,a instanceof Object&&_setChainPropAccess(a,chain)}});else{var e,r,t,c,value=base[prop];e=base,r=prop,t={get:()=>(hit(source),logMessage(source,`Get ${prop}`,!0),console.table(refineStackTrace((new Error).stack)),value),set(newValue){hit(source),logMessage(source,`Set ${prop}`,!0),console.table(refineStackTrace((new Error).stack)),value=newValue}},(c=Object.getOwnPropertyDescriptor(e,r))&&!c.configurable||Object.defineProperty(e,r,t)}};_setChainPropAccess(window,property)}}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['m3u-prune', 'm3u-prune.js', 'ubo-m3u-prune.js', 'ubo-m3u-prune'],
            scriptlet: 'function m3uPrune(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function hit(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}function toRegExp(e){var r=e||"",t="/";if(""===r)return new RegExp(".?");var n,i,s=r.lastIndexOf(t),a=r.substring(s+1),g=r.substring(0,s+1),u=(i=a,(n=g).startsWith(t)&&n.endsWith(t)&&!n.endsWith("\\\\/")&&function(e){if(!e)return!1;try{return new RegExp("",e),!0}catch(e){return!1}}(i)?i:"");if(r.startsWith(t)&&r.endsWith(t)||u)return new RegExp((u?g:r).slice(1,-1),u);var c=r.replace(/\\\\\'/g,"\'").replace(/\\\\"/g,\'"\').replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&");return new RegExp(c)}function logMessage(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}function getXhrData(r,t,a,e,n){return{method:r,url:t,async:a,user:e,password:n}}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,propsToRemove){var urlToMatch=arguments.length>2&&void 0!==arguments[2]?arguments[2]:"";if("undefined"!=typeof Reflect&&"undefined"!=typeof fetch&&"undefined"!=typeof Proxy&&"undefined"!=typeof Response){var xhrData,shouldPruneResponse=!1,shouldLogContent="true"===(arguments.length>3&&void 0!==arguments[3]&&arguments[3]),urlMatchRegexp=toRegExp(urlToMatch),AD_MARKER_ASSET="#EXT-X-ASSET:",AD_MARKER_CUE="#EXT-X-CUE:",AD_MARKER_CUE_IN="#EXT-X-CUE-IN",AD_MARKER_DISCONTINUITY="#EXT-X-DISCONTINUITY",AD_MARKER_EXTINF="#EXTINF",AD_MARKER_EXTM3U="#EXTM3U",AD_MARKER_SCTE35="#EXT-X-SCTE35:",COMCAST_AD_MARKER_AD="-AD-",COMCAST_AD_MARKER_VAST="-VAST-",COMCAST_AD_MARKER_VMAP_AD="-VMAP-AD-",COMCAST_AD_MARKER_VMAP_AD_BREAK="#EXT-X-VMAP-AD-BREAK:",TAGS_ALLOWLIST=["#EXT-X-TARGETDURATION","#EXT-X-MEDIA-SEQUENCE","#EXT-X-DISCONTINUITY-SEQUENCE","#EXT-X-ENDLIST","#EXT-X-PLAYLIST-TYPE","#EXT-X-I-FRAMES-ONLY","#EXT-X-MEDIA","#EXT-X-STREAM-INF","#EXT-X-I-FRAME-STREAM-INF","#EXT-X-SESSION-DATA","#EXT-X-SESSION-KEY","#EXT-X-INDEPENDENT-SEGMENTS","#EXT-X-START"],isAllowedTag=function(str){return TAGS_ALLOWLIST.some((function(el){return str.startsWith(el)}))},_pruneExtinfFromVmapBlock=function(lines,i){var array=lines.slice(),index=i;if(array[index].includes(AD_MARKER_EXTINF)&&(array[index]=void 0,array[index+=1].includes(AD_MARKER_DISCONTINUITY))){array[index]=void 0;var prunedExtinf=_pruneExtinfFromVmapBlock(array,index+=1);array=prunedExtinf.array,index=prunedExtinf.index}return{array:array,index:index}},removeM3ULineRegexp=toRegExp(propsToRemove),isM3U=function(text){if("string"==typeof text){var trimmedText=text.trim();return trimmedText.startsWith(AD_MARKER_EXTM3U)||trimmedText.startsWith(COMCAST_AD_MARKER_VMAP_AD_BREAK)}return!1},isPruningNeeded=function(text,regexp){return isM3U(text)&&regexp.test(text)},pruneM3U=function(text){shouldLogContent&&logMessage(source,`Original M3U content:\\n${text}`);var lines=text.split(/\\r?\\n/);return text.includes(COMCAST_AD_MARKER_VMAP_AD_BREAK)?(lines=(lines=function(lines){for(var array=lines.slice(),i=0;i<array.length-1;i+=1)if((array[i].includes(COMCAST_AD_MARKER_VMAP_AD)||array[i].includes(COMCAST_AD_MARKER_VAST)||array[i].includes(COMCAST_AD_MARKER_AD))&&(array[i]=void 0,array[i+1].includes(AD_MARKER_EXTINF))){var prunedExtinf=_pruneExtinfFromVmapBlock(array,i+=1);array=prunedExtinf.array,i=prunedExtinf.index-1}return array}(lines)).filter((function(l){return!!l})).join("\\n"),shouldLogContent&&logMessage(source,`Modified M3U content:\\n${lines}`),lines):(lines=(lines=function(lines){for(var i=0;i<lines.length-1;i+=1){var _lines$i;if(null!==(_lines$i=lines[i])&&void 0!==_lines$i&&_lines$i.startsWith("#")&&removeM3ULineRegexp.test(lines[i])){var segmentName=lines[i].substring(0,lines[i].indexOf(":"));if(!segmentName)return lines;lines[i]=void 0;for(var j=i+=1;j<lines.length;j+=1){if(lines[j].includes(segmentName)||isAllowedTag(lines[j])){i=j-1;break}lines[j]=void 0}}}return lines}(lines)).map((function(line,index,array){return void 0===line||(line=function(line,index,array){return line.startsWith(AD_MARKER_CUE)?(line=void 0,array[index+=1].startsWith(AD_MARKER_ASSET)&&(array[index]=void 0,index+=1),array[index].startsWith(AD_MARKER_SCTE35)&&(array[index]=void 0,index+=1),array[index].startsWith(AD_MARKER_CUE_IN)&&(array[index]=void 0,index+=1),array[index].startsWith(AD_MARKER_SCTE35)&&(array[index]=void 0),line):line}(line,index,array),void 0!==line&&(line=function(line,index,array){return line.startsWith(AD_MARKER_EXTINF)&&removeM3ULineRegexp.test(array[index+1])?(isAllowedTag(array[index])||(array[index]=void 0),isAllowedTag(array[index+=1])||(array[index]=void 0),array[index+=1].startsWith(AD_MARKER_DISCONTINUITY)&&(array[index]=void 0),line):line}(line,index,array))),line})).filter((function(l){return!!l})).join("\\n"),shouldLogContent&&logMessage(source,`Modified M3U content:\\n${lines}`),lines)},nativeOpen=window.XMLHttpRequest.prototype.open,nativeSend=window.XMLHttpRequest.prototype.send,openHandler={apply:function(target,thisArg,args){if(xhrData=getXhrData.apply(null,args),function(e,t,r){if(""===t||"*"===t)return!0;var a,s=function(e){var r={};return e.split(" ").forEach((function(e){var n=e.indexOf(":"),i=e.slice(0,n);if(function(e){return["url","method","headers","body","credentials","cache","redirect","referrer","referrerPolicy","integrity","keepalive","signal","mode"].includes(e)}(i)){var s=e.slice(n+1);r[i]=s}else r.url=e})),r}(t);if(function(t){return Object.values(t).every((function(t){return function(e){var t,n=function(e){return e.replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&")}(e);"/"===e[0]&&"/"===e[e.length-1]&&(n=e.slice(1,-1));try{t=new RegExp(n),t=!0}catch(e){t=!1}return t}(t)}))}(s)){var n=function(t){var a={};return Object.keys(t).forEach((function(c){a[c]=toRegExp(t[c])})),a}(s);a=Object.keys(n).every((function(e){var t=n[e],a=r[e];return Object.prototype.hasOwnProperty.call(r,e)&&"string"==typeof a&&(null==t?void 0:t.test(a))}))}else logMessage(e,`Invalid parameter: ${t}`),a=!1;return a}(source,urlToMatch,xhrData)&&(thisArg.shouldBePruned=!0),thisArg.shouldBePruned){thisArg.collectedHeaders=[];var setRequestHeaderHandler={apply:function(target,thisArg,args){return thisArg.collectedHeaders.push(args),Reflect.apply(target,thisArg,args)}};thisArg.setRequestHeader=new Proxy(thisArg.setRequestHeader,setRequestHeaderHandler)}return Reflect.apply(target,thisArg,args)}},sendHandler={apply:function(target,thisArg,args){if(!thisArg.shouldBePruned||!["","text"].includes(thisArg.responseType))return Reflect.apply(target,thisArg,args);var forgedRequest=new XMLHttpRequest;forgedRequest.addEventListener("readystatechange",(function(){if(4===forgedRequest.readyState){var{readyState:readyState,response:response,responseText:responseText,responseURL:responseURL,responseXML:responseXML,status:status,statusText:statusText}=forgedRequest;if("string"==typeof(responseText||response)){propsToRemove?shouldPruneResponse=isPruningNeeded(response,removeM3ULineRegexp):isM3U(response)&&logMessage(source,`XMLHttpRequest.open() URL: ${responseURL}\\nresponse: ${response}`);var responseContent=shouldPruneResponse?pruneM3U(response):response;Object.defineProperties(thisArg,{readyState:{value:readyState,writable:!1},responseURL:{value:responseURL,writable:!1},responseXML:{value:responseXML,writable:!1},status:{value:status,writable:!1},statusText:{value:statusText,writable:!1},response:{value:responseContent,writable:!1},responseText:{value:responseContent,writable:!1}}),setTimeout((function(){var stateEvent=new Event("readystatechange");thisArg.dispatchEvent(stateEvent);var loadEvent=new Event("load");thisArg.dispatchEvent(loadEvent);var loadEndEvent=new Event("loadend");thisArg.dispatchEvent(loadEndEvent)}),1),hit(source)}}})),nativeOpen.apply(forgedRequest,[xhrData.method,xhrData.url]),thisArg.collectedHeaders.forEach((function(header){var name=header[0],value=header[1];forgedRequest.setRequestHeader(name,value)})),thisArg.collectedHeaders=[];try{nativeSend.call(forgedRequest,args)}catch(_unused){return Reflect.apply(target,thisArg,args)}}};XMLHttpRequest.prototype.open=new Proxy(XMLHttpRequest.prototype.open,openHandler),XMLHttpRequest.prototype.send=new Proxy(XMLHttpRequest.prototype.send,sendHandler);var nativeFetch=window.fetch,fetchHandler={apply:async function(target,thisArg,args){var fetchURL=args[0]instanceof Request?args[0].url:args[0];if("string"!=typeof fetchURL||0===fetchURL.length)return Reflect.apply(target,thisArg,args);if(urlMatchRegexp.test(fetchURL)){var response=await nativeFetch(...args),clonedResponse=response.clone(),responseText=await response.text();if(!propsToRemove&&isM3U(responseText))return logMessage(source,`fetch URL: ${fetchURL}\\nresponse text: ${responseText}`),clonedResponse;if(isPruningNeeded(responseText,removeM3ULineRegexp)){var prunedText=pruneM3U(responseText);return hit(source),new Response(prunedText,{status:response.status,statusText:response.statusText,headers:response.headers})}return clonedResponse}return Reflect.apply(target,thisArg,args)}};window.fetch=new Proxy(window.fetch,fetchHandler)}}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['metrika-yandex-tag'],
            scriptlet: 'function metrikaYandexTag(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function noopFunc(){}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source){var asyncCallbackFromOptions=function(id,param){var options=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{},{callback:callback}=options,{ctx:ctx}=options;"function"==typeof callback&&(callback=void 0!==ctx?callback.bind(ctx):callback,setTimeout((function(){return callback()})))},api={addFileExtension:noopFunc,extLink:asyncCallbackFromOptions,file:asyncCallbackFromOptions,getClientID:function(id,cb){cb&&setTimeout(cb(null))},hit:asyncCallbackFromOptions,notBounce:asyncCallbackFromOptions,params:noopFunc,reachGoal:function(id,target,params,callback,ctx){asyncCallbackFromOptions(null,null,{callback:callback,ctx:ctx})},setUserID:noopFunc,userParams:noopFunc,destruct:noopFunc};function init(id){window[`yaCounter${id}`]=api,document.dispatchEvent(new Event(`yacounter${id}inited`))}function ym(id,funcName){if("init"===funcName)return init(id);for(var _len=arguments.length,args=new Array(_len>2?_len-2:0),_key=2;_key<_len;_key++)args[_key-2]=arguments[_key];return api[funcName]&&api[funcName](id,...args)}void 0===window.ym?(window.ym=ym,ym.a=[]):window.ym&&window.ym.a&&(ym.a=window.ym.a,window.ym=ym,window.ym.a.forEach((function(params){init(params[0])}))),function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source)}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['metrika-yandex-watch'],
            scriptlet: 'function metrikaYandexWatch(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function noopFunc(){}function noopArray(){return[]}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source){var cbName="yandex_metrika_callbacks",asyncCallbackFromOptions=function(){var options=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},{callback:callback}=options,{ctx:ctx}=options;"function"==typeof callback&&(callback=void 0!==ctx?callback.bind(ctx):callback,setTimeout((function(){return callback()})))};function Metrika(){}Metrika.counters=noopArray,Metrika.prototype.addFileExtension=noopFunc,Metrika.prototype.getClientID=noopFunc,Metrika.prototype.setUserID=noopFunc,Metrika.prototype.userParams=noopFunc,Metrika.prototype.params=noopFunc,Metrika.prototype.counters=noopArray,Metrika.prototype.extLink=function(url,options){asyncCallbackFromOptions(options)},Metrika.prototype.file=function(url,options){asyncCallbackFromOptions(options)},Metrika.prototype.hit=function(url,options){asyncCallbackFromOptions(options)},Metrika.prototype.reachGoal=function(target,params,cb,ctx){asyncCallbackFromOptions({callback:cb,ctx:ctx})},Metrika.prototype.notBounce=asyncCallbackFromOptions,window.Ya?window.Ya.Metrika=Metrika:window.Ya={Metrika:Metrika},window[cbName]&&Array.isArray(window[cbName])&&window[cbName].forEach((function(func){"function"==typeof func&&func()})),function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source)}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['no-protected-audience'],
            scriptlet: 'function noProtectedAudience(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function noopStr(){return""}function noopFunc(){}function noopResolveVoid(){return Promise.resolve(void 0)}function noopResolveNull(){return Promise.resolve(null)}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source){if(Document instanceof Object!=0){for(var protectedAudienceMethods={joinAdInterestGroup:noopResolveVoid,runAdAuction:noopResolveNull,leaveAdInterestGroup:noopResolveVoid,clearOriginJoinedAdInterestGroups:noopResolveVoid,createAuctionNonce:noopStr,updateAdInterestGroups:noopFunc},_i=0,_Object$keys=Object.keys(protectedAudienceMethods);_i<_Object$keys.length;_i++){var methodName=_Object$keys[_i],prototype=Navigator.prototype;Object.prototype.hasOwnProperty.call(prototype,methodName)&&prototype[methodName]instanceof Function!=0&&(prototype[methodName]=protectedAudienceMethods[methodName])}!function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source)}}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['no-topics'],
            scriptlet: 'function noTopics(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source){Document instanceof Object!=0&&Object.prototype.hasOwnProperty.call(Document.prototype,"browsingTopics")&&Document.prototype.browsingTopics instanceof Function!=0&&(Document.prototype.browsingTopics=function(){return function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:"{}",t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"",s=arguments.length>2&&void 0!==arguments[2]?arguments[2]:"basic";if("undefined"!=typeof Response){var n=new Response(e,{headers:{"Content-Length":`${e.length}`},status:200,statusText:"OK"});return"opaque"===s?Object.defineProperties(n,{body:{value:null},status:{value:0},ok:{value:!1},statusText:{value:""},url:{value:""},type:{value:s}}):Object.defineProperties(n,{url:{value:t},type:{value:s}}),Promise.resolve(n)}}("[]")},function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source))}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: [
                'noeval',
                'noeval.js',
                'silent-noeval.js',
                'ubo-noeval.js',
                'ubo-silent-noeval.js',
                'ubo-noeval',
                'ubo-silent-noeval',
            ],
            scriptlet: 'function noeval(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source){window.eval=function(s){!function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source),function(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}(source,`ABY has prevented eval:\\n${s}`,!0)}.bind()}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['nowebrtc', 'nowebrtc.js', 'ubo-nowebrtc.js', 'ubo-nowebrtc'],
            scriptlet: 'function nowebrtc(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function noopFunc(){}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source){var propertyName="";if(window.RTCPeerConnection?propertyName="RTCPeerConnection":window.webkitRTCPeerConnection&&(propertyName="webkitRTCPeerConnection"),""!==propertyName){var rtcReplacement=function(config){var message=`Document tried to create an RTCPeerConnection: ${function(e){var t="undefined";if(null===e)t="null";else if(e instanceof Object){var r="iceServers",n="urls";Object.prototype.hasOwnProperty.call(e,r)&&e[r]&&Object.prototype.hasOwnProperty.call(e[r][0],n)&&e[r][0][n]&&(t=e[r][0][n].toString())}return t}(config)}`;!function(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}(source,message),function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source)};rtcReplacement.prototype={close:noopFunc,createDataChannel:noopFunc,createOffer:noopFunc,setRemoteDescription:noopFunc};var rtc=window[propertyName];window[propertyName]=rtcReplacement,rtc.prototype&&(rtc.prototype.createDataChannel=function(a,b){return{close:noopFunc,send:noopFunc}}.bind(null))}}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: [
                'prevent-addEventListener',
                'addEventListener-defuser.js',
                'ubo-addEventListener-defuser.js',
                'aeld.js',
                'ubo-aeld.js',
                'ubo-addEventListener-defuser',
                'ubo-aeld',
                'abp-prevent-listener',
            ],
            scriptlet: 'function preventAddEventListener(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function toRegExp(e){var r=e||"",t="/";if(""===r)return new RegExp(".?");var n,i,s=r.lastIndexOf(t),a=r.substring(s+1),g=r.substring(0,s+1),u=(i=a,(n=g).startsWith(t)&&n.endsWith(t)&&!n.endsWith("\\\\/")&&function(e){if(!e)return!1;try{return new RegExp("",e),!0}catch(e){return!1}}(i)?i:"");if(r.startsWith(t)&&r.endsWith(t)||u)return new RegExp((u?g:r).slice(1,-1),u);var c=r.replace(/\\\\\'/g,"\'").replace(/\\\\"/g,\'"\').replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&");return new RegExp(c)}function logMessage(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,typeSearch,listenerSearch,additionalArgName,additionalArgValue){var elementToMatch,typeSearchRegexp=toRegExp(typeSearch),listenerSearchRegexp=toRegExp(listenerSearch);if(additionalArgName){if("elements"!==additionalArgName)return void logMessage(source,`Invalid "additionalArgName": ${additionalArgName}\\nOnly "elements" is supported.`);if(!additionalArgValue)return void logMessage(source,\'"additionalArgValue" is required.\');elementToMatch=additionalArgValue}var nativeAddEventListener=window.EventTarget.prototype.addEventListener;function addEventListenerWrapper(type,listener){var _this$constructor,element,n,shouldPrevent=!1;if(null!=type&&(void 0!==(n=listener)&&("function"==typeof n||"object"==typeof n&&null!==n&&"handleEvent"in n&&"function"==typeof n.handleEvent))&&(shouldPrevent=typeSearchRegexp.test(type.toString())&&listenerSearchRegexp.test(function(n){return"function"==typeof n?n.toString():n.handleEvent.toString()}(listener))&&(element=this,void 0===elementToMatch||("window"===elementToMatch?element===window:"document"===elementToMatch?element===document:!!(element&&element.matches&&element.matches(elementToMatch))))),!shouldPrevent){var context=this;this&&"Window"===(null===(_this$constructor=this.constructor)||void 0===_this$constructor?void 0:_this$constructor.name)&&this!==window&&(context=window);for(var _len=arguments.length,args=new Array(_len>2?_len-2:0),_key=2;_key<_len;_key++)args[_key-2]=arguments[_key];return nativeAddEventListener.apply(context,[type,listener,...args])}!function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source)}var descriptor={configurable:!0,set:function(){},get:function(){return addEventListenerWrapper}};Object.defineProperty(window.EventTarget.prototype,"addEventListener",descriptor),Object.defineProperty(window,"addEventListener",descriptor),Object.defineProperty(document,"addEventListener",descriptor)}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['prevent-adfly'],
            scriptlet: 'function preventAdfly(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source){var val,e,r,t,c,isDigit=function(data){return/^\\d$/.test(data)},applyHandler=!0;e=window,r="ysmm",t={configurable:!1,set:function(value){if(applyHandler){applyHandler=!1;try{"string"==typeof value&&function(encodedURL){for(var evenChars="",oddChars="",i=0;i<encodedURL.length;i+=1)i%2==0?evenChars+=encodedURL.charAt(i):oddChars=encodedURL.charAt(i)+oddChars;for(var data=(evenChars+oddChars).split(""),_i=0;_i<data.length;_i+=1)if(isDigit(data[_i]))for(var ii=_i+1;ii<data.length;ii+=1)if(isDigit(data[ii])){var temp=parseInt(data[_i],10)^parseInt(data[ii],10);temp<10&&(data[_i]=temp.toString()),_i=ii;break}data=data.join("");var decodedURL=window.atob(data).slice(16,-16);window.stop&&window.stop(),window.onbeforeunload=null,window.location.href=decodedURL}(value)}catch(err){}}val=value},get:function(){return val}},(c=Object.getOwnPropertyDescriptor(e,r))&&!c.configurable||(Object.defineProperty(e,r,t),0)?function(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}(source,"Failed to set up prevent-adfly scriptlet"):function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source)}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['prevent-bab', 'ubo-nobab', 'nobab', 'bab-defuser', 'nobab.js', 'ubo-nobab.js', 'bab-defuser.js'],
            scriptlet: 'function preventBab(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function hit(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source){var nativeSetTimeout=window.setTimeout,babRegex=/\\.bab_elementid.$/;window.setTimeout=function(callback){if("string"!=typeof callback||!babRegex.test(callback)){for(var _len=arguments.length,args=new Array(_len>1?_len-1:0),_key=1;_key<_len;_key++)args[_key-1]=arguments[_key];return nativeSetTimeout.apply(window,[callback,...args])}hit(source)};var signatures=[["blockadblock"],["babasbm"],[/getItem\\(\'babn\'\\)/],["getElementById","String.fromCharCode","ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789","charAt","DOMContentLoaded","AdBlock","addEventListener","doScroll","fromCharCode","<<2|r>>4","sessionStorage","clientWidth","localStorage","Math","random"]],nativeEval=window.eval;window.eval=function(str){if(!function(str){if("string"!=typeof str)return!1;for(var i=0;i<signatures.length;i+=1){for(var tokens=signatures[i],match=0,j=0;j<tokens.length;j+=1){var token=tokens[j];(token instanceof RegExp?token.test(str):str.includes(token))&&(match+=1)}if(match/tokens.length>=.8)return!0}return!1}(str))return nativeEval(str);hit(source);var bodyEl=document.body;bodyEl&&bodyEl.style.removeProperty("visibility");var el=document.getElementById("babasbmsgx");el&&el.parentNode.removeChild(el)}.bind(window),window.eval.toString=nativeEval.toString.bind(nativeEval)}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['prevent-canvas', 'prevent-canvas.js', 'ubo-prevent-canvas.js', 'ubo-prevent-canvas'],
            scriptlet: 'function preventCanvas(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function toRegExp(e){var r=e||"",t="/";if(""===r)return new RegExp(".?");var n,i,s=r.lastIndexOf(t),a=r.substring(s+1),g=r.substring(0,s+1),u=(i=a,(n=g).startsWith(t)&&n.endsWith(t)&&!n.endsWith("\\\\/")&&function(e){if(!e)return!1;try{return new RegExp("",e),!0}catch(e){return!1}}(i)?i:"");if(r.startsWith(t)&&r.endsWith(t)||u)return new RegExp((u?g:r).slice(1,-1),u);var c=r.replace(/\\\\\'/g,"\'").replace(/\\\\"/g,\'"\').replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&");return new RegExp(c)}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,contextType){var canvasHandler={apply:function(target,thisArg,argumentsList){var t,i,type=argumentsList[0],shouldPrevent=!1;if(contextType)if(i=t=contextType,null!=t&&t.startsWith("!")&&(i=t.slice(1)),function(e){var t,n=function(e){return e.replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&")}(e);"/"===e[0]&&"/"===e[e.length-1]&&(n=e.slice(1,-1));try{t=new RegExp(n),t=!0}catch(e){t=!1}return t}(i)){var{isInvertedMatch:isInvertedMatch,matchRegexp:matchRegexp}=function(t){var e=!!t&&(null==t?void 0:t.startsWith("!")),a=e?t.slice(1):t;return{isInvertedMatch:e,matchRegexp:toRegExp(a),matchValue:a}}(contextType);shouldPrevent=matchRegexp.test(type)!==isInvertedMatch}else!function(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}(source,`Invalid contextType parameter: ${contextType}`),shouldPrevent=!1;else shouldPrevent=!0;return shouldPrevent?(function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source),null):Reflect.apply(target,thisArg,argumentsList)}};window.HTMLCanvasElement.prototype.getContext=new Proxy(window.HTMLCanvasElement.prototype.getContext,canvasHandler)}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['prevent-constructor'],
            scriptlet: 'function preventConstructor(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function toRegExp(e){var r=e||"",t="/";if(""===r)return new RegExp(".?");var n,i,s=r.lastIndexOf(t),a=r.substring(s+1),g=r.substring(0,s+1),u=(i=a,(n=g).startsWith(t)&&n.endsWith(t)&&!n.endsWith("\\\\/")&&function(e){if(!e)return!1;try{return new RegExp("",e),!0}catch(e){return!1}}(i)?i:"");if(r.startsWith(t)&&r.endsWith(t)||u)return new RegExp((u?g:r).slice(1,-1),u);var c=r.replace(/\\\\\'/g,"\'").replace(/\\\\"/g,\'"\').replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&");return new RegExp(c)}function logMessage(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}function noopFunc(){}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,constructorName,argumentsMatch){if(constructorName){var nativeConstructor=window[constructorName];if("function"==typeof nativeConstructor){var arrayArgPatterns=function(input){if(!input)return null;if(input.trim().startsWith("[")&&input.trim().endsWith("]"))try{var parsed=JSON.parse(input);return Array.isArray(parsed)?parsed.map((function(p){return String(p)})):(logMessage(source,"Invalid argumentsMatch: not an array"),null)}catch(e){return logMessage(source,`Invalid JSON in argumentsMatch: ${input}`),null}return null}(argumentsMatch),isMatchingSuspended=!1,constructorHandler={construct:function(target,args,newTarget){if(isMatchingSuspended)return Reflect.construct(target,args,newTarget);isMatchingSuspended=!0;var shouldPrevent=!1;if(argumentsMatch)if(null!==arrayArgPatterns){shouldPrevent=!0;for(var i=0;i<arrayArgPatterns.length;i+=1){var pattern=arrayArgPatterns[i];if("*"!==pattern){if(i>=args.length){var msg=`Pattern expects argument at position ${i}, but constructor called with ${args.length} arguments`;logMessage(source,msg),shouldPrevent=!1;break}var arg=args[i],argStr=void 0;if("function"==typeof arg)argStr=arg.toString();else if("object"==typeof arg&&null!==arg)try{argStr=JSON.stringify(arg)}catch(e){argStr=String(arg)}else argStr=String(arg);if(!toRegExp(pattern).test(argStr)){shouldPrevent=!1;break}}}}else{var firstArgStr,firstArg=args[0];if("function"==typeof firstArg)firstArgStr=firstArg.toString();else if("object"==typeof firstArg&&null!==firstArg)try{firstArgStr=JSON.stringify(firstArg)}catch(e){firstArgStr=String(firstArg)}else firstArgStr=String(firstArg);shouldPrevent=toRegExp(argumentsMatch).test(firstArgStr)}else shouldPrevent=!0;if(!shouldPrevent)return isMatchingSuspended=!1,Reflect.construct(target,args,newTarget);!function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source);try{var result=Reflect.construct(target,[noopFunc],newTarget);return isMatchingSuspended=!1,result}catch(e){return isMatchingSuspended=!1,Object.create(target.prototype||null)}},get:(target,prop,receiver)=>"toString"===prop?Function.prototype.toString.bind(target):Reflect.get(target,prop,receiver)};window[constructorName]=new Proxy(nativeConstructor,constructorHandler)}else logMessage(source,`"${constructorName}" is not a function`)}}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['prevent-element-src-loading'],
            scriptlet: 'function preventElementSrcLoading(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function hit(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}function safeGetDescriptor(r,e){var t=Object.getOwnPropertyDescriptor(r,e);return t&&t.configurable?t:null}function noopFunc(){}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,tagName,match){if("undefined"!=typeof Proxy&&"undefined"!=typeof Reflect){var instance,srcMockData={script:"data:text/javascript;base64,KCk9Pnt9",img:"data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==",iframe:"data:text/html;base64, PGRpdj48L2Rpdj4=",link:"data:text/plain;base64,"};if("script"===tagName)instance=HTMLScriptElement;else if("img"===tagName)instance=HTMLImageElement;else if("iframe"===tagName)instance=HTMLIFrameElement;else{if("link"!==tagName)return;instance=HTMLLinkElement}var policy=function(t){var r,e=null==t||null===(r=t.api)||void 0===r?void 0:r.policy;if(e)return e;var n="AGPolicy",i=window.trustedTypes,u=!!i,c={HTML:"TrustedHTML",Script:"TrustedScript",ScriptURL:"TrustedScriptURL"};if(!u)return{name:n,isSupported:u,TrustedType:c,createHTML:function(t){return t},createScript:function(t){return t},createScriptURL:function(t){return t},create:function(t,r){return r},getAttributeType:function(){return null},convertAttributeToTrusted:function(t,r,e){return e},getPropertyType:function(){return null},convertPropertyToTrusted:function(t,r,e){return e},isHTML:function(){return!1},isScript:function(){return!1},isScriptURL:function(){return!1}};var o=i.createPolicy(n,{createHTML:function(t){return t},createScript:function(t){return t},createScriptURL:function(t){return t}}),createHTML=function(t){return o.createHTML(t)},createScript=function(t){return o.createScript(t)},createScriptURL=function(t){return o.createScriptURL(t)},create=function(t,r){switch(t){case c.HTML:return createHTML(r);case c.Script:return createScript(r);case c.ScriptURL:return createScriptURL(r);default:return r}},p=i.getAttributeType.bind(i),T=i.getPropertyType.bind(i),s=i.isHTML.bind(i),a=i.isScript.bind(i),f=i.isScriptURL.bind(i);return{name:n,isSupported:u,TrustedType:c,createHTML:createHTML,createScript:createScript,createScriptURL:createScriptURL,create:create,getAttributeType:p,convertAttributeToTrusted:function(t,r,e,n,i){var u=p(t,r,n,i);return u?create(u,e):e},getPropertyType:T,convertPropertyToTrusted:function(t,r,e,n){var i=T(t,r,n);return i?create(i,e):e},isHTML:s,isScript:a,isScriptURL:f}}(source),SOURCE_PROPERTY_NAME="link"===tagName?"href":"src",searchRegexp=function(e){var r=e||"",t="/";if(""===r)return new RegExp(".?");var n,i,s=r.lastIndexOf(t),a=r.substring(s+1),g=r.substring(0,s+1),u=(i=a,(n=g).startsWith(t)&&n.endsWith(t)&&!n.endsWith("\\\\/")&&function(e){if(!e)return!1;try{return new RegExp("",e),!0}catch(e){return!1}}(i)?i:"");if(r.startsWith(t)&&r.endsWith(t)||u)return new RegExp((u?g:r).slice(1,-1),u);var c=r.replace(/\\\\\'/g,"\'").replace(/\\\\"/g,\'"\').replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&");return new RegExp(c)}(match),setMatchedAttribute=function(elem){return elem.setAttribute(source.name,"matched")},setAttributeHandler={apply:function(target,thisArg,args){if(!args[0]||!args[1])return Reflect.apply(target,thisArg,args);var nodeName=thisArg.nodeName.toLowerCase(),attrName=args[0].toLowerCase(),attrValue=args[1];return attrName===SOURCE_PROPERTY_NAME&&tagName.toLowerCase()===nodeName&&srcMockData[nodeName]&&searchRegexp.test(attrValue)?(hit(source),setMatchedAttribute(thisArg),Reflect.apply(target,thisArg,[attrName,srcMockData[nodeName]])):Reflect.apply(target,thisArg,args)}};instance.prototype.setAttribute=new Proxy(Element.prototype.setAttribute,setAttributeHandler);var origSrcDescriptor=safeGetDescriptor(instance.prototype,SOURCE_PROPERTY_NAME);if(origSrcDescriptor){Object.defineProperty(instance.prototype,SOURCE_PROPERTY_NAME,{enumerable:!0,configurable:!0,get(){return origSrcDescriptor.get.call(this)},set(urlValue){var nodeName=this.nodeName.toLowerCase();if(tagName.toLowerCase()!==nodeName||!srcMockData[nodeName]||!searchRegexp.test(urlValue))return origSrcDescriptor.set.call(this,urlValue),!0;var mockData=srcMockData[nodeName];"undefined"!=typeof TrustedScriptURL&&null!=policy&&policy.isSupported&&urlValue instanceof TrustedScriptURL&&(mockData=policy.createScriptURL(mockData)),setMatchedAttribute(this),origSrcDescriptor.set.call(this,mockData),hit(source)}});var origOnerrorDescriptor=safeGetDescriptor(HTMLElement.prototype,"onerror");if(origOnerrorDescriptor){Object.defineProperty(HTMLElement.prototype,"onerror",{enumerable:!0,configurable:!0,get(){return origOnerrorDescriptor.get.call(this)},set(cb){return"matched"===this.getAttribute(source.name)?(origOnerrorDescriptor.set.call(this,noopFunc),!0):(origOnerrorDescriptor.set.call(this,cb),!0)}});var addEventListenerHandler={apply:function(target,thisArg,args){if(!args[0]||!args[1]||!thisArg)return Reflect.apply(target,thisArg,args);var eventName=args[0];return"function"==typeof thisArg.getAttribute&&"matched"===thisArg.getAttribute(source.name)&&"error"===eventName?Reflect.apply(target,thisArg,[eventName,noopFunc]):Reflect.apply(target,thisArg,args)}};EventTarget.prototype.addEventListener=new Proxy(EventTarget.prototype.addEventListener,addEventListenerHandler),function(tagName,src){window.addEventListener("error",(function(event){event.target&&event.target.nodeName&&event.target.nodeName.toLowerCase()===tagName&&event.target.src&&src.test(event.target.src)&&(hit(source),"function"!=typeof event.target.onload?event.target.onerror=noopFunc:event.target.onerror=event.target.onload)}),!0)}(tagName,searchRegexp)}}}}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['prevent-eval-if', 'noeval-if.js', 'ubo-noeval-if.js', 'ubo-noeval-if'],
            scriptlet: 'function preventEvalIf(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,search){var searchRegexp=function(e){var r=e||"",t="/";if(""===r)return new RegExp(".?");var n,i,s=r.lastIndexOf(t),a=r.substring(s+1),g=r.substring(0,s+1),u=(i=a,(n=g).startsWith(t)&&n.endsWith(t)&&!n.endsWith("\\\\/")&&function(e){if(!e)return!1;try{return new RegExp("",e),!0}catch(e){return!1}}(i)?i:"");if(r.startsWith(t)&&r.endsWith(t)||u)return new RegExp((u?g:r).slice(1,-1),u);var c=r.replace(/\\\\\'/g,"\'").replace(/\\\\"/g,\'"\').replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&");return new RegExp(c)}(search),nativeEval=window.eval;window.eval=function(payload){if(!searchRegexp.test(payload.toString()))return nativeEval.call(window,payload);!function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source)}.bind(window),window.eval.toString=nativeEval.toString.bind(nativeEval)}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: [
                'prevent-fab-3.2.0',
                'nofab.js',
                'ubo-nofab.js',
                'fuckadblock.js-3.2.0',
                'ubo-fuckadblock.js-3.2.0',
                'ubo-nofab',
            ],
            scriptlet: 'function preventFab(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function noopFunc(){}function noopThis(){return this}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source){!function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source);var Fab=function(){};Fab.prototype.check=noopFunc,Fab.prototype.clearEvent=noopFunc,Fab.prototype.emitEvent=noopFunc,Fab.prototype.on=function(a,b){return a||b(),this},Fab.prototype.onDetected=noopThis,Fab.prototype.onNotDetected=function(a){return a(),this},Fab.prototype.setOption=noopFunc,Fab.prototype.options={set:noopFunc,get:noopFunc};var fab=new Fab,getSetFab={get:()=>Fab,set(){}},getsetfab={get:()=>fab,set(){}};Object.prototype.hasOwnProperty.call(window,"FuckAdBlock")?window.FuckAdBlock=Fab:Object.defineProperty(window,"FuckAdBlock",getSetFab),Object.prototype.hasOwnProperty.call(window,"BlockAdBlock")?window.BlockAdBlock=Fab:Object.defineProperty(window,"BlockAdBlock",getSetFab),Object.prototype.hasOwnProperty.call(window,"SniffAdBlock")?window.SniffAdBlock=Fab:Object.defineProperty(window,"SniffAdBlock",getSetFab),Object.prototype.hasOwnProperty.call(window,"fuckAdBlock")?window.fuckAdBlock=fab:Object.defineProperty(window,"fuckAdBlock",getsetfab),Object.prototype.hasOwnProperty.call(window,"blockAdBlock")?window.blockAdBlock=fab:Object.defineProperty(window,"blockAdBlock",getsetfab),Object.prototype.hasOwnProperty.call(window,"sniffAdBlock")?window.sniffAdBlock=fab:Object.defineProperty(window,"sniffAdBlock",getsetfab)}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: [
                'prevent-fetch',
                'prevent-fetch.js',
                'ubo-prevent-fetch.js',
                'ubo-prevent-fetch',
                'no-fetch-if.js',
                'ubo-no-fetch-if.js',
                'ubo-no-fetch-if',
            ],
            scriptlet: 'function preventFetch(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function hit(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}function objectToString(t){return t&&"object"==typeof t?function(t){return 0===Object.keys(t).length&&!t.prototype}(t)?"{}":Object.entries(t).map((function(t){var n=t[0],e=t[1],o=e;return e instanceof Object&&(o=`{ ${objectToString(e)} }`),`${n}:"${o}"`})).join(" "):String(t)}function logMessage(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}function noopPromiseResolve(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:"{}",t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"",s=arguments.length>2&&void 0!==arguments[2]?arguments[2]:"basic";if("undefined"!=typeof Response){var n=new Response(e,{headers:{"Content-Length":`${e.length}`},status:200,statusText:"OK"});return"opaque"===s?Object.defineProperties(n,{body:{value:null},status:{value:0},ok:{value:!1},statusText:{value:""},url:{value:""},type:{value:s}}):Object.defineProperties(n,{url:{value:t},type:{value:s}}),Promise.resolve(n)}}function nativeIsFinite(i){return(Number.isFinite||window.isFinite)(i)}function getNumberFromString(n){var N,r=parseInt(n,10);return N=r,(Number.isNaN||window.isNaN)(N)?null:r}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,propsToMatch){var responseBody=arguments.length>2&&void 0!==arguments[2]?arguments[2]:"emptyObj",responseType=arguments.length>3?arguments[3]:void 0;if("undefined"!=typeof fetch&&"undefined"!=typeof Proxy&&"undefined"!=typeof Response){var strResponseBody,nativeRequestClone=Request.prototype.clone;if(""===responseBody||"emptyObj"===responseBody)strResponseBody="{}";else if("emptyArr"===responseBody)strResponseBody="[]";else if("emptyStr"===responseBody)strResponseBody="";else{if("true"!==responseBody&&!responseBody.match(/^length:\\d+-\\d+$/))return void logMessage(source,`Invalid responseBody parameter: \'${responseBody}\'`);strResponseBody=function(e){var t=e;if("true"===t)return Math.random().toString(36).slice(-10);if(t=t.replace("length:",""),!/^\\d+-\\d+$/.test(t))return null;var n=getNumberFromString(t.split("-")[0]),r=getNumberFromString(t.split("-")[1]);if(!nativeIsFinite(n)||!nativeIsFinite(r))return null;if(n>r){var i=n;n=r,r=i}if(r>5e5)return null;var a=function(t,n){return t=Math.ceil(t),n=Math.floor(n),Math.floor(Math.random()*(n-t+1)+t)}(n,r);return function(r){for(var t="",a="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+=~",n=0;n<r;n+=1)t+=a.charAt(Math.floor(76*Math.random()));return t}(a)}(responseBody)}if(void 0===responseType||function(responseType){return["basic","cors","opaque"].includes(responseType)}(responseType)){var fetchHandler={apply:async function(target,thisArg,args){var fetchData=function(e,t){var a,c,n={},r=e[0];if(r instanceof Request){var f=function(t){var e=["url","method","headers","body","credentials","cache","redirect","referrer","referrerPolicy","integrity","keepalive","signal","mode"].map((function(e){return[e,t[e]]}));return Object.fromEntries(e)}(t.call(r));a=f.url,c=f}else a=r,c=e[1];return n.url=a,c instanceof Object&&Object.keys(c).forEach((function(e){n[e]=c[e]})),n}(args,nativeRequestClone);if(void 0===propsToMatch)return logMessage(source,`fetch( ${objectToString(fetchData)} )`,!0),hit(source),Reflect.apply(target,thisArg,args);if(function(e,t,r){if(""===t||"*"===t)return!0;var a,s=function(e){var r={};return e.split(" ").forEach((function(e){var n=e.indexOf(":"),i=e.slice(0,n);if(function(e){return["url","method","headers","body","credentials","cache","redirect","referrer","referrerPolicy","integrity","keepalive","signal","mode"].includes(e)}(i)){var s=e.slice(n+1);r[i]=s}else r.url=e})),r}(t);if(function(t){return Object.values(t).every((function(t){return function(e){var t,n=function(e){return e.replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&")}(e);"/"===e[0]&&"/"===e[e.length-1]&&(n=e.slice(1,-1));try{t=new RegExp(n),t=!0}catch(e){t=!1}return t}(t)}))}(s)){var n=function(t){var a={};return Object.keys(t).forEach((function(c){a[c]=function(e){var r=e||"",t="/";if(""===r)return new RegExp(".?");var n,i,s=r.lastIndexOf(t),a=r.substring(s+1),g=r.substring(0,s+1),u=(i=a,(n=g).startsWith(t)&&n.endsWith(t)&&!n.endsWith("\\\\/")&&function(e){if(!e)return!1;try{return new RegExp("",e),!0}catch(e){return!1}}(i)?i:"");if(r.startsWith(t)&&r.endsWith(t)||u)return new RegExp((u?g:r).slice(1,-1),u);var c=r.replace(/\\\\\'/g,"\'").replace(/\\\\"/g,\'"\').replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&");return new RegExp(c)}(t[c])})),a}(s);a=Object.keys(n).every((function(e){var t=n[e],a=r[e];return Object.prototype.hasOwnProperty.call(r,e)&&"string"==typeof a&&(null==t?void 0:t.test(a))}))}else logMessage(e,`Invalid parameter: ${t}`),a=!1;return a}(source,propsToMatch,fetchData)){var finalResponseType;hit(source);try{finalResponseType=responseType||function(request){try{var{mode:mode}=request;if(void 0===mode||"cors"===mode||"no-cors"===mode)return new URL(request.url).origin===document.location.origin?"basic":"no-cors"===mode?"opaque":"cors"}catch(error){logMessage(source,`Could not determine response type: ${error}`)}}(fetchData);var origResponse=await Reflect.apply(target,thisArg,args);return origResponse.ok?function(e){var t,s=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{body:"{}"},u={};null==e||null===(t=e.headers)||void 0===t||t.forEach((function(e,t){u[t]=e}));var n=new Response(s.body,{status:e.status,statusText:e.statusText,headers:u});return Object.defineProperties(n,{url:{value:e.url},type:{value:s.type||e.type}}),n}(origResponse,{body:strResponseBody,type:finalResponseType}):noopPromiseResolve(strResponseBody,fetchData.url,finalResponseType)}catch(ex){return noopPromiseResolve(strResponseBody,fetchData.url,finalResponseType)}}return Reflect.apply(target,thisArg,args)}};fetch=new Proxy(fetch,fetchHandler)}else logMessage(source,`Invalid responseType parameter: \'${responseType}\'`)}}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['prevent-innerHTML', 'prevent-innerHTML.js', 'ubo-prevent-innerHTML.js', 'ubo-prevent-innerHTML'],
            scriptlet: 'function preventInnerHTML(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function hit(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}function logMessage(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}function toRegExp(e){var r=e||"",t="/";if(""===r)return new RegExp(".?");var n,i,s=r.lastIndexOf(t),a=r.substring(s+1),g=r.substring(0,s+1),u=(i=a,(n=g).startsWith(t)&&n.endsWith(t)&&!n.endsWith("\\\\/")&&function(e){if(!e)return!1;try{return new RegExp("",e),!0}catch(e){return!1}}(i)?i:"");if(r.startsWith(t)&&r.endsWith(t)||u)return new RegExp((u?g:r).slice(1,-1),u);var c=r.replace(/\\\\\'/g,"\'").replace(/\\\\"/g,\'"\').replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&");return new RegExp(c)}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source){var t,e,a,selector=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"",pattern=arguments.length>2&&void 0!==arguments[2]?arguments[2]:"",replacement=arguments.length>3?arguments[3]:void 0,{isInvertedMatch:isInvertedMatch,matchRegexp:matchRegexp}=(e=!!(t=pattern)&&(null==t?void 0:t.startsWith("!")),a=e?t.slice(1):t,{isInvertedMatch:e,matchRegexp:toRegExp(a),matchValue:a}),nativeDescriptor=Object.getOwnPropertyDescriptor(Element.prototype,"innerHTML");if(void 0!==nativeDescriptor){var shouldPrevent=function(element,value){if(""!==selector){if("function"!=typeof element.matches)return!1;try{if(!1===element.matches(selector))return!1}catch(e){return logMessage(source,`prevent-innerHTML: invalid selector "${selector}"`,!0),!1}}var patternMatches=matchRegexp.test(String(value));return isInvertedMatch?!patternMatches:patternMatches};Object.defineProperty(Element.prototype,"innerHTML",{configurable:!0,enumerable:!0,get(){var value=nativeDescriptor.get?nativeDescriptor.get.call(this):nativeDescriptor.value;return void 0!==replacement&&shouldPrevent(this,value)?(hit(source),logMessage(source,"Replaced innerHTML getter value"),replacement):value},set(value){if(shouldPrevent(this,value))return hit(source),void logMessage(source,"Prevented innerHTML assignment");nativeDescriptor.set&&nativeDescriptor.set.call(this,value)}})}}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['prevent-popads-net', 'popads.net.js', 'ubo-popads.net.js', 'ubo-popads.net'],
            scriptlet: 'function preventPopadsNet(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source){var r,n,rid=Math.random().toString(36).slice(2,9),throwError=function(){throw new ReferenceError(rid)};delete window.PopAds,delete window.popns,Object.defineProperties(window,{PopAds:{set:throwError},popns:{set:throwError}}),window.onerror=(r=rid,n=window.onerror,function(e){if("string"==typeof e&&e.includes(r))return!0;if(n instanceof Function){for(var t=arguments.length,o=new Array(t>1?t-1:0),i=1;i<t;i++)o[i-1]=arguments[i];return n.apply(window,[e,...o])}return!1}).bind(),function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source)}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: [
                'prevent-refresh',
                'prevent-refresh.js',
                'refresh-defuser.js',
                'refresh-defuser',
                'ubo-prevent-refresh.js',
                'ubo-prevent-refresh',
                'ubo-refresh-defuser.js',
                'ubo-refresh-defuser',
            ],
            scriptlet: 'function preventRefresh(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function getNumberFromString(n){var N,r=parseInt(n,10);return N=r,(Number.isNaN||window.isNaN)(N)?null:r}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,delaySec){var getMetaElements=function(){var metaNodes=[];try{metaNodes=document.querySelectorAll(\'meta[http-equiv="refresh" i][content]\')}catch(e){try{metaNodes=document.querySelectorAll(\'meta[http-equiv="refresh"][content]\')}catch(e){!function(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}(source,e)}}return Array.from(metaNodes)},stop=function(){var metaElements=getMetaElements();if(0!==metaElements.length){var secondsToRun=getNumberFromString(delaySec);null===secondsToRun&&(secondsToRun=function(metaElements){var delays=metaElements.map((function(meta){var contentString=meta.getAttribute("content");if(0===contentString.length)return null;var limiterIndex=contentString.indexOf(";");return getNumberFromString(-1!==limiterIndex?contentString.substring(0,limiterIndex):contentString)})).filter((function(delay){return null!==delay}));return delays.length?delays.reduce((function(a,b){return Math.min(a,b)})):null}(metaElements)),null!==secondsToRun&&setTimeout((function(){window.stop(),function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source)}),1e3*secondsToRun)}};"loading"===document.readyState?document.addEventListener("DOMContentLoaded",stop,{once:!0}):stop()}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: [
                'prevent-requestAnimationFrame',
                'no-requestAnimationFrame-if.js',
                'ubo-no-requestAnimationFrame-if.js',
                'norafif.js',
                'ubo-norafif.js',
                'ubo-no-requestAnimationFrame-if',
                'ubo-norafif',
            ],
            scriptlet: 'function preventRequestAnimationFrame(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function hit(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}function noopFunc(){}function toRegExp(e){var r=e||"",t="/";if(""===r)return new RegExp(".?");var n,i,s=r.lastIndexOf(t),a=r.substring(s+1),g=r.substring(0,s+1),u=(i=a,(n=g).startsWith(t)&&n.endsWith(t)&&!n.endsWith("\\\\/")&&function(e){if(!e)return!1;try{return new RegExp("",e),!0}catch(e){return!1}}(i)?i:"");if(r.startsWith(t)&&r.endsWith(t)||u)return new RegExp((u?g:r).slice(1,-1),u);var c=r.replace(/\\\\\'/g,"\'").replace(/\\\\"/g,\'"\').replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&");return new RegExp(c)}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,match){var t,e,a,nativeRequestAnimationFrame=window.requestAnimationFrame,shouldLog=void 0===match,{isInvertedMatch:isInvertedMatch,matchRegexp:matchRegexp}=(e=!!(t=match)&&(null==t?void 0:t.startsWith("!")),a=e?t.slice(1):t,{isInvertedMatch:e,matchRegexp:toRegExp(a),matchValue:a});window.requestAnimationFrame=function(callback){var n,shouldPrevent=!1;if(shouldLog?(hit(source),function(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}(source,`requestAnimationFrame(${String(callback)})`,!0)):((n=callback)instanceof Function||"string"==typeof n)&&function(e){var t,n=function(e){return e.replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&")}(e);"/"===e[0]&&"/"===e[e.length-1]&&(n=e.slice(1,-1));try{t=new RegExp(n),t=!0}catch(e){t=!1}return t}(match)&&(shouldPrevent=matchRegexp.test(callback.toString())!==isInvertedMatch),shouldPrevent)return hit(source),nativeRequestAnimationFrame(noopFunc);for(var _len=arguments.length,args=new Array(_len>1?_len-1:0),_key=1;_key<_len;_key++)args[_key-1]=arguments[_key];return nativeRequestAnimationFrame.apply(window,[callback,...args])}}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: [
                'prevent-setInterval',
                'no-setInterval-if.js',
                'ubo-no-setInterval-if.js',
                'setInterval-defuser.js',
                'ubo-setInterval-defuser.js',
                'nosiif.js',
                'ubo-nosiif.js',
                'sid.js',
                'ubo-sid.js',
                'ubo-no-setInterval-if',
                'ubo-setInterval-defuser',
                'ubo-nosiif',
                'ubo-sid',
            ],
            scriptlet: 'function preventSetInterval(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function hit(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}function noopFunc(){}function toRegExp(e){var r=e||"",t="/";if(""===r)return new RegExp(".?");var n,i,s=r.lastIndexOf(t),a=r.substring(s+1),g=r.substring(0,s+1),u=(i=a,(n=g).startsWith(t)&&n.endsWith(t)&&!n.endsWith("\\\\/")&&function(e){if(!e)return!1;try{return new RegExp("",e),!0}catch(e){return!1}}(i)?i:"");if(r.startsWith(t)&&r.endsWith(t)||u)return new RegExp((u?g:r).slice(1,-1),u);var c=r.replace(/\\\\\'/g,"\'").replace(/\\\\"/g,\'"\').replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&");return new RegExp(c)}function nativeIsNaN(N){return(Number.isNaN||window.isNaN)(N)}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,matchCallback,matchDelay){var shouldLog=void 0===matchCallback&&void 0===matchDelay,setIntervalHandler={apply:function(target,thisArg,args){var callback=args[0],delay=args[1],shouldPrevent=!1;return shouldLog?(hit(source),function(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}(source,`setInterval(${String(callback)}, ${delay})`,!0)):shouldPrevent=function(a){var{callback:e,delay:t,matchCallback:r,matchDelay:l}=a;if(!function(n){return n instanceof Function||"string"==typeof n}(e))return!1;if(!function(t){var i=t;return null!=t&&t.startsWith("!")&&(i=t.slice(1)),function(e){var t,n=function(e){return e.replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&")}(e);"/"===e[0]&&"/"===e[e.length-1]&&(n=e.slice(1,-1));try{t=new RegExp(n),t=!0}catch(e){t=!1}return t}(i)}(r)||l&&!function(a){var t=a;null!=a&&a.startsWith("!")&&(t=a.slice(1));var i=parseFloat(t);return!nativeIsNaN(i)&&function(i){return(Number.isFinite||window.isFinite)(i)}(i)}(l))return!1;var{isInvertedMatch:c,matchRegexp:i}=function(t){var e=!!t&&(null==t?void 0:t.startsWith("!")),a=e?t.slice(1):t;return{isInvertedMatch:e,matchRegexp:toRegExp(a),matchValue:a}}(r),{isInvertedDelayMatch:n,delayMatch:s}=function(a){var e=null==a?void 0:a.startsWith("!"),t=e?a.slice(1):a,l=parseInt(t,10);return{isInvertedDelayMatch:e,delayMatch:nativeIsNaN(l)?null:l}}(l),d=function(a){var e=Math.floor(parseInt(a,10));return"number"!=typeof e||nativeIsNaN(e)?a:e}(t),h=String(e);return null===s?i.test(h)!==c:r?i.test(h)!==c&&d===s!==n:d===s!==n}({callback:callback,delay:delay,matchCallback:matchCallback,matchDelay:matchDelay}),shouldPrevent&&(hit(source),args[0]=noopFunc),target.apply(thisArg,args)}};window.setInterval=new Proxy(window.setInterval,setIntervalHandler)}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: [
                'prevent-setTimeout',
                'no-setTimeout-if.js',
                'ubo-no-setTimeout-if.js',
                'nostif.js',
                'ubo-nostif.js',
                'ubo-no-setTimeout-if',
                'ubo-nostif',
                'setTimeout-defuser.js',
                'ubo-setTimeout-defuser.js',
                'ubo-setTimeout-defuser',
                'std.js',
                'ubo-std.js',
                'ubo-std',
            ],
            scriptlet: 'function preventSetTimeout(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function hit(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}function noopFunc(){}function toRegExp(e){var r=e||"",t="/";if(""===r)return new RegExp(".?");var n,i,s=r.lastIndexOf(t),a=r.substring(s+1),g=r.substring(0,s+1),u=(i=a,(n=g).startsWith(t)&&n.endsWith(t)&&!n.endsWith("\\\\/")&&function(e){if(!e)return!1;try{return new RegExp("",e),!0}catch(e){return!1}}(i)?i:"");if(r.startsWith(t)&&r.endsWith(t)||u)return new RegExp((u?g:r).slice(1,-1),u);var c=r.replace(/\\\\\'/g,"\'").replace(/\\\\"/g,\'"\').replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&");return new RegExp(c)}function nativeIsNaN(N){return(Number.isNaN||window.isNaN)(N)}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,matchCallback,matchDelay){var shouldLog=void 0===matchCallback&&void 0===matchDelay,setTimeoutHandler={apply:function(target,thisArg,args){var callback=args[0],delay=args[1],shouldPrevent=!1;return shouldLog?(hit(source),function(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}(source,`setTimeout(${String(callback)}, ${delay})`,!0)):shouldPrevent=function(a){var{callback:e,delay:t,matchCallback:r,matchDelay:l}=a;if(!function(n){return n instanceof Function||"string"==typeof n}(e))return!1;if(!function(t){var i=t;return null!=t&&t.startsWith("!")&&(i=t.slice(1)),function(e){var t,n=function(e){return e.replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&")}(e);"/"===e[0]&&"/"===e[e.length-1]&&(n=e.slice(1,-1));try{t=new RegExp(n),t=!0}catch(e){t=!1}return t}(i)}(r)||l&&!function(a){var t=a;null!=a&&a.startsWith("!")&&(t=a.slice(1));var i=parseFloat(t);return!nativeIsNaN(i)&&function(i){return(Number.isFinite||window.isFinite)(i)}(i)}(l))return!1;var{isInvertedMatch:c,matchRegexp:i}=function(t){var e=!!t&&(null==t?void 0:t.startsWith("!")),a=e?t.slice(1):t;return{isInvertedMatch:e,matchRegexp:toRegExp(a),matchValue:a}}(r),{isInvertedDelayMatch:n,delayMatch:s}=function(a){var e=null==a?void 0:a.startsWith("!"),t=e?a.slice(1):a,l=parseInt(t,10);return{isInvertedDelayMatch:e,delayMatch:nativeIsNaN(l)?null:l}}(l),d=function(a){var e=Math.floor(parseInt(a,10));return"number"!=typeof e||nativeIsNaN(e)?a:e}(t),h=String(e);return null===s?i.test(h)!==c:r?i.test(h)!==c&&d===s!==n:d===s!==n}({callback:callback,delay:delay,matchCallback:matchCallback,matchDelay:matchDelay}),shouldPrevent&&(hit(source),args[0]=noopFunc),target.apply(thisArg,args)}};window.setTimeout=new Proxy(window.setTimeout,setTimeoutHandler)}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: [
                'prevent-window-open',
                'window.open-defuser.js',
                'ubo-window.open-defuser.js',
                'ubo-window.open-defuser',
                'nowoif.js',
                'ubo-nowoif.js',
                'ubo-nowoif',
                'no-window-open-if.js',
                'ubo-no-window-open-if.js',
                'ubo-no-window-open-if',
            ],
            scriptlet: 'function preventWindowOpen(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function hit(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}function isValidStrPattern(e){var t,n=function(e){return e.replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&")}(e);"/"===e[0]&&"/"===e[e.length-1]&&(n=e.slice(1,-1));try{t=new RegExp(n),t=!0}catch(e){t=!1}return t}function toRegExp(e){var r=e||"",t="/";if(""===r)return new RegExp(".?");var n,i,s=r.lastIndexOf(t),a=r.substring(s+1),g=r.substring(0,s+1),u=(i=a,(n=g).startsWith(t)&&n.endsWith(t)&&!n.endsWith("\\\\/")&&function(e){if(!e)return!1;try{return new RegExp("",e),!0}catch(e){return!1}}(i)?i:"");if(r.startsWith(t)&&r.endsWith(t)||u)return new RegExp((u?g:r).slice(1,-1),u);var c=r.replace(/\\\\\'/g,"\'").replace(/\\\\"/g,\'"\').replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&");return new RegExp(c)}function logMessage(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}function noopFunc(){}function trueFunc(){return!0}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source){var match=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"*",delay=arguments.length>2?arguments[2]:void 0,replacement=arguments.length>3?arguments[3]:void 0,nativeOpen=window.open,isNewSyntax="0"!==match&&"1"!==match;window.open=isNewSyntax?function(url){for(var shouldLog=replacement&&replacement.includes("log"),_len2=arguments.length,args=new Array(_len2>1?_len2-1:0),_key2=1;_key2<_len2;_key2++)args[_key2-1]=arguments[_key2];if(shouldLog){var argsStr=args&&args.length>0?`, ${args.join(", ")}`:"";logMessage(source,`${url}${argsStr}`,!0),hit(source)}var t,i,n,N,shouldPrevent=!1;if("*"===match)shouldPrevent=!0;else if(i=t=match,null!=t&&t.startsWith("!")&&(i=t.slice(1)),isValidStrPattern(i)){var{isInvertedMatch:isInvertedMatch,matchRegexp:matchRegexp}=function(t){var e=!!t&&(null==t?void 0:t.startsWith("!")),a=e?t.slice(1):t;return{isInvertedMatch:e,matchRegexp:toRegExp(a),matchValue:a}}(match);shouldPrevent=matchRegexp.test(url)!==isInvertedMatch}else logMessage(source,`Invalid parameter: ${match}`),shouldPrevent=!1;if(shouldPrevent){var result,parsedDelay=parseInt(delay,10);if(N=parsedDelay,(Number.isNaN||window.isNaN)(N))result=null;else{var decoy=function(e){var t,r=function(e){return e.Object="data",e.Iframe="src",e}({}),{replacement:n,url:o,delay:a}=e;t="obj"===n?"object":"iframe";var i=document.createElement(t);return i instanceof HTMLObjectElement?i[r.Object]=o:i instanceof HTMLIFrameElement&&(i[r.Iframe]=o),i.style.setProperty("height","1px","important"),i.style.setProperty("position","fixed","important"),i.style.setProperty("top","-1px","important"),i.style.setProperty("width","1px","important"),document.body.appendChild(i),setTimeout((function(){return i.remove()}),1e3*a),i}({replacement:replacement,url:url,delay:parsedDelay}),popup=decoy.contentWindow;if("object"==typeof popup&&null!==popup)Object.defineProperty(popup,"closed",{value:!1}),Object.defineProperty(popup,"opener",{value:window}),Object.defineProperty(popup,"frameElement",{value:null});else{var nativeGetter=decoy.contentWindow&&decoy.contentWindow.get;Object.defineProperty(decoy,"contentWindow",{get:(n=nativeGetter,function(t,e){return(!e||"closed"!==e)&&("function"==typeof n?noopFunc:e&&t[e])})}),popup=decoy.contentWindow}result=popup}return hit(source),result}return nativeOpen.apply(window,[url,...args])}:function(str){match=Number(match)>0;for(var _len=arguments.length,args=new Array(_len>1?_len-1:0),_key=1;_key<_len;_key++)args[_key-1]=arguments[_key];if(!isValidStrPattern(delay))return logMessage(source,`Invalid parameter: ${delay}`),nativeOpen.apply(window,[str,...args]);var searchRegexp=toRegExp(delay);return match!==searchRegexp.test(str)?nativeOpen.apply(window,[str,...args]):(hit(source),function(e){var n;if(e){if("trueFunc"===e)n=trueFunc;else if(e.includes("=")&&e.startsWith("{")&&e.endsWith("}")){var t=e.slice(1,-1),u=function(r,n){if(!r||!n)return r;var e=r.indexOf(n);return e<0?r:r.substring(0,e)}(t,"=");"noopFunc"===function(n,r){if(!n)return n;var t=n.indexOf(r);return t<0?"":n.substring(t+r.length)}(t,"=")&&((n={})[u]=noopFunc)}}else n=noopFunc;return n}(replacement))},window.open.toString=nativeOpen.toString.bind(nativeOpen)}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['prevent-xhr', 'no-xhr-if.js', 'ubo-no-xhr-if.js', 'ubo-no-xhr-if'],
            scriptlet: 'function preventXHR(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function hit(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}function objectToString(t){return t&&"object"==typeof t?function(t){return 0===Object.keys(t).length&&!t.prototype}(t)?"{}":Object.entries(t).map((function(t){var n=t[0],e=t[1],o=e;return e instanceof Object&&(o=`{ ${objectToString(e)} }`),`${n}:"${o}"`})).join(" "):String(t)}function getXhrData(r,t,a,e,n){return{method:r,url:t,async:a,user:e,password:n}}function logMessage(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}function getNumberFromString(n){var N,r=parseInt(n,10);return N=r,(Number.isNaN||window.isNaN)(N)?null:r}function nativeIsFinite(i){return(Number.isFinite||window.isFinite)(i)}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,propsToMatch,customResponseText){if("undefined"!=typeof Proxy){var xhrData,nativeOpen=window.XMLHttpRequest.prototype.open,nativeGetResponseHeader=window.XMLHttpRequest.prototype.getResponseHeader,nativeGetAllResponseHeaders=window.XMLHttpRequest.prototype.getAllResponseHeaders,matchedXhrRequests=new Map,xhrRequestHeaders=new Map,modifiedResponse="",modifiedResponseText="",openHandler={apply:function(target,thisArg,args){if(xhrData=getXhrData.apply(null,args),void 0===propsToMatch?(logMessage(source,`xhr( ${objectToString(xhrData)} )`,!0),hit(source)):function(e,t,r){if(""===t||"*"===t)return!0;var a,s=function(e){var r={};return e.split(" ").forEach((function(e){var n=e.indexOf(":"),i=e.slice(0,n);if(function(e){return["url","method","headers","body","credentials","cache","redirect","referrer","referrerPolicy","integrity","keepalive","signal","mode"].includes(e)}(i)){var s=e.slice(n+1);r[i]=s}else r.url=e})),r}(t);if(function(t){return Object.values(t).every((function(t){return function(e){var t,n=function(e){return e.replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&")}(e);"/"===e[0]&&"/"===e[e.length-1]&&(n=e.slice(1,-1));try{t=new RegExp(n),t=!0}catch(e){t=!1}return t}(t)}))}(s)){var n=function(t){var a={};return Object.keys(t).forEach((function(c){a[c]=function(e){var r=e||"",t="/";if(""===r)return new RegExp(".?");var n,i,s=r.lastIndexOf(t),a=r.substring(s+1),g=r.substring(0,s+1),u=(i=a,(n=g).startsWith(t)&&n.endsWith(t)&&!n.endsWith("\\\\/")&&function(e){if(!e)return!1;try{return new RegExp("",e),!0}catch(e){return!1}}(i)?i:"");if(r.startsWith(t)&&r.endsWith(t)||u)return new RegExp((u?g:r).slice(1,-1),u);var c=r.replace(/\\\\\'/g,"\'").replace(/\\\\"/g,\'"\').replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&");return new RegExp(c)}(t[c])})),a}(s);a=Object.keys(n).every((function(e){var t=n[e],a=r[e];return Object.prototype.hasOwnProperty.call(r,e)&&"string"==typeof a&&(null==t?void 0:t.test(a))}))}else logMessage(e,`Invalid parameter: ${t}`),a=!1;return a}(source,propsToMatch,xhrData)&&("function"==typeof thisArg.onreadystatechange&&(xhrData.shouldFireFirstStage=!0),matchedXhrRequests.set(thisArg,xhrData)),matchedXhrRequests.has(thisArg)&&!xhrRequestHeaders.has(thisArg)){xhrRequestHeaders.set(thisArg,[]);var setRequestHeaderHandler={apply:function(target,thisArg,args){var headers=xhrRequestHeaders.get(thisArg);return headers&&headers.push(args),Reflect.apply(target,thisArg,args)}};thisArg.setRequestHeader=new Proxy(thisArg.setRequestHeader,setRequestHeaderHandler)}return Reflect.apply(target,thisArg,args)}},sendHandler={apply:function(target,thisArg,args){if(!matchedXhrRequests.has(thisArg))return Reflect.apply(target,thisArg,args);var storedXhrData=matchedXhrRequests.get(thisArg);if("blob"===thisArg.responseType&&(modifiedResponse=new Blob),"arraybuffer"===thisArg.responseType&&(modifiedResponse=new ArrayBuffer),customResponseText){var randomText=function(e){var t=e;if("true"===t)return Math.random().toString(36).slice(-10);if(t=t.replace("length:",""),!/^\\d+-\\d+$/.test(t))return null;var n=getNumberFromString(t.split("-")[0]),r=getNumberFromString(t.split("-")[1]);if(!nativeIsFinite(n)||!nativeIsFinite(r))return null;if(n>r){var i=n;n=r,r=i}if(r>5e5)return null;var a=function(t,n){return t=Math.ceil(t),n=Math.floor(n),Math.floor(Math.random()*(n-t+1)+t)}(n,r);return function(r){for(var t="",a="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+=~",n=0;n<r;n+=1)t+=a.charAt(Math.floor(76*Math.random()));return t}(a)}(customResponseText);randomText?(modifiedResponse=randomText,modifiedResponseText=randomText):logMessage(source,`Invalid randomize parameter: \'${customResponseText}\'`)}var forgedRequest=new XMLHttpRequest,transitionReadyState=function(state){if(2===state){var{responseURL:responseURL}=forgedRequest;Object.defineProperties(thisArg,{responseURL:{value:responseURL||storedXhrData.url,writable:!1}})}if(4===state){var{responseXML:responseXML}=forgedRequest;Object.defineProperties(thisArg,{readyState:{value:4,writable:!1},statusText:{value:"OK",writable:!1},responseXML:{value:responseXML,writable:!1},status:{value:200,writable:!1},response:{value:modifiedResponse,writable:!1},responseText:{value:modifiedResponseText,writable:!1}}),hit(source)}else Object.defineProperty(thisArg,"readyState",{value:state,writable:!0,configurable:!0});var stateEvent=new Event("readystatechange");thisArg.dispatchEvent(stateEvent)};forgedRequest.addEventListener("readystatechange",(function(){matchedXhrRequests.get(thisArg).shouldFireFirstStage&&transitionReadyState(1);var loadStartEvent=new ProgressEvent("loadstart");thisArg.dispatchEvent(loadStartEvent),transitionReadyState(2),transitionReadyState(3);var progressEvent=new ProgressEvent("progress");thisArg.dispatchEvent(progressEvent),transitionReadyState(4)})),setTimeout((function(){var loadEvent=new ProgressEvent("load");thisArg.dispatchEvent(loadEvent);var loadEndEvent=new ProgressEvent("loadend");thisArg.dispatchEvent(loadEndEvent)}),1),nativeOpen.apply(forgedRequest,[storedXhrData.method,storedXhrData.url]),(xhrRequestHeaders.get(thisArg)||[]).forEach((function(header){var name=header[0],value=header[1];forgedRequest.setRequestHeader(name,value)}))}},getHeaderHandler={apply:function(target,thisArg,args){var collectedHeaders=xhrRequestHeaders.get(thisArg);if(!collectedHeaders)return nativeGetResponseHeader.apply(thisArg,args);if(!collectedHeaders.length)return null;var searchHeaderName=args[0].toLowerCase(),matchedHeader=collectedHeaders.find((function(header){return header[0].toLowerCase()===searchHeaderName}));return matchedHeader?matchedHeader[1]:null}},getAllHeadersHandler={apply:function(target,thisArg){var collectedHeaders=xhrRequestHeaders.get(thisArg);return collectedHeaders?collectedHeaders.length?collectedHeaders.map((function(header){var headerName=header[0],headerValue=header[1];return`${headerName.toLowerCase()}: ${headerValue}`})).join("\\r\\n"):"":nativeGetAllResponseHeaders.call(thisArg)}};XMLHttpRequest.prototype.open=new Proxy(XMLHttpRequest.prototype.open,openHandler),XMLHttpRequest.prototype.send=new Proxy(XMLHttpRequest.prototype.send,sendHandler),XMLHttpRequest.prototype.getResponseHeader=new Proxy(XMLHttpRequest.prototype.getResponseHeader,getHeaderHandler),XMLHttpRequest.prototype.getAllResponseHeaders=new Proxy(XMLHttpRequest.prototype.getAllResponseHeaders,getAllHeadersHandler)}}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['remove-attr', 'remove-attr.js', 'ubo-remove-attr.js', 'ra.js', 'ubo-ra.js', 'ubo-remove-attr', 'ubo-ra'],
            scriptlet: 'function removeAttr(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function observeDOMChanges(t){var e=arguments.length>1&&void 0!==arguments[1]&&arguments[1],n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:[],i=new MutationObserver(function(n,t){var r,e=!1,_wrapper=function(){for(var o=arguments.length,u=new Array(o),f=0;f<o;f++)u[f]=arguments[f];e?r=u:(n(...u),e=!0,setTimeout((function(){e=!1,r&&(_wrapper(...r),r=null)}),t))};return _wrapper}((function(){disconnect(),t(),connect()}),20)),connect=function(){n.length>0?i.observe(document.documentElement,{childList:!0,subtree:!0,attributes:e,attributeFilter:n}):i.observe(document.documentElement,{childList:!0,subtree:!0,attributes:e})},disconnect=function(){i.disconnect()};connect()}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,attrs,selector){var applying=arguments.length>3&&void 0!==arguments[3]?arguments[3]:"asap stay";if(attrs){attrs=attrs.split(/\\s*\\|\\s*/),selector||(selector=`[${attrs.join("],[")}]`);var t,e,n,a,r,s,rmattr=function(){var nodes=[];try{nodes=[].slice.call(document.querySelectorAll(selector))}catch(e){!function(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}(source,`Invalid selector arg: \'${selector}\'`)}var removed=!1;nodes.forEach((function(node){attrs.forEach((function(attr){node.removeAttribute(attr),removed=!0}))})),removed&&function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source)},flags=(t=applying,e="asap",n="complete",a="stay",r=new Set([e,n,a]),s=new Set(t.trim().split(" ").filter((function(t){return r.has(t)}))),{ASAP:e,COMPLETE:n,STAY:a,hasFlag:function(t){return s.has(t)}});flags.hasFlag(flags.ASAP)&&("loading"===document.readyState?window.addEventListener("DOMContentLoaded",rmattr,{once:!0}):rmattr()),"complete"!==document.readyState&&flags.hasFlag(flags.COMPLETE)?window.addEventListener("load",(function(){rmattr(),flags.hasFlag(flags.STAY)&&observeDOMChanges(rmattr,!0)}),{once:!0}):flags.hasFlag(flags.STAY)&&(applying.includes(" ")||rmattr(),observeDOMChanges(rmattr,!0))}}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: [
                'remove-class',
                'remove-class.js',
                'ubo-remove-class.js',
                'rc.js',
                'ubo-rc.js',
                'ubo-remove-class',
                'ubo-rc',
            ],
            scriptlet: 'function removeClass(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function observeDOMChanges(t){var e=arguments.length>1&&void 0!==arguments[1]&&arguments[1],n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:[],i=new MutationObserver(function(n,t){var r,e=!1,_wrapper=function(){for(var o=arguments.length,u=new Array(o),f=0;f<o;f++)u[f]=arguments[f];e?r=u:(n(...u),e=!0,setTimeout((function(){e=!1,r&&(_wrapper(...r),r=null)}),t))};return _wrapper}((function(){disconnect(),t(),connect()}),20)),connect=function(){n.length>0?i.observe(document.documentElement,{childList:!0,subtree:!0,attributes:e,attributeFilter:n}):i.observe(document.documentElement,{childList:!0,subtree:!0,attributes:e})},disconnect=function(){i.disconnect()};connect()}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,classNames,selector){var applying=arguments.length>3&&void 0!==arguments[3]?arguments[3]:"asap stay";if(classNames){classNames=classNames.split(/\\s*\\|\\s*/);var selectors=[];selector||(selectors=classNames.map((function(className){return`.${className}`})));var t,e,n,a,r,s,removeClassHandler=function(){var nodes=new Set;if(selector){var foundNodes=[];try{foundNodes=[].slice.call(document.querySelectorAll(selector))}catch(e){!function(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}(source,`Invalid selector arg: \'${selector}\'`)}foundNodes.forEach((function(n){return nodes.add(n)}))}else selectors.length>0&&selectors.forEach((function(s){for(var elements=document.querySelectorAll(s),i=0;i<elements.length;i+=1){var element=elements[i];nodes.add(element)}}));var removed=!1;nodes.forEach((function(node){classNames.forEach((function(className){node.classList.contains(className)&&(node.classList.remove(className),removed=!0)}))})),removed&&function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source)},CLASS_ATTR_NAME=["class"],flags=(t=applying,e="asap",n="complete",a="stay",r=new Set([e,n,a]),s=new Set(t.trim().split(" ").filter((function(t){return r.has(t)}))),{ASAP:e,COMPLETE:n,STAY:a,hasFlag:function(t){return s.has(t)}});flags.hasFlag(flags.ASAP)&&("loading"===document.readyState?window.addEventListener("DOMContentLoaded",removeClassHandler,{once:!0}):removeClassHandler()),"complete"!==document.readyState&&flags.hasFlag(flags.COMPLETE)?window.addEventListener("load",(function(){removeClassHandler(),flags.hasFlag(flags.STAY)&&observeDOMChanges(removeClassHandler,!0,CLASS_ATTR_NAME)}),{once:!0}):flags.hasFlag(flags.STAY)&&(applying.includes(" ")||removeClassHandler(),observeDOMChanges(removeClassHandler,!0,CLASS_ATTR_NAME))}}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: [
                'remove-cookie',
                'cookie-remover.js',
                'ubo-cookie-remover.js',
                'ubo-cookie-remover',
                'remove-cookie.js',
                'ubo-remove-cookie.js',
                'ubo-remove-cookie',
                'abp-cookie-remover',
            ],
            scriptlet: 'function removeCookie(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,match){var matchRegexp=function(e){var r=e||"",t="/";if(""===r)return new RegExp(".?");var n,i,s=r.lastIndexOf(t),a=r.substring(s+1),g=r.substring(0,s+1),u=(i=a,(n=g).startsWith(t)&&n.endsWith(t)&&!n.endsWith("\\\\/")&&function(e){if(!e)return!1;try{return new RegExp("",e),!0}catch(e){return!1}}(i)?i:"");if(r.startsWith(t)&&r.endsWith(t)||u)return new RegExp((u?g:r).slice(1,-1),u);var c=r.replace(/\\\\\'/g,"\'").replace(/\\\\"/g,\'"\').replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&");return new RegExp(c)}(match),removeCookieFromHost=function(cookieName,hostName){var cookieSpec=`${cookieName}=`,domain1=`; domain=${hostName}`,domain2=`; domain=.${hostName}`,path="; path=/",expiration="; expires=Thu, 01 Jan 1970 00:00:00 GMT";document.cookie=cookieSpec+expiration,document.cookie=cookieSpec+domain1+expiration,document.cookie=cookieSpec+domain2+expiration,document.cookie=cookieSpec+path+expiration,document.cookie=cookieSpec+domain1+path+expiration,document.cookie=cookieSpec+domain2+path+expiration,function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source)},rmCookie=function(){document.cookie.split(";").forEach((function(cookieStr){var pos=cookieStr.indexOf("=");if(-1!==pos){var cookieName=cookieStr.slice(0,pos).trim();if(matchRegexp.test(cookieName))for(var hostParts=document.location.hostname.split("."),i=0;i<=hostParts.length-1;i+=1){var hostName=hostParts.slice(i).join(".");hostName&&removeCookieFromHost(cookieName,hostName)}}}))};rmCookie(),window.addEventListener("beforeunload",rmCookie)}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['remove-in-shadow-dom'],
            scriptlet: 'function removeInShadowDom(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function findHostElements(o){var n=[];return o&&o.querySelectorAll("*").forEach((function(o){o.shadowRoot&&n.push(o)})),n}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,selector,baseSelector){if(Element.prototype.attachShadow){var removeHandler=function(){for(var hostElements=baseSelector?document.querySelectorAll(baseSelector):findHostElements(document.documentElement),_loop=function(){var isRemoved=!1,{targets:targets,innerHosts:innerHosts}=function(e,t){var c=[],l=[];t.forEach((function(t){var o=t.querySelectorAll(e);c=c.concat([].slice.call(o));var r=t.shadowRoot,a=r.querySelectorAll(e);c=c.concat([].slice.call(a)),l.push(findHostElements(r))}));var o=function(r){var n=[];r.forEach((function(r){return n.push(r)}));for(var t=[];n.length;){var u=n.pop();Array.isArray(u)?u.forEach((function(r){return n.push(r)})):t.push(u)}return t.reverse()}(l);return{targets:c,innerHosts:o}}(selector,hostElements);targets.forEach((function(targetEl){targetEl.remove(),isRemoved=!0})),isRemoved&&function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source),hostElements=innerHosts};0!==hostElements.length;)_loop()};removeHandler(),function(t){var e=arguments.length>1&&void 0!==arguments[1]&&arguments[1],n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:[],i=new MutationObserver(function(n,t){var r,e=!1,_wrapper=function(){for(var o=arguments.length,u=new Array(o),f=0;f<o;f++)u[f]=arguments[f];e?r=u:(n(...u),e=!0,setTimeout((function(){e=!1,r&&(_wrapper(...r),r=null)}),t))};return _wrapper}((function(){disconnect(),t(),connect()}),20)),connect=function(){n.length>0?i.observe(document.documentElement,{childList:!0,subtree:!0,attributes:e,attributeFilter:n}):i.observe(document.documentElement,{childList:!0,subtree:!0,attributes:e})},disconnect=function(){i.disconnect()};connect()}(removeHandler,!0)}}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: [
                'remove-node-text',
                'remove-node-text.js',
                'ubo-remove-node-text.js',
                'rmnt.js',
                'ubo-rmnt.js',
                'ubo-remove-node-text',
                'ubo-rmnt',
            ],
            scriptlet: 'function removeNodeText(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function handleExistingNodes(e,n,o){(o?document.querySelectorAll(o):[document]).forEach((function(o){return function(o){if("#text"===e){var r=nodeListToArray(o.childNodes).filter((function(e){return e.nodeType===Node.TEXT_NODE}));n(r)}else{var t=nodeListToArray(o.querySelectorAll(e));n(t)}}(o)}))}function nodeListToArray(r){for(var n=[],o=0;o<r.length;o+=1)n.push(r[o]);return n}function toRegExp(e){var r=e||"",t="/";if(""===r)return new RegExp(".?");var n,i,s=r.lastIndexOf(t),a=r.substring(s+1),g=r.substring(0,s+1),u=(i=a,(n=g).startsWith(t)&&n.endsWith(t)&&!n.endsWith("\\\\/")&&function(e){if(!e)return!1;try{return new RegExp("",e),!0}catch(e){return!1}}(i)?i:"");if(r.startsWith(t)&&r.endsWith(t)||u)return new RegExp((u?g:r).slice(1,-1),u);var c=r.replace(/\\\\\'/g,"\'").replace(/\\\\"/g,\'"\').replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&");return new RegExp(c)}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,nodeName,textMatch,parentSelector){var{selector:selector,nodeNameMatch:nodeNameMatch,textContentMatch:textContentMatch}=function(t,e){var a,n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:null,r="/",s=!(t.startsWith(r)&&t.endsWith(r)),o=s?t:"*",h=s?t:toRegExp(t),i=e.startsWith(r)?toRegExp(e):e;return n&&(a=n.startsWith(r)?toRegExp(n):n),{selector:o,nodeNameMatch:h,textContentMatch:i,patternMatch:a}}(nodeName,textMatch),handleNodes=function(nodes){return nodes.forEach((function(node){(function(e,t,n){var{nodeName:o,textContent:s}=e,a=o.toLowerCase();return null!==s&&""!==s&&(t instanceof RegExp?t.test(a):t===a)&&(n instanceof RegExp?n.test(s):s.includes(n))})(node,nodeNameMatch,textContentMatch)&&function(e,t,n,r){var{textContent:a}=t;if(a){var i=a.replace(n,r);"SCRIPT"===t.nodeName&&(i=function(t){var r,e=null==t||null===(r=t.api)||void 0===r?void 0:r.policy;if(e)return e;var n="AGPolicy",i=window.trustedTypes,u=!!i,c={HTML:"TrustedHTML",Script:"TrustedScript",ScriptURL:"TrustedScriptURL"};if(!u)return{name:n,isSupported:u,TrustedType:c,createHTML:function(t){return t},createScript:function(t){return t},createScriptURL:function(t){return t},create:function(t,r){return r},getAttributeType:function(){return null},convertAttributeToTrusted:function(t,r,e){return e},getPropertyType:function(){return null},convertPropertyToTrusted:function(t,r,e){return e},isHTML:function(){return!1},isScript:function(){return!1},isScriptURL:function(){return!1}};var o=i.createPolicy(n,{createHTML:function(t){return t},createScript:function(t){return t},createScriptURL:function(t){return t}}),createHTML=function(t){return o.createHTML(t)},createScript=function(t){return o.createScript(t)},createScriptURL=function(t){return o.createScriptURL(t)},create=function(t,r){switch(t){case c.HTML:return createHTML(r);case c.Script:return createScript(r);case c.ScriptURL:return createScriptURL(r);default:return r}},p=i.getAttributeType.bind(i),T=i.getPropertyType.bind(i),s=i.isHTML.bind(i),a=i.isScript.bind(i),f=i.isScriptURL.bind(i);return{name:n,isSupported:u,TrustedType:c,createHTML:createHTML,createScript:createScript,createScriptURL:createScriptURL,create:create,getAttributeType:p,convertAttributeToTrusted:function(t,r,e,n,i){var u=p(t,r,n,i);return u?create(u,e):e},getPropertyType:T,convertPropertyToTrusted:function(t,r,e,n){var i=T(t,r,n);return i?create(i,e):e},isHTML:s,isScript:a,isScriptURL:f}}(e).createScript(i)),t.textContent=i,function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(e)}}(source,node,/^[^]*$/,"")}))};document.documentElement&&handleExistingNodes(selector,handleNodes,parentSelector),function(e){var t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{subtree:!0,childList:!0},n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:1e4,o=new MutationObserver((function(n,o){o.disconnect(),e(n,o),o.observe(document.documentElement,t)}));o.observe(document.documentElement,t),"number"==typeof n&&setTimeout((function(){return o.disconnect()}),n)}((function(mutations){return d=handleNodes,e=selector,o=parentSelector,t=function(d){for(var e=[],r=0;r<d.length;r+=1)for(var{addedNodes:n}=d[r],o=0;o<n.length;o+=1)e.push(n[o]);return e}(mutations),void(e&&o?t.forEach((function(){handleExistingNodes(e,d,o)})):d(t));var d,e,o,t}))}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['remove-request-query-parameter', 'abp-strip-fetch-query-parameter'],
            scriptlet: 'function removeRequestQueryParameter(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function logMessage(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}function toRegExp(e){var r=e||"",t="/";if(""===r)return new RegExp(".?");var n,i,s=r.lastIndexOf(t),a=r.substring(s+1),g=r.substring(0,s+1),u=(i=a,(n=g).startsWith(t)&&n.endsWith(t)&&!n.endsWith("\\\\/")&&function(e){if(!e)return!1;try{return new RegExp("",e),!0}catch(e){return!1}}(i)?i:"");if(r.startsWith(t)&&r.endsWith(t)||u)return new RegExp((u?g:r).slice(1,-1),u);var c=r.replace(/\\\\\'/g,"\'").replace(/\\\\"/g,\'"\').replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&");return new RegExp(c)}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,parametersToRemove,urlPattern){if(parametersToRemove){var regexpParamsToRemove,urlPatternRegExp=null;if(urlPattern)try{urlPatternRegExp=toRegExp(urlPattern)}catch(e){return void logMessage(source,`Invalid URL pattern: ${urlPattern}`)}try{if(parametersToRemove.startsWith("/"))regexpParamsToRemove=[toRegExp(parametersToRemove)];else{var paramsToRemove=function(t,n){for(var e=[],i="",g=0;g<t.length;)"\\\\"===t[g]&&g+1<t.length&&t.substring(g+1,g+1+n.length)===n?(i+=n,g+=1+n.length):t.substring(g,g+n.length)===n?(e.push(i),i="",g+=n.length):(i+=t[g],g+=1);return e.push(i),e}(parametersToRemove,",");regexpParamsToRemove=paramsToRemove.map((function(param){return toRegExp(param)}))}}catch(e){return void logMessage(source,`Invalid parameter pattern: ${parametersToRemove}`)}var removeParams=function(url){try{var modified=!1,urlObj=new URL(url,window.location.origin);if(Array.from(urlObj.searchParams.keys()).forEach((function(paramName){regexpParamsToRemove.some((function(regex){return regex.lastIndex=0,regex.test(paramName)}))&&(urlObj.searchParams.delete(paramName),modified=!0)})),modified)return function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source),urlObj.toString()}catch(e){logMessage(source,`Cannot remove query parameters from URL: ${url}`)}return url},xhrHandler={apply:function(target,thisArg,argumentsList){var url,urlArg=argumentsList[1];if(!urlArg)return Reflect.apply(target,thisArg,argumentsList);if("string"==typeof urlArg)url=urlArg;else{if(!(urlArg instanceof URL))return Reflect.apply(target,thisArg,argumentsList);url=urlArg.toString()}if(urlPatternRegExp&&!urlPatternRegExp.test(url))return Reflect.apply(target,thisArg,argumentsList);var newUrl=removeParams(url);return argumentsList[1]=newUrl,Reflect.apply(target,thisArg,argumentsList)}},fetchHandler={apply:function(target,thisArg,argumentsList){var requestUrl={url:"",type:""},urlArg=argumentsList[0];if(!urlArg)return Reflect.apply(target,thisArg,argumentsList);if("string"==typeof urlArg?(requestUrl.url=urlArg,requestUrl.type="string"):urlArg instanceof URL?(requestUrl.url=urlArg.toString(),requestUrl.type="string"):urlArg instanceof Request&&(requestUrl.url=urlArg.url,requestUrl.type="request"),!requestUrl.url)return Reflect.apply(target,thisArg,argumentsList);if(urlPatternRegExp&&!urlPatternRegExp.test(requestUrl.url))return Reflect.apply(target,thisArg,argumentsList);var newUrl=removeParams(requestUrl.url);if(newUrl===requestUrl.url)return Reflect.apply(target,thisArg,argumentsList);if("string"===requestUrl.type)argumentsList[0]=newUrl;else if("request"===requestUrl.type){var originalRequest=argumentsList[0];argumentsList[0]=new Request(newUrl,originalRequest)}return Reflect.apply(target,thisArg,argumentsList)}};window.XMLHttpRequest.prototype.open=new Proxy(window.XMLHttpRequest.prototype.open,xhrHandler),window.fetch=new Proxy(window.fetch,fetchHandler)}else logMessage(source,"Missing parameters to remove")}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['set-attr', 'set-attr.js', 'ubo-set-attr.js', 'ubo-set-attr'],
            scriptlet: 'function setAttr(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function setAttributeBySelector(e,t,l,o){var r,c=arguments.length>4&&void 0!==arguments[4]?arguments[4]:defaultAttributeSetter;try{r=document.querySelectorAll(t)}catch(l){return void logMessage(e,`Failed to find elements matching selector "${t}"`)}if(r&&0!==r.length)try{r.forEach((function(e){return c(e,l,o)})),function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(e)}catch(t){logMessage(e,`Failed to set [${l}="${o}"] to each of selected elements.`)}}function defaultAttributeSetter(t,e,r){return t.setAttribute(e,r)}function logMessage(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,selector,attr){var value=arguments.length>3&&void 0!==arguments[3]?arguments[3]:"";if(selector&&attr){var N,n,attributeHandler,shouldCopyValue=value.startsWith("[")&&value.endsWith("]"),isValidValue=0===value.length||(N=parseInt(value,10),!(Number.isNaN||window.isNaN)(N)&&parseInt(value,10)>=0&&parseInt(value,10)<=32767)||["true","false"].includes(value.toLowerCase());shouldCopyValue||isValidValue?(shouldCopyValue&&(attributeHandler=function(elem,attr,value){var valueToCopy=elem.getAttribute(value.slice(1,-1));null===valueToCopy&&logMessage(source,`No element attribute found to copy value from: ${value}`),elem.setAttribute(attr,valueToCopy)}),setAttributeBySelector(source,selector,attr,value,attributeHandler),function(t){var e=arguments.length>1&&void 0!==arguments[1]&&arguments[1],n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:[],i=new MutationObserver(function(n,t){var r,e=!1,_wrapper=function(){for(var o=arguments.length,u=new Array(o),f=0;f<o;f++)u[f]=arguments[f];e?r=u:(n(...u),e=!0,setTimeout((function(){e=!1,r&&(_wrapper(...r),r=null)}),t))};return _wrapper}((function(){disconnect(),t(),connect()}),20)),connect=function(){n.length>0?i.observe(document.documentElement,{childList:!0,subtree:!0,attributes:e,attributeFilter:n}):i.observe(document.documentElement,{childList:!0,subtree:!0,attributes:e})},disconnect=function(){i.disconnect()};connect()}((function(){return setAttributeBySelector(source,selector,attr,value,attributeHandler)}),!0)):logMessage(source,`Invalid attribute value provided: \'${n=value,void 0===n?"undefined":"object"==typeof n?null===n?"null":objectToString(n):String(n)}\'`)}}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: [
                'set-constant',
                'set-constant.js',
                'ubo-set-constant.js',
                'set.js',
                'ubo-set.js',
                'ubo-set-constant',
                'ubo-set',
                'abp-override-property-read',
            ],
            scriptlet: 'function setConstant(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function hit(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}function noopFunc(){}function noopCallbackFunc(){return noopFunc}function trueFunc(){return!0}function falseFunc(){return!1}function throwFunc(){throw new Error}function noopPromiseReject(){return Promise.reject()}function noopPromiseResolve(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:"{}",t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"",s=arguments.length>2&&void 0!==arguments[2]?arguments[2]:"basic";if("undefined"!=typeof Response){var n=new Response(e,{headers:{"Content-Length":`${e.length}`},status:200,statusText:"OK"});return"opaque"===s?Object.defineProperties(n,{body:{value:null},status:{value:0},ok:{value:!1},statusText:{value:""},url:{value:""},type:{value:s}}):Object.defineProperties(n,{url:{value:t},type:{value:s}}),Promise.resolve(n)}}function nativeIsNaN(N){return(Number.isNaN||window.isNaN)(N)}function toRegExp(e){var r=e||"",t="/";if(""===r)return new RegExp(".?");var n,i,s=r.lastIndexOf(t),a=r.substring(s+1),g=r.substring(0,s+1),u=(i=a,(n=g).startsWith(t)&&n.endsWith(t)&&!n.endsWith("\\\\/")&&function(e){if(!e)return!1;try{return new RegExp("",e),!0}catch(e){return!1}}(i)?i:"");if(r.startsWith(t)&&r.endsWith(t)||u)return new RegExp((u?g:r).slice(1,-1),u);var c=r.replace(/\\\\\'/g,"\'").replace(/\\\\"/g,\'"\').replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&");return new RegExp(c)}function restoreRegExpValues(e){if(e.length)try{var r;r=1===e.length?`(${e[0]})`:e.reduce((function(e,r,t){return 1===t?`(${e}),(${r})`:`${e},(${r})`}));var t=new RegExp(r);e.toString().replace(t,"")}catch(e){var n=`Failed to restore RegExp values: ${e}`;console.log(n)}}function getPropertyInChain(e,r){var n=r.indexOf(".");if(-1===n)return{base:e,prop:r};var i=r.slice(0,n);if(null===e)return{base:e,prop:i,chain:r};var t=e[i];return r=r.slice(n+1),(e instanceof Object||"object"==typeof e)&&isEmptyObject(e)||null===t?{base:e,prop:i,chain:r}:void 0!==t?getPropertyInChain(t,r):(Object.defineProperty(e,i,{configurable:!0}),{base:e,prop:i,chain:r})}function isEmptyObject(t){return 0===Object.keys(t).length&&!t.prototype}function getDescriptorAddon(){return{isAbortingSuspended:!1,isolateCallback(r){this.isAbortingSuspended=!0;try{for(var e=arguments.length,n=new Array(e>1?e-1:0),t=1;t<e;t++)n[t-1]=arguments[t];var i=r(...n);return this.isAbortingSuspended=!1,i}catch(r){var s=randomId();throw this.isAbortingSuspended=!1,new ReferenceError(s)}}}}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,property,value){var r,stack=arguments.length>3&&void 0!==arguments[3]?arguments[3]:"",valueWrapper=arguments.length>4&&void 0!==arguments[4]?arguments[4]:"",setProxyTrap=arguments.length>5&&void 0!==arguments[5]&&arguments[5];if(["set-constant.js","ubo-set-constant.js","set.js","ubo-set.js","ubo-set-constant","ubo-set"].includes(source.name)&&(1!==stack.length&&(nativeIsNaN(r=parseInt(stack,10))||!r)&&(valueWrapper=stack),stack=void 0),property){var constantValue,isProxyTrapSet=!1;if("undefined"===value)constantValue=void 0;else if("false"===value)constantValue=!1;else if("true"===value)constantValue=!0;else if("null"===value)constantValue=null;else if("emptyArr"===value)constantValue=[];else if("emptyObj"===value)constantValue={};else if("noopFunc"===value)constantValue=noopFunc;else if("noopCallbackFunc"===value)constantValue=noopCallbackFunc;else if("trueFunc"===value)constantValue=trueFunc;else if("falseFunc"===value)constantValue=falseFunc;else if("throwFunc"===value)constantValue=throwFunc;else if("noopPromiseResolve"===value)constantValue=noopPromiseResolve;else if("noopPromiseReject"===value)constantValue=noopPromiseReject;else if(/^\\d+$/.test(value)){if(nativeIsNaN(constantValue=parseFloat(value)))return;if(Math.abs(constantValue)>32767)return}else if("-1"===value)constantValue=-1;else if(""===value)constantValue="";else if("yes"===value)constantValue="yes";else{if("no"!==value)return;constantValue="no"}["asFunction","asCallback","asResolved","asRejected"].includes(valueWrapper)&&(constantValue={asFunction:v=>function(){return v},asCallback:v=>function(){return function(){return v}},asResolved:v=>Promise.resolve(v),asRejected:v=>Promise.reject(v)}[valueWrapper](constantValue));var canceled=!1,setChainPropAccess=function(t){var{source:e,stack:r,mustCancel:i,trapProp:n,getConstantValue:a,setConstantValue:s}=t,_setChainPropAccess=function(t,c){var o=getPropertyInChain(t,c),{base:u,prop:d,chain:f}=o,h={factValue:void 0,init(t){return this.factValue=t,!0},get(){return this.factValue},set(t){this.factValue!==t&&(this.factValue=t,t instanceof Object&&_setChainPropAccess(t,f))}},l={factValue:void 0,descriptorAddon:getDescriptorAddon(),init(t){return!i(t)&&(this.factValue=t,!0)},get(){if(!r)return hit(e),a();if(!this.descriptorAddon.isAbortingSuspended){this.descriptorAddon.isAbortingSuspended=!0;var t=!1;try{t=function(e,t){if(!e||""===e)return!0;var r=function(){try{for(var r=[],e=1;e<10;e+=1){var a=`$${e}`;if(!RegExp[a])break;r.push(RegExp[a])}return r}catch(r){return[]}}();if(function(t,i){var r="inlineScript",n="injectedScript",isInlineScript=function(t){return t.includes(r)},isInjectedScript=function(t){return t.includes(n)};if(!isInlineScript(t)&&!isInjectedScript(t))return!1;var e=window.location.href,s=e.indexOf("#");-1!==s&&(e=e.slice(0,s));var c=i.split("\\n").slice(2).map((function(t){return t.trim()})).map((function(t){var i,s=/(.*?@)?(\\S+)(:\\d+)(:\\d+)\\)?$/.exec(t);if(s){var c,l,a=s[2],u=s[3],o=s[4];if(null!==(c=a)&&void 0!==c&&c.startsWith("(")&&(a=a.slice(1)),null!==(l=a)&&void 0!==l&&l.startsWith("<anonymous>")){var d;a=n;var f=void 0!==s[1]?s[1].slice(0,-1):t.slice(0,s.index).trim();null!==(d=f)&&void 0!==d&&d.startsWith("at")&&(f=f.slice(2).trim()),i=`${f} ${a}${u}${o}`.trim()}else i=a===e?`${r}${u}${o}`.trim():`${a}${u}${o}`.trim()}else i=t;return i}));if(c)for(var l=0;l<c.length;l+=1){if(isInlineScript(t)&&c[l].startsWith(r)&&c[l].match(toRegExp(t)))return!0;if(isInjectedScript(t)&&c[l].startsWith(n)&&c[l].match(toRegExp(t)))return!0}return!1}(e,t))return r.length&&r[0]!==RegExp.$1&&restoreRegExpValues(r),!0;var n=toRegExp(e),a=t.split("\\n").slice(2).map((function(e){return e.trim()})).join("\\n");return r.length&&r[0]!==RegExp.$1&&restoreRegExpValues(r),function(){var t=Object.getOwnPropertyDescriptor(RegExp.prototype,"test"),e=null==t?void 0:t.value;if(t&&"function"==typeof t.value)return e;throw new Error("RegExp.prototype.test is not a function")}().call(n,a)}(r,(new Error).stack||"")}catch(t){return this.descriptorAddon.isAbortingSuspended=!1,this.factValue}if(this.descriptorAddon.isAbortingSuspended=!1,t)return hit(e),a()}return this.factValue},set(t){i(t)?s(t):this.factValue=t}};if(f)if(void 0===u||null!==u[d]){(u instanceof Object||"object"==typeof u)&&isEmptyObject(u)&&n(u,d,!0,h);var p=t[d];(p instanceof Object||"object"==typeof p&&null!==p)&&_setChainPropAccess(p,f),n(u,d,!0,h)}else n(u,d,!0,h);else n(u,d,!1,l)};return _setChainPropAccess}({source:source,stack:stack,mustCancel:function(value){return canceled||(canceled=void 0!==value&&void 0!==constantValue&&typeof value!=typeof constantValue&&null!==value)},trapProp:function(base,prop,configurable,handler){if(!handler.init(base[prop]))return!1;var prevSetter,origDescriptor=Object.getOwnPropertyDescriptor(base,prop);if(origDescriptor instanceof Object){if(!origDescriptor.configurable)return function(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}(source,`Property \'${prop}\' is not configurable`),!1;base[prop]&&(base[prop]=constantValue),origDescriptor.set instanceof Function&&(prevSetter=origDescriptor.set)}return Object.defineProperty(base,prop,{configurable:configurable,get:()=>handler.get(),set(a){if(void 0!==prevSetter&&prevSetter(a),a instanceof Object){var propertiesToCheck=property.split(".").slice(1);setProxyTrap&&!isProxyTrapSet&&(isProxyTrapSet=!0,a=new Proxy(a,{get:function(target,propertyKey,val){return propertiesToCheck.reduce((function(object,currentProp,index,array){var currentObj=null==object?void 0:object[currentProp];return index===array.length-1&&currentObj!==constantValue&&(object[currentProp]=constantValue),currentObj||object}),target),Reflect.get(target,propertyKey,val)}}))}handler.set(a)}}),!0},getConstantValue:function(){return constantValue},setConstantValue:function(v){constantValue=v}});setChainPropAccess(window,property)}}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['set-cookie', 'set-cookie.js', 'ubo-set-cookie.js', 'ubo-set-cookie'],
            scriptlet: 'function setCookie(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function logMessage(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,name,value){var n,path=arguments.length>3&&void 0!==arguments[3]?arguments[3]:"/",domain=arguments.length>4&&void 0!==arguments[4]?arguments[4]:"",validValue=function(e){if(!e)return null;var n,N;if(new Set(["true","t","false","f","yes","y","no","n","ok","on","off","accept","accepted","notaccepted","reject","rejected","allow","allowed","disallow","deny","denied","enable","enabled","disable","disabled","necessary","required","hide","hidden","essential","nonessential","checked","unchecked","forbidden","forever"]).has(e.toLowerCase()))n=e;else if("emptyArr"===e)n="[]";else if("emptyObj"===e)n="{}";else{if(!/^\\d+$/.test(e))return null;if(N=n=parseFloat(e),(Number.isNaN||window.isNaN)(N))return null;if(Math.abs(n)<0||Math.abs(n)>32767)return null}return n}(value);if(null!==validValue)if("/"===(n=path)||"none"===n)if(document.location.origin.includes(domain)){var cookieToSet=function(e,o,i){var n=arguments.length>3&&void 0!==arguments[3]?arguments[3]:"",t=!(arguments.length>4&&void 0!==arguments[4])||arguments[4];if(!t&&`${o}`.includes(";")||e.includes(";"))return null;var r=`${e}=${t?encodeURIComponent(o):o}`;if(e.startsWith("__Host-"))return r+="; path=/; secure",n&&console.debug(`Domain value: "${n}" has been ignored, because is not allowed for __Host- prefixed cookies`),r;var s=function(t){return"/"===t?"path=/":""}(i);return s&&(r+=`; ${s}`),e.startsWith("__Secure-")&&(r+="; secure"),n&&(r+=`; domain=${n}`),r}(name,validValue,path,domain,!1);cookieToSet?(function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source),document.cookie=cookieToSet):logMessage(source,"Invalid cookie name or value")}else logMessage(source,`Cookie domain not matched by origin: \'${domain}\'`);else logMessage(source,`Invalid cookie path: \'${path}\'`);else logMessage(source,`Invalid cookie value: \'${validValue}\'`)}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['set-cookie-reload', 'set-cookie-reload.js', 'ubo-set-cookie-reload.js', 'ubo-set-cookie-reload'],
            scriptlet: 'function setCookieReload(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function logMessage(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}function isCookieSetWithValue(e,t,r){return e.split(";").some((function(e){var n=e.indexOf("=");if(-1===n)return!1;var i=e.slice(0,n).trim(),a=e.slice(n+1).trim();if(new Set(["$now$","$currentDate$","$currentISODate$"]).has(r)){var u=Date.now(),s=/^\\d+$/.test(a)?parseInt(a,10):new Date(a).getTime();return t===i&&s>u-864e5}return t===i&&r===a}))}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,name,value){var path=arguments.length>3&&void 0!==arguments[3]?arguments[3]:"/",domain=arguments.length>4&&void 0!==arguments[4]?arguments[4]:"";if(!isCookieSetWithValue(document.cookie,name,value)){var n,validValue=function(e){if(!e)return null;var n,N;if(new Set(["true","t","false","f","yes","y","no","n","ok","on","off","accept","accepted","notaccepted","reject","rejected","allow","allowed","disallow","deny","denied","enable","enabled","disable","disabled","necessary","required","hide","hidden","essential","nonessential","checked","unchecked","forbidden","forever"]).has(e.toLowerCase()))n=e;else if("emptyArr"===e)n="[]";else if("emptyObj"===e)n="{}";else{if(!/^\\d+$/.test(e))return null;if(N=n=parseFloat(e),(Number.isNaN||window.isNaN)(N))return null;if(Math.abs(n)<0||Math.abs(n)>32767)return null}return n}(value);if(null!==validValue)if("/"===(n=path)||"none"===n)if(document.location.origin.includes(domain)){var cookieToSet=function(e,o,i){var n=arguments.length>3&&void 0!==arguments[3]?arguments[3]:"",t=!(arguments.length>4&&void 0!==arguments[4])||arguments[4];if(!t&&`${o}`.includes(";")||e.includes(";"))return null;var r=`${e}=${t?encodeURIComponent(o):o}`;if(e.startsWith("__Host-"))return r+="; path=/; secure",n&&console.debug(`Domain value: "${n}" has been ignored, because is not allowed for __Host- prefixed cookies`),r;var s=function(t){return"/"===t?"path=/":""}(i);return s&&(r+=`; ${s}`),e.startsWith("__Secure-")&&(r+="; secure"),n&&(r+=`; domain=${n}`),r}(name,validValue,path,domain,!1);cookieToSet?(document.cookie=cookieToSet,function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source),isCookieSetWithValue(document.cookie,name,value)&&window.location.reload()):logMessage(source,"Invalid cookie name or value")}else logMessage(source,`Cookie domain not matched by origin: \'${domain}\'`);else logMessage(source,`Invalid cookie path: \'${path}\'`);else logMessage(source,`Invalid cookie value: \'${value}\'`)}}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: [
                'set-local-storage-item',
                'set-local-storage-item.js',
                'ubo-set-local-storage-item.js',
                'ubo-set-local-storage-item',
            ],
            scriptlet: 'function setLocalStorageItem(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function logMessage(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,key,value){if(void 0!==key){var validValue;try{validValue=function(e){if("string"!=typeof e)throw new Error("Invalid value");var r,N;if(new Set(["undefined","false","true","null","","yes","no","on","off","accept","accepted","reject","rejected","allowed","denied","forbidden","forever"]).has(e.toLowerCase()))r=e;else if("emptyArr"===e)r="[]";else if("emptyObj"===e)r="{}";else if(/^\\d+$/.test(e)){if(N=r=parseFloat(e),(Number.isNaN||window.isNaN)(N))throw new Error("Invalid value");if(Math.abs(r)>32767)throw new Error("Invalid value")}else{if("$remove$"!==e)throw new Error("Invalid value");r="$remove$"}return r}(value)}catch(_unused){return void logMessage(source,`Invalid storage item value: \'${value}\'`)}var{localStorage:localStorage}=window;"$remove$"===validValue?function(e,t,o){try{if(o.startsWith("/")&&(o.endsWith("/")||o.endsWith("/i"))&&function(e){var t,n=function(e){return e.replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&")}(e);"/"===e[0]&&"/"===e[e.length-1]&&(n=e.slice(1,-1));try{t=new RegExp(n),t=!0}catch(e){t=!1}return t}(o)){var r=function(e){var r=e||"",t="/";if(""===r)return new RegExp(".?");var n,i,s=r.lastIndexOf(t),a=r.substring(s+1),g=r.substring(0,s+1),u=(i=a,(n=g).startsWith(t)&&n.endsWith(t)&&!n.endsWith("\\\\/")&&function(e){if(!e)return!1;try{return new RegExp("",e),!0}catch(e){return!1}}(i)?i:"");if(r.startsWith(t)&&r.endsWith(t)||u)return new RegExp((u?g:r).slice(1,-1),u);var c=r.replace(/\\\\\'/g,"\'").replace(/\\\\"/g,\'"\').replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&");return new RegExp(c)}(o);Object.keys(t).forEach((function(e){r.test(e)&&t.removeItem(e)}))}else t.removeItem(o)}catch(t){logMessage(e,`Unable to remove storage item due to: ${t.message}`)}}(source,localStorage,key):function(e,t,s,a){try{t.setItem(s,a)}catch(t){logMessage(e,`Unable to set storage item due to: ${t.message}`)}}(source,localStorage,key,validValue),function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source)}else logMessage(source,"Item key should be specified.")}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['set-popads-dummy', 'popads-dummy.js', 'ubo-popads-dummy.js', 'ubo-popads-dummy'],
            scriptlet: 'function setPopadsDummy(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function hit(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source){delete window.PopAds,delete window.popns,Object.defineProperties(window,{PopAds:{get:function(){return hit(source),{}}},popns:{get:function(){return hit(source),{}}}})}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: [
                'set-session-storage-item',
                'set-session-storage-item.js',
                'ubo-set-session-storage-item.js',
                'ubo-set-session-storage-item',
            ],
            scriptlet: 'function setSessionStorageItem(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function logMessage(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,key,value){if(void 0!==key){var validValue;try{validValue=function(e){if("string"!=typeof e)throw new Error("Invalid value");var r,N;if(new Set(["undefined","false","true","null","","yes","no","on","off","accept","accepted","reject","rejected","allowed","denied","forbidden","forever"]).has(e.toLowerCase()))r=e;else if("emptyArr"===e)r="[]";else if("emptyObj"===e)r="{}";else if(/^\\d+$/.test(e)){if(N=r=parseFloat(e),(Number.isNaN||window.isNaN)(N))throw new Error("Invalid value");if(Math.abs(r)>32767)throw new Error("Invalid value")}else{if("$remove$"!==e)throw new Error("Invalid value");r="$remove$"}return r}(value)}catch(_unused){return void logMessage(source,`Invalid storage item value: \'${value}\'`)}var{sessionStorage:sessionStorage}=window;"$remove$"===validValue?function(e,t,o){try{if(o.startsWith("/")&&(o.endsWith("/")||o.endsWith("/i"))&&function(e){var t,n=function(e){return e.replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&")}(e);"/"===e[0]&&"/"===e[e.length-1]&&(n=e.slice(1,-1));try{t=new RegExp(n),t=!0}catch(e){t=!1}return t}(o)){var r=function(e){var r=e||"",t="/";if(""===r)return new RegExp(".?");var n,i,s=r.lastIndexOf(t),a=r.substring(s+1),g=r.substring(0,s+1),u=(i=a,(n=g).startsWith(t)&&n.endsWith(t)&&!n.endsWith("\\\\/")&&function(e){if(!e)return!1;try{return new RegExp("",e),!0}catch(e){return!1}}(i)?i:"");if(r.startsWith(t)&&r.endsWith(t)||u)return new RegExp((u?g:r).slice(1,-1),u);var c=r.replace(/\\\\\'/g,"\'").replace(/\\\\"/g,\'"\').replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&");return new RegExp(c)}(o);Object.keys(t).forEach((function(e){r.test(e)&&t.removeItem(e)}))}else t.removeItem(o)}catch(t){logMessage(e,`Unable to remove storage item due to: ${t.message}`)}}(source,sessionStorage,key):function(e,t,s,a){try{t.setItem(s,a)}catch(t){logMessage(e,`Unable to set storage item due to: ${t.message}`)}}(source,sessionStorage,key,validValue),function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source)}else logMessage(source,"Item key should be specified.")}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['spoof-css', 'spoof-css.js', 'ubo-spoof-css.js', 'ubo-spoof-css'],
            scriptlet: 'function spoofCSS(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function hit(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,selectors,cssPropertyName,cssPropertyValue){if(selectors){var shouldDebug=!("debug"!==cssPropertyName||!cssPropertyValue),propToValueMap=new Map;if(["spoof-css.js","ubo-spoof-css.js","ubo-spoof-css"].includes(source.name)){var{args:args}=source,arrayOfProperties=[];arrayOfProperties="debug"===args.at(-2)?args.slice(1,-2):args.slice(1);for(var i=0;i<arrayOfProperties.length&&""!==arrayOfProperties[i];i+=2)propToValueMap.set(convertToCamelCase(arrayOfProperties[i]),arrayOfProperties[i+1])}else cssPropertyName&&cssPropertyValue&&!shouldDebug&&propToValueMap.set(convertToCamelCase(cssPropertyName),cssPropertyValue);var spoofStyle=function(cssProperty,realCssValue){return propToValueMap.has(cssProperty)?propToValueMap.get(cssProperty):realCssValue},cloakFunc=function(fn,thisArg,fnName){var cloakedToString=function(){return`function ${fnName}() { [native code] }`},toStringOfToString=function(){return"function toString() { [native code] }"};toStringOfToString.toString=toStringOfToString,cloakedToString.toString=toStringOfToString;var bound=fn.bind(thisArg);return Object.defineProperty(bound,"name",{value:fnName}),Object.defineProperty(bound,"toString",{value:cloakedToString}),bound},setRectValue=function(rect,prop,value){Object.defineProperty(rect,prop,{value:parseFloat(value)})},propsToBindSet=new Set(["__defineGetter__","__defineSetter__","__lookupGetter__","__lookupSetter__"]),getter=function(target,prop,receiver){if(hit(source),"toString"===prop)return fnName=target.name||"getComputedStyle",toString=function(){return`function ${fnName}() { [native code] }`},(toStringOfToString=function(){return"function toString() { [native code] }"}).toString=toStringOfToString,toString.toString=toStringOfToString,toString;var fnName,toString,toStringOfToString;if(propsToBindSet.has(prop)){var nativeFn=target[prop];if("function"==typeof nativeFn)return nativeFn.bind(target)}return Reflect.get(target,prop,receiver)},getComputedStyleHandler={apply:function(target,thisArg,args){if(shouldDebug)debugger;var style=Reflect.apply(target,thisArg,args);if(!args[0].matches(selectors))return style;var proxiedStyle=new Proxy(style,{get(target,prop){var CSSStyleProp=target[prop];return"function"!=typeof CSSStyleProp?spoofStyle(prop,CSSStyleProp||""):"getPropertyValue"!==prop?cloakFunc(CSSStyleProp,target,prop):cloakFunc((function(cssPropName){var cssValue=target[cssPropName]||"";return spoofStyle(cssPropName,cssValue)}),target,"getPropertyValue")},getOwnPropertyDescriptor:(target,prop)=>propToValueMap.has(prop)?{configurable:!0,enumerable:!0,value:propToValueMap.get(prop),writable:!0}:Reflect.getOwnPropertyDescriptor(target,prop)});return hit(source),proxiedStyle},get:getter};window.getComputedStyle=new Proxy(window.getComputedStyle,getComputedStyleHandler);var getBoundingClientRectHandler={apply:function(target,thisArg,args){if(shouldDebug)debugger;var rect=Reflect.apply(target,thisArg,args);if(!thisArg.matches(selectors))return rect;var{x:x,y:y,height:height,width:width}=rect,newDOMRect=new window.DOMRect(x,y,width,height);return propToValueMap.has("top")&&setRectValue(newDOMRect,"top",propToValueMap.get("top")),propToValueMap.has("bottom")&&setRectValue(newDOMRect,"bottom",propToValueMap.get("bottom")),propToValueMap.has("left")&&setRectValue(newDOMRect,"left",propToValueMap.get("left")),propToValueMap.has("right")&&setRectValue(newDOMRect,"right",propToValueMap.get("right")),propToValueMap.has("height")&&setRectValue(newDOMRect,"height",propToValueMap.get("height")),propToValueMap.has("width")&&setRectValue(newDOMRect,"width",propToValueMap.get("width")),hit(source),newDOMRect},get:getter};window.Element.prototype.getBoundingClientRect=new Proxy(window.Element.prototype.getBoundingClientRect,getBoundingClientRectHandler)}function convertToCamelCase(cssProperty){if(!cssProperty.includes("-"))return cssProperty;var splittedProperty=cssProperty.split("-"),firstPart=splittedProperty[0],secondPart=splittedProperty[1];return`${firstPart}${secondPart[0].toUpperCase()}${secondPart.slice(1)}`}}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['trusted-click-element'],
            scriptlet: 'function trustedClickElement(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function toRegExp(e){var r=e||"",t="/";if(""===r)return new RegExp(".?");var n,i,s=r.lastIndexOf(t),a=r.substring(s+1),g=r.substring(0,s+1),u=(i=a,(n=g).startsWith(t)&&n.endsWith(t)&&!n.endsWith("\\\\/")&&function(e){if(!e)return!1;try{return new RegExp("",e),!0}catch(e){return!1}}(i)?i:"");if(r.startsWith(t)&&r.endsWith(t)||u)return new RegExp((u?g:r).slice(1,-1),u);var c=r.replace(/\\\\\'/g,"\'").replace(/\\\\"/g,\'"\').replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&");return new RegExp(c)}function parseCookieString(i){var r=i.split(";"),n={};return r.forEach((function(i){var r,t="",e=i.indexOf("=");-1===e?r=i.trim():(r=i.slice(0,e).trim(),t=i.slice(e+1)),n[r]=t||null})),n}function logMessage(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}function parseMatchArg(t){var e=!!t&&(null==t?void 0:t.startsWith("!")),a=e?t.slice(1):t;return{isInvertedMatch:e,matchRegexp:toRegExp(a),matchValue:a}}function queryShadowSelector(e){var t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:document.documentElement,l=arguments.length>2&&void 0!==arguments[2]?arguments[2]:null,r=arguments.length>3?arguments[3]:void 0,o=e.indexOf(" >>> ");if(-1===o)return l?function(e,n,t){for(var l=e.querySelectorAll(n),r=0;r<l.length;r+=1)if(doesElementContainText(l[r],t))return l[r];return null}(t,e,l):t.querySelector(e);var i=e.slice(0,o).trim(),u=t.querySelector(i);if(!u)return null;var d=u.shadowRoot||(null==r?void 0:r.get(u));return d?queryShadowSelector(e.slice(o+5).trim(),d,l,r):null}function triggerMainObserver(){var e=`adg-${Math.random().toString(36).slice(2,9)}`,t=document.documentElement;t.setAttribute(e,""),t.removeAttribute(e)}function clickElement(e){var n=Object.keys(e).find((function(e){return e.startsWith("__reactProps$")}));if(n){var t=e[n];if(t&&"function"==typeof t.onClick)return"function"==typeof t.onFocus&&t.onFocus(),void t.onClick()}var o=e.getBoundingClientRect(),i=o.left+o.width/2,s=o.top+o.height/2,c={bubbles:!0,cancelable:!0,composed:!0,view:window,clientX:i,clientY:s,screenX:i+window.screenX,screenY:s+window.screenY,button:0,buttons:1},r=Object.assign({},c,{bubbles:!1}),u=Object.assign({},c,{buttons:0}),v="function"==typeof PointerEvent;v&&(e.dispatchEvent(new PointerEvent("pointerover",c)),e.dispatchEvent(new PointerEvent("pointerenter",r))),e.dispatchEvent(new MouseEvent("mouseover",c)),e.dispatchEvent(new MouseEvent("mouseenter",r)),v&&e.dispatchEvent(new PointerEvent("pointerdown",c)),e.dispatchEvent(new MouseEvent("mousedown",c)),e.focus(),v&&e.dispatchEvent(new PointerEvent("pointerup",u)),e.dispatchEvent(new MouseEvent("mouseup",u)),e.dispatchEvent(new MouseEvent("click",u))}function doesElementContainText(t,e){var{textContent:n}=t;return!!n&&e.test(n)}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,selectors){var extraMatch=arguments.length>2&&void 0!==arguments[2]?arguments[2]:"",delay=arguments.length>3&&void 0!==arguments[3]?arguments[3]:NaN,reload=arguments.length>4&&void 0!==arguments[4]?arguments[4]:"",observerTimeoutSec=arguments.length>5&&void 0!==arguments[5]?arguments[5]:NaN;if(selectors){var sleep=function(delayMs){return new Promise((function(resolve){setTimeout(resolve,delayMs)}))};!function(){var e=Symbol.for("adg-spoof-click-isTrusted");if(!EventTarget.prototype[e]){var t=new Set(["click","mousedown","mouseup","mouseover","mouseenter","pointerdown","pointerup","pointerover","pointerenter"]),r=EventTarget.prototype.addEventListener,n=EventTarget.prototype.removeEventListener,o=new WeakMap,getMapKey=function(e,t){return`${e}\\0${function(e){var t;return"boolean"==typeof e?e:null!==(t=null==e?void 0:e.capture)&&void 0!==t&&t}(t)}`};EventTarget.prototype.addEventListener=function(e,n,i){if(!n||!t.has(e))return r.call(this,e,n,i);var a="function"==typeof n,u=getMapKey(e,i),wrapped=function(e){var t=new Proxy(e,{get(e,t){if("isTrusted"===t)return!0;var r=Reflect.get(e,t);return"function"==typeof r?r.bind(e):r}});return a?n.call(this,t):n.handleEvent.call(n,t)},s=n,v=o.get(s);v||(v=new Map,o.set(s,v));var l=v.get(u);return l||v.set(u,wrapped),r.call(this,e,l||wrapped,i)},EventTarget.prototype.removeEventListener=function(e,r,i){if(!r||!t.has(e))return n.call(this,e,r,i);var a=r,u=getMapKey(e,i),s=o.get(a);if(s&&s.has(u)){var v=s.get(u);return s.delete(u),n.call(this,e,v,i)}return n.call(this,e,r,i)},EventTarget.prototype[e]=!0}}();var closedShadowRoots=new WeakMap,bridgeObservers=new Set;if(selectors.includes(" >>> ")){var attachShadowHandler={apply:function(target,thisArg,argumentsList){var _argumentsList$,shadowRoot=Reflect.apply(target,thisArg,argumentsList);"closed"===(null===(_argumentsList$=argumentsList[0])||void 0===_argumentsList$?void 0:_argumentsList$.mode)&&closedShadowRoots.set(thisArg,shadowRoot);var bridgeObserver=new MutationObserver((function(mutations){triggerMainObserver(),mutations.forEach((function(mutation){var e;e=mutation.addedNodes,Array.from(e).forEach((function(e){e instanceof HTMLIFrameElement&&e.addEventListener("load",(function(){triggerMainObserver()})),e instanceof Element&&e.querySelectorAll("iframe").forEach((function(e){e.addEventListener("load",(function(){triggerMainObserver()}))}))}))}))}));return bridgeObserver.observe(shadowRoot,{childList:!0,subtree:!0}),bridgeObservers.add(bridgeObserver),shadowRoot}};window.Element.prototype.attachShadow=new Proxy(window.Element.prototype.attachShadow,attachShadowHandler)}var parsedDelayMs,disconnectBridgeObservers=function(){bridgeObservers.forEach((function(obs){return obs.disconnect()})),bridgeObservers.clear()},observerTimeoutMs=1e4;if(observerTimeoutSec){var parsedTimeout=Number(observerTimeoutSec);if(!Number.isInteger(parsedTimeout)||parsedTimeout<=0)return void logMessage(source,`Passed observer timeout \'${observerTimeoutSec}\' is invalid`);observerTimeoutMs=1e3*parsedTimeout}if(delay){if(parsedDelayMs=Number(delay),!Number.isInteger(parsedDelayMs)||parsedDelayMs<0)return void logMessage(source,`Passed delay \'${delay}\' is invalid`);if(parsedDelayMs>=observerTimeoutMs)return void logMessage(source,`Passed delay \'${delay}\' is bigger than ${observerTimeoutMs} ms`)}var canClick=!parsedDelayMs,cookieMatches=[],localStorageMatches=[],textMatches="",isInvertedMatchCookie=!1,isInvertedMatchLocalStorage=!1;if(extraMatch&&extraMatch.split(/(,\\s*){1}(?=!?cookie:|!?localStorage:|containsText:)/).map((function(matchStr){return matchStr.trim()})).forEach((function(matchStr){if(matchStr.includes("cookie:")){var{isInvertedMatch:isInvertedMatch,matchValue:matchValue}=parseMatchArg(matchStr);isInvertedMatchCookie=isInvertedMatch;var cookieMatch=matchValue.replace("cookie:","");cookieMatches.push(cookieMatch)}if(matchStr.includes("localStorage:")){var{isInvertedMatch:_isInvertedMatch,matchValue:_matchValue}=parseMatchArg(matchStr);isInvertedMatchLocalStorage=_isInvertedMatch;var localStorageMatch=_matchValue.replace("localStorage:","");localStorageMatches.push(localStorageMatch)}if(matchStr.includes("containsText:")){var{matchValue:_matchValue2}=parseMatchArg(matchStr),textMatch=_matchValue2.replace("containsText:","");textMatches=textMatch}})),cookieMatches.length>0){var parsedCookieMatches=parseCookieString(cookieMatches.join(";")),parsedCookies=parseCookieString(document.cookie),cookieKeys=Object.keys(parsedCookies);if(0===cookieKeys.length)return;if(Object.keys(parsedCookieMatches).every((function(key){var valueMatch=parsedCookieMatches[key]?toRegExp(parsedCookieMatches[key]):null,keyMatch=toRegExp(key);return cookieKeys.some((function(cookieKey){if(!keyMatch.test(cookieKey))return!1;if(!valueMatch)return!0;var parsedCookieValue=parsedCookies[cookieKey];return!!parsedCookieValue&&valueMatch.test(parsedCookieValue)}))}))===isInvertedMatchCookie)return}if(localStorageMatches.length>0&&localStorageMatches.every((function(str){var itemValue=window.localStorage.getItem(str);return itemValue||""===itemValue}))===isInvertedMatchLocalStorage)return;var textMatchRegexp=textMatches?toRegExp(textMatches):null,selectorsSequence=selectors.split(",").map((function(selector){return selector.trim()})),createElementObj=function(element,selector){return{element:element||null,clicked:!1,selectorText:selector||null}},elementsSequence=Array(selectorsSequence.length).fill(createElementObj(null)),findAndClickElement=function(elementObj){try{if(!elementObj.selectorText)return;var element=queryShadowSelector(elementObj.selectorText,document.documentElement,null,closedShadowRoots);if(!element)return void logMessage(source,`Could not find element: \'${elementObj.selectorText}\'`);clickElement(element),elementObj.clicked=!0}catch(error){logMessage(source,`Could not click element: \'${elementObj.selectorText}\'`)}},shouldReloadAfterClick=!1,reloadDelayMs=500;if(reload){var reloadSplit=reload.split(":"),reloadMarker=reloadSplit[0],reloadValue=reloadSplit[1];if("reloadAfterClick"!==reloadMarker)return void logMessage(source,`Passed reload option \'${reload}\' is invalid`);if(reloadValue){var passedReload=Number(reloadValue);if(Number.isNaN(passedReload))return void logMessage(source,`Passed reload delay value \'${passedReload}\' is invalid`);if(passedReload>observerTimeoutMs)return void logMessage(source,`Passed reload delay value \'${passedReload}\' is bigger than maximum ${observerTimeoutMs} ms`);reloadDelayMs=passedReload}shouldReloadAfterClick=!0}var canReload=!0,clickElementsBySequence=async function(){for(var i=0;i<elementsSequence.length;i+=1){var elementObj=elementsSequence[i];if(i>=1&&await sleep(150),!elementObj.element)break;elementObj.clicked||(elementObj.element.isConnected?(clickElement(elementObj.element),elementObj.clicked=!0):findAndClickElement(elementObj))}var allElementsClicked=elementsSequence.every((function(elementObj){return!0===elementObj.clicked}));allElementsClicked&&(shouldReloadAfterClick&&canReload&&(canReload=!1,setTimeout((function(){window.location.reload()}),reloadDelayMs)),function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source))},fulfillAndHandleSelectors=function(){var fulfilledSelectors=[];return selectorsSequence.forEach((function(selector,i){if(selector){var element=queryShadowSelector(selector,document.documentElement,textMatchRegexp,closedShadowRoots);element&&(function(element,i,selector){var elementObj=createElementObj(element,selector);elementsSequence[i]=elementObj,canClick&&clickElementsBySequence()}(element,i,selector),fulfilledSelectors.push(selector))}})),selectorsSequence=selectorsSequence.map((function(selector){return selector&&fulfilledSelectors.includes(selector)?null:selector}))},findElements=function(mutations,observer){(selectorsSequence=fulfillAndHandleSelectors()).every((function(selector){return null===selector}))&&(observer.disconnect(),disconnectBridgeObservers())},initializeMutationObserver=function(){var n,t,r,e,_wrapper,observer=new MutationObserver((n=findElements,t=20,e=!1,_wrapper=function(){for(var o=arguments.length,u=new Array(o),f=0;f<o;f++)u[f]=arguments[f];e?r=u:(n(...u),e=!0,setTimeout((function(){e=!1,r&&(_wrapper(...r),r=null)}),t))},_wrapper));observer.observe(document.documentElement,{attributes:!0,childList:!0,subtree:!0}),setTimeout((function(){observer.disconnect(),disconnectBridgeObservers()}),observerTimeoutMs)};selectorsSequence.every((function(selector){return!!selector&&!!queryShadowSelector(selector,document.documentElement,textMatchRegexp,closedShadowRoots)}))?(fulfillAndHandleSelectors(),disconnectBridgeObservers()):initializeMutationObserver(),parsedDelayMs&&setTimeout((function(){clickElementsBySequence(),canClick=!0}),parsedDelayMs)}}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['trusted-dispatch-event'],
            scriptlet: 'function trustedDispatchEvent(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,event,target){if(event){var hasBeenDispatched=!1,eventTarget=document;"window"===target&&(eventTarget=window);var events=new Set,dispatch=function(){var customEvent=new Event(event);"string"==typeof target&&"window"!==target&&(eventTarget=document.querySelector(target));var isEventAdded=events.has(event);!hasBeenDispatched&&isEventAdded&&eventTarget&&(hasBeenDispatched=!0,function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source),eventTarget.dispatchEvent(customEvent))},handler={apply:function(eventListener,thisArg,args){var eventName=args[0];return thisArg&&eventName&&(events.add(eventName),setTimeout((function(){dispatch()}),1)),Reflect.apply(eventListener,thisArg,args)}};EventTarget.prototype.addEventListener=new Proxy(EventTarget.prototype.addEventListener,handler)}}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['trusted-prune-inbound-object'],
            scriptlet: 'function trustedPruneInboundObject(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function hit(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}function getPropertyInChain(e,r){var n=r.indexOf(".");if(-1===n)return{base:e,prop:r};var i=r.slice(0,n);if(null===e)return{base:e,prop:i,chain:r};var t=e[i];return r=r.slice(n+1),(e instanceof Object||"object"==typeof e)&&function(t){return 0===Object.keys(t).length&&!t.prototype}(e)||null===t?{base:e,prop:i,chain:r}:void 0!==t?getPropertyInChain(t,r):(Object.defineProperty(e,i,{configurable:!0}),{base:e,prop:i,chain:r})}function getWildcardPropertyInChain(r,e){var a=arguments.length>2&&void 0!==arguments[2]&&arguments[2],i=arguments.length>3&&void 0!==arguments[3]?arguments[3]:[],t=arguments.length>4?arguments[4]:void 0,o=e.indexOf(".");if(-1===o){if("*"===e||"[]"===e){for(var n in r)if(Object.prototype.hasOwnProperty.call(r,n))if(void 0!==t){var s=r[n];"string"==typeof s&&t instanceof RegExp?t.test(s)&&i.push({base:r,prop:n}):s===t&&i.push({base:r,prop:n})}else i.push({base:r,prop:n})}else if(void 0!==t){var p=r[e];"string"==typeof p&&t instanceof RegExp?t.test(p)&&i.push({base:r,prop:e}):r[e]===t&&i.push({base:r,prop:e})}else i.push({base:r,prop:e});return i}var c=e.slice(0,o);if("[]"===c&&Array.isArray(r)||"*"===c&&r instanceof Object||"[-]"===c&&Array.isArray(r)||"{-}"===c&&r instanceof Object){var f=e.slice(o+1),y=Object.keys(r);if("{-}"===c||"[-]"===c){var h=Array.isArray(r)?"array":"object";return("{-}"!==c||"object"!==h)&&("[-]"!==c||"array"!==h)||y.forEach((function(e){(function(t,r,e){var n=r.split("."),_check=function(t,r){if(null==t)return!1;if(0===r.length)return void 0===e||("string"==typeof t&&e instanceof RegExp?e.test(t):t===e);var n=r[0],i=r.slice(1);if("*"===n||"[]"===n){if(Array.isArray(t))return t.some((function(t){return _check(t,i)}));if("object"==typeof t&&null!==t)return Object.keys(t).some((function(r){return _check(t[r],i)}))}return!!Object.prototype.hasOwnProperty.call(t,n)&&_check(t[n],i)};return _check(t,n)})(r[e],f,t)&&i.push({base:r,prop:e})})),i}y.forEach((function(e){getWildcardPropertyInChain(r[e],f,a,i,t)}))}Array.isArray(r)&&r.forEach((function(r){void 0!==r&&getWildcardPropertyInChain(r,e,a,i,t)}));var d=r[c];return e=e.slice(o+1),void 0!==d&&getWildcardPropertyInChain(d,e,a,i,t),i}function logMessage(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}function getPrunePath(t){var r=".[=].";if("string"==typeof t&&void 0!==t&&""!==t){var e=function(t){for(var e=[],n="",i=0,o=!1,s=!1;i<t.length;){var a=t[i];if(o)n+=a,"\\\\"===a?s=!s:("/"!==a||s||(o=!1),s=!1),i+=1;else{if(" "===a||"\\n"===a||"\\t"===a||"\\r"===a||"\\f"===a||"\\v"===a){for(;i<t.length&&/\\s/.test(t[i]);)i+=1;""!==n&&(e.push(n),n="");continue}if(t.startsWith(r,i)){if(n+=r,"/"===t[i+=5]){o=!0,s=!1,n+="/",i+=1;continue}continue}n+=a,i+=1}}return""!==n&&e.push(n),e}(t),n=e.map((function(t){var e=t.split(r),n=e[0],i=e[1];return void 0!==i?("true"===i?i=!0:"false"===i?i=!1:i.startsWith("/")?i=toRegExp(i):"string"==typeof i&&/^\\d+$/.test(i)&&(i=parseFloat(i)),{path:n,value:i}):{path:n}}));return console.log("parts",n),n}return[]}function toRegExp(e){var r=e||"",t="/";if(""===r)return new RegExp(".?");var n,i,s=r.lastIndexOf(t),a=r.substring(s+1),g=r.substring(0,s+1),u=(i=a,(n=g).startsWith(t)&&n.endsWith(t)&&!n.endsWith("\\\\/")&&function(e){if(!e)return!1;try{return new RegExp("",e),!0}catch(e){return!1}}(i)?i:"");if(r.startsWith(t)&&r.endsWith(t)||u)return new RegExp((u?g:r).slice(1,-1),u);var c=r.replace(/\\\\\'/g,"\'").replace(/\\\\"/g,\'"\').replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&");return new RegExp(c)}function restoreRegExpValues(e){if(e.length)try{var r;r=1===e.length?`(${e[0]})`:e.reduce((function(e,r,t){return 1===t?`(${e}),(${r})`:`${e},(${r})`}));var t=new RegExp(r);e.toString().replace(t,"")}catch(e){var n=`Failed to restore RegExp values: ${e}`;console.log(n)}}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,functionName,propsToRemove,requiredInitialProps){var stack=arguments.length>4&&void 0!==arguments[4]?arguments[4]:"";if(functionName){var nativeObjects={nativeStringify:window.JSON.stringify},{base:base,prop:prop}=getPropertyInChain(window,functionName);if(base&&prop&&"function"==typeof base[prop]){var prunePaths=getPrunePath(propsToRemove),requiredPaths=getPrunePath(requiredInitialProps),objectHandler={apply:function(target,thisArg,args){var data=args[0];return"object"==typeof data&&(data=function(e,r,n,a,t,i){var{nativeStringify:o}=i;if(0===n.length&&0===a.length)return logMessage(e,`${window.location.hostname}\\n${o(r,null,2)}\\nStack trace:\\n${(new Error).stack}`,!0),r&&"object"==typeof r&&logMessage(e,r,!0,!1),r;try{if(!1===function(n,t,r,e,a,i){if(!t)return!1;var o,{nativeStringify:u}=i,c=r.map((function(n){return n.path})),f=e.map((function(n){return n.path}));if(0===c.length&&f.length>0){var g=u(t);if(toRegExp(f.join("")).test(g))return logMessage(n,`${window.location.hostname}\\n${u(t,null,2)}\\nStack trace:\\n${(new Error).stack}`,!0),t&&"object"==typeof t&&logMessage(n,t,!0,!1),o=!1}if(a&&!function(e,t){if(!e||""===e)return!0;var r=function(){try{for(var r=[],e=1;e<10;e+=1){var a=`$${e}`;if(!RegExp[a])break;r.push(RegExp[a])}return r}catch(r){return[]}}();if(function(t,i){var r="inlineScript",n="injectedScript",isInlineScript=function(t){return t.includes(r)},isInjectedScript=function(t){return t.includes(n)};if(!isInlineScript(t)&&!isInjectedScript(t))return!1;var e=window.location.href,s=e.indexOf("#");-1!==s&&(e=e.slice(0,s));var c=i.split("\\n").slice(2).map((function(t){return t.trim()})).map((function(t){var i,s=/(.*?@)?(\\S+)(:\\d+)(:\\d+)\\)?$/.exec(t);if(s){var c,l,a=s[2],u=s[3],o=s[4];if(null!==(c=a)&&void 0!==c&&c.startsWith("(")&&(a=a.slice(1)),null!==(l=a)&&void 0!==l&&l.startsWith("<anonymous>")){var d;a=n;var f=void 0!==s[1]?s[1].slice(0,-1):t.slice(0,s.index).trim();null!==(d=f)&&void 0!==d&&d.startsWith("at")&&(f=f.slice(2).trim()),i=`${f} ${a}${u}${o}`.trim()}else i=a===e?`${r}${u}${o}`.trim():`${a}${u}${o}`.trim()}else i=t;return i}));if(c)for(var l=0;l<c.length;l+=1){if(isInlineScript(t)&&c[l].startsWith(r)&&c[l].match(toRegExp(t)))return!0;if(isInjectedScript(t)&&c[l].startsWith(n)&&c[l].match(toRegExp(t)))return!0}return!1}(e,t))return r.length&&r[0]!==RegExp.$1&&restoreRegExpValues(r),!0;var n=toRegExp(e),a=t.split("\\n").slice(2).map((function(e){return e.trim()})).join("\\n");return r.length&&r[0]!==RegExp.$1&&restoreRegExpValues(r),function(){var t=Object.getOwnPropertyDescriptor(RegExp.prototype,"test"),e=null==t?void 0:t.value;if(t&&"function"==typeof t.value)return e;throw new Error("RegExp.prototype.test is not a function")}().call(n,a)}(a,(new Error).stack||""))return o=!1;for(var s,l=[".*.","*.",".*",".[].","[].",".[]"],_loop=function(){var n=f[p],r=n.split(".").pop(),e=l.some((function(t){return n.includes(t)})),a=getWildcardPropertyInChain(t,n,e);if(!a.length)return{v:o=!1};o=!e;for(var i=0;i<a.length;i+=1){var u="string"==typeof r&&void 0!==a[i].base[r];o=e?u||o:u&&o}},p=0;p<f.length;p+=1)if(s=_loop())return s.v;return o}(e,r,n,a,t,i))return r;n.forEach((function(n){for(var a=n.path,t=n.value,i=getWildcardPropertyInChain(r,a,!0,[],t),o=i.length-1;o>=0;o-=1){var s=i[o];if(void 0!==s&&s.base)if(hit(e),Array.isArray(s.base))try{var l=Number(s.prop);if(Number.isNaN(l))continue;s.base.splice(l,1)}catch(e){console.error("Error while deleting array element",e)}else delete s.base[s.prop]}}))}catch(r){logMessage(e,r)}return r}(source,data,prunePaths,requiredPaths,stack,nativeObjects),args[0]=data),Reflect.apply(target,thisArg,args)}};base[prop]=new Proxy(base[prop],objectHandler)}else logMessage(source,`${functionName} is not a function`)}}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['trusted-replace-node-text'],
            scriptlet: 'function trustedReplaceNodeText(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function handleExistingNodes(e,n,o){(o?document.querySelectorAll(o):[document]).forEach((function(o){return function(o){if("#text"===e){var r=nodeListToArray(o.childNodes).filter((function(e){return e.nodeType===Node.TEXT_NODE}));n(r)}else{var t=nodeListToArray(o.querySelectorAll(e));n(t)}}(o)}))}function logMessage(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}function nodeListToArray(r){for(var n=[],o=0;o<r.length;o+=1)n.push(r[o]);return n}function toRegExp(e){var r=e||"",t="/";if(""===r)return new RegExp(".?");var n,i,s=r.lastIndexOf(t),a=r.substring(s+1),g=r.substring(0,s+1),u=(i=a,(n=g).startsWith(t)&&n.endsWith(t)&&!n.endsWith("\\\\/")&&function(e){if(!e)return!1;try{return new RegExp("",e),!0}catch(e){return!1}}(i)?i:"");if(r.startsWith(t)&&r.endsWith(t)||u)return new RegExp((u?g:r).slice(1,-1),u);var c=r.replace(/\\\\\'/g,"\'").replace(/\\\\"/g,\'"\').replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&");return new RegExp(c)}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,nodeName,textMatch,pattern,replacement){for(var fixQuotes=function(str){return"string"!=typeof str?str:str.replace(/\\\\\'/g,"\'").replace(/\\\\"/g,\'"\')},fixedPattern=fixQuotes(pattern),fixedReplacement=fixQuotes(replacement),{selector:selector,nodeNameMatch:nodeNameMatch,textContentMatch:textContentMatch,patternMatch:patternMatch}=function(t,e){var a,n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:null,r="/",s=!(t.startsWith(r)&&t.endsWith(r)),o=s?t:"*",h=s?t:toRegExp(t),i=e.startsWith(r)?toRegExp(e):e;return n&&(a=n.startsWith(r)?toRegExp(n):n),{selector:o,nodeNameMatch:h,textContentMatch:i,patternMatch:a}}(nodeName,textMatch,fixedPattern),_len=arguments.length,extraArgs=new Array(_len>5?_len-5:0),_key=5;_key<_len;_key++)extraArgs[_key-5]=arguments[_key];var shouldLog=extraArgs.includes("verbose"),handleNodes=function(nodes){return nodes.forEach((function(node){if(function(e,t,n){var{nodeName:o,textContent:s}=e,a=o.toLowerCase();return null!==s&&""!==s&&(t instanceof RegExp?t.test(a):t===a)&&(n instanceof RegExp?n.test(s):s.includes(n))}(node,nodeNameMatch,textContentMatch)){if(shouldLog){var originalText=node.textContent;originalText&&logMessage(source,`Original text content: ${originalText}`)}if(function(e,t,n,r){var{textContent:a}=t;if(a){var i=a.replace(n,r);"SCRIPT"===t.nodeName&&(i=function(t){var r,e=null==t||null===(r=t.api)||void 0===r?void 0:r.policy;if(e)return e;var n="AGPolicy",i=window.trustedTypes,u=!!i,c={HTML:"TrustedHTML",Script:"TrustedScript",ScriptURL:"TrustedScriptURL"};if(!u)return{name:n,isSupported:u,TrustedType:c,createHTML:function(t){return t},createScript:function(t){return t},createScriptURL:function(t){return t},create:function(t,r){return r},getAttributeType:function(){return null},convertAttributeToTrusted:function(t,r,e){return e},getPropertyType:function(){return null},convertPropertyToTrusted:function(t,r,e){return e},isHTML:function(){return!1},isScript:function(){return!1},isScriptURL:function(){return!1}};var o=i.createPolicy(n,{createHTML:function(t){return t},createScript:function(t){return t},createScriptURL:function(t){return t}}),createHTML=function(t){return o.createHTML(t)},createScript=function(t){return o.createScript(t)},createScriptURL=function(t){return o.createScriptURL(t)},create=function(t,r){switch(t){case c.HTML:return createHTML(r);case c.Script:return createScript(r);case c.ScriptURL:return createScriptURL(r);default:return r}},p=i.getAttributeType.bind(i),T=i.getPropertyType.bind(i),s=i.isHTML.bind(i),a=i.isScript.bind(i),f=i.isScriptURL.bind(i);return{name:n,isSupported:u,TrustedType:c,createHTML:createHTML,createScript:createScript,createScriptURL:createScriptURL,create:create,getAttributeType:p,convertAttributeToTrusted:function(t,r,e,n,i){var u=p(t,r,n,i);return u?create(u,e):e},getPropertyType:T,convertPropertyToTrusted:function(t,r,e,n){var i=T(t,r,n);return i?create(i,e):e},isHTML:s,isScript:a,isScriptURL:f}}(e).createScript(i)),t.textContent=i,function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(e)}}(source,node,patternMatch,fixedReplacement),shouldLog){var modifiedText=node.textContent;modifiedText&&logMessage(source,`Modified text content: ${modifiedText}`)}}}))};document.documentElement&&handleExistingNodes(selector,handleNodes),function(e){var t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{subtree:!0,childList:!0},n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:1e4,o=new MutationObserver((function(n,o){o.disconnect(),e(n,o),o.observe(document.documentElement,t)}));o.observe(document.documentElement,t),"number"==typeof n&&setTimeout((function(){return o.disconnect()}),n)}((function(mutations){return d=handleNodes,t=function(d){for(var e=[],r=0;r<d.length;r+=1)for(var{addedNodes:n}=d[r],o=0;o<n.length;o+=1)e.push(n[o]);return e}(mutations),void(e&&o?t.forEach((function(){handleExistingNodes(e,d,o)})):d(t));var d,e,o,t}))}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['trusted-replace-outbound-text'],
            scriptlet: 'function trustedReplaceOutboundText(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function getPropertyInChain(e,r){var n=r.indexOf(".");if(-1===n)return{base:e,prop:r};var i=r.slice(0,n);if(null===e)return{base:e,prop:i,chain:r};var t=e[i];return r=r.slice(n+1),(e instanceof Object||"object"==typeof e)&&function(t){return 0===Object.keys(t).length&&!t.prototype}(e)||null===t?{base:e,prop:i,chain:r}:void 0!==t?getPropertyInChain(t,r):(Object.defineProperty(e,i,{configurable:!0}),{base:e,prop:i,chain:r})}function logMessage(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}function toRegExp(e){var r=e||"",t="/";if(""===r)return new RegExp(".?");var n,i,s=r.lastIndexOf(t),a=r.substring(s+1),g=r.substring(0,s+1),u=(i=a,(n=g).startsWith(t)&&n.endsWith(t)&&!n.endsWith("\\\\/")&&function(e){if(!e)return!1;try{return new RegExp("",e),!0}catch(e){return!1}}(i)?i:"");if(r.startsWith(t)&&r.endsWith(t)||u)return new RegExp((u?g:r).slice(1,-1),u);var c=r.replace(/\\\\\'/g,"\'").replace(/\\\\"/g,\'"\').replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&");return new RegExp(c)}function restoreRegExpValues(e){if(e.length)try{var r;r=1===e.length?`(${e[0]})`:e.reduce((function(e,r,t){return 1===t?`(${e}),(${r})`:`${e},(${r})`}));var t=new RegExp(r);e.toString().replace(t,"")}catch(e){var n=`Failed to restore RegExp values: ${e}`;console.log(n)}}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,methodPath){var textToReplace=arguments.length>2&&void 0!==arguments[2]?arguments[2]:"",replacement=arguments.length>3&&void 0!==arguments[3]?arguments[3]:"",decodeMethod=arguments.length>4&&void 0!==arguments[4]?arguments[4]:"",stack=arguments.length>5&&void 0!==arguments[5]?arguments[5]:"",logContent=arguments.length>6&&void 0!==arguments[6]?arguments[6]:"";if(methodPath){var getPathParts=getPropertyInChain,{base:base,chain:chain,prop:prop}=getPathParts(window,methodPath);if(void 0===chain){var nativeMethod=base[prop];if(nativeMethod&&"function"==typeof nativeMethod){var decodeAndReplaceContent=function(content,pattern,textReplacement,decode,log){if("base64"===decode)try{if(!function(str){try{if(""===str)return!1;var decodedString=atob(str),encodedString=btoa(decodedString),stringWithoutPadding=str.replace(/=+$/,"");return encodedString.replace(/=+$/,"")===stringWithoutPadding}catch(e){return!1}}(content))return logMessage(source,`Text content is not a valid base64 encoded string: ${content}`),content;var decodedContent=atob(content);log&&logMessage(source,`Decoded text content: ${decodedContent}`);var modifiedContent=textToReplace?decodedContent.replace(pattern,textReplacement):decodedContent;return log&&logMessage(source,modifiedContent!==decodedContent?`Modified decoded text content: ${modifiedContent}`:"Decoded text content was not modified"),btoa(modifiedContent)}catch(e){return content}return content.replace(pattern,textReplacement)},logOriginalContent=!textToReplace||!!logContent,logModifiedContent=!!logContent,logDecodedContent=!!decodeMethod&&!!logContent,isMatchingSuspended=!1,objectHandler={apply:function(target,thisArg,argumentsList){if(isMatchingSuspended)return Reflect.apply(target,thisArg,argumentsList);isMatchingSuspended=!0,function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source);var result=Reflect.apply(target,thisArg,argumentsList);if(stack&&!function(e,t){if(!e||""===e)return!0;var r=function(){try{for(var r=[],e=1;e<10;e+=1){var a=`$${e}`;if(!RegExp[a])break;r.push(RegExp[a])}return r}catch(r){return[]}}();if(function(t,i){var r="inlineScript",n="injectedScript",isInlineScript=function(t){return t.includes(r)},isInjectedScript=function(t){return t.includes(n)};if(!isInlineScript(t)&&!isInjectedScript(t))return!1;var e=window.location.href,s=e.indexOf("#");-1!==s&&(e=e.slice(0,s));var c=i.split("\\n").slice(2).map((function(t){return t.trim()})).map((function(t){var i,s=/(.*?@)?(\\S+)(:\\d+)(:\\d+)\\)?$/.exec(t);if(s){var c,l,a=s[2],u=s[3],o=s[4];if(null!==(c=a)&&void 0!==c&&c.startsWith("(")&&(a=a.slice(1)),null!==(l=a)&&void 0!==l&&l.startsWith("<anonymous>")){var d;a=n;var f=void 0!==s[1]?s[1].slice(0,-1):t.slice(0,s.index).trim();null!==(d=f)&&void 0!==d&&d.startsWith("at")&&(f=f.slice(2).trim()),i=`${f} ${a}${u}${o}`.trim()}else i=a===e?`${r}${u}${o}`.trim():`${a}${u}${o}`.trim()}else i=t;return i}));if(c)for(var l=0;l<c.length;l+=1){if(isInlineScript(t)&&c[l].startsWith(r)&&c[l].match(toRegExp(t)))return!0;if(isInjectedScript(t)&&c[l].startsWith(n)&&c[l].match(toRegExp(t)))return!0}return!1}(e,t))return r.length&&r[0]!==RegExp.$1&&restoreRegExpValues(r),!0;var n=toRegExp(e),a=t.split("\\n").slice(2).map((function(e){return e.trim()})).join("\\n");return r.length&&r[0]!==RegExp.$1&&restoreRegExpValues(r),function(){var t=Object.getOwnPropertyDescriptor(RegExp.prototype,"test"),e=null==t?void 0:t.value;if(t&&"function"==typeof t.value)return e;throw new Error("RegExp.prototype.test is not a function")}().call(n,a)}(stack,(new Error).stack||""))return result;if("string"==typeof result){logOriginalContent&&logMessage(source,`Original text content: ${result}`);var patternRegexp=toRegExp(textToReplace),modifiedContent=textToReplace||logDecodedContent?decodeAndReplaceContent(result,patternRegexp,replacement,decodeMethod,logContent):result;return logModifiedContent&&logMessage(source,modifiedContent!==result?`Modified text content: ${modifiedContent}`:"Text content was not modified"),isMatchingSuspended=!1,modifiedContent}return isMatchingSuspended=!1,logMessage(source,"Content is not a string"),result}};base[prop]=new Proxy(nativeMethod,objectHandler)}else logMessage(source,`Could not retrieve the method: ${methodPath}`)}else logMessage(source,`Could not reach the end of the prop chain: ${methodPath}`)}}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['trusted-set-attr'],
            scriptlet: 'function trustedSetAttr(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function setAttributeBySelector(e,t,l,o){var r,c=arguments.length>4&&void 0!==arguments[4]?arguments[4]:defaultAttributeSetter;try{r=document.querySelectorAll(t)}catch(l){return void logMessage(e,`Failed to find elements matching selector "${t}"`)}if(r&&0!==r.length)try{r.forEach((function(e){return c(e,l,o)})),function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(e)}catch(t){logMessage(e,`Failed to set [${l}="${o}"] to each of selected elements.`)}}function defaultAttributeSetter(t,e,r){return t.setAttribute(e,r)}function logMessage(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,selector,attr){var value=arguments.length>3&&void 0!==arguments[3]?arguments[3]:"";selector&&attr&&(setAttributeBySelector(source,selector,attr,value),function(t){var e=arguments.length>1&&void 0!==arguments[1]&&arguments[1],n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:[],i=new MutationObserver(function(n,t){var r,e=!1,_wrapper=function(){for(var o=arguments.length,u=new Array(o),f=0;f<o;f++)u[f]=arguments[f];e?r=u:(n(...u),e=!0,setTimeout((function(){e=!1,r&&(_wrapper(...r),r=null)}),t))};return _wrapper}((function(){disconnect(),t(),connect()}),20)),connect=function(){n.length>0?i.observe(document.documentElement,{childList:!0,subtree:!0,attributes:e,attributeFilter:n}):i.observe(document.documentElement,{childList:!0,subtree:!0,attributes:e})},disconnect=function(){i.disconnect()};connect()}((function(){return setAttributeBySelector(source,selector,attr,value)}),!0))}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['trusted-set-constant'],
            scriptlet: 'function trustedSetConstant(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function hit(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}function logMessage(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}function getPropertyInChain(e,r){var n=r.indexOf(".");if(-1===n)return{base:e,prop:r};var i=r.slice(0,n);if(null===e)return{base:e,prop:i,chain:r};var t=e[i];return r=r.slice(n+1),(e instanceof Object||"object"==typeof e)&&isEmptyObject(e)||null===t?{base:e,prop:i,chain:r}:void 0!==t?getPropertyInChain(t,r):(Object.defineProperty(e,i,{configurable:!0}),{base:e,prop:i,chain:r})}function toRegExp(e){var r=e||"",t="/";if(""===r)return new RegExp(".?");var n,i,s=r.lastIndexOf(t),a=r.substring(s+1),g=r.substring(0,s+1),u=(i=a,(n=g).startsWith(t)&&n.endsWith(t)&&!n.endsWith("\\\\/")&&function(e){if(!e)return!1;try{return new RegExp("",e),!0}catch(e){return!1}}(i)?i:"");if(r.startsWith(t)&&r.endsWith(t)||u)return new RegExp((u?g:r).slice(1,-1),u);var c=r.replace(/\\\\\'/g,"\'").replace(/\\\\"/g,\'"\').replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&");return new RegExp(c)}function isEmptyObject(t){return 0===Object.keys(t).length&&!t.prototype}function restoreRegExpValues(e){if(e.length)try{var r;r=1===e.length?`(${e[0]})`:e.reduce((function(e,r,t){return 1===t?`(${e}),(${r})`:`${e},(${r})`}));var t=new RegExp(r);e.toString().replace(t,"")}catch(e){var n=`Failed to restore RegExp values: ${e}`;console.log(n)}}function getDescriptorAddon(){return{isAbortingSuspended:!1,isolateCallback(r){this.isAbortingSuspended=!0;try{for(var e=arguments.length,n=new Array(e>1?e-1:0),t=1;t<e;t++)n[t-1]=arguments[t];var i=r(...n);return this.isAbortingSuspended=!1,i}catch(r){var s=randomId();throw this.isAbortingSuspended=!1,new ReferenceError(s)}}}}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,property,value,stack){if(property){var constantValue;try{constantValue=function(r){if("undefined"!==r){if("false"===r)return!1;if("true"===r)return!0;if("null"===r)return null;if("NaN"===r)return NaN;if(r.startsWith("/")&&r.endsWith("/"))return toRegExp(r);var e=Number(r);if(N=e,!(Number.isNaN||window.isNaN)(N)){if(Math.abs(e)>32767)throw new Error("number values bigger than 32767 are not allowed");return e}try{var t=JSON.parse(r);if(t instanceof Object||"string"==typeof t)return t}catch(e){return r}return r}var N}(value)}catch(e){return void logMessage(source,e)}var canceled=!1,setChainPropAccess=function(t){var{source:e,stack:r,mustCancel:i,trapProp:n,getConstantValue:a,setConstantValue:s}=t,_setChainPropAccess=function(t,c){var o=getPropertyInChain(t,c),{base:u,prop:d,chain:f}=o,h={factValue:void 0,init(t){return this.factValue=t,!0},get(){return this.factValue},set(t){this.factValue!==t&&(this.factValue=t,t instanceof Object&&_setChainPropAccess(t,f))}},l={factValue:void 0,descriptorAddon:getDescriptorAddon(),init(t){return!i(t)&&(this.factValue=t,!0)},get(){if(!r)return hit(e),a();if(!this.descriptorAddon.isAbortingSuspended){this.descriptorAddon.isAbortingSuspended=!0;var t=!1;try{t=function(e,t){if(!e||""===e)return!0;var r=function(){try{for(var r=[],e=1;e<10;e+=1){var a=`$${e}`;if(!RegExp[a])break;r.push(RegExp[a])}return r}catch(r){return[]}}();if(function(t,i){var r="inlineScript",n="injectedScript",isInlineScript=function(t){return t.includes(r)},isInjectedScript=function(t){return t.includes(n)};if(!isInlineScript(t)&&!isInjectedScript(t))return!1;var e=window.location.href,s=e.indexOf("#");-1!==s&&(e=e.slice(0,s));var c=i.split("\\n").slice(2).map((function(t){return t.trim()})).map((function(t){var i,s=/(.*?@)?(\\S+)(:\\d+)(:\\d+)\\)?$/.exec(t);if(s){var c,l,a=s[2],u=s[3],o=s[4];if(null!==(c=a)&&void 0!==c&&c.startsWith("(")&&(a=a.slice(1)),null!==(l=a)&&void 0!==l&&l.startsWith("<anonymous>")){var d;a=n;var f=void 0!==s[1]?s[1].slice(0,-1):t.slice(0,s.index).trim();null!==(d=f)&&void 0!==d&&d.startsWith("at")&&(f=f.slice(2).trim()),i=`${f} ${a}${u}${o}`.trim()}else i=a===e?`${r}${u}${o}`.trim():`${a}${u}${o}`.trim()}else i=t;return i}));if(c)for(var l=0;l<c.length;l+=1){if(isInlineScript(t)&&c[l].startsWith(r)&&c[l].match(toRegExp(t)))return!0;if(isInjectedScript(t)&&c[l].startsWith(n)&&c[l].match(toRegExp(t)))return!0}return!1}(e,t))return r.length&&r[0]!==RegExp.$1&&restoreRegExpValues(r),!0;var n=toRegExp(e),a=t.split("\\n").slice(2).map((function(e){return e.trim()})).join("\\n");return r.length&&r[0]!==RegExp.$1&&restoreRegExpValues(r),function(){var t=Object.getOwnPropertyDescriptor(RegExp.prototype,"test"),e=null==t?void 0:t.value;if(t&&"function"==typeof t.value)return e;throw new Error("RegExp.prototype.test is not a function")}().call(n,a)}(r,(new Error).stack||"")}catch(t){return this.descriptorAddon.isAbortingSuspended=!1,this.factValue}if(this.descriptorAddon.isAbortingSuspended=!1,t)return hit(e),a()}return this.factValue},set(t){i(t)?s(t):this.factValue=t}};if(f)if(void 0===u||null!==u[d]){(u instanceof Object||"object"==typeof u)&&isEmptyObject(u)&&n(u,d,!0,h);var p=t[d];(p instanceof Object||"object"==typeof p&&null!==p)&&_setChainPropAccess(p,f),n(u,d,!0,h)}else n(u,d,!0,h);else n(u,d,!1,l)};return _setChainPropAccess}({source:source,stack:stack,mustCancel:function(value){return canceled||(canceled=void 0!==value&&void 0!==constantValue&&typeof value!=typeof constantValue&&null!==value)},trapProp:function(base,prop,configurable,handler){if(!handler.init(base[prop]))return!1;var prevSetter,origDescriptor=Object.getOwnPropertyDescriptor(base,prop);if(origDescriptor instanceof Object){if(!origDescriptor.configurable)return logMessage(source,`Property \'${prop}\' is not configurable`),!1;base[prop]=constantValue,origDescriptor.set instanceof Function&&(prevSetter=origDescriptor.set)}return Object.defineProperty(base,prop,{configurable:configurable,get:()=>handler.get(),set(a){void 0!==prevSetter&&prevSetter(a),handler.set(a)}}),!0},getConstantValue:function(){return constantValue},setConstantValue:function(v){constantValue=v}});setChainPropAccess(window,property)}}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['trusted-set-cookie'],
            scriptlet: 'function trustedSetCookie(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function logMessage(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,name,value){var offsetExpiresSec=arguments.length>3&&void 0!==arguments[3]?arguments[3]:"",path=arguments.length>4&&void 0!==arguments[4]?arguments[4]:"/",domain=arguments.length>5&&void 0!==arguments[5]?arguments[5]:"";if(void 0!==name)if(void 0!==value){var t,e,n,parsedValue=(e=t=value,"$now$"===t?e=Date.now().toString():"$currentDate$"===t?e=Date():"$currentISODate$"===t&&(e=(new Date).toISOString()),e);if("/"===(n=path)||"none"===n)if(document.location.origin.includes(domain)){var cookieToSet=function(e,o,i){var n=arguments.length>3&&void 0!==arguments[3]?arguments[3]:"",t=!(arguments.length>4&&void 0!==arguments[4])||arguments[4];if(!t&&`${o}`.includes(";")||e.includes(";"))return null;var r=`${e}=${t?encodeURIComponent(o):o}`;if(e.startsWith("__Host-"))return r+="; path=/; secure",n&&console.debug(`Domain value: "${n}" has been ignored, because is not allowed for __Host- prefixed cookies`),r;var s=function(t){return"/"===t?"path=/":""}(i);return s&&(r+=`; ${s}`),e.startsWith("__Secure-")&&(r+="; secure"),n&&(r+=`; domain=${n}`),r}(name,parsedValue,path,domain,!1);if(cookieToSet){if(offsetExpiresSec){var parsedOffsetMs=function(e){var r;if("1year"===e)r=31536e3;else if("1day"===e)r=86400;else if(r=Number.parseInt(e,10),Number.isNaN(r))return null;return 1e3*r}(offsetExpiresSec);if(!parsedOffsetMs)return void logMessage(source,`Invalid offsetExpiresSec value: ${offsetExpiresSec}`);var expires=Date.now()+parsedOffsetMs;cookieToSet+=`; expires=${new Date(expires).toUTCString()}`}document.cookie=cookieToSet,function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source)}else logMessage(source,"Invalid cookie name or value")}else logMessage(source,`Cookie domain not matched by origin: \'${domain}\'`);else logMessage(source,`Invalid cookie path: \'${path}\'`)}else logMessage(source,"Cookie value should be specified");else logMessage(source,"Cookie name should be specified")}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['trusted-set-cookie-reload'],
            scriptlet: 'function trustedSetCookieReload(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function logMessage(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}function isCookieSetWithValue(e,t,r){return e.split(";").some((function(e){var n=e.indexOf("=");if(-1===n)return!1;var i=e.slice(0,n).trim(),a=e.slice(n+1).trim();if(new Set(["$now$","$currentDate$","$currentISODate$"]).has(r)){var u=Date.now(),s=/^\\d+$/.test(a)?parseInt(a,10):new Date(a).getTime();return t===i&&s>u-864e5}return t===i&&r===a}))}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,name,value){var offsetExpiresSec=arguments.length>3&&void 0!==arguments[3]?arguments[3]:"",path=arguments.length>4&&void 0!==arguments[4]?arguments[4]:"/",domain=arguments.length>5&&void 0!==arguments[5]?arguments[5]:"";if(void 0!==name)if(void 0!==value){if(!isCookieSetWithValue(document.cookie,name,value)){var t,e,n,parsedValue=(e=t=value,"$now$"===t?e=Date.now().toString():"$currentDate$"===t?e=Date():"$currentISODate$"===t&&(e=(new Date).toISOString()),e);if("/"===(n=path)||"none"===n)if(document.location.origin.includes(domain)){var cookieToSet=function(e,o,i){var n=arguments.length>3&&void 0!==arguments[3]?arguments[3]:"",t=!(arguments.length>4&&void 0!==arguments[4])||arguments[4];if(!t&&`${o}`.includes(";")||e.includes(";"))return null;var r=`${e}=${t?encodeURIComponent(o):o}`;if(e.startsWith("__Host-"))return r+="; path=/; secure",n&&console.debug(`Domain value: "${n}" has been ignored, because is not allowed for __Host- prefixed cookies`),r;var s=function(t){return"/"===t?"path=/":""}(i);return s&&(r+=`; ${s}`),e.startsWith("__Secure-")&&(r+="; secure"),n&&(r+=`; domain=${n}`),r}(name,parsedValue,path,domain,!1);if(cookieToSet){if(offsetExpiresSec){var parsedOffsetMs=function(e){var r;if("1year"===e)r=31536e3;else if("1day"===e)r=86400;else if(r=Number.parseInt(e,10),Number.isNaN(r))return null;return 1e3*r}(offsetExpiresSec);if(!parsedOffsetMs)return void logMessage(source,`Invalid offsetExpiresSec value: ${offsetExpiresSec}`);var expires=Date.now()+parsedOffsetMs;cookieToSet+=`; expires=${new Date(expires).toUTCString()}`}document.cookie=cookieToSet,function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source);var cookieValueToCheck=function(){var r=document.cookie.split(";"),n={};return r.forEach((function(i){var r,t="",e=i.indexOf("=");-1===e?r=i.trim():(r=i.slice(0,e).trim(),t=i.slice(e+1)),n[r]=t||null})),n}()[name];isCookieSetWithValue(document.cookie,name,cookieValueToCheck)&&window.location.reload()}else logMessage(source,"Invalid cookie name or value")}else logMessage(source,`Cookie domain not matched by origin: \'${domain}\'`);else logMessage(source,`Invalid cookie path: \'${path}\'`)}}else logMessage(source,"Cookie value should be specified");else logMessage(source,"Cookie name should be specified")}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['trusted-set-local-storage-item'],
            scriptlet: 'function trustedSetLocalStorageItem(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function logMessage(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,key,value){if(void 0!==key)if(void 0!==value){var t,e,parsedValue=(e=t=value,"$now$"===t?e=Date.now().toString():"$currentDate$"===t?e=Date():"$currentISODate$"===t&&(e=(new Date).toISOString()),e),{localStorage:localStorage}=window;!function(e,t,s,a){try{t.setItem(s,a)}catch(t){logMessage(e,`Unable to set storage item due to: ${t.message}`)}}(source,localStorage,key,parsedValue),function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source)}else logMessage(source,"Item value should be specified");else logMessage(source,"Item key should be specified")}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['trusted-set-session-storage-item'],
            scriptlet: 'function trustedSetSessionStorageItem(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function logMessage(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,key,value){if(void 0!==key)if(void 0!==value){var t,e,parsedValue=(e=t=value,"$now$"===t?e=Date.now().toString():"$currentDate$"===t?e=Date():"$currentISODate$"===t&&(e=(new Date).toISOString()),e),{sessionStorage:sessionStorage}=window;!function(e,t,s,a){try{t.setItem(s,a)}catch(t){logMessage(e,`Unable to set storage item due to: ${t.message}`)}}(source,sessionStorage,key,parsedValue),function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source)}else logMessage(source,"Item value should be specified");else logMessage(source,"Item key should be specified")}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['trusted-suppress-native-method'],
            scriptlet: 'function trustedSuppressNativeMethod(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function logMessage(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}function getPropertyInChain(e,r){var n=r.indexOf(".");if(-1===n)return{base:e,prop:r};var i=r.slice(0,n);if(null===e)return{base:e,prop:i,chain:r};var t=e[i];return r=r.slice(n+1),(e instanceof Object||"object"==typeof e)&&function(t){return 0===Object.keys(t).length&&!t.prototype}(e)||null===t?{base:e,prop:i,chain:r}:void 0!==t?getPropertyInChain(t,r):(Object.defineProperty(e,i,{configurable:!0}),{base:e,prop:i,chain:r})}function isValueMatched(t,r){return"function"!=typeof t&&(nativeIsNaN(t)?nativeIsNaN(r):null==t||"number"==typeof t||"boolean"==typeof t?t===r:"string"==typeof t?("string"==typeof r||r instanceof RegExp)&&function(t,n){return"string"==typeof n?""===n?t===n:t.includes(n):n instanceof RegExp&&n.test(t)}(t,r):Array.isArray(t)&&Array.isArray(r)?function(r,n){if(0===r.length)return 0===n.length;if(0===n.length)return!1;for(var t,_loop=function(){var t=n[e];return r.some((function(r){return isValueMatched(r,t)}))?0:{v:!1}},e=0;e<n.length;e+=1)if(0!==(t=_loop())&&t)return t.v;return!0}(t,r):!(!isArbitraryObject(t)||!isArbitraryObject(r))&&function(e,t){for(var r=Object.keys(t),a=0;a<r.length;a+=1){var c=r[a];if(!isValueMatched(e[c],t[c]))return!1}return!0}(t,r))}function toRegExp(e){var r=e||"",t="/";if(""===r)return new RegExp(".?");var n,i,s=r.lastIndexOf(t),a=r.substring(s+1),g=r.substring(0,s+1),u=(i=a,(n=g).startsWith(t)&&n.endsWith(t)&&!n.endsWith("\\\\/")&&function(e){if(!e)return!1;try{return new RegExp("",e),!0}catch(e){return!1}}(i)?i:"");if(r.startsWith(t)&&r.endsWith(t)||u)return new RegExp((u?g:r).slice(1,-1),u);var c=r.replace(/\\\\\'/g,"\'").replace(/\\\\"/g,\'"\').replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&");return new RegExp(c)}function nativeIsNaN(N){return(Number.isNaN||window.isNaN)(N)}function isArbitraryObject(r){return!(null===r||"object"!=typeof r||Array.isArray(r)||r instanceof RegExp)}function restoreRegExpValues(e){if(e.length)try{var r;r=1===e.length?`(${e[0]})`:e.reduce((function(e,r,t){return 1===t?`(${e}),(${r})`:`${e},(${r})`}));var t=new RegExp(r);e.toString().replace(t,"")}catch(e){var n=`Failed to restore RegExp values: ${e}`;console.log(n)}}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,methodPath,signatureStr){var stack=arguments.length>4&&void 0!==arguments[4]?arguments[4]:"";if(methodPath&&signatureStr){var r,n,signatureMatcher,suppress="abort"===(arguments.length>3&&void 0!==arguments[3]?arguments[3]:"abort")?(r=Math.random().toString(36).slice(2,9),n=!1,function(){throw n||(window.onerror=function(r){var n=window.onerror;return function(e){if("string"==typeof e&&e.includes(r))return!0;if(n instanceof Function){for(var t=arguments.length,o=new Array(t>1?t-1:0),i=1;i<t;i++)o[i-1]=arguments[i];return n.apply(window,[e,...o])}return!1}}(r),n=!0),new ReferenceError(r)}):function(){};try{signatureMatcher=function(e){for(var i=[],n="",t=!1,f=0;f<e.length;){var r=e[f];if(t){if("/"===r){for(var u=0,o=n.length-1;o>=0&&"\\\\"===n[o];)u+=1,o-=1;if(u%2==0){for(n+=r,f+=1;f<e.length&&/[gimsuy]/.test(e[f]);)n+=e[f],f+=1;t=!1;continue}}}else{if("/"===r&&""===n){t=!0,n+=r,f+=1;continue}if("|"===r){i.push(n),n="",f+=1;continue}}n+=r,f+=1}return i.push(n),i}(signatureStr).map((function(value){return" "===value?value:function(r){if("undefined"!==r){if("false"===r)return!1;if("true"===r)return!0;if("null"===r)return null;if("NaN"===r)return NaN;if(r.startsWith("/")&&r.endsWith("/"))return toRegExp(r);var e=Number(r);if(!nativeIsNaN(e)){if(Math.abs(e)>32767)throw new Error("number values bigger than 32767 are not allowed");return e}try{var t=JSON.parse(r);if(t instanceof Object||"string"==typeof t)return t}catch(e){return r}return r}}(value)}))}catch(e){return void logMessage(source,`Could not parse the signature matcher: ${function(e){var r;if("object"==typeof(r=e)&&null!==r&&"message"in r&&"string"==typeof r.message)return e.message;try{return new Error(JSON.stringify(e)).message}catch(r){return new Error(String(e)).message}}(e)}`)}var getPathParts=getPropertyInChain,{base:base,chain:chain,prop:prop}=getPathParts(window,methodPath);if(void 0===chain){var nativeMethod=base[prop];if(nativeMethod&&"function"==typeof nativeMethod){var isMatchingSuspended=!1;base[prop]=new Proxy(nativeMethod,{apply:function(target,thisArg,argumentsList){if(isMatchingSuspended)return Reflect.apply(target,thisArg,argumentsList);if(isMatchingSuspended=!0,stack&&!function(e,t){if(!e||""===e)return!0;var r=function(){try{for(var r=[],e=1;e<10;e+=1){var a=`$${e}`;if(!RegExp[a])break;r.push(RegExp[a])}return r}catch(r){return[]}}();if(function(t,i){var r="inlineScript",n="injectedScript",isInlineScript=function(t){return t.includes(r)},isInjectedScript=function(t){return t.includes(n)};if(!isInlineScript(t)&&!isInjectedScript(t))return!1;var e=window.location.href,s=e.indexOf("#");-1!==s&&(e=e.slice(0,s));var c=i.split("\\n").slice(2).map((function(t){return t.trim()})).map((function(t){var i,s=/(.*?@)?(\\S+)(:\\d+)(:\\d+)\\)?$/.exec(t);if(s){var c,l,a=s[2],u=s[3],o=s[4];if(null!==(c=a)&&void 0!==c&&c.startsWith("(")&&(a=a.slice(1)),null!==(l=a)&&void 0!==l&&l.startsWith("<anonymous>")){var d;a=n;var f=void 0!==s[1]?s[1].slice(0,-1):t.slice(0,s.index).trim();null!==(d=f)&&void 0!==d&&d.startsWith("at")&&(f=f.slice(2).trim()),i=`${f} ${a}${u}${o}`.trim()}else i=a===e?`${r}${u}${o}`.trim():`${a}${u}${o}`.trim()}else i=t;return i}));if(c)for(var l=0;l<c.length;l+=1){if(isInlineScript(t)&&c[l].startsWith(r)&&c[l].match(toRegExp(t)))return!0;if(isInjectedScript(t)&&c[l].startsWith(n)&&c[l].match(toRegExp(t)))return!0}return!1}(e,t))return r.length&&r[0]!==RegExp.$1&&restoreRegExpValues(r),!0;var n=toRegExp(e),a=t.split("\\n").slice(2).map((function(e){return e.trim()})).join("\\n");return r.length&&r[0]!==RegExp.$1&&restoreRegExpValues(r),function(){var t=Object.getOwnPropertyDescriptor(RegExp.prototype,"test"),e=null==t?void 0:t.value;if(t&&"function"==typeof t.value)return e;throw new Error("RegExp.prototype.test is not a function")}().call(n,a)}(stack,(new Error).stack||""))return isMatchingSuspended=!1,Reflect.apply(target,thisArg,argumentsList);var nativeArguments,isMatching=(nativeArguments=argumentsList,signatureMatcher.every((function(matcher,i){return" "===matcher||isValueMatched(nativeArguments[i],matcher)})));return isMatchingSuspended=!1,isMatching?(function(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}(source),suppress()):Reflect.apply(target,thisArg,argumentsList)}})}else logMessage(source,`Could not retrieve the method: ${methodPath}`)}else logMessage(source,`Could not reach the end of the prop chain: ${methodPath}`)}}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
        {
            names: ['xml-prune', 'xml-prune.js', 'ubo-xml-prune.js', 'ubo-xml-prune'],
            scriptlet: 'function xmlPrune(source,args){const uniqueIdentifier=source.uniqueId+source.name+"_"+(Array.isArray(args)?args.join("_"):"");if(source.uniqueId&&"done"===Window.prototype.toString[uniqueIdentifier])return;function hit(e){if(e.verbose){try{var n=console.trace.bind(console),i="[ABY] ";"corelibs"===e.engine?i+=e.ruleText:(e.domainName&&(i+=`${e.domainName}`),e.args?i+=`#%#//scriptlet(\'${e.name}\', \'${e.args.join("\', \'")}\')`:i+=`#%#//scriptlet(\'${e.name}\')`),n&&n(i)}catch(e){}"function"==typeof window.__debug&&window.__debug(e)}}function logMessage(e,o){var n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],g=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],{name:l,verbose:v}=e;if(n||v){var a=console.log;g?a(`${l}: ${o}`):a(`${l}:`,o)}}function toRegExp(e){var r=e||"",t="/";if(""===r)return new RegExp(".?");var n,i,s=r.lastIndexOf(t),a=r.substring(s+1),g=r.substring(0,s+1),u=(i=a,(n=g).startsWith(t)&&n.endsWith(t)&&!n.endsWith("\\\\/")&&function(e){if(!e)return!1;try{return new RegExp("",e),!0}catch(e){return!1}}(i)?i:"");if(r.startsWith(t)&&r.endsWith(t)||u)return new RegExp((u?g:r).slice(1,-1),u);var c=r.replace(/\\\\\'/g,"\'").replace(/\\\\"/g,\'"\').replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&");return new RegExp(c)}function getXhrData(r,t,a,e,n){return{method:r,url:t,async:a,user:e,password:n}}const updatedArgs=args?[].concat(source).concat(args):[source];try{(function(source,propsToRemove){var optionalProp=arguments.length>2&&void 0!==arguments[2]?arguments[2]:"",urlToMatch=arguments.length>3&&void 0!==arguments[3]?arguments[3]:"";if("undefined"!=typeof Reflect&&"undefined"!=typeof fetch&&"undefined"!=typeof Proxy&&"undefined"!=typeof Response){var xhrData,shouldPruneResponse=!1,shouldLogContent="true"===(arguments.length>4&&void 0!==arguments[4]&&arguments[4]),urlMatchRegexp=toRegExp(urlToMatch),isXpath=propsToRemove&&propsToRemove.startsWith("xpath("),getXPathElements=function(contextNode){var matchedElements=[];try{for(var elementsToRemove=propsToRemove.slice(6,-1),xpathResult=contextNode.evaluate(elementsToRemove,contextNode,null,XPathResult.UNORDERED_NODE_SNAPSHOT_TYPE,null),i=0;i<xpathResult.snapshotLength;i+=1)matchedElements.push(xpathResult.snapshotItem(i))}catch(ex){logMessage(source,`Invalid XPath parameter: ${propsToRemove}\\n${ex}`)}return matchedElements},isXML=function(text){if("string"==typeof text){var trimmedText=text.trim();if(trimmedText.startsWith("<")&&trimmedText.endsWith(">"))return!0}return!1},createXMLDocument=function(text){return(new DOMParser).parseFromString(text,"text/xml")},isPruningNeeded=function(response,propsToRemove){if(!isXML(response))return!1;var docXML=createXMLDocument(response);return isXpath?getXPathElements(docXML):!!docXML.querySelector(propsToRemove)},pruneXML=function(text){if(!isXML(text))return shouldPruneResponse=!1,text;var xmlDoc=createXMLDocument(text);if(xmlDoc.querySelector("parsererror"))return text;if(""!==optionalProp&&null===xmlDoc.querySelector(optionalProp))return shouldPruneResponse=!1,text;var elements=isXpath?getXPathElements(xmlDoc):xmlDoc.querySelectorAll(propsToRemove);if(!elements.length)return shouldPruneResponse=!1,text;if(shouldLogContent){var cloneXmlDoc=xmlDoc.cloneNode(!0);logMessage(source,"Original xml:"),logMessage(source,cloneXmlDoc,!0,!1)}return isXpath?elements.forEach((function(element){1===element.nodeType?element.remove():2===element.nodeType&&element.ownerElement.removeAttribute(element.nodeName)})):elements.forEach((function(elem){elem.remove()})),shouldLogContent&&(logMessage(source,"Modified xml:"),logMessage(source,xmlDoc,!0,!1)),(new XMLSerializer).serializeToString(xmlDoc)},nativeOpen=window.XMLHttpRequest.prototype.open,nativeSend=window.XMLHttpRequest.prototype.send,matchedXhrRequests=new Set,xhrRequestHeaders=new Map,openHandler={apply:function(target,thisArg,args){if(xhrData=getXhrData.apply(null,args),function(e,t,r){if(""===t||"*"===t)return!0;var a,s=function(e){var r={};return e.split(" ").forEach((function(e){var n=e.indexOf(":"),i=e.slice(0,n);if(function(e){return["url","method","headers","body","credentials","cache","redirect","referrer","referrerPolicy","integrity","keepalive","signal","mode"].includes(e)}(i)){var s=e.slice(n+1);r[i]=s}else r.url=e})),r}(t);if(function(t){return Object.values(t).every((function(t){return function(e){var t,n=function(e){return e.replace(/[.*+?^${}()|[\\]\\\\]/g,"\\\\$&")}(e);"/"===e[0]&&"/"===e[e.length-1]&&(n=e.slice(1,-1));try{t=new RegExp(n),t=!0}catch(e){t=!1}return t}(t)}))}(s)){var n=function(t){var a={};return Object.keys(t).forEach((function(c){a[c]=toRegExp(t[c])})),a}(s);a=Object.keys(n).every((function(e){var t=n[e],a=r[e];return Object.prototype.hasOwnProperty.call(r,e)&&"string"==typeof a&&(null==t?void 0:t.test(a))}))}else logMessage(e,`Invalid parameter: ${t}`),a=!1;return a}(source,urlToMatch,xhrData)&&matchedXhrRequests.add(thisArg),matchedXhrRequests.has(thisArg)&&!xhrRequestHeaders.has(thisArg)){xhrRequestHeaders.set(thisArg,[]);var setRequestHeaderHandler={apply:function(target,thisArg,args){var headers=xhrRequestHeaders.get(thisArg);return headers&&headers.push(args),Reflect.apply(target,thisArg,args)}};thisArg.setRequestHeader=new Proxy(thisArg.setRequestHeader,setRequestHeaderHandler)}return Reflect.apply(target,thisArg,args)}},sendHandler={apply:function(target,thisArg,args){if(!matchedXhrRequests.has(thisArg)||!["","text"].includes(thisArg.responseType))return Reflect.apply(target,thisArg,args);var forgedRequest=new XMLHttpRequest;forgedRequest.withCredentials=thisArg.withCredentials,forgedRequest.addEventListener("readystatechange",(function(){if(4===forgedRequest.readyState){var{readyState:readyState,response:response,responseText:responseText,responseURL:responseURL,responseXML:responseXML,status:status,statusText:statusText}=forgedRequest;if("string"==typeof(responseText||response)){propsToRemove?shouldPruneResponse=isPruningNeeded(response,propsToRemove):isXML(response)&&(logMessage(source,`XMLHttpRequest.open() URL: ${responseURL}\\nresponse: ${response}`),logMessage(source,createXMLDocument(response),!0,!1));var responseContent=shouldPruneResponse?pruneXML(response):response;Object.defineProperties(thisArg,{readyState:{value:readyState,writable:!1},responseURL:{value:responseURL,writable:!1},responseXML:{value:responseXML,writable:!1},status:{value:status,writable:!1},statusText:{value:statusText,writable:!1},response:{value:responseContent,writable:!1},responseText:{value:responseContent,writable:!1}}),setTimeout((function(){var stateEvent=new Event("readystatechange");thisArg.dispatchEvent(stateEvent);var loadEvent=new ProgressEvent("load");thisArg.dispatchEvent(loadEvent);var loadEndEvent=new ProgressEvent("loadend");thisArg.dispatchEvent(loadEndEvent)}),1),shouldPruneResponse&&hit(source)}}})),nativeOpen.apply(forgedRequest,[xhrData.method,xhrData.url]),(xhrRequestHeaders.get(thisArg)||[]).forEach((function(header){var name=header[0],value=header[1];forgedRequest.setRequestHeader(name,value)})),xhrRequestHeaders.delete(thisArg),matchedXhrRequests.delete(thisArg);try{nativeSend.call(forgedRequest,args)}catch(_unused){return Reflect.apply(target,thisArg,args)}}};XMLHttpRequest.prototype.open=new Proxy(XMLHttpRequest.prototype.open,openHandler),XMLHttpRequest.prototype.send=new Proxy(XMLHttpRequest.prototype.send,sendHandler);var nativeFetch=window.fetch,fetchHandler={apply:async function(target,thisArg,args){var fetchURL=args[0]instanceof Request?args[0].url:args[0];if("string"!=typeof fetchURL||0===fetchURL.length)return Reflect.apply(target,thisArg,args);if(urlMatchRegexp.test(fetchURL)){var response=await nativeFetch(...args),clonedResponse=response.clone(),responseText=await response.text();if(!(shouldPruneResponse=isPruningNeeded(responseText,propsToRemove)))return logMessage(source,`fetch URL: ${fetchURL}\\nresponse text: ${responseText}`),logMessage(source,createXMLDocument(responseText),!0,!1),clonedResponse;var prunedText=pruneXML(responseText);return shouldPruneResponse?(hit(source),new Response(prunedText,{status:response.status,statusText:response.statusText,headers:response.headers})):clonedResponse}return Reflect.apply(target,thisArg,args)}};window.fetch=new Proxy(window.fetch,fetchHandler)}}).apply(this,updatedArgs),source.uniqueId&&Object.defineProperty(Window.prototype.toString,uniqueIdentifier,{value:"done",enumerable:!1,writable:!1,configurable:!1})}catch(e){console.log(e)}}',
        },
    ],
};

;// ./src/helpers/scriptlets/get-scriptlet-function.ts

function getScriptletFunction(scriptletName) {
    var scriptlets = scriptletsLib.scriptlets;
    var foundScriptlet = scriptlets.find(function (_a) {
        var names = _a.names;
        return names.includes(scriptletName);
    });
    return foundScriptlet ? foundScriptlet.scriptlet : null;
}

;// ./src/helpers/scriptlets/pass-source-and-props.ts
function passSourceAndProps(source, code) {
    var sourceString = JSON.stringify(source);
    var argsString = source.args ? "[".concat(source.args.map(function (arg) { return JSON.stringify(arg); }), "]") : undefined;
    var params = argsString ? "".concat(sourceString, ", ").concat(argsString) : sourceString;
    return "(".concat(code, ")(").concat(params, ");");
}

;// ./src/helpers/scriptlets/get-scriptlet-code.ts


var getScriptletString = function (scriptletSource) {
    return scriptletSource.map(function (source) { return getScriptletCode(source); }).join(';');
};
var getScriptletCode = function (source) {
    var scriptletFunction = getScriptletFunction(source.name);
    if (!scriptletFunction) {
        return '';
    }
    return passSourceAndProps(source, scriptletFunction);
};

;// ./src/background/helpers/css-execute.ts
var css_execute_awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var css_execute_generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};


var cssExecute = function (tabId, cssText) { return css_execute_awaiter(void 0, void 0, void 0, function () {
    var e_1;
    return css_execute_generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                _a.trys.push([0, 2, , 3]);
                return [4, chrome.scripting.insertCSS({
                        css: cssText,
                        origin: 'USER',
                        target: { tabId: tabId },
                    })];
            case 1:
                _a.sent();
                return [3, 3];
            case 2:
                e_1 = _a.sent();
                if (false) {}
                return [3, 3];
            case 3: return [2];
        }
    });
}); };
var getCssAndInject = function (tabId) { return css_execute_awaiter(void 0, void 0, void 0, function () {
    var cssText;
    return css_execute_generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                cssText = "".concat(Settings[SettingsKeys.CssRules].join(','), " { display:none!important; }");
                return [4, cssExecute(tabId, cssText)];
            case 1:
                _a.sent();
                return [2];
        }
    });
}); };

;// ./src/constants/inline-scripts/index.ts
var inlineScriptsArray = [
    '(()=>{let t=document.location.href,e=[],n=[],o="",r=!1;const i=Array.prototype.push,a={apply:(t,o,a)=>(window.yt?.config_?.EXPERIMENT_FLAGS?.html5_enable_ssap_entity_id&&a[0]&&a[0]!==window&&"number"==typeof a[0].start&&a[0].end&&"ssap"===a[0].namespace&&a[0].id&&(r||0!==a[0]?.start||n.includes(a[0].id)||(e.length=0,n.length=0,r=!0,i.call(e,a[0]),i.call(n,a[0].id)),r&&0!==a[0]?.start&&!n.includes(a[0].id)&&(i.call(e,a[0]),i.call(n,a[0].id))),Reflect.apply(t,o,a))};window.Array.prototype.push=new Proxy(window.Array.prototype.push,a),document.addEventListener("DOMContentLoaded",(function(){if(!window.yt?.config_?.EXPERIMENT_FLAGS?.html5_enable_ssap_entity_id)return;const i=()=>{const t=document.querySelector("video");if(t&&e.length){const i=Math.round(t.duration),a=Math.round(e.at(-1).end/1e3),c=n.join(",");if(!1===t.loop&&o!==c&&i&&i===a){const n=e.at(-1).start/1e3;t.currentTime<n&&(t.currentTime=n,r=!1,o=c)}else if(!0===t.loop&&i&&i===a){const n=e.at(-1).start/1e3;t.currentTime<n&&(t.currentTime=n,r=!1,o=c)}}};i();new MutationObserver((()=>{t!==document.location.href&&(t=document.location.href,e.length=0,n.length=0,r=!1),i()})).observe(document,{childList:!0,subtree:!0})}))})();',
    '(()=>{const e={apply:(e,t,n)=>{const o=Reflect.apply(e,t,n);try{o instanceof HTMLIFrameElement&&"about:blank"===o.src&&o.contentWindow&&(o.contentWindow.fetch=window.fetch,o.contentWindow.Request=window.Request)}catch(e){}return o}};Node.prototype.appendChild=new Proxy(Node.prototype.appendChild,e)})();',
    '(()=>{const t={apply:(t,o,n)=>{const e=n[0];return"function"==typeof e&&e.toString().includes("onAbnormalityDetected")&&(n[0]=function(){}),Reflect.apply(t,o,n)}};window.Promise.prototype.then=new Proxy(window.Promise.prototype.then,t)})();',
    '(()=>{const e="pyv",t="param_first",a="param_second",n="client_screen",c="ad_type",o="none",r="eAFgAQ",l="8AUB",i="YAHI",s="CHANNEL",y=t;let p=y,u=null;const d=Object.getOwnPropertyDescriptor(Document.prototype,"visibilityState"),b=()=>{try{Object.defineProperty(document,"visibilityState",{get:()=>"visible",configurable:!0})}catch(e){}},m=window.JSON.stringify,f=e=>{p=e};(()=>{try{const e=Object.getOwnPropertyDescriptor(window.JSON,"parse");return!!e&&e.writable}catch(e){return!1}})()||((()=>{const e={apply:(e,t,a)=>{try{const e=t;e?.includes(\'"minimumPlaybackRate":100,"maximumPlaybackRate":100\')&&(t=e.replace(\'"minimumPlaybackRate":100,"maximumPlaybackRate":100\',\'"minimumPlaybackRate":25,"maximumPlaybackRate":200\'))}catch(e){}return Reflect.apply(e,t,a)}};window.String.prototype.replace=new Proxy(window.String.prototype.replace,e)})(),f(n));const x=e=>{(e.playbackContext||e.playerRequest)&&delete e.context?.client?.configInfo?.appInstallData},C=(p,m,C)=>{try{if(!p||!m||!C)return;(e=>{const t=e?.videoId;t&&(u&&u!==t&&f(y),u=t)})(p);const R=document.getElementById("movie_player")?.getPlayerResponse()?.playabilityStatus?.status;if("LOGIN_REQUIRED"!==R&&"CONTENT_CHECK_REQUIRED"!==R||(C=o),C===t&&p.context?.client?.clientScreen!==s&&!p.params?.startsWith(i))return p.params=r,p.playerRequest&&p.playerRequest.params!==r&&(p.playerRequest.params=r),p.playbackContext&&p.playbackContext.params!==r&&(p.playbackContext.params=r),m.contentPlaybackContext.lactMilliseconds=String(Date.now()),b(),void x(p);if(C===a&&p.context?.client?.clientScreen!==s&&!p.params?.startsWith(i))return p.params!==l&&(p.params=l),p.playerRequest&&p.playerRequest.params!==l&&(p.playerRequest.params=l),p.playbackContext&&p.playbackContext.params!==l&&(p.playbackContext.params=l),p.playlistId||(p.context.client.clientScreen=s),m.contentPlaybackContext.lactMilliseconds=String(Date.now()),b(),void x(p);if(!(C!==e||p.context?.client?.clientScreen===s||m.params?.startsWith(r)&&m.params?.startsWith(l)))return m.adPlaybackContext={pyv:!0},m.contentPlaybackContext.lactMilliseconds=String(Date.now()),void x(p);if(C===n&&"WEB"===p.context?.client?.clientName)return p.context.client.clientScreen=s,m.contentPlaybackContext.lactMilliseconds=String(Date.now()),b(),void x(p);if(C===c)return m.adPlaybackContext={adType:"AD_TYPE_INSTREAM"},m.contentPlaybackContext.lactMilliseconds=String(Date.now()),b(),void x(p);if(C===o)return delete m.adPlaybackContext,void(()=>{try{Object.defineProperty(document,"visibilityState",d)}catch(e){}})()}catch(e){}},R=["playerErrorMessageRenderer","UNPLAYABLE"],k={apply:(r,l,i)=>{if(location.href.includes("/shorts/")||location.href.includes("youtube.com/tv")||location.href.includes("youtube.com/embed/")||p===o)return Reflect.apply(r,l,i);let s;try{if(s=Reflect.apply(r,l,i),!s.responseContext&&!s.playabilityStatus)return s;const y=m(s);return R.some((e=>y.includes(e)))&&!y.includes("CONTENT_CHECK_REQUIRED")?p===t?(f(a),s):p===a?(f(e),s):p===e?(f(n),s):p===n?(f(c),s):(f(o),s):(p===t&&s.playerConfig?.audioConfig?.muteOnStart&&(location.href.includes("/watch")||s.cards&&!s.playabilityStatus?.miniplayer)&&(delete s.playerConfig.audioConfig.muteOnStart,s.messages[0]?.youThereRenderer&&delete s.messages[0].youThereRenderer),p===c&&s.playerConfig?.granularVariableSpeedConfig&&(s.playerConfig.granularVariableSpeedConfig.maximumPlaybackRate=200,s.playerConfig.granularVariableSpeedConfig.minimumPlaybackRate=25),s)}catch(e){}return s}};window.JSON.parse=new Proxy(window.JSON.parse,k);const w={apply:(e,t,a)=>{if(location.href.includes("/shorts/")||location.href.includes("youtube.com/tv")||location.href.includes("youtube.com/embed/"))return Reflect.apply(e,t,a);try{let n=a[0];if(n&&(n.includes(\'"contentPlaybackContext"\')||n.includes(\'"adSignalsInfo"\'))){const c=JSON.parse(n);if(!c.context?.client)return Reflect.apply(e,t,a);c.playbackContext&&C(c,c.playbackContext,p),c.playerRequest&&C(c,c.playerRequest.playbackContext,p),n=m(c),a[0]=n}}catch(e){}return Reflect.apply(e,t,a)}};window.TextEncoder.prototype.encode=new Proxy(window.TextEncoder.prototype.encode,w);const g={apply:(e,t,a)=>{if(location.href.includes("/shorts/")||location.href.includes("youtube.com/tv")||location.href.includes("youtube.com/embed/"))return Reflect.apply(e,t,a);try{const n=a[0];if(!n?.context?.client)return Reflect.apply(e,t,a);n.playbackContext&&void 0===n.playbackContext.adPlaybackContext&&C(n,n.playbackContext,p),n.playerRequest&&void 0===n.playerRequest.playbackContext.adPlaybackContext&&C(n,n.playerRequest.playbackContext,p),a[0]=n}catch(e){}return Reflect.apply(e,t,a)}};window.JSON.stringify=new Proxy(window.JSON.stringify,g);const S={construct:(e,t,a)=>{try{const n=t[0];let c=t[1]?.body;if(!n?.includes("youtubei")||location.href.includes("/shorts/")||location.href.includes("youtube.com/tv")||location.href.includes("youtube.com/embed/")||!c)return Reflect.construct(e,t,a);if(c.includes(\'"contentPlaybackContext"\')||c.includes(\'"adSignalsInfo"\')){const n=JSON.parse(c);if(!n.context?.client)return Reflect.construct(e,t,a);n.playbackContext&&C(n,n.playbackContext,p),n.playerRequest&&C(n,n.playerRequest.playbackContext,p),c=m(n),t[1].body=c}}catch(e){}return Reflect.construct(e,t,a)}};window.Request=new Proxy(window.Request,S)})();',
    '(()=>{const e="movie_player",t="ytd-watch-flexy[player-unavailable]",r=`#${e} > .ytp-error`,n="yt-playability-error-supported-renderers#error-screen:has(>*)",a=\'yt-playability-error-supported-renderers#error-screen a[href^="//support.google.com/youtube/answer/2802245"]\',o="LOGIN_REQUIRED",i="CONTENT_CHECK_REQUIRED",l="pyv",c="param_first",s="param_second",y="client_screen",p="ad_type",d="none",u="eAFgAQ",m="8AUB",f="YAHI",b="CHANNEL",S=c;let v=S,x=null;const g=new Set,C=()=>{const t=document.getElementById(e),r=window.location.search,n=new URLSearchParams(r).get("v")||t?.getVideoData?.().video_id,a=new URLSearchParams(r).get("t")??"0";return{videoId:n,timeInSeconds:parseInt(a,10)}},R=()=>{q();const t=document.getElementById(e);if(t&&"function"==typeof t.loadVideoById)try{const{videoId:e,timeInSeconds:r}=C();t.loadVideoById(e,r)}catch(e){}},I=(()=>{let e=null,t=null,r=0;return n=>{try{if(!n)return!1;const{videoId:a}=C();return!!a&&(e===a&&t===n?r++:(e=a,t=n,r=1),r>=2&&(r=0,!0))}catch(e){return!1}}})(),P=e=>{v=e},h=Object.getOwnPropertyDescriptor(Document.prototype,"visibilityState"),k=()=>{try{Object.defineProperty(document,"visibilityState",{get:()=>"visible",configurable:!0})}catch(e){}},q=()=>{const r=document.getElementById(e),l=document.querySelector(n),c=document.querySelector("yt-playability-error-supported-renderers.ytdMiniplayerPlayerContainerPlayabilityError:has(>*)"),s=document.querySelector(t),y=document.querySelector(a);if(!r||y)return;const p=r.getPlayerResponse?.();p?.playabilityStatus?.status!==o&&p?.playabilityStatus?.status!==i?(s||c)&&(l?.style.setProperty("display","none","important"),c?.style.setProperty("display","none","important"),s?.removeAttribute("player-unavailable")):l?.style.setProperty("display","block","important")},w=e=>{(e.playbackContext||e.playerRequest)&&delete e.context?.client?.configInfo?.appInstallData},E=(e,t,r)=>{try{if(!e||!t||!r)return;if((e=>{const t=e?.videoId;t&&(x&&x!==t&&P(S),x=t)})(e),r===c&&e.context?.client?.clientScreen!==b&&!e.params?.startsWith(f))return e.params=u,e.playerRequest&&e.playerRequest.params!==u&&(e.playerRequest.params=u),e.playbackContext&&e.playbackContext.params!==u&&(e.playbackContext.params=u),t.contentPlaybackContext.lactMilliseconds=String(Date.now()),k(),void w(e);if(r===s&&e.context?.client?.clientScreen!==b&&!e.params?.startsWith(f))return e.params!==m&&(e.params=m),e.playerRequest&&e.playerRequest.params!==m&&(e.playerRequest.params=m),e.playbackContext&&e.playbackContext.params!==m&&(e.playbackContext.params=m),e.playlistId||(e.context.client.clientScreen=b),t.contentPlaybackContext.lactMilliseconds=String(Date.now()),k(),void w(e);if(!(r!==l||e.context?.client?.clientScreen===b||t.params?.startsWith(u)&&t.params?.startsWith(m)))return t.adPlaybackContext={pyv:!0},t.contentPlaybackContext.lactMilliseconds=String(Date.now()),k(),void w(e);if(r===y&&"WEB"===e.context?.client?.clientName)return e.context.client.clientScreen=b,t.contentPlaybackContext.lactMilliseconds=String(Date.now()),k(),void w(e);if(r===p)return t.adPlaybackContext={adType:"AD_TYPE_INSTREAM"},t.contentPlaybackContext.lactMilliseconds=String(Date.now()),k(),void w(e);if(r===d)return delete t.adPlaybackContext,void(()=>{try{Object.defineProperty(document,"visibilityState",h)}catch(e){}})()}catch(e){}};(()=>{const e={apply:(e,t,r)=>{try{let n=r[0];if(!n||location.href.includes("youtube.com/tv")||location.href.includes("youtube.com/embed/"))return Reflect.apply(e,t,r);const a=Array.isArray(n),o=a?n[0]:n;if("string"!=typeof o)return Reflect.apply(e,t,r);if(!o.includes(\'"contentPlaybackContext"\')&&!o.includes(\'"adSignalsInfo"\'))return Reflect.apply(e,t,r);const i=JSON.parse(o);if(!i.context?.client)return Reflect.apply(e,t,r);i.playbackContext&&E(i,i.playbackContext,v),i.playerRequest&&E(i,i.playerRequest.playbackContext,v);const l=JSON.stringify(i);a?r[0][0]=l:r[0]=l}catch(e){}return Reflect.apply(e,t,r)}};window.XMLHttpRequest.prototype.send=new Proxy(window.XMLHttpRequest.prototype.send,e)})();const D=document.documentElement;new MutationObserver((()=>{if(document.querySelector(n)&&q(),!(()=>{const l=document.getElementById(e),c=document.querySelector(r),s=document.querySelector(n),y=document.querySelector(t),p=document.querySelector(a);if(!l||p)return!1;const d=l.getPlayerResponse?.();if(d?.playabilityStatus?.status===o||d?.playabilityStatus?.status===i)return!1;const u=l.getVideoData?.();return(s||y||c)&&null!=u?.errorCode})())return;const{videoId:u}=C();(e=>{if(e)for(const t of g)t!==e&&g.delete(t)})(u),(()=>{if(v===c){if(!I(s))return void R();P(s),R()}else if(v===s){if(!I(l))return void R();P(l),R()}else if(v===l){if(!I(y))return void R();P(y),R()}else if(v===y){if(!I(p))return void R();P(p),R()}else if(v===p){if(!I(d))return void R();P(d),R()}else if(v===d){const{videoId:e}=C();if(!e||g.has(e))return void q();g.add(e),R()}})()})).observe(D,{attributes:!0,childList:!0,subtree:!0})})();',
    '(()=>{const e={apply:(e,r,t)=>{const n=t[0];if("string"==typeof n?.value&&n.value.includes("playerResponse"))try{n.value=(l=n.value,(location.href.includes("/watch")||l.includes("cards")&&!l.includes(\'"miniplayer"\'))&&l.includes(\'"muteOnStart":true\')&&(l=l.replace(\'"muteOnStart":true\',\'"muteOnStart":false\')).includes(\'"youThereRenderer":\')&&(l=l.replace(\'"youThereRenderer":\',\'"no_youThereRenderer":\')),l.replace(/"(adSlots|playerAds)":/g,\'"no_ads":\')),t[0]=n}catch(e){}var l;return Reflect.apply(e,r,t)}},r={apply:(r,t,n)=>{const l=n[0];return"function"==typeof l&&l.toString().includes(".next(")&&(n[0]=new Proxy(l,e)),Reflect.apply(r,t,n)}};window.Promise.prototype.then=new Proxy(window.Promise.prototype.then,r)})();',
    '(()=>{const e={apply:(e,t,o)=>{const n=Reflect.apply(e,t,o);if(n?.responseContext)try{delete n.adSlots,delete n.playerAds,n.playerConfig?.audioConfig?.muteOnStart&&(location.href.includes("/watch")||n.cards&&!n.playabilityStatus?.miniplayer)&&(delete n.playerConfig.audioConfig.muteOnStart,n.messages[0]?.youThereRenderer&&delete n.messages[0].youThereRenderer)}catch(e){}return n}},t={apply:(t,o,n)=>{const r=n[0];return"function"==typeof r&&r.toString().includes("jspbResponseCtor")&&(n[0]=new Proxy(r,e)),Reflect.apply(t,o,n)}};window.Promise.prototype.then=new Proxy(window.Promise.prototype.then,t)})();',
];

;// ./src/background/helpers/script-execute.ts
var script_execute_awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var script_execute_generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};





function injectedFunction(script, scriptId) {
    if (window[scriptId])
        return;
    var policy = window.trustedTypes.createPolicy('default', {
        createScript: function (input) { return input; },
    });
    var safeScriptContent = policy.createScript(script);
    window[scriptId] = true;
    var scriptTag = document.createElement('script');
    scriptTag.setAttribute('type', 'text/javascript');
    scriptTag.textContent = safeScriptContent;
    var parent = document.head || document.documentElement;
    parent.appendChild(scriptTag);
    parent.removeChild(scriptTag);
}
function executeScriptOnPage(tabId, script) {
    return script_execute_awaiter(this, void 0, void 0, function () {
        var injectionString, e_1;
        return script_execute_generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    injectionString = "(()=>{try {".concat(script, ";} catch (e) {console.log(e)}})();");
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 3, , 4]);
                    return [4, chrome.scripting.executeScript({
                            target: { tabId: tabId },
                            func: injectedFunction,
                            injectImmediately: true,
                            world: 'MAIN',
                            args: [injectionString, 'aby-38oj8EJVO3Uu7t4G9PdfI'],
                        })];
                case 2:
                    _a.sent();
                    return [3, 4];
                case 3:
                    e_1 = _a.sent();
                    if (false) {}
                    return [3, 4];
                case 4: return [2];
            }
        });
    });
}
var getScriptsAndInject = function (tabId) { return script_execute_awaiter(void 0, void 0, void 0, function () {
    var scriptlets, inlineScripts;
    return script_execute_generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                scriptlets = getScriptletString(Settings[SettingsKeys.ScripletsRules]);
                inlineScripts = inlineScriptsArray.join(';');
                return [4, executeScriptOnPage(tabId, scriptlets + inlineScripts)];
            case 1:
                _a.sent();
                return [2];
        }
    });
}); };
var cosmeticInject = function (tabId) { return script_execute_awaiter(void 0, void 0, void 0, function () {
    return script_execute_generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4, getScriptsAndInject(tabId)];
            case 1:
                _a.sent();
                return [4, getCssAndInject(tabId)];
            case 2:
                _a.sent();
                return [2];
        }
    });
}); };

;// ./src/background/helpers/process-open-tab.ts
var process_open_tab_awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var process_open_tab_generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var process_open_tab_values = (undefined && undefined.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};





var processOpenTab = function () { return process_open_tab_awaiter(void 0, void 0, void 0, function () {
    var allTabs, allTabs_1, allTabs_1_1, tab, e_1_1;
    var e_1, _a;
    return process_open_tab_generator(this, function (_b) {
        switch (_b.label) {
            case 0:
                if (!Settings[SettingsKeys.Ads])
                    return [2];
                return [4, getAllTabs()];
            case 1:
                allTabs = _b.sent();
                _b.label = 2;
            case 2:
                _b.trys.push([2, 7, 8, 9]);
                allTabs_1 = process_open_tab_values(allTabs), allTabs_1_1 = allTabs_1.next();
                _b.label = 3;
            case 3:
                if (!!allTabs_1_1.done) return [3, 6];
                tab = allTabs_1_1.value;
                if (!tab.id || !tab.url || !isAdBlockWorksOnPage(tab.url))
                    return [3, 5];
                return [4, cosmeticInject(tab.id)];
            case 4:
                _b.sent();
                _b.label = 5;
            case 5:
                allTabs_1_1 = allTabs_1.next();
                return [3, 3];
            case 6: return [3, 9];
            case 7:
                e_1_1 = _b.sent();
                e_1 = { error: e_1_1 };
                return [3, 9];
            case 8:
                try {
                    if (allTabs_1_1 && !allTabs_1_1.done && (_a = allTabs_1.return)) _a.call(allTabs_1);
                }
                finally { if (e_1) throw e_1.error; }
                return [7];
            case 9: return [2];
        }
    });
}); };

;// ./src/api/server-data.ts
var server_data_awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var server_data_generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};

var fetchServerData = function (signal) { return server_data_awaiter(void 0, void 0, void 0, function () {
    var response, e_1;
    return server_data_generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                _a.trys.push([0, 3, , 4]);
                return [4, fetch("".concat("https://api.adblock-for-youtube.com", "/api/v2/rules?version=").concat(EXTENSION_VERSION), { signal: signal })];
            case 1:
                response = _a.sent();
                return [4, response.json()];
            case 2: return [2, _a.sent()];
            case 3:
                e_1 = _a.sent();
                console.log(e_1);
                return [2, null];
            case 4: return [2];
        }
    });
}); };

;// ./src/background/helpers/update-settings-from-server.ts
var update_settings_from_server_assign = (undefined && undefined.__assign) || function () {
    update_settings_from_server_assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return update_settings_from_server_assign.apply(this, arguments);
};
var update_settings_from_server_awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var update_settings_from_server_generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};










var CONFIG_FETCH_ATTEMPTS = 3;
var CONFIG_FETCH_RETRY_DELAY_MS = 1000;
var CONFIG_FETCH_ATTEMPT_TIMEOUT_MS = 5000;
var RULES_FETCH_TTL_MS = 6 * 60 * 60 * 1000;
var update_settings_from_server_wait = function (ms) { return new Promise(function (resolve) { return setTimeout(resolve, ms); }); };
var fetchServerDataWithTimeout = function () { return update_settings_from_server_awaiter(void 0, void 0, void 0, function () {
    var controller, timeout;
    return update_settings_from_server_generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                controller = new AbortController();
                timeout = setTimeout(function () { return controller.abort(); }, CONFIG_FETCH_ATTEMPT_TIMEOUT_MS);
                _a.label = 1;
            case 1:
                _a.trys.push([1, , 3, 4]);
                return [4, fetchServerData(controller.signal)];
            case 2: return [2, _a.sent()];
            case 3:
                clearTimeout(timeout);
                return [7];
            case 4: return [2];
        }
    });
}); };
var fetchServerDataWithRetry = function () { return update_settings_from_server_awaiter(void 0, void 0, void 0, function () {
    var attempt, response;
    return update_settings_from_server_generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                attempt = 1;
                _a.label = 1;
            case 1:
                if (!(attempt <= CONFIG_FETCH_ATTEMPTS)) return [3, 5];
                return [4, fetchServerDataWithTimeout()];
            case 2:
                response = _a.sent();
                if (response) {
                    return [2, response];
                }
                if (!(attempt < CONFIG_FETCH_ATTEMPTS)) return [3, 4];
                return [4, update_settings_from_server_wait(CONFIG_FETCH_RETRY_DELAY_MS * attempt)];
            case 3:
                _a.sent();
                _a.label = 4;
            case 4:
                attempt += 1;
                return [3, 1];
            case 5: return [2, null];
        }
    });
}); };
var mergeAdLeakNoticeConfig = function (incoming) {
    if (!incoming || typeof incoming !== 'object') {
        return DefaultAdLeakNoticeConfig;
    }
    return update_settings_from_server_assign(update_settings_from_server_assign(update_settings_from_server_assign({}, DefaultAdLeakNoticeConfig), incoming), { detector: update_settings_from_server_assign(update_settings_from_server_assign({}, DefaultAdLeakNoticeConfig.detector), incoming.detector), frequency: update_settings_from_server_assign(update_settings_from_server_assign({}, DefaultAdLeakNoticeConfig.frequency), incoming.frequency), texts: update_settings_from_server_assign(update_settings_from_server_assign({}, DefaultAdLeakNoticeConfig.texts), incoming.texts) });
};
var updateSettingsFromServer = function () { return update_settings_from_server_awaiter(void 0, void 0, void 0, function () {
    var lastRulesFetchAt, msSinceLastFetch, isCacheFresh, isAppVersionChanged, response, networkRules, cssRules, popupConfig, scripletsRules, updatePageConfig, adLeakNotice, rulesVersion, data;
    var _a;
    return update_settings_from_server_generator(this, function (_b) {
        switch (_b.label) {
            case 0: return [4, getFromChromeStorage(ExtensionsKeys.LastRulesFetchAt)];
            case 1:
                lastRulesFetchAt = _b.sent();
                msSinceLastFetch = lastRulesFetchAt ? Date.now() - lastRulesFetchAt : Infinity;
                isCacheFresh = msSinceLastFetch >= 0 && msSinceLastFetch < RULES_FETCH_TTL_MS;
                isAppVersionChanged = getRuntimeInfo().isAppVersionChanged;
                if (isCacheFresh && !isAppVersionChanged) {
                    return [2];
                }
                return [4, fetchServerDataWithRetry()];
            case 2:
                response = _b.sent();
                if (!response)
                    return [2];
                networkRules = response.networkRules, cssRules = response.cssRules, popupConfig = response.popupConfig, scripletsRules = response.scripletsRules, updatePageConfig = response.updatePageConfig, adLeakNotice = response.adLeakNotice, rulesVersion = response.rulesVersion;
                data = (_a = {},
                    _a[SettingsKeys.ScripletsRules] = scripletsRules,
                    _a[SettingsKeys.CssRules] = cssRules,
                    _a[SettingsKeys.NetworkRules] = networkRules,
                    _a[SettingsKeys.RulesVersion] = Number.isInteger(rulesVersion) ? rulesVersion : null,
                    _a[SettingsKeys.PopupConfig] = popupConfig !== null && popupConfig !== void 0 ? popupConfig : DefaultPopupsConfig,
                    _a[SettingsKeys.AdLeakNoticeConfig] = mergeAdLeakNoticeConfig(adLeakNotice),
                    _a);
                return [4, setMultiplyToStorageAndSettings(data)];
            case 3:
                _b.sent();
                return [4, setToChromeStorage(ExtensionsKeys.LastRulesFetchAt, Date.now())];
            case 4:
                _b.sent();
                return [4, tryOpenUpdatePage(updatePageConfig)];
            case 5:
                _b.sent();
                return [2];
        }
    });
}); };
var tryOpenUpdatePage = function (updatePageConfig) { return update_settings_from_server_awaiter(void 0, void 0, void 0, function () {
    var shouldCheckUpdatePageConfig, informAboutUpdates, shouldShowForCurrentVersion, e_1;
    var _a;
    return update_settings_from_server_generator(this, function (_b) {
        switch (_b.label) {
            case 0:
                _b.trys.push([0, 6, , 7]);
                return [4, getFromChromeStorage(ExtensionsKeys.ShouldCheckUpdatePageConfig)];
            case 1:
                shouldCheckUpdatePageConfig = _b.sent();
                if (!shouldCheckUpdatePageConfig) {
                    return [2];
                }
                return [4, getFromChromeStorage(SettingsKeys.InformAboutUpdates)];
            case 2:
                informAboutUpdates = _b.sent();
                if (!(informAboutUpdates === false)) return [3, 4];
                return [4, setMultipleToChromeStorage((_a = {},
                        _a[ExtensionsKeys.ShouldCheckUpdatePageConfig] = false,
                        _a[ExtensionsKeys.UpdatePagePending] = false,
                        _a))];
            case 3:
                _b.sent();
                return [2];
            case 4:
                shouldShowForCurrentVersion = !!updatePageConfig[EXTENSION_VERSION];
                return [4, setToChromeStorage(ExtensionsKeys.UpdatePagePending, shouldShowForCurrentVersion)];
            case 5:
                _b.sent();
                return [3, 7];
            case 6:
                e_1 = _b.sent();
                console.error('arm pending update page failed:', e_1);
                return [3, 7];
            case 7: return [2];
        }
    });
}); };
var tryOpenPendingUpdatePage = function () { return update_settings_from_server_awaiter(void 0, void 0, void 0, function () {
    var updatePagePending, informAboutUpdates, e_2;
    var _a, _b;
    return update_settings_from_server_generator(this, function (_c) {
        switch (_c.label) {
            case 0: return [4, consumeStartupWake()];
            case 1:
                if (!(_c.sent())) {
                    return [2];
                }
                _c.label = 2;
            case 2:
                _c.trys.push([2, 9, , 10]);
                return [4, getFromChromeStorage(ExtensionsKeys.UpdatePagePending)];
            case 3:
                updatePagePending = _c.sent();
                if (!updatePagePending) {
                    return [2];
                }
                return [4, getFromChromeStorage(SettingsKeys.InformAboutUpdates)];
            case 4:
                informAboutUpdates = _c.sent();
                if (!(informAboutUpdates === false)) return [3, 6];
                return [4, setMultipleToChromeStorage((_a = {},
                        _a[ExtensionsKeys.UpdatePagePending] = false,
                        _a[ExtensionsKeys.ShouldCheckUpdatePageConfig] = false,
                        _a))];
            case 5:
                _c.sent();
                return [2];
            case 6: return [4, createTab(UPDATE_URL)];
            case 7:
                _c.sent();
                return [4, setMultipleToChromeStorage((_b = {},
                        _b[ExtensionsKeys.UpdatePagePending] = false,
                        _b[ExtensionsKeys.ShouldCheckUpdatePageConfig] = false,
                        _b))];
            case 8:
                _c.sent();
                return [3, 10];
            case 9:
                e_2 = _c.sent();
                console.error('open pending update page failed:', e_2);
                return [3, 10];
            case 10: return [2];
        }
    });
}); };

;// ./src/background/helpers/update-settings-from-storage.ts
var update_settings_from_storage_awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var update_settings_from_storage_generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var update_settings_from_storage_values = (undefined && undefined.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};



var updateSettingsFromStorage = function () { return update_settings_from_storage_awaiter(void 0, void 0, void 0, function () {
    var result, _a, _b, key;
    var e_1, _c;
    return update_settings_from_storage_generator(this, function (_d) {
        switch (_d.label) {
            case 0: return [4, getMultipleFromChromeStorage([
                    SettingsKeys.Ads,
                    SettingsKeys.InformAboutUpdates,
                    SettingsKeys.NetworkRules,
                    SettingsKeys.CssRules,
                    SettingsKeys.ScripletsRules,
                    SettingsKeys.PopupConfig,
                    SettingsKeys.AdLeakNotices,
                    SettingsKeys.AdLeakNoticeConfig,
                    SettingsKeys.RulesVersion,
                ])];
            case 1:
                result = _d.sent();
                try {
                    for (_a = update_settings_from_storage_values(Object.keys(result)), _b = _a.next(); !_b.done; _b = _a.next()) {
                        key = _b.value;
                        if (result[key] !== undefined) {
                            Settings[key] = result[key];
                        }
                    }
                }
                catch (e_1_1) { e_1 = { error: e_1_1 }; }
                finally {
                    try {
                        if (_b && !_b.done && (_c = _a.return)) _c.call(_a);
                    }
                    finally { if (e_1) throw e_1.error; }
                }
                return [2];
        }
    });
}); };

;// ./src/background/helpers/web-navigation.ts
var web_navigation_awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var web_navigation_generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};




var onCommitted = function (details) { return web_navigation_awaiter(void 0, void 0, void 0, function () {
    var tabId, url;
    return web_navigation_generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                tabId = details.tabId, url = details.url;
                if (!isAdBlockWorksOnPage(url) || !Settings[SettingsKeys.Ads]) {
                    return [2];
                }
                return [4, cosmeticInject(tabId)];
            case 1:
                _a.sent();
                return [2];
        }
    });
}); };
var webNavigation = function () {
    chrome.webNavigation.onCommitted.addListener(onCommitted);
};

;// ./src/background/helpers/web-request.ts
var web_request_awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var web_request_generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};




var onResponseStarted = function (details) { return web_request_awaiter(void 0, void 0, void 0, function () {
    var type, tabId, url;
    return web_request_generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (!Settings[SettingsKeys.Ads]) {
                    return [2];
                }
                type = details.type, tabId = details.tabId, url = details.url;
                if (!['main_frame', 'sub_frame'].includes(type)) {
                    return [2];
                }
                if (!tabId || !isAdBlockWorksOnPage(url)) {
                    return [2];
                }
                return [4, getScriptsAndInject(tabId)];
            case 1:
                _a.sent();
                return [2];
        }
    });
}); };
var webRequest = function () {
    chrome.webRequest.onResponseStarted.addListener(onResponseStarted, { urls: ['<all_urls>'] }, [
        'responseHeaders',
        'extraHeaders',
    ]);
};

;// ./src/background/index.ts
var background_awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var background_generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};














(function () { return background_awaiter(void 0, void 0, void 0, function () {
    return background_generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                listenMessages();
                return [4, handleExtensionLifecycleEvents()];
            case 1:
                _a.sent();
                return [4, runtimeInfoLifeCycle()];
            case 2:
                _a.sent();
                return [4, applyMigrations()];
            case 3:
                _a.sent();
                return [4, updateSettingsFromStorage()];
            case 4:
                _a.sent();
                listenStoreChanged();
                webRequest();
                webNavigation();
                return [4, updateDynamicRules()];
            case 5:
                _a.sent();
                return [4, updateActionIcon()];
            case 6:
                _a.sent();
                return [4, updateSettingsFromServer()];
            case 7:
                _a.sent();
                return [4, tryOpenPendingUpdatePage()];
            case 8:
                _a.sent();
                return [4, processOpenTab()];
            case 9:
                _a.sent();
                return [4, mainScheduler()];
            case 10:
                _a.sent();
                return [2];
        }
    });
}); })();

/******/ })()
;