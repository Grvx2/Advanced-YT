"use strict";

(() => {
  const PREFIX = "sponsorblock:";
  const nativeStorage = chrome.storage;
  const listeners = new Set();
  let moduleEnabled = true;
  let stateInitialized = false;

  function reportStorageError(message) {
    const error = chrome.runtime.lastError;
    if (error) console.error(`[SponsorBlock] ${message}:`, error.message);
    return error;
  }

  function updateModuleState(enabled) {
    const changed = stateInitialized && moduleEnabled !== enabled;
    const previous = moduleEnabled;
    moduleEnabled = enabled;
    stateInitialized = true;
    if (!changed) return;

    const change = {
      disableSkipping: {
        oldValue: !previous,
        newValue: !enabled,
      },
    };
    for (const listener of listeners) listener(change, "sync");
  }

  function refreshModuleState(callback) {
    nativeStorage.local.get({ sponsorBlockEnabled: true }, (localSettings) => {
      const localError = reportStorageError("Nie udało się odczytać przełącznika modułu");
      nativeStorage.sync.get({ aytGlobalEnabled: true }, (syncSettings) => {
        const syncError = reportStorageError("Nie udało się odczytać głównego przełącznika");
        if (localError || syncError) {
          callback(moduleEnabled);
          return;
        }
        const enabled = localSettings.sponsorBlockEnabled !== false
          && syncSettings.aytGlobalEnabled !== false;
        updateModuleState(enabled);
        callback(enabled);
      });
    });
  }

  function prefixKeys(keys) {
    if (keys === null || keys === undefined) return null;
    if (typeof keys === "string") return `${PREFIX}${keys}`;
    if (Array.isArray(keys)) return keys.map((key) => `${PREFIX}${key}`);
    if (typeof keys === "object") {
      return Object.fromEntries(Object.entries(keys).map(([key, value]) => [`${PREFIX}${key}`, value]));
    }
    return keys;
  }

  function unprefixValues(values, enabled) {
    const result = Object.fromEntries(Object.entries(values || {})
      .filter(([key]) => key.startsWith(PREFIX))
      .map(([key, value]) => [key.slice(PREFIX.length), value]));
    if (!enabled) result.disableSkipping = true;
    return result;
  }

  function createArea(areaName) {
    const area = nativeStorage[areaName];

    return {
      get(keys, callback) {
        if (typeof callback !== "function") {
          return new Promise((resolve) => this.get(keys, resolve));
        }
        refreshModuleState((enabled) => {
          area.get(prefixKeys(keys), (values) => {
            if (reportStorageError(`Nie udało się odczytać ustawień ${areaName}`)) {
              callback({});
              return;
            }
            callback(unprefixValues(values, enabled));
          });
        });
      },
      set(values, callback) {
        const prefixed = Object.fromEntries(Object.entries(values || {})
          .map(([key, value]) => [`${PREFIX}${key}`, value]));
        return area.set(prefixed, callback);
      },
      remove(keys, callback) {
        const prefixed = typeof keys === "string"
          ? `${PREFIX}${keys}`
          : Array.isArray(keys)
            ? keys.map((key) => `${PREFIX}${key}`)
            : keys;
        return area.remove(prefixed, callback);
      },
      clear(callback) {
        area.get(null, (values) => {
          if (reportStorageError(`Nie udało się wyczyścić ustawień ${areaName}`)) {
            callback?.();
            return;
          }
          const keys = Object.keys(values || {}).filter((key) => key.startsWith(PREFIX));
          if (!keys.length) {
            callback?.();
            return;
          }
          area.remove(keys, callback);
        });
      },
      getBytesInUse(keys, callback) {
        const prefixed = prefixKeys(keys);
        return area.getBytesInUse(prefixed, callback);
      },
    };
  }

  nativeStorage.onChanged.addListener((changes, areaName) => {
    const effectiveSettingChanged = areaName === "local"
      ? Object.hasOwn(changes, "sponsorBlockEnabled")
      : areaName === "sync" && Object.hasOwn(changes, "aytGlobalEnabled");
    if (effectiveSettingChanged) refreshModuleState(() => {});

    const namespacedChanges = Object.fromEntries(Object.entries(changes)
      .filter(([key]) => key.startsWith(PREFIX))
      .map(([key, change]) => {
        const name = key.slice(PREFIX.length);
        const effectiveChange = { ...change };
        if (name === "disableSkipping" && !moduleEnabled) effectiveChange.newValue = true;
        return [name, effectiveChange];
      }));
    if (Object.keys(namespacedChanges).length) {
      for (const listener of listeners) listener(namespacedChanges, areaName);
    }
  });

  const onChanged = Object.freeze({
    addListener(listener) {
      listeners.add(listener);
    },
    removeListener(listener) {
      listeners.delete(listener);
    },
    hasListener(listener) {
      return listeners.has(listener);
    },
    hasListeners() {
      return listeners.size > 0;
    },
  });

  globalThis.SponsorBlockStorage = Object.freeze({
    sync: createArea("sync"),
    local: createArea("local"),
    onChanged,
  });
  globalThis.SponsorBlockGetURL = (path) => {
    if (typeof path !== "string" || /^[a-z][a-z\d+.-]*:/i.test(path)) return path;
    const normalized = path.replace(/^\/+/, "");
    const resource = normalized.startsWith("modules/sponsorblock/")
      ? normalized
      : `modules/sponsorblock/${normalized}`;
    return chrome.runtime.getURL(resource);
  };
  globalThis.SponsorBlockContentScripts = [
    {
      all_frames: true,
      exclude_matches: ["https://accounts.youtube.com/RotateCookiesPage*"],
      matches: ["https://*.youtube.com/*", "https://www.youtube-nocookie.com/embed/*"],
      js: ["modules/sponsorblock/js/document.js"],
      run_at: "document_start",
      world: "MAIN",
    },
    {
      all_frames: true,
      exclude_matches: ["https://accounts.youtube.com/RotateCookiesPage*"],
      matches: ["https://*.youtube.com/*", "https://www.youtube-nocookie.com/embed/*"],
      css: ["modules/sponsorblock/content.css", "modules/sponsorblock/shared.css"],
      js: [
        "modules/sponsorblock/js/storage-namespace.js",
        "modules/sponsorblock/js/content.js",
      ],
      run_at: "document_start",
    },
  ];
  globalThis.SponsorBlockManifest = Object.freeze({
    version: "6.1.6",
  });
})();
