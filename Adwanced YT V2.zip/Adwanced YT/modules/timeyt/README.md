# TimeYT — moduł Advanced YT

Moduł MV3 rozszerzenia Advanced YT dla Opery GX i Chromium. Co sekundę zapisuje lokalnie rzeczywisty czas oglądania, czas przesunięcia filmu, datę, godzinę, film, kanał oraz kategorię filmu.

## Instalacja i przeniesienie danych

1. Otwórz `opera://extensions`.
2. Włącz tryb deweloperski.
3. Wybierz **Załaduj rozpakowane** i wskaż główny folder `Adwanced YT`, nie podfolder `modules/timeyt`.
4. Przed zastąpieniem wcześniejszej, osobno zainstalowanej wersji TimeYT wyeksportuj z niej historię do JSON. Nowe połączenie ma inny identyfikator rozszerzenia, więc przeglądarka nie udostępni mu automatycznie poprzedniej bazy IndexedDB.
5. Otwórz panel TimeYT z ikony na pasku YouTube, zaimportuj JSON i sprawdź historię. Dopiero potem można usunąć starą instalację TimeYT.

## Dane i prywatność

- Historia, wygląd i własna ikonka są przechowywane w IndexedDB lokalnego profilu rozszerzenia. Nie są zapisywane do plików instalacyjnych rozszerzenia ani wysyłane do chmury.
- Obraz ikonki jest przechowywany w jednej oryginalnej kopii w lokalnej bazie IndexedDB. Rozmiar jest dopasowywany przy wyświetlaniu, bez ponownego zapisywania skompresowanego rastra; animowany GIF zachowuje animację. Usunięcie pliku źródłowego z komputera nie usuwa ikony z rozszerzenia.
- Wybrany format obrazu (PNG, JPEG, WebP lub GIF), przezroczystość i proporcje obrazu są zachowywane. Plik może mieć maksymalnie 4 MB.
- Zwykłe zamknięcie przeglądarki nie usuwa danych. Odinstalowanie rozszerzenia albo wyczyszczenie profilu może je usunąć, dlatego przed tym warto użyć eksportu historii.
- Rzeczywisty czas oglądania i czas filmu są zapisywane jako osobne sumy. Czas filmu wynika ze zmiany `currentTime` odtwarzacza, więc odzwierciedla prędkość widoczną dla YouTube (również zmienioną przez inne rozszerzenie); przy x2 przez minutę wartości wynoszą około 60 s i 120 s. Po włączeniu tej opcji czas filmu pokazuje się przy głównym liczniku, podsumowaniach typów i wpisach historii.
- Przy kilku równocześnie odtwarzających kartach wspólna blokada w lokalnej bazie przydziela rzeczywisty czas tylko jednej z nich. Czas filmu nadal sumuje postęp ze wszystkich kart, więc może rosnąć szybciej niż czas rzeczywisty. Blokada jest zwalniana po zatrzymaniu filmu lub zamknięciu karty; po awarii wygasa automatycznie.
- Rozszerzenie nie korzysta z kont, synchronizacji, Google Drive ani zewnętrznego serwera historii. Miniatury są pobierane z YouTube podczas wyświetlania.

## Wykres i wygląd

- **Dzień**, **Tydzień** i **Miesiąc** pokazują maksymalnie 10 dni, 7 tygodni lub 12 miesięcy, kończąc na aktualnym okresie. Po wyłączeniu ukrywania pustych okresów zakres pokazuje zawsze pełne 10/7/12 słupków, także przed rozpoczęciem zbierania danych. Kółkiem przesuwa się o jeden okres na obrót, a kliknięcie słupka zaznacza go bez niepotrzebnego przestawiania widocznego zakresu.
- Wybór daty w górnym pasku jest dostępny w widoku Dzień. W widoku All kalendarz służy do ustawiania zakresu wykresu: lewy klik wybiera początek (fioletowy), prawy klik koniec (różowy), a dni pomiędzy nimi są cieniowane gradientem. Daty poza zakresem są blokowane dla niepasującego końca; punkty odpowiadają tylko datom z zapisanymi danymi. Tydzień i Miesiąc korzystają z nawigacji wykresu bez kalendarza.
- Słupki mają wspólną linię podstawy we wszystkich zakresach; szerokość toru słupka wykorzystuje większą część miejsca danej kolumny, bez zwiększania wysokości panelu wykresu.
- Opisy dni tygodnia można ustawić jako pełne lub skrócone i wybrać wielkość liter. Domyślnie poniedziałek jest skrócony, aby etykiety mieściły się w jednym wierszu. Bieżący tydzień podaje liczbę dni, które już do niego należą.
- Kolory sezonowe są używane tylko na wykresie miesięcznym. Każdy zakres ma niezależny sposób skalowania słupków: maksimum w widocznym zakresie, maksimum od początku historii albo własną liczbę godzin dla 100%. Wartości nad słupkami pokazują czas i procent skali; wypełnienie zatrzymuje się na 100%.
- Tydzień jest liczony od poniedziałku do niedzieli.
- W formacie czasu można zawsze ukryć sekundy albo wyświetlać je tylko przed przekroczeniem ustawionego progu godzin.
- **All** pokazuje dzienny czas oglądania na wykresie liniowym od początku zbierania danych do dziś; punkty z zapisami są oznaczone, także gdy historia obejmuje tylko jeden dzień. Linie pomocnicze i podpisy osi X dopasowują się do zakresu (dni, tygodnie, miesiące lub lata). Nowe punkty są odświeżane najwyżej co 10 minut, aby podpowiedzi nie migały. Kółkiem myszy albo przyciskami można przybliżać i oddalać widok.
- Przełącznik ukrywania okresów wcześniejszych niż początek zbierania danych jest domyślnie włączony.
- Ustawienia są podzielone na kategorie. Można w nich włączyć osobny czas filmu przy wpisach historii, zmienić etykiety i skale wykresu oraz motyw lub harmonogram jasnego i ciemnego wariantu.
- W kategorii „Ikona YouTube” można ustawić opóźnienie pojawienia się przycisku rozszerzenia od 0 do 2000 ms, co 100 ms. Tryb „Bez ograniczeń” zastępuje suwaki polami całkowitych wartości dla opóźnienia, wysokości i przesunięć.
- Wykresy Dzień/Tydzień/Miesiąc wybiera się kliknięciem słupka. Bieżący okres jest zaznaczony domyślnie bez obramowania; wybrany okres historyczny ma czarną ramkę. Kółko i przeciąganie przesuwają wykres po okresach, nie dalej niż do dziś; przy ukrywaniu okresów pustych przewijanie zaczyna się od daty rozpoczęcia śledzenia, a puste dni późniejsze nadal są widoczne.
- Ustawienia wykresów pozwalają wybrać liczbę filmów/kanałów przewijanych jednym ruchem kółka oraz liczbę jednocześnie widocznych wpisów. Lista przewija się płynnie, zawsze przyciąga pełne wpisy, a nieinteraktywny wskaźnik po prawej pokazuje pozycję. Panel rozszerza się w pionie stosownie do wybranej liczby wpisów.
- Ikony pod wykresem filtrują historię po filmach, shortach lub transmisjach na żywo. Kliknięcie aktywnego filtra pokazuje wszystkie typy; ustawienie „Domyślny filtr historii” wybiera zachowanie przy następnym otwarciu panelu.
- W historii kliknięcie licznika wpisów po prawej stronie nagłówka przełącza sortowanie. Filmy mogą być sortowane według czasu oglądania albo od najnowszych; kanały według czasu oglądania albo liczby unikalnych obejrzanych filmów. Po zatrzymaniu kursora na liczniku przez 2,5 sekundy wyświetla się informacja o aktywnym sortowaniu. Ustawienie w kategorii Wykresy określa, czy ostatnie sortowanie ma być zapamiętywane po ponownym otwarciu.
- Rozmiar własnej ikonki YouTube w zwykłym trybie określa jej maksymalną wysokość (8–60 px), a proporcje obrazu są zachowane i rozmiar jest ponownie dopasowywany po załadowaniu grafiki. Przycisk rezerwuje stałe miejsce w pasku, więc zmiana skali nie przesuwa wyszukiwarki. Bardzo panoramiczne obrazy są dopasowywane do tego miejsca. W trybie „Bez ograniczeń” własne wartości wysokości i przesunięć są stosowane bez standardowego limitu suwaków.
- W bieżącym miesiącu pod słupkiem pojawia się etykieta „Obecny” i numer dnia miesiąca, np. „Obecny 17”. Etykiety wykresu są oddzielone od torów słupków i mają większą czcionkę.
- Format czasu można ustawić jako zawsze pokazujący sekundy, ukrywający sekundy albo pokazujący je tylko poniżej progu. Pole progu jest dostępne wyłącznie dla ostatniego wariantu. Sposób skalowania słupków można wybierać przyciskami w czarno-białym układzie.
- Dla każdej skali „Widoczny” można włączyć stałą bazę odniesienia z ostatnich 10 dni, 7 tygodni lub 12 miesięcy. Dzięki temu przewijanie nie zmienia punktu odniesienia; wartości ponad bazę są opisane procentami większymi niż 100%, choć wysokość słupka nadal jest ograniczona do panelu.
- Liczba widocznych filmów/kanałów wynosi od 3 do 7; oba ustawienia przewijania historii można zmieniać kółkiem myszy nad polem wyboru. Popup dopasowuje wysokość do liczby rzeczywistych wpisów, a przy krótszej liście nie pozostawia pustego miejsca na brakujące pozycje.
- Przycisk ikony YouTube zachowuje ten sam element podczas nawigacji YouTube i przebudowy paska, więc nie znika na czas ponownego wstawiania.
- Przełącznik „Timer Oglądania” w popupie Advanced YT włącza lub wyłącza cały moduł lokalnie; jego osobne ustawienie kontroluje wyłącznie widoczność ikonki na pasku YouTube.
- Advanced YT ukrywa wyłącznie pytanie YouTube „Film nie odtwarza się płynnie?” (oraz jego angielską wersję), nie pozostałe powiadomienia.
- Eksport/import ustawień Advanced YT obejmuje ustawienia TimeYT z IndexedDB, ale nie kopiuje historii (filmy, sesje, statystyki ani pozycje odtwarzania).
- Kółko nad wykresem przewija zakres lub zmienia przybliżenie All; nad historią przewija listę. W pozostałej części panelu przewijanie nie trafia do strony YouTube. Panel osadzony nie zasłania całej strony, więc kliknięcia i interakcje poza jego prostokątem nadal działają.

Eksport zapisuje historię do pliku JSON, nie zmieniając danych w profilu. Import akceptuje plik JSON tego rozszerzenia oraz starsze pliki zawierające tablicę wpisów w polu `videos`, `history` lub `records` (albo samą tablicę). Wpisy są walidowane przed zapisem; uszkodzony lub nieobsługiwany rekord przerywa import bez częściowego zapisu. Import łączy dane z istniejącą historią, nie kasuje bieżących wpisów, a w przypadku nakładających się identycznych przedziałów zachowuje większą wartość, żeby ponowne wczytanie tego samego eksportu nie podwajało czasu. Po imporcie aktualizuje się początek historii.
