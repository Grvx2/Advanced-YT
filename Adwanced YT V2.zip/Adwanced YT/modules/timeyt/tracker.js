"use strict";

(() => {
  const MESSAGE_SOURCE = "vtm-local-video-metadata";
  const SESSION_ID = crypto.randomUUID();
  const metadataByVideo = new Map();
  const pendingMessages = [];
  let sequence = 0;
  let pendingSeconds = 0;
  let pendingMediaSeconds = 0;
  let currentMetadata = null;
  let previousVideoTime = null;
  let previousSampleTime = null;
  let lastSeekAt = -Infinity;
  const seekListeners = new WeakSet();
  let drainInProgress = false;
  let lastSaveError = "";
  let playbackWasActive = false;
  let extensionEnabled = false;
  let globalEnabled = false;

  function dateAndHour(timestamp) {
    const date = new Date(timestamp);
    return {
      date: `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`,
      hour: date.getHours(),
    };
  }

  function fallbackMetadata(videoId) {
    const title = document.title.replace(/\s+-\s+YouTube\s*$/, "").trim();
    const channelAnchor = document.querySelector(
      "ytd-watch-metadata ytd-channel-name a, ytd-video-owner-renderer a, ytd-channel-name a",
    );
    const channelLink = channelAnchor?.href ?? "";
    const channelId = /\/channel\/([^/?]+)/.exec(channelLink)?.[1] ?? "";
    const channelUrl = /^https:\/\/(?:www\.)?youtube\.com\/(?:channel\/[\w-]+|@[\w.-]+|c\/[\w.-]+|user\/[\w.-]+)\/?$/.test(channelLink)
      ? channelLink
      : "";
    const channelAvatar = document.querySelector(
      "ytd-watch-metadata #avatar img, ytd-video-owner-renderer #avatar img, ytd-channel-name img, #owner #avatar img",
    );
    const channelIconUrl = channelAvatar?.getAttribute("srcset")
      ?.split(",")
      .map((candidate) => candidate.trim().split(/\s+/)[0])
      .filter(Boolean)
      .at(-1)
      || channelAvatar?.currentSrc
      || channelAvatar?.src
      || "";
    const isShort = location.pathname.startsWith("/shorts/");
    return {
      videoId,
      title: title.slice(0, 300),
      channelName: (channelAnchor?.textContent ?? "").trim().slice(0, 200),
      channelId,
      channelUrl,
      channelIconUrl,
      videoType: isShort ? "short" : "video",
      durationSeconds: 0,
    };
  }

  function getCurrentVideoId() {
    const url = new URL(location.href);
    if (url.pathname === "/watch") return url.searchParams.get("v");
    return /^\/(?:shorts|live|embed)\/([^/?]+)/.exec(url.pathname)?.[1] ?? null;
  }

  function getMetadata(videoId) {
    return { ...fallbackMetadata(videoId), ...metadataByVideo.get(videoId) };
  }

  function flushPending() {
    if (!currentMetadata || pendingSeconds <= 0) return;
    const seconds = Math.round(pendingSeconds * 100) / 100;
    const mediaSeconds = Math.round(pendingMediaSeconds * 100) / 100;
    pendingSeconds = 0;
    pendingMediaSeconds = 0;
    pendingMessages.push({
      type: "vtm:watch-event",
      event: {
        ...currentMetadata,
        ...dateAndHour(Date.now()),
        seconds,
        mediaSeconds,
        sessionId: SESSION_ID,
        sequence: ++sequence,
      },
    });
    void drainQueue();
  }

  async function drainQueue() {
    if (drainInProgress || !chrome.runtime?.id) return;
    drainInProgress = true;
    try {
      while (pendingMessages.length > 0) {
        const response = await chrome.runtime.sendMessage(pendingMessages[0]);
        if (!response?.ok) {
          const message = response?.error ?? "Brak potwierdzenia zapisu.";
          if (message !== lastSaveError) {
            console.error("[VTM Local] Zapis lokalny nie powiódł się:", message);
            lastSaveError = message;
          }
          break;
        }
        lastSaveError = "";
        pendingMessages.shift();
      }
    } catch (error) {
      if (error.message !== lastSaveError) {
        console.error("[VTM Local] Nie można skontaktować się z lokalnym magazynem:", error);
        lastSaveError = error.message;
      }
    } finally {
      drainInProgress = false;
    }
  }

  function releasePlayback() {
    if (!playbackWasActive) return;
    playbackWasActive = false;
    pendingMessages.push({ type: "vtm:release-playback" });
    void drainQueue();
  }

  function samplePlayback() {
    const now = performance.now();
    if (!extensionEnabled || !globalEnabled) {
      flushPending();
      releasePlayback();
      currentMetadata = null;
      previousVideoTime = null;
      previousSampleTime = null;
      return;
    }

    const video = document.querySelector("video");
    const videoId = getCurrentVideoId();
    if (video && !seekListeners.has(video)) {
      seekListeners.add(video);
      video.addEventListener("seeking", () => { lastSeekAt = performance.now(); });
      video.addEventListener("seeked", () => { lastSeekAt = performance.now(); });
    }
    if (videoId && !metadataByVideo.has(videoId)) {
      window.postMessage({ source: MESSAGE_SOURCE, type: "request" }, location.origin);
    }
    const playing = video
      && !video.paused
      && !video.ended
      && video.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA
      && videoId;

    if (!playing) {
      flushPending();
      releasePlayback();
      currentMetadata = videoId ? getMetadata(videoId) : null;
      previousVideoTime = null;
      previousSampleTime = null;
      return;
    }

    playbackWasActive = true;
    if (!currentMetadata || currentMetadata.videoId !== videoId) {
      flushPending();
      currentMetadata = getMetadata(videoId);
      previousVideoTime = video.currentTime;
      previousSampleTime = now;
      return;
    }

    const elapsedSeconds = Math.max(0, (now - previousSampleTime) / 1000);
    const playbackProgress = video.currentTime - previousVideoTime;
    const playbackRate = Number.isFinite(video.playbackRate) && video.playbackRate > 0
      ? video.playbackRate
      : 1;
    const maximumObservedRate = Math.max(16, playbackRate);
    const plausibleProgress = playbackProgress > 0.05
      && playbackProgress <= elapsedSeconds * maximumObservedRate + 1
      && !video.seeking
      && now - lastSeekAt > 1_000;
    if (plausibleProgress && elapsedSeconds <= 15 && !isAdvertisement()) {
      pendingSeconds += elapsedSeconds;
      pendingMediaSeconds += playbackProgress;
    }
    previousVideoTime = video.currentTime;
    previousSampleTime = now;

    if (pendingSeconds >= 0.5) flushPending();
  }

  function isAdvertisement() {
    return Boolean(document.querySelector(
      "#movie_player.ad-showing, #movie_player .ytp-ad-player-overlay-layout",
    ));
  }

  window.addEventListener("message", (event) => {
    if (event.source !== window || event.origin !== location.origin
      || event.data?.source !== MESSAGE_SOURCE) return;
    const metadata = event.data.metadata;
    if (!metadata || typeof metadata.videoId !== "string"
      || !/^[\w-]{6,20}$/.test(metadata.videoId)) return;
    metadataByVideo.set(metadata.videoId, metadata);
    if (metadataByVideo.size > 100) {
      metadataByVideo.delete(metadataByVideo.keys().next().value);
    }
    if (currentMetadata?.videoId === metadata.videoId) {
      currentMetadata = { ...fallbackMetadata(metadata.videoId), ...metadata };
    }
  });
  window.postMessage({ source: MESSAGE_SOURCE, type: "request" }, location.origin);

  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden") flushPending();
  });
  window.addEventListener("pagehide", () => {
    flushPending();
    releasePlayback();
  });
  chrome.storage.local.get({ vtmEnabled: true }, (settings) => {
    if (chrome.runtime.lastError) {
      console.error("[VTM Local] Nie udało się odczytać stanu modułu:", chrome.runtime.lastError.message);
      return;
    }
    extensionEnabled = settings.vtmEnabled !== false;
  });
  chrome.storage.sync.get({ aytGlobalEnabled: true }, (settings) => {
    if (chrome.runtime.lastError) {
      console.error("[VTM Local] Nie udało się odczytać stanu Advanced YT:", chrome.runtime.lastError.message);
      return;
    }
    globalEnabled = settings.aytGlobalEnabled !== false;
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    const change = area === "local" ? changes.vtmEnabled
      : area === "sync" ? changes.aytGlobalEnabled
        : null;
    if (!change) return;
    const enabled = change.newValue !== false;
    if (!enabled) {
      flushPending();
      void drainQueue();
      releasePlayback();
    }
    if (area === "local") extensionEnabled = enabled;
    else globalEnabled = enabled;
  });
  window.setInterval(() => {
    samplePlayback();
    void drainQueue();
  }, 1000);
})();
