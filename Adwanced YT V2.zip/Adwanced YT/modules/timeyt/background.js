"use strict";

function localDateKey(date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

chrome.runtime.onInstalled.addListener(() => {
  Promise.all([
    VtmStorage.getSetting("tracking-start-date", ""),
    VtmStorage.getFirstHistoryDate(),
  ]).then(async ([savedStart, firstRecord]) => {
    const startDate = [savedStart, firstRecord].filter(Boolean).sort()[0] || localDateKey(new Date());
    await VtmStorage.setSetting("tracking-start-date", startDate);
  }).catch((error) => {
    console.error("[VTM Local] Nie udało się zapisać początku zbierania danych:", error);
  });
});

chrome.tabs.onRemoved.addListener((tabId) => {
  VtmStorage.releasePlaybackOwner(tabId).catch((error) => {
    console.warn("[VTM Local] Nie udało się zwolnić aktywnej karty śledzenia:", error);
  });
});

async function broadcastButtonSettings() {
  const [image, scale, offset, offsetX, delay, unlimited, enabled] = await Promise.all([
    getPersistentButtonImage(),
    getPersistentButtonSetting("youtube-button-scale", "vtmButtonScale", 24),
    VtmStorage.getSetting("youtube-button-offset", 0),
    VtmStorage.getSetting("youtube-button-offset-x", 0),
    VtmStorage.getSetting("youtube-button-delay", 0),
    getPersistentButtonSetting("youtube-button-unlimited", "vtmButtonUnlimited", false),
    getButtonEnabled(),
  ]);
  const tabs = await chrome.tabs.query({
    url: ["https://www.youtube.com/*", "https://music.youtube.com/*"],
  });
  await Promise.all(tabs.filter((tab) => tab.id !== undefined).map(async (tab) => {
    try {
      await chrome.tabs.sendMessage(tab.id, {
        type: "vtm:button-settings",
        settings: { image, scale, offset, offsetX, delay, unlimited, enabled },
      });
    } catch (error) {
      console.warn("[VTM Local] Nie udało się zaktualizować ikonki na karcie:", error);
    }
  }));
}

async function getPersistentButtonSetting(databaseKey, localKey, fallback) {
  const [databaseValue, localValues] = await Promise.all([
    VtmStorage.getSetting(databaseKey, null),
    new Promise((resolve, reject) => {
      chrome.storage.local.get([localKey], (values) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        resolve(values);
      });
    }),
  ]);
  if (databaseValue !== null && databaseValue !== undefined) return databaseValue;
  const cachedValue = localValues[localKey];
  return cachedValue !== null && cachedValue !== undefined ? cachedValue : fallback;
}

async function getPersistentButtonImage() {
  let cachedImage = "";
  let cacheReadError;
  try {
    const settings = await new Promise((resolve, reject) => {
      chrome.storage.local.get({ vtmButtonImage: "" }, (values) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        resolve(values);
      });
    });
    cachedImage = typeof settings.vtmButtonImage === "string" ? settings.vtmButtonImage : "";
  } catch (error) {
    cacheReadError = error;
  }

  let databaseImage = "";
  let databaseReadError;
  try {
    databaseImage = await VtmStorage.getSetting("youtube-button-image", "");
  } catch (error) {
    databaseReadError = error;
  }

  const isSupportedImage = (image) => typeof image === "string"
    && /^data:image\/(?:png|jpeg|webp|gif);base64,/i.test(image);
  if (isSupportedImage(databaseImage)) {
    if (cacheReadError) {
      console.warn("[VTM Local] Nie udało się odczytać szybkiej kopii ikonki:", cacheReadError);
    } else if (cachedImage !== databaseImage) {
      try {
        await new Promise((resolve, reject) => {
          chrome.storage.local.set({ vtmButtonImage: databaseImage }, () => {
            if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
            else resolve();
          });
        });
      } catch (error) {
        console.warn("[VTM Local] Ikonka jest zapisana w bazie, ale nie udało się odświeżyć jej szybkiej kopii:", error);
      }
    }
    return databaseImage;
  }

  if (isSupportedImage(cachedImage)) {
    if (databaseReadError) {
      console.error("[VTM Local] Nie udało się odczytać ikonki z bazy; używam zapisanej kopii:", databaseReadError);
    } else {
      try {
        await VtmStorage.setSetting("youtube-button-image", cachedImage);
      } catch (error) {
        console.warn("[VTM Local] Nie udało się przywrócić ikonki do bazy; używam zapisanej kopii:", error);
      }
    }
    return cachedImage;
  }

  if (databaseReadError) {
    console.error("[VTM Local] Nie udało się odczytać ikonki z bazy TimeYT:", databaseReadError);
    throw databaseReadError;
  }
  if (cacheReadError) {
    console.error("[VTM Local] Nie udało się odczytać szybkiej kopii ikonki TimeYT:", cacheReadError);
    throw cacheReadError;
  }
  return "";
}

function getButtonEnabled() {
  return Promise.all([
    new Promise((resolve, reject) => {
      chrome.storage.local.get({ vtmButtonEnabled: true, vtmEnabled: true }, (settings) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        resolve(settings.vtmButtonEnabled !== false && settings.vtmEnabled !== false);
      });
    }),
    new Promise((resolve, reject) => {
      chrome.storage.sync.get({ aytGlobalEnabled: true }, (settings) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        resolve(settings.aytGlobalEnabled !== false);
      });
    }),
  ]).then(([moduleEnabled, globalEnabled]) => moduleEnabled && globalEnabled);
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && !changes.vtmButtonEnabled && !changes.vtmEnabled) return;
  if (area === "sync" && !changes.aytGlobalEnabled) return;
  broadcastButtonSettings().catch((error) => {
    console.error("[VTM Local] Nie udało się zmienić widoczności ikonki YouTube:", error);
  });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "vtm:get-button-settings") {
    Promise.all([
      getPersistentButtonImage(),
      getPersistentButtonSetting("youtube-button-scale", "vtmButtonScale", 24),
      VtmStorage.getSetting("youtube-button-offset", 0),
      VtmStorage.getSetting("youtube-button-offset-x", 0),
      VtmStorage.getSetting("youtube-button-delay", 0),
      getPersistentButtonSetting("youtube-button-unlimited", "vtmButtonUnlimited", false),
      getButtonEnabled(),
    ]).then(([image, scale, offset, offsetX, delay, unlimited, enabled]) => {
      sendResponse({ ok: true, settings: { image, scale, offset, offsetX, delay, unlimited, enabled } });
    }).catch((error) => {
      console.error("[VTM Local] Nie udało się odczytać ustawień ikonki:", error);
      sendResponse({ ok: false, error: error.message });
    });
    return true;
  }

  if (message?.type === "vtm:open-dashboard") {
    const pageUrl = sender.url ?? sender.tab?.url ?? "";
    if (!/^https:\/\/(?:www|music)\.youtube\.com\//.test(pageUrl) || sender.tab?.id === undefined) {
      sendResponse({ ok: false, error: "Przycisk pulpitu jest dostępny na stronach YouTube." });
      return false;
    }
    chrome.tabs.sendMessage(sender.tab.id, { type: "vtm:toggle-dashboard" })
      .then(() => sendResponse({ ok: true }))
      .catch((error) => {
        console.error("[VTM Local] Nie udało się otworzyć pulpitu na stronie YouTube:", error);
        sendResponse({ ok: false, error: error.message });
      });
    return true;
  }

  if (message?.type === "vtm:button-settings-changed") {
    broadcastButtonSettings()
      .then(() => sendResponse({ ok: true }))
      .catch((error) => {
        console.error("[VTM Local] Nie udało się zaktualizować ikonki YouTube:", error);
        sendResponse({ ok: false, error: error.message });
      });
    return true;
  }

  if (message?.type === "vtm:watch-event") {
    const pageUrl = sender.url ?? sender.tab?.url ?? "";
    if (!/^https:\/\/(?:www|music)\.youtube\.com\//.test(pageUrl)) {
      sendResponse({ ok: false, error: "Zapis dozwolony jest tylko dla stron YouTube." });
      return false;
    }

    VtmStorage.saveWatchEvent(message.event, sender.tab?.id ?? null)
      .then(({ seconds, duplicate }) => {
        const savedEvent = { ...message.event, seconds };
        if (!duplicate) chrome.runtime.sendMessage({ type: "vtm:history-changed", event: savedEvent }).catch((error) => {
          console.warn("[VTM Local] Nie udało się powiadomić pulpitu o nowym zapisie:", error);
        });
        sendResponse({ ok: true });
      })
      .catch((error) => {
        console.error("[VTM Local] Nie udało się zapisać czasu oglądania:", error);
        sendResponse({ ok: false, error: error.message });
      });
    return true;
  }

  if (message?.type === "vtm:release-playback") {
    const pageUrl = sender.url ?? sender.tab?.url ?? "";
    if (!/^https:\/\/(?:www|music)\.youtube\.com\//.test(pageUrl)
      || sender.tab?.id === undefined) {
      sendResponse({ ok: false, error: "Zwolnienie blokady jest dozwolone tylko dla kart YouTube." });
      return false;
    }
    VtmStorage.releasePlaybackOwner(sender.tab.id)
      .then((released) => sendResponse({ ok: true, released }))
      .catch((error) => {
        console.error("[VTM Local] Nie udało się zwolnić blokady czasu oglądania:", error);
        sendResponse({ ok: false, error: error.message });
      });
    return true;
  }

  return false;
});
