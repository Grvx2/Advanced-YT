"use strict";

(() => {
  const MESSAGE_SOURCE = "vtm-local-video-metadata";
  let lastSignature = "";

  function getPlayerResponse() {
    const player = document.getElementById("movie_player");
    const response = player?.getPlayerResponse?.()
      ?? window.ytInitialPlayerResponse
      ?? window.ytplayer?.config?.args?.player_response;
    if (typeof response === "string") {
      try {
        return JSON.parse(response);
      } catch {
        return null;
      }
    }
    return response && typeof response === "object" ? response : null;
  }

  function getCurrentVideoId() {
    const url = new URL(location.href);
    if (url.pathname === "/watch") return url.searchParams.get("v");
    const match = /^\/(?:shorts|live|embed)\/([^/?]+)/.exec(url.pathname);
    return match?.[1] ?? null;
  }

  function getChannelIconUrl() {
    const avatar = document.querySelector(
      "ytd-watch-metadata #avatar img, ytd-video-owner-renderer #avatar img, ytd-channel-name img, #owner #avatar img",
    );
    const candidates = (avatar?.getAttribute("srcset") ?? "")
      .split(",")
      .map((candidate) => candidate.trim().split(/\s+/)[0])
      .filter(Boolean);
    const preferred = candidates.at(-1) || avatar?.currentSrc || avatar?.src || "";
    return /^https:\/\/(?:yt3\.ggpht\.com|yt3\.googleusercontent\.com)\//.test(preferred)
      ? preferred.slice(0, 1000)
      : "";
  }

  function publishMetadata(force = false) {
    const response = getPlayerResponse();
    const details = response?.videoDetails;
    const videoId = getCurrentVideoId() || details?.videoId;
    if (!videoId || !details) return;

    const microformat = response?.microformat?.playerMicroformatRenderer;
    const path = location.pathname;
    const isLive = details.isLiveContent === true
      || Boolean(microformat?.liveBroadcastDetails?.isLiveNow)
      || path.startsWith("/live/");
    const videoType = path.startsWith("/shorts/")
      ? "short"
      : isLive ? "live" : "video";
    const channelIconUrl = getChannelIconUrl();
    const metadata = {
      videoId,
      title: String(details.title ?? microformat?.title?.simpleText ?? "").slice(0, 300),
      channelName: String(details.author ?? microformat?.ownerChannelName ?? "").slice(0, 200),
      channelId: String(details.channelId ?? "").slice(0, 100),
      ...(typeof microformat?.ownerProfileUrl === "string"
        ? { channelUrl: microformat.ownerProfileUrl.slice(0, 500) }
        : {}),
      ...(channelIconUrl ? { channelIconUrl } : {}),
      videoType,
      durationSeconds: Number(details.lengthSeconds) || 0,
    };
    const signature = JSON.stringify(metadata);
    if (signature === lastSignature && !force) return;
    lastSignature = signature;
    window.postMessage({ source: MESSAGE_SOURCE, metadata }, location.origin);
  }

  window.addEventListener("message", (event) => {
    if (event.source === window && event.origin === location.origin
      && event.data?.source === MESSAGE_SOURCE && event.data?.type === "request") {
      publishMetadata(true);
    }
  });

  publishMetadata();
  window.setInterval(publishMetadata, 750);
})();
