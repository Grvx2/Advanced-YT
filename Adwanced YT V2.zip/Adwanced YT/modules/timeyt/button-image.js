"use strict";

(() => {
  async function validateDataUrl(dataUrl) {
    if (typeof dataUrl !== "string"
      || !/^data:image\/(?:png|jpeg|webp|gif);base64,/i.test(dataUrl)) {
      throw new Error("Wybierz prawidłowy obraz PNG, JPEG, WebP lub GIF.");
    }

    const image = new Image();
    await new Promise((resolve, reject) => {
      image.onload = resolve;
      image.onerror = () => reject(new Error("Nie można odczytać wybranego obrazu."));
      image.src = dataUrl;
      if (image.complete && image.naturalWidth > 0) resolve();
    });
    if (image.naturalWidth < 1 || image.naturalHeight < 1) {
      throw new Error("Wybrany obraz nie zawiera prawidłowej grafiki.");
    }
    return { width: image.naturalWidth, height: image.naturalHeight };
  }

  globalThis.VtmButtonImage = Object.freeze({ validateDataUrl });
})();
