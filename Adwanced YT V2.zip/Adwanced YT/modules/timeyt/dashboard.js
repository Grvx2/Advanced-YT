"use strict";

(() => {
  const PERIODS = ["day", "week", "month", "year"];
  const EMBEDDED = new URLSearchParams(location.search).has("embedded");
  const state = {
    period: "day",
    offset: 0,
    selectedDate: new Date(),
    view: "videos",
    videoSort: "time",
    channelSort: "time",
    historyTypeFilter: "video",
    sortPersistence: "default",
    rows: [],
    allHistory: [],
    allHistoryLoaded: false,
    historyRangeKey: "",
    rendering: false,
    renderQueued: false,
    firstDate: null,
    hideUntracked: true,
    showMediaTime: false,
    durationFormat: "smart",
    durationSecondsThreshold: 1,
    weekdayLabelStyle: "monday-short-title",
    chartScales: {
      day: { mode: "visible", hours: 8 },
      week: { mode: "visible", hours: 40 },
      month: { mode: "visible", hours: 160 },
    },
    allChartCompact: true,
    chartFixedWindow: { day: true, week: true, month: true },
    calendarOffset: 0,
    calendarOpen: false,
    allRangeStart: "",
    allRangeEnd: "",
    buttonIconDelay: 0,
    buttonIconUnlimited: false,
    historyWheelRows: 2,
    historyVisibleRows: 5,
    historyScrollTarget: 0,
    historyScrollFrame: 0,
    historyWheelRemainder: 0,
    historyResetOnNextRender: false,
    historySortTooltipTimer: 0,
    chartWheelRemainder: 0,
    chartWheelBusy: false,
    lastAllChartRenderAt: 0,
    allChartRefreshTimer: 0,
    allChartDirty: true,
    draggingChart: false,
    dragStartX: 0,
    dragDeltaX: 0,
    dragColumnWidth: 0,
    allZoom: 1,
  };
  const $ = (selector) => document.querySelector(selector);
  if (EMBEDDED) document.body.dataset.embedded = "true";

  function dateKey(date) {
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
  }

  function startOfPeriod(date, period) {
    const result = new Date(date);
    if (period === "week") result.setDate(result.getDate() - ((result.getDay() + 6) % 7));
    if (period === "month") result.setDate(1);
    if (period === "year") {
      result.setDate(1);
      result.setMonth(0);
    }
    return result;
  }

  function shiftPeriod(date, period, amount) {
    const result = new Date(date);
    if (period === "day") result.setDate(result.getDate() + amount);
    if (period === "week") result.setDate(result.getDate() + amount * 7);
    if (period === "month") result.setMonth(result.getMonth() + amount);
    return result;
  }

  function periodCount() {
    return state.period === "day" ? 10 : state.period === "week" ? 7 : 12;
  }

  function periodKey(date, period = state.period) {
    return dateKey(startOfPeriod(date, period));
  }

  function allPeriodKeys(period = state.period) {
    if (period === "year") return [];
    const anchor = startOfPeriod(new Date(), period);
    const anchorKey = dateKey(anchor);
    if (state.hideUntracked) {
      const firstTracked = state.firstDate
        ? startOfPeriod(new Date(`${state.firstDate}T12:00:00`), period)
        : anchor;
      const keys = [];
      for (let current = firstTracked; dateKey(current) <= anchorKey; current = shiftPeriod(current, period, 1)) {
        keys.push(dateKey(current));
      }
      return keys;
    }

    const firstTracked = state.firstDate
      ? startOfPeriod(new Date(`${state.firstDate}T12:00:00`), period)
      : anchor;
    const periodsBeforeAnchor = period === "month"
      ? (anchor.getFullYear() - firstTracked.getFullYear()) * 12 + anchor.getMonth() - firstTracked.getMonth()
      : Math.floor((Date.UTC(anchor.getFullYear(), anchor.getMonth(), anchor.getDate())
        - Date.UTC(firstTracked.getFullYear(), firstTracked.getMonth(), firstTracked.getDate()))
        / 86_400_000 / (period === "week" ? 7 : 1));
    const first = shiftPeriod(anchor, period, -(Math.max(0, periodsBeforeAnchor) + periodCount() - 1));
    const keys = [];
    for (let current = first; dateKey(current) <= anchorKey; current = shiftPeriod(current, period, 1)) keys.push(dateKey(current));
    return keys;
  }

  function maximumOffset() {
    if (state.period === "year") return 0;
    const keys = allPeriodKeys();
    return Math.max(0, keys.length - periodCount());
  }

  function offsetToIncludePeriod(index) {
    const keys = allPeriodKeys();
    if (index < 0 || index >= keys.length) return 0;
    const minimum = Math.max(0, keys.length - index - periodCount());
    const maximum = Math.max(0, keys.length - index - 1);
    return Math.max(minimum, Math.min(maximum, state.offset));
  }

  function maximumAllZoom() {
    const first = new Date(`${state.allRangeStart || state.firstDate || dateKey(new Date())}T12:00:00`);
    const last = new Date(`${state.allRangeEnd || dateKey(new Date())}T12:00:00`);
    const totalDays = Math.max(1, Math.round((last - first) / 86_400_000) + 1);
    return Math.max(1, Math.ceil(totalDays / 14));
  }

  function anchorPeriodStart() {
    if (state.hideUntracked) {
      const keys = allPeriodKeys();
      return keys.length
        ? new Date(`${keys[Math.max(0, keys.length - 1 - state.offset)]}T12:00:00`)
        : startOfPeriod(state.selectedDate, state.period);
    }
    return shiftPeriod(startOfPeriod(new Date(), state.period), state.period, -state.offset);
  }

  function endOfPeriod(start, period) {
    if (period === "week") return shiftPeriod(start, "day", 6);
    if (period === "month") return new Date(start.getFullYear(), start.getMonth() + 1, 0);
    return new Date(start);
  }

  function rangeForPeriod() {
    if (state.period === "year") {
      const firstYear = state.firstDate ? Number(state.firstDate.slice(0, 4)) : new Date().getFullYear();
      return {
        date: new Date(),
        start: new Date(firstYear, 0, 1),
        end: new Date(new Date().getFullYear(), 11, 31),
      };
    }
    const selected = startOfPeriod(state.selectedDate, state.period);
    return { date: selected, start: selected, end: endOfPeriod(selected, state.period) };
  }

  function formatDuration(seconds) {
    const total = Math.max(0, Math.round(seconds));
    const hours = Math.floor(total / 3600);
    const minutes = Math.floor((total % 3600) / 60);
    const showSeconds = state.durationFormat === "always-seconds"
      || (state.durationFormat === "smart" && total < state.durationSecondsThreshold * 3600);
    const secondsPart = showSeconds ? ` ${total % 60} s` : "";
    if (hours) return `${hours} godz. ${String(minutes).padStart(2, "0")} min${secondsPart}`;
    if (minutes) return `${minutes} min${secondsPart}`;
    return showSeconds ? `${total} s` : "0 min";
  }

  function setPeriod(period) {
    if (!PERIODS.includes(period)) return;
    state.period = period;
    state.allChartDirty = true;
    state.offset = 0;
    state.selectedDate = new Date();
    state.calendarOffset = 0;
    closeCalendar();
    void render();
  }

  function closeCalendar() {
    state.calendarOpen = false;
    $("#calendar-popover").hidden = true;
    $("#date-picker").setAttribute("aria-expanded", "false");
  }

  function calendarButtonLabel() {
    if (state.period === "year") {
      return `${calendarDateLabel(state.allRangeStart)} – ${calendarDateLabel(state.allRangeEnd)}`;
    }
    const selectedPeriod = state.selectedDate;
    const date = state.period === "week" ? startOfPeriod(selectedPeriod, "week") : selectedPeriod;
    if (state.period === "month") {
      return date.toLocaleDateString("pl-PL", { month: "short", year: "numeric" });
    }
    if (state.period === "week") {
      const end = shiftPeriod(date, "day", 6);
      return `${date.toLocaleDateString("pl-PL", { day: "2-digit", month: "2-digit" })}–${end.toLocaleDateString("pl-PL", { day: "2-digit", month: "2-digit", year: "2-digit" })}`;
    }
    return date.toLocaleDateString("pl-PL", { day: "2-digit", month: "2-digit", year: "numeric" });
  }

  function calendarDateLabel(key) {
    if (!key) return "";
    return `${key.slice(8, 10)}.${key.slice(5, 7)}.${key.slice(0, 4)}r`;
  }

  function renderAllCalendar(today) {
    const grid = $("#calendar-grid");
    grid.replaceChildren();
    const month = new Date(today.getFullYear(), today.getMonth() - state.calendarOffset, 1);
    const firstDay = startOfPeriod(month, "week");
    firstDay.setHours(12, 0, 0, 0);
    const lastDay = shiftPeriod(firstDay, "day", 41);
    $("#calendar-title").textContent = month.toLocaleDateString("pl-PL", { month: "long", year: "numeric" });
    grid.className = "calendar-grid calendar-day-grid all-calendar-grid";
    for (const label of ["Pn", "Wt", "Śr", "Cz", "Pt", "Sb", "Nd"]) {
      const weekday = document.createElement("span");
      weekday.className = "calendar-weekday";
      weekday.textContent = label;
      grid.append(weekday);
    }
    const firstTime = new Date(`${state.allRangeStart}T12:00:00`).getTime();
    const lastTime = new Date(`${state.allRangeEnd}T12:00:00`).getTime();
    for (let index = 0; index < 42; index += 1) {
      const date = shiftPeriod(firstDay, "day", index);
      const key = dateKey(date);
      const time = date.getTime();
      const future = time > today.getTime();
      const beforeStart = time < firstTime;
      const afterEnd = time > lastTime;
      const cell = document.createElement("button");
      cell.type = "button";
      cell.className = "calendar-day";
      cell.textContent = String(date.getDate());
      cell.dataset.date = key;
      cell.disabled = future;
      cell.classList.toggle("outside-month", date.getMonth() !== month.getMonth());
      cell.classList.toggle("range-before-start", beforeStart);
      cell.classList.toggle("range-start", key === state.allRangeStart);
      cell.classList.toggle("range-end", key === state.allRangeEnd);
      if (time > firstTime && time < lastTime) {
        const span = Math.max(1, lastTime - firstTime);
        const progress = Math.min(1, Math.max(0, (time - firstTime) / span));
        const start = [126, 78, 181];
        const end = [225, 110, 169];
        const color = start.map((component, channel) =>
          Math.round(component + (end[channel] - component) * progress));
        cell.classList.add("range-between");
        cell.style.setProperty("--range-color", `rgb(${color.join(" ")})`);
      }
      cell.title = `${calendarDateLabel(key)}${key === state.allRangeStart ? " · Początek" : ""}${key === state.allRangeEnd ? " · Koniec" : ""}`;
      cell.addEventListener("click", () => {
        if (time > lastTime) return;
        state.allRangeStart = key;
        state.calendarOffset = Math.max(0,
          (new Date(`${dateKey(today)}T12:00:00`).getFullYear() - date.getFullYear()) * 12
          + today.getMonth() - date.getMonth());
        $("#date-picker").textContent = calendarButtonLabel();
        state.allZoom = 1;
        renderAllTimeChart(state.rows);
        renderAllCalendar(today);
      });
      cell.addEventListener("contextmenu", (event) => {
        event.preventDefault();
        if (time < firstTime) return;
        state.allRangeEnd = key;
        state.calendarOffset = Math.max(0,
          (new Date(`${dateKey(today)}T12:00:00`).getFullYear() - date.getFullYear()) * 12
          + today.getMonth() - date.getMonth());
        $("#date-picker").textContent = calendarButtonLabel();
        state.allZoom = 1;
        renderAllTimeChart(state.rows);
        renderAllCalendar(today);
      });
      grid.append(cell);
    }
  }

  function renderCalendar() {
    const grid = $("#calendar-grid");
    const today = new Date();
    today.setHours(12, 0, 0, 0);
    const trackedDays = new Set(state.allHistory.map((row) => row.date));
    const trackedWeeks = new Set([...trackedDays].map((key) => periodKey(new Date(`${key}T12:00:00`), "week")));
    const trackedMonths = new Set([...trackedDays].map((key) => key.slice(0, 7)));
    const hiddenFilter = state.hideUntracked;
    grid.replaceChildren();
    $("#calendar-forward").disabled = state.calendarOffset === 0;

    if (state.period === "year") {
      renderAllCalendar(today);
      return;
    }

    if (state.period === "month") {
      const currentMonth = new Date(today.getFullYear(), today.getMonth() - state.calendarOffset * 12, 1);
      $("#calendar-title").textContent = currentMonth.toLocaleDateString("pl-PL", { year: "numeric" });
      grid.className = "calendar-grid calendar-month-grid";
      const months = [];
      for (let index = 11; index >= 0; index -= 1) {
        const month = new Date(currentMonth.getFullYear(), currentMonth.getMonth() - index, 1);
        const key = `${month.getFullYear()}-${String(month.getMonth() + 1).padStart(2, "0")}`;
        if (!hiddenFilter || trackedMonths.has(key)) months.push({ month, key });
      }
      for (const { month, key } of months) {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "calendar-month";
        const monthName = month.toLocaleDateString("pl-PL", { month: "long" });
        button.textContent = month.getFullYear() === currentMonth.getFullYear()
          ? monthName
          : `${monthName} ${month.getFullYear()}`;
        button.disabled = month > new Date(today.getFullYear(), today.getMonth(), 1);
        button.classList.toggle("selected", key === dateKey(startOfPeriod(state.selectedDate, "month")).slice(0, 7));
        button.addEventListener("click", () => {
          state.selectedDate = month;
          state.offset = 0;
          state.calendarOffset = 0;
          closeCalendar();
          void render();
        });
        grid.append(button);
      }
      return;
    }

    const pageEnd = new Date(today);
    pageEnd.setDate(pageEnd.getDate() - state.calendarOffset * 42);
    const endOfWeek = startOfPeriod(pageEnd, "week");
    endOfWeek.setDate(endOfWeek.getDate() + 6);
    const firstDay = new Date(endOfWeek);
    firstDay.setDate(firstDay.getDate() - 41);
    firstDay.setHours(12, 0, 0, 0);
    const lastDay = new Date(endOfWeek);
    lastDay.setHours(12, 0, 0, 0);
    $("#calendar-title").textContent = `${firstDay.toLocaleDateString("pl-PL", { day: "numeric", month: "short" })} – ${lastDay.toLocaleDateString("pl-PL", { day: "numeric", month: "short", year: "numeric" })}`;
    grid.className = "calendar-grid calendar-day-grid";
    for (const label of ["Pn", "Wt", "Śr", "Cz", "Pt", "Sb", "Nd"]) {
      const weekday = document.createElement("span");
      weekday.className = "calendar-weekday";
      weekday.textContent = label;
      grid.append(weekday);
    }
    const rowDays = Array.from({ length: 6 }, (_, weekIndex) => {
      const monday = new Date(firstDay);
      monday.setDate(monday.getDate() + weekIndex * 7);
      const weekKey = dateKey(monday);
      return { monday, weekKey, days: Array.from({ length: 7 }, (_, dayIndex) => {
        const date = new Date(monday);
        date.setDate(date.getDate() + dayIndex);
        return date;
      }) };
    }).filter((week) => !hiddenFilter || (state.period === "week"
      ? trackedWeeks.has(week.weekKey)
      : week.days.some((date) => trackedDays.has(dateKey(date)))));

    for (const { weekKey, days } of rowDays) {
      for (const date of days) {
        const key = dateKey(date);
        const future = date > today;
        const hasData = trackedDays.has(key);
        const button = document.createElement("button");
        button.type = "button";
        button.className = "calendar-day";
        button.textContent = String(date.getDate());
        button.dataset.date = key;
        button.disabled = future || (hiddenFilter && !hasData);
        button.classList.toggle("outside-month", date.getMonth() !== days[3].getMonth());
        button.classList.toggle("is-untracked", hiddenFilter && !hasData && state.period !== "week");
        button.classList.toggle("selected", state.period === "week"
          ? weekKey === periodKey(state.selectedDate, "week")
          : key === dateKey(state.selectedDate));
        button.dataset.week = weekKey;
        button.addEventListener("pointerenter", () => {
          if (state.period !== "week") return;
          grid.querySelectorAll(".calendar-day").forEach((cell) =>
            cell.classList.toggle("week-hover", cell.dataset.week === weekKey));
        });
        button.addEventListener("click", () => {
          state.selectedDate = date;
          const keys = allPeriodKeys();
          const selectedKey = periodKey(date, state.period);
          const selectedIndex = keys.indexOf(selectedKey);
          state.offset = offsetToIncludePeriod(selectedIndex);
          state.calendarOffset = 0;
          closeCalendar();
          void render();
        });
        grid.append(button);
      }
    }
  }

  function weekdayLabel(date) {
    const full = date.toLocaleDateString("pl-PL", { weekday: "long" });
    const short = ["pon", "wt", "śr", "czw", "pt", "sob", "niedz"][(date.getDay() + 6) % 7];
    const style = state.weekdayLabelStyle;
    const upperFirst = (text) => text[0].toLocaleUpperCase("pl") + text.slice(1);
    if (style.startsWith("monday-short") && date.getDay() === 1) {
      if (style.endsWith("upper")) return short.toLocaleUpperCase("pl");
      if (style.endsWith("title")) return upperFirst(short);
      return short;
    }
    if (style === "full-title") return upperFirst(full);
    if (style === "short-title") return upperFirst(short);
    if (style === "short-upper") return short.toLocaleUpperCase("pl");
    if (style === "short-lower") return short;
    return full;
  }

  function makeChartData() {
    const keys = allPeriodKeys();
    const end = keys.length - state.offset;
    const visibleKeys = keys.slice(Math.max(0, end - periodCount()), end);
    const secondsByKey = new Map();
    for (const row of state.allHistory) {
      const key = periodKey(new Date(`${row.date}T12:00:00`));
      secondsByKey.set(key, (secondsByKey.get(key) || 0) + row.seconds);
    }
    return visibleKeys.map((key) => {
      const bucketStart = new Date(`${key}T12:00:00`);
      const bucketEnd = endOfPeriod(bucketStart, state.period);
      const currentWeek = state.period === "week" && key === periodKey(new Date(), "week");
      let label = "";
      if (state.period === "day") {
        label = key === dateKey(new Date()) ? "Dziś" : weekdayLabel(bucketStart);
      } else if (state.period === "week") {
        const endLabel = bucketEnd.toLocaleDateString("pl-PL", { day: "numeric", month: "short" });
        const weekDayCount = Math.min(7, ((new Date().getDay() + 6) % 7) + 1);
        label = currentWeek
          ? `Obecny ${weekDayCount}`
          : `${bucketStart.toLocaleDateString("pl-PL", { day: "numeric", month: "short" })}–${endLabel}`;
      } else {
        label = key === periodKey(new Date(), "month") ? `Obecny ${new Date().getDate()}` : "";
      }
      return {
        key,
        start: key,
        end: dateKey(bucketEnd),
        label,
        seconds: secondsByKey.get(key) || 0,
        selected: key === periodKey(state.selectedDate),
      };
    });
  }

  async function slideChartToOffset(nextOffset, startingTransform = null) {
    const chart = $("#chart");
    const direction = Math.sign(nextOffset - state.offset);
    if (!direction) return;
    const columnWidth = chart.clientWidth / Math.max(1, chart.children.length);
    chart.style.transition = "none";
    chart.style.transform = startingTransform ?? `translateX(${direction * columnWidth}px)`;
    void chart.offsetWidth;
    state.offset = nextOffset;
    state.selectedDate = anchorPeriodStart();
    await render();
    requestAnimationFrame(() => {
      const updatedChart = $("#chart");
      updatedChart.style.transition = "transform .16s ease";
      updatedChart.style.transform = "translateX(0)";
      setTimeout(() => {
        updatedChart.style.transition = "";
        updatedChart.style.transform = "";
      }, 180);
    });
  }

  function groupRows(rows) {
    const grouped = new Map();
    for (const row of rows) {
      const key = state.view === "videos"
        ? row.videoId
        : row.channelId || row.channelName || "unknown-channel";
      const current = grouped.get(key) ?? {
        key,
        title: state.view === "videos" ? row.title || "Nieznany film" : row.channelName || "Nieznany kanał",
        subtitle: state.view === "videos" ? row.channelName || "YouTube" : "",
        seconds: 0,
        mediaSeconds: 0,
        latestHour: row.hour,
        videos: new Set(),
        newest: row.date,
        videoId: row.videoId,
        channelId: row.channelId,
        channelUrl: row.channelUrl,
        channelIconUrl: row.channelIconUrl,
      };
      current.seconds += row.seconds;
      current.mediaSeconds += row.mediaSeconds ?? row.seconds;
      current.videos.add(row.videoId);
      if (row.date > current.newest || (row.date === current.newest && row.hour > current.latestHour)) {
        current.newest = row.date;
        current.latestHour = row.hour;
      }
      if (state.view === "videos" && row.title) current.title = row.title;
      if (state.view === "videos" && row.channelName) current.subtitle = row.channelName;
      if (state.view === "channels" && row.channelName) current.title = row.channelName;
      if (row.date > current.newest || (row.date === current.newest && row.hour >= current.latestHour)) {
        current.videoId = row.videoId;
        current.channelId = row.channelId || current.channelId;
        current.channelUrl = row.channelUrl || current.channelUrl;
        current.channelIconUrl = row.channelIconUrl || current.channelIconUrl;
      }
      grouped.set(key, current);
    }
    const sortMode = state.view === "videos" ? state.videoSort : state.channelSort;
    return [...grouped.values()].sort((a, b) => {
      if (state.view === "videos" && sortMode === "recent") {
        return b.newest.localeCompare(a.newest) || b.latestHour - a.latestHour || b.seconds - a.seconds;
      }
      if (state.view === "channels" && sortMode === "videos") {
        return b.videos.size - a.videos.size || b.seconds - a.seconds;
      }
      return b.seconds - a.seconds || b.newest.localeCompare(a.newest);
    });
  }

  function mergeHistoryRow(row) {
    const index = state.allHistory.findIndex((current) =>
      current.date === row.date && current.hour === row.hour && current.videoId === row.videoId);
    if (index === -1) state.allHistory.push(row);
    else state.allHistory[index] = row;
  }

  function mergeHistoryEvent(event) {
    if (!event || typeof event.videoId !== "string" || typeof event.date !== "string") return;
    const index = state.allHistory.findIndex((row) =>
      row.date === event.date && row.hour === event.hour && row.videoId === event.videoId);
    if (index === -1) {
      state.allHistory.push({
        ...event,
        mediaSeconds: event.mediaSeconds ?? event.seconds,
        url: `https://www.youtube.com/watch?v=${encodeURIComponent(event.videoId)}`,
      });
      return;
    }
    const previous = state.allHistory[index];
    state.allHistory[index] = {
      ...previous,
      ...event,
      title: event.title || previous.title,
      channelId: event.channelId || previous.channelId,
      channelName: event.channelName || previous.channelName,
      channelUrl: event.channelUrl || previous.channelUrl,
      channelIconUrl: event.channelIconUrl || previous.channelIconUrl,
      seconds: previous.seconds + event.seconds,
      mediaSeconds: (previous.mediaSeconds ?? previous.seconds) + (event.mediaSeconds ?? event.seconds),
    };
  }

  function renderHistory(rows) {
    const query = $("#search").value.trim().toLocaleLowerCase("pl");
    const filteredRows = state.historyTypeFilter
      ? rows.filter((row) => (row.videoType || "video") === state.historyTypeFilter)
      : rows;
    const items = groupRows(filteredRows).filter((item) => `${item.title} ${item.subtitle}`.toLocaleLowerCase("pl").includes(query));
    $("#result-count").textContent = `${items.length}`;
    updateHistorySortControl();
    const list = $("#history-list");
    const shouldResetScroll = state.historyResetOnNextRender;
    state.historyResetOnNextRender = false;
    const previousTop = shouldResetScroll ? 0 : list.scrollTop;
    const listTop = list.getBoundingClientRect().top;
    const firstVisibleRow = shouldResetScroll ? null : [...list.querySelectorAll(".history-row")]
      .find((row) => row.getBoundingClientRect().bottom > listTop + 1);
    const anchorKey = firstVisibleRow?.dataset.itemKey;
    if (state.historyScrollFrame) cancelAnimationFrame(state.historyScrollFrame);
    state.historyScrollFrame = 0;
    list.scrollTop = previousTop;
    list.replaceChildren();
    const restoreScrollPosition = () => {
      const anchor = anchorKey
        ? [...list.querySelectorAll(".history-row")].find((row) => row.dataset.itemKey === anchorKey)
        : null;
      list.scrollTop = anchor
        ? Math.max(0, anchor.getBoundingClientRect().top - list.getBoundingClientRect().top + list.scrollTop)
        : Math.min(previousTop, Math.max(0, list.scrollHeight - list.clientHeight));
      state.historyScrollTarget = list.scrollTop;
      updateHistoryScrollIndicator();
    };
    if (items.length === 0) {
      const empty = document.createElement("p");
      empty.className = "empty-state";
      empty.textContent = query
        ? "Nie znaleziono pasujących wpisów."
        : filteredRows.length === 0
          ? state.historyTypeFilter
            ? "Brak zapisanej historii dla wybranego typu."
            : "Brak zapisanej historii w tym zakresie."
          : "Nie znaleziono pasujących wpisów.";
      list.append(empty);
      requestAnimationFrame(restoreScrollPosition);
      resizePopupToHistory();
      return;
    }
    for (const [itemIndex, item] of items.entries()) {
      const row = document.createElement("article");
      row.className = "history-row";
      row.dataset.itemKey = item.key;
      const imageLink = document.createElement("a");
      imageLink.className = "history-image-link";
      imageLink.href = state.view === "videos"
        ? `https://www.youtube.com/watch?v=${encodeURIComponent(item.videoId)}`
        : item.channelUrl
          ? item.channelUrl
          : item.channelId
          ? `https://www.youtube.com/channel/${encodeURIComponent(item.channelId)}`
          : `https://www.youtube.com/results?search_query=${encodeURIComponent(item.title)}`;
      imageLink.target = "_blank";
      imageLink.rel = "noopener noreferrer";
      imageLink.title = state.view === "videos" ? "Otwórz film w nowej karcie" : "Otwórz kanał w nowej karcie";
      if (state.view === "videos") {
        const image = document.createElement("img");
        image.className = "history-image video-thumbnail";
        image.src = `https://i.ytimg.com/vi/${encodeURIComponent(item.videoId)}/mqdefault.jpg`;
        image.alt = "";
        image.loading = itemIndex < 8 ? "eager" : "lazy";
        image.decoding = "async";
        image.fetchPriority = itemIndex < 4 ? "high" : "auto";
        image.addEventListener("error", () => {
          image.replaceWith(makeVideoFallback());
        }, { once: true });
        imageLink.append(image);
      } else if (item.channelIconUrl) {
        const image = document.createElement("img");
        image.className = "history-image channel-thumbnail";
        image.src = item.channelIconUrl;
        image.alt = "";
        image.loading = itemIndex < 8 ? "eager" : "lazy";
        image.decoding = "async";
        image.fetchPriority = itemIndex < 4 ? "high" : "auto";
        image.addEventListener("error", () => {
          image.replaceWith(makeChannelFallback());
        }, { once: true });
        imageLink.append(image);
      } else {
        imageLink.append(makeChannelFallback());
      }
      const details = document.createElement("div");
      details.className = "history-details";
      const title = document.createElement("div");
      title.className = "row-title";
      title.textContent = item.title;
      const subtitle = document.createElement("div");
      subtitle.className = "row-subtitle";
      subtitle.textContent = state.view === "videos"
        ? `${item.subtitle} · ${new Date(`${item.newest}T12:00:00`).toLocaleDateString("pl-PL")}`
        : `${item.videos.size} ${item.videos.size === 1 ? "film" : "filmów"}`;
      details.append(title, subtitle);
      const time = document.createElement("span");
      time.className = "row-time";
      time.textContent = formatDuration(item.seconds);
      if (state.showMediaTime) {
        const mediaTime = document.createElement("span");
        mediaTime.className = "row-media-time";
        mediaTime.textContent = `Film: ${formatDuration(item.mediaSeconds)}`;
        mediaTime.title = "Czas, o jaki przesunęła się oś filmu";
        time.append(mediaTime);
      }
      row.append(imageLink, details, time);
      list.append(row);
    }
    requestAnimationFrame(restoreScrollPosition);
    resizePopupToHistory();
  }

  function updateHistoryScrollIndicator() {
    const list = $("#history-list");
    const indicator = $(".history-scroll-indicator");
    const thumb = $("#history-scroll-thumb");
    if (!list || !indicator || !thumb) return;
    const maxScroll = list.scrollHeight - list.clientHeight;
    indicator.hidden = maxScroll <= 1;
    if (maxScroll <= 1) return;
    const trackHeight = indicator.clientHeight;
    const thumbHeight = Math.max(12, trackHeight * list.clientHeight / list.scrollHeight);
    const maxThumbTravel = Math.max(0, trackHeight - thumbHeight);
    const progress = maxScroll - list.scrollTop <= 1 ? 1 : list.scrollTop / maxScroll;
    thumb.style.height = `${thumbHeight}px`;
    thumb.style.transform = `translateY(${maxThumbTravel * progress}px)`;
  }

  function updateHistoryTypeFilter() {
    document.querySelectorAll(".legend-filter").forEach((button) => {
      const selected = button.dataset.historyType === state.historyTypeFilter;
      button.classList.toggle("selected", selected);
      button.setAttribute("aria-pressed", String(selected));
    });
  }

  function resetHistoryScroll() {
    const list = $("#history-list");
    if (state.historyScrollFrame) cancelAnimationFrame(state.historyScrollFrame);
    state.historyScrollFrame = 0;
    state.historyScrollTarget = 0;
    state.historyWheelRemainder = 0;
    state.historyResetOnNextRender = true;
    list.scrollTop = 0;
  }

  function moveChartByWheel(direction) {
    if (state.chartWheelBusy) {
      state.chartWheelRemainder = Math.max(-1, Math.min(1, state.chartWheelRemainder + direction));
      return;
    }
    const nextOffset = Math.max(0, Math.min(maximumOffset(), state.offset + direction));
    if (nextOffset === state.offset) return;
    state.chartWheelBusy = true;
    void slideChartToOffset(nextOffset).finally(() => {
      setTimeout(() => {
        state.chartWheelBusy = false;
        const queuedDirection = Math.sign(state.chartWheelRemainder);
        state.chartWheelRemainder = 0;
        if (queuedDirection) moveChartByWheel(queuedDirection);
      }, 180);
    });
  }

  function makeChannelFallback() {
    const icon = document.createElement("span");
    icon.className = "history-image channel-placeholder";
    icon.textContent = "▶";
    return icon;
  }

  function formatChartDuration(seconds) {
    if (seconds <= 0) return "";
    const showSeconds = state.durationFormat === "always-seconds"
      || (state.durationFormat === "smart" && seconds < state.durationSecondsThreshold * 3600);
    if (seconds >= 3600) {
      const hours = Math.floor(seconds / 3600);
      const minutes = Math.floor((seconds % 3600) / 60);
      const secondsLabel = showSeconds ? ` ${Math.floor(seconds % 60)}s` : "";
      return `${hours}h${minutes ? ` ${minutes}m` : ""}${secondsLabel}`;
    }
    if (seconds >= 60) {
      const minutes = Math.floor(seconds / 60);
      const secondsLabel = showSeconds ? ` ${Math.floor(seconds % 60)}s` : "";
      return `${minutes}m${secondsLabel}`;
    }
    return showSeconds ? `${Math.floor(seconds)}s` : "0m";
  }

  function seasonColor(month) {
    if ([11, 0, 1].includes(month)) return "#b9e6f5";
    if ([2, 3, 4].includes(month)) return "#b8d9a6";
    if ([5, 6, 7].includes(month)) return "#e7d28e";
    return "#bb8063";
  }

  function createSvgElement(name, attributes = {}) {
    const element = document.createElementNS("http://www.w3.org/2000/svg", name);
    for (const [key, value] of Object.entries(attributes)) element.setAttribute(key, String(value));
    return element;
  }

  function renderAllTimeChart(rows) {
    const chart = $("#chart");
    state.lastAllChartRenderAt = Date.now();
    state.allChartDirty = false;
    if (state.allChartRefreshTimer) clearTimeout(state.allChartRefreshTimer);
    chart.replaceChildren();
    chart.classList.remove("chart-all-time");
    chart.classList.add("all-time-chart");
    $("#all-time-controls").hidden = false;

    const firstDate = state.allRangeStart || state.firstDate || dateKey(new Date());
    const lastDate = state.allRangeEnd || dateKey(new Date());
    const first = new Date(`${firstDate}T12:00:00`);
    const last = new Date(`${lastDate}T12:00:00`);
    const dayMs = 86_400_000;
    const totalDays = Math.max(1, Math.round((last - first) / dayMs) + 1);
    state.allZoom = Math.min(state.allZoom, maximumAllZoom());
    const visibleDays = Math.min(totalDays, Math.max(14, Math.ceil(totalDays / state.allZoom)));
    const visibleStart = new Date(Math.max(first.getTime(), last.getTime() - (visibleDays - 1) * dayMs));
    const totals = new Map();
    for (const row of state.allHistory) totals.set(row.date, (totals.get(row.date) || 0) + row.seconds);

    const points = [];
    const visibleCount = Math.max(1, Math.round((last - visibleStart) / dayMs) + 1);
    for (let i = 0; i < visibleCount; i++) {
      const date = new Date(visibleStart.getTime() + i * dayMs);
      const key = dateKey(date);
      points.push({ date, value: (totals.get(key) || 0) / 3600 });
    }

    const width = 540;
    const height = state.allChartCompact ? 96 : 190;
    const left = 48;
    const right = 12;
    const top = state.allChartCompact ? 8 : 15;
    const bottom = state.allChartCompact ? 20 : 34;
    const plotWidth = width - left - right;
    const plotHeight = height - top - bottom;
    const gridStep = visibleDays <= 14 ? 1 : visibleDays <= 60 ? 7 : visibleDays <= 730 ? 30 : 365;
    const maxValue = Math.max(0.25, ...points.map((point) => point.value));
    const rawStep = maxValue / 4;
    const stepMagnitude = 10 ** Math.floor(Math.log10(rawStep));
    const normalizedStep = rawStep / stepMagnitude;
    const niceStep = normalizedStep <= 1 ? 1 : normalizedStep <= 2 ? 2 : normalizedStep <= 2.5 ? 2.5 : normalizedStep <= 5 ? 5 : 10;
    const yStep = niceStep * stepMagnitude;
    const yMaximum = yStep * 4;
    const svg = createSvgElement("svg", { viewBox: `0 0 ${width} ${height}`, role: "img", "aria-label": "Dzienny czas oglądania od początku zbierania danych" });
    for (let tick = 0; tick <= 4; tick++) {
      const value = yMaximum * tick / 4;
      const y = top + plotHeight - plotHeight * tick / 4;
      svg.append(createSvgElement("line", { x1: left, x2: width - right, y1: y, y2: y, class: "all-time-grid" }));
      const label = createSvgElement("text", { x: left - 7, y: y + 3, "text-anchor": "end", class: "all-time-axis-label" });
      label.textContent = Number(value.toFixed(2)).toString();
      svg.append(label);
    }
    for (let index = 1; index < points.length; index++) {
      const date = points[index].date;
      const isBoundary = gridStep === 1
        || (gridStep === 7 && date.getDay() === 1)
        || (gridStep === 30 && date.getDate() === 1)
        || (gridStep === 365 && date.getMonth() === 0 && date.getDate() === 1);
      if (!isBoundary) continue;
      const x = left + index / Math.max(1, points.length - 1) * plotWidth;
      svg.append(createSvgElement("line", {
        x1: x, x2: x, y1: top, y2: top + plotHeight, class: "all-time-x-grid",
      }));
      const label = createSvgElement("text", {
        x: Math.min(width - right, Math.max(left, x + 2)),
        y: height - 16,
        "text-anchor": x > width - 65 ? "end" : "start",
        class: "all-time-x-label",
      });
      label.textContent = gridStep === 1
        ? `${date.getDate()}.${String(date.getMonth() + 1).padStart(2, "0")}`
        : gridStep === 7
          ? `${date.getDate()} ${date.toLocaleDateString("pl-PL", { month: "short" })}`
          : gridStep === 30
            ? date.toLocaleDateString("pl-PL", { month: "short", year: "2-digit" })
            : String(date.getFullYear());
      svg.append(label);
    }
    const path = points.map((point, index) => {
      const x = left + (points.length === 1 ? plotWidth : index / (points.length - 1) * plotWidth);
      const y = top + plotHeight - point.value / yMaximum * plotHeight;
      return `${index ? "L" : "M"}${x.toFixed(2)} ${y.toFixed(2)}`;
    }).join(" ");
    svg.append(createSvgElement("path", { d: path, class: "all-time-line" }));
    for (const [index, point] of points.entries()) {
      if (!totals.has(dateKey(point.date)) || point.value <= 0) continue;
      const x = left + (points.length === 1 ? plotWidth / 2 : index / (points.length - 1) * plotWidth);
      const y = top + plotHeight - point.value / yMaximum * plotHeight;
      const marker = createSvgElement("circle", { cx: x, cy: y, r: 3, class: "all-time-point" });
      const title = createSvgElement("title");
      title.textContent = `${dateLabel(point.date)} · ${formatDuration(point.value * 3600)}`;
      marker.append(title);
      svg.append(marker);
    }
    const startLabel = createSvgElement("text", { x: left, y: height - 8, "text-anchor": "start", class: "all-time-axis-label" });
    startLabel.textContent = dateLabel(visibleStart);
    const endLabel = createSvgElement("text", { x: width - right, y: height - 8, "text-anchor": "end", class: "all-time-axis-label" });
    endLabel.textContent = dateLabel(last);
    svg.append(startLabel, endLabel);
    chart.append(svg);
    $("#all-time-controls").dataset.zoom = `${state.allZoom}×`;
    if (state.period === "year") {
      state.allChartRefreshTimer = setTimeout(() => {
        if (state.period === "year") renderAllTimeChart(state.rows);
      }, 10 * 60 * 1000);
    }
  }

  function dateLabel(date) {
    return date.toLocaleDateString("pl-PL", { day: "numeric", month: "short", year: "2-digit" });
  }

  function makeVideoFallback() {
    const icon = document.createElement("span");
    icon.className = "history-image video-placeholder";
    icon.textContent = "▶";
    return icon;
  }

  function renderChart(start, end, rows = state.rows) {
    if (state.period === "year") {
      if (state.allChartDirty || !$("#chart").querySelector("svg")
        || Date.now() - state.lastAllChartRenderAt >= 10 * 60 * 1000) {
        renderAllTimeChart(rows);
      }
      return;
    }
    const buckets = makeChartData();
    const scale = state.chartScales[state.period] || { mode: "visible", hours: 8 };
    const visibleMaximum = Math.max(0, ...buckets.map((bucket) => bucket.seconds)) || 1;
    let allTimeMaximum = 0;
    const historyBuckets = new Map();
    for (const row of state.allHistory) {
      const key = periodKey(new Date(`${row.date}T12:00:00`));
      historyBuckets.set(key, (historyBuckets.get(key) || 0) + row.seconds);
    }
    allTimeMaximum = Math.max(0, ...historyBuckets.values(), ...buckets.map((bucket) => bucket.seconds)) || 1;
    const recentKeys = allPeriodKeys(state.period).slice(-periodCount());
    const fixedWindowMaximum = Math.max(0, ...recentKeys.map((key) => historyBuckets.get(key) || 0)) || 1;
    const fixedMaximum = Math.max(0.25, Number(scale.hours) || 8) * 3600;
    const maximum = scale.mode === "sinceStart"
      ? allTimeMaximum
      : scale.mode === "fixed"
        ? fixedMaximum
        : state.chartFixedWindow[state.period]
          ? fixedWindowMaximum
          : visibleMaximum;
    const chart = $("#chart");
    chart.replaceChildren();
    for (const bucket of buckets) {
      const column = document.createElement("div");
      const isCurrent = bucket.key === periodKey(new Date(), state.period);
      column.className = `chart-column chart-${state.period}${bucket.selected ? " selected" : ""}${isCurrent ? " current-period" : ""}`;
      column.tabIndex = 0;
      column.setAttribute("role", "button");
      column.setAttribute("aria-label", `${bucket.start} · ${formatDuration(bucket.seconds)}`);
      column.title = `${bucket.start} – ${bucket.end} · ${formatDuration(bucket.seconds)}`;
      const selectBucket = () => {
        if (state.ignoreNextChartClick) return;
        const keys = allPeriodKeys();
        const bucketIndex = keys.indexOf(bucket.key);
        if (bucketIndex < 0) return;
        state.offset = offsetToIncludePeriod(bucketIndex);
        state.selectedDate = new Date(`${bucket.key}T12:00:00`);
        void render();
      };
      column.addEventListener("click", selectBucket);
      column.addEventListener("keydown", (event) => {
        if (event.key !== "Enter" && event.key !== " ") return;
        event.preventDefault();
        selectBucket();
      });
      const value = document.createElement("span");
      value.className = "chart-value";
      value.textContent = formatChartDuration(bucket.seconds);
      const percent = document.createElement("span");
      percent.className = "chart-percent";
      const percentage = bucket.seconds > 0
        ? Math.max(1, Math.round(bucket.seconds / maximum * 100))
        : 0;
      percent.textContent = `${percentage}%`;
      const track = document.createElement("div");
      track.className = "chart-track";
      const bar = document.createElement("div");
      bar.className = "chart-bar";
      bar.style.height = `${bucket.seconds > 0 ? Math.max(1, Math.min(100, bucket.seconds / maximum * 100)) : 0}%`;
      if (state.period === "month") {
        bar.style.setProperty("--bucket-color", seasonColor(Number(bucket.start.slice(5, 7)) - 1));
      }
      track.append(bar);
      const label = document.createElement("span");
      label.className = "chart-label";
      label.textContent = bucket.label;
      column.append(value, percent, track, label);
      chart.append(column);
    }
    chart.classList.remove("chart-all-time", "all-time-chart");
    $("#all-time-controls").hidden = true;
  }

  async function render() {
    if (state.rendering) {
      state.renderQueued = true;
      return;
    }
    state.rendering = true;
    let range = rangeForPeriod();
    const datePicker = $("#date-picker");
    $("#date-controls").dataset.period = state.period;
    datePicker.hidden = state.period === "week" || state.period === "month";
    document.querySelectorAll(".period-button").forEach((button) => {
      button.classList.toggle("selected", button.dataset.period === state.period);
    });

    try {
      const [firstRecord, savedStart] = await Promise.all([
        VtmStorage.getFirstHistoryDate(),
        VtmStorage.getSetting("tracking-start-date", ""),
      ]);
      const trackingStart = savedStart || firstRecord || dateKey(new Date());
      state.firstDate = trackingStart;
      if (!savedStart) await VtmStorage.setSetting("tracking-start-date", trackingStart);
      if (!state.allHistoryLoaded) {
        state.allHistory = await VtmStorage.getAllHistory();
        state.allHistoryLoaded = true;
      }
      if (!state.allRangeStart || !state.allRangeEnd) {
        state.allRangeStart = state.firstDate || dateKey(new Date());
        state.allRangeEnd = dateKey(new Date());
      }
      range = rangeForPeriod();
      const { date, start, end } = range;
      if (state.period === "day" || state.period === "year") datePicker.textContent = calendarButtonLabel();
      if (state.period === "year" && state.firstDate) {
        const firstYear = Number(state.firstDate.slice(0, 4));
        start.setFullYear(firstYear, 0, 1);
      }
      const historyRangeKey = `${state.period}:${dateKey(start)}:${dateKey(end)}`;
      if (state.historyRangeKey !== historyRangeKey) {
        state.historyRangeKey = historyRangeKey;
        resetHistoryScroll();
      }
      state.rows = await VtmStorage.listHistory(dateKey(start), dateKey(end));
      for (const row of state.rows) mergeHistoryRow(row);
      state.showMediaTime = await VtmStorage.getSetting("show-media-time", false);
      const total = state.rows.reduce((sum, row) => sum + row.seconds, 0);
      const videos = new Set(state.rows.map((row) => row.videoId));
      const channels = new Set(state.rows.map((row) => row.channelId || row.channelName).filter(Boolean));
      const byType = { video: 0, short: 0, live: 0 };
      const mediaTotal = state.rows.reduce((sum, row) => sum + (row.mediaSeconds ?? row.seconds), 0);
      const byTypeMedia = { video: 0, short: 0, live: 0 };
      for (const row of state.rows) byType[row.videoType] = (byType[row.videoType] ?? 0) + row.seconds;
      for (const row of state.rows) byTypeMedia[row.videoType] = (byTypeMedia[row.videoType] ?? 0) + (row.mediaSeconds ?? row.seconds);
      $("#total-time").textContent = formatDuration(total);
      $("#total-media-time").hidden = !state.showMediaTime;
      $("#total-media-time").textContent = `Film: ${formatDuration(mediaTotal)}`;
      $("#video-count").textContent = videos.size;
      $("#channel-count").textContent = channels.size;
      $("#video-time").textContent = formatDuration(byType.video);
      $("#short-time").textContent = formatDuration(byType.short);
      $("#live-time").textContent = formatDuration(byType.live);
      for (const type of ["video", "short", "live"]) {
        const mediaTime = $(`#${type}-media-time`);
        mediaTime.hidden = !state.showMediaTime;
        mediaTime.textContent = `Film: ${formatDuration(byTypeMedia[type])}`;
      }
      renderChart(start, end, state.rows);
      renderHistory(state.rows);
      if (state.calendarOpen) renderCalendar();
    } catch (error) {
      console.error("[VTM Local] Nie udało się odczytać lokalnej historii:", error);
      $("#history-list").textContent = `Błąd odczytu lokalnej historii: ${error.message}`;
    } finally {
      state.rendering = false;
      if (state.renderQueued) {
        state.renderQueued = false;
        void render();
      }
    }
  }

  function minutesFromTime(value, fallback) {
    const match = /^(\d{2}):(\d{2})$/.exec(value);
    return match ? Number(match[1]) * 60 + Number(match[2]) : fallback;
  }

  async function applyAppearance() {
    const [style, mode, lightStart, lightEnd] = await Promise.all([
      VtmStorage.getSetting("appearance-style", "expressive"),
      VtmStorage.getSetting("appearance-mode", "dark"),
      VtmStorage.getSetting("appearance-light-start", "07:00"),
      VtmStorage.getSetting("appearance-light-end", "19:00"),
    ]);
    const now = new Date();
    const currentMinutes = now.getHours() * 60 + now.getMinutes();
    const startMinutes = minutesFromTime(lightStart, 7 * 60);
    const endMinutes = minutesFromTime(lightEnd, 19 * 60);
    const isLight = startMinutes === endMinutes
      || (startMinutes < endMinutes
        ? currentMinutes >= startMinutes && currentMinutes < endMinutes
        : currentMinutes >= startMinutes || currentMinutes < endMinutes);
    document.body.dataset.style = style === "cyberpunk" ? "cyberpunk" : "expressive";
    document.body.dataset.mode = mode === "auto" ? (isLight ? "light" : "dark") : mode === "light" ? "light" : "dark";
    document.querySelectorAll("[data-style-choice]").forEach((button) => {
      button.classList.toggle("selected", button.dataset.styleChoice === document.body.dataset.style);
    });
    document.querySelectorAll("[data-mode-choice]").forEach((button) => {
      button.classList.toggle("selected", button.dataset.modeChoice === mode);
    });
    $("#auto-theme-times").hidden = mode !== "auto";
    $("#light-start").value = lightStart;
    $("#light-end").value = lightEnd;
  }

  function showStatus(message, isError = false) {
    const status = $("#settings-status");
    status.textContent = message;
    status.classList.toggle("error", isError);
  }

  async function exportHistory() {
    const videos = await VtmStorage.getAllHistory();
    const exportFile = {
      format: "video-time-manager-local",
      schemaVersion: 1,
      exportedAt: new Date().toISOString(),
      videos,
    };
    const url = URL.createObjectURL(new Blob([JSON.stringify(exportFile)], { type: "application/json" }));
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `video-time-manager-${dateKey(new Date())}.json`;
    anchor.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    showStatus(`Wyeksportowano ${videos.length} wpisów.`);
  }

  function extractImportRecords(data) {
    if (Array.isArray(data)) return data;
    if (!data || typeof data !== "object") {
      throw new Error("Plik JSON musi zawierać listę wpisów historii.");
    }
    const records = [data.videos, data.history, data.records]
      .find((candidate) => Array.isArray(candidate));
    if (!records) {
      throw new Error("Nie znaleziono listy historii. Oczekiwano pola videos, history lub records.");
    }
    if (data.schemaVersion !== undefined && data.schemaVersion !== 1) {
      throw new Error(`Nieobsługiwana wersja pliku historii: ${data.schemaVersion}.`);
    }
    return records;
  }

  async function importHistoryFile(file) {
    if (!file) return;
    if (file.size > 50 * 1024 * 1024) {
      throw new Error("Plik importu nie może być większy niż 50 MB.");
    }
    let data;
    try {
      data = JSON.parse(await file.text());
    } catch (error) {
      throw new Error(`Nie można odczytać pliku JSON: ${error.message}`);
    }
    const records = extractImportRecords(data);
    const result = await VtmStorage.importHistory(records);
    const importedFirstDate = await VtmStorage.getFirstHistoryDate();
    const previousFirstDate = await VtmStorage.getSetting("tracking-start-date", "");
    const trackingStart = [previousFirstDate, importedFirstDate].filter(Boolean).sort()[0];
    if (trackingStart && trackingStart !== previousFirstDate) {
      await VtmStorage.setSetting("tracking-start-date", trackingStart);
    }
    state.allHistory = await VtmStorage.getAllHistory();
    state.allHistoryLoaded = true;
    state.firstDate = trackingStart || state.firstDate;
    if (trackingStart && (!state.allRangeStart || trackingStart < state.allRangeStart)) {
      state.allRangeStart = trackingStart;
    }
    state.allChartDirty = true;
    await render();
    showStatus(
      `Import zakończony: ${result.added} dodanych, ${result.updated} uzupełnionych, ${result.unchanged} bez zmian.`,
    );
  }

  async function saveSetting(key, value) {
    await VtmStorage.setSetting(key, value);
  }

  function updateSettingChoices(key, value) {
    document.querySelectorAll(`[data-setting-key="${key}"]`).forEach((button) => {
      const selected = button.dataset.settingValue === value;
      button.classList.toggle("selected", selected);
      button.setAttribute("aria-pressed", String(selected));
    });
  }

  async function notifyButtonSettingsChanged() {
    const response = await chrome.runtime.sendMessage({ type: "vtm:button-settings-changed" });
    if (response?.ok === false) {
      throw new Error(response.error || "Nie udało się zaktualizować ikonki na YouTube.");
    }
  }

  async function applyButtonSettings() {
    let [image, scale, offset, offsetX, delay, unlimited] = await Promise.all([
      VtmStorage.getSetting("youtube-button-image", ""),
      VtmStorage.getSetting("youtube-button-scale", 24),
      VtmStorage.getSetting("youtube-button-offset", 0),
      VtmStorage.getSetting("youtube-button-offset-x", 0),
      VtmStorage.getSetting("youtube-button-delay", 0),
      VtmStorage.getSetting("youtube-button-unlimited", false),
    ]);
    const originalImage = await VtmStorage.getSetting("youtube-button-image-original", "");
    if (originalImage) {
      image = originalImage;
      await VtmStorage.setSetting("youtube-button-image", image);
      await VtmStorage.removeSettings(["youtube-button-image-original"]);
      await notifyButtonSettingsChanged();
    }
    if (!image) {
      image = await getPersistentButtonImage();
      if (image) await VtmStorage.setSetting("youtube-button-image", image);
    } else {
      await setPersistentButtonImage(image);
    }
    await cacheButtonSizeSettings(scale, unlimited);
    state.buttonIconUnlimited = Boolean(unlimited);
    $("#button-icon-scale").value = Math.max(8, Math.min(60, Number(scale) || 24));
    $("#button-icon-offset").value = Math.max(-24, Math.min(24, Number(offset) || 0));
    $("#button-icon-scale-value").value = `${$("#button-icon-scale").value} px`;
    $("#button-icon-offset-value").value = `${$("#button-icon-offset").value} px`;
    $("#button-icon-offset-x").value = Math.max(-24, Math.min(24, Number(offsetX) || 0));
    $("#button-icon-offset-x-value").value = `${Number(offsetX) > 0 ? "+" : ""}${$("#button-icon-offset-x").value} px`;
    state.buttonIconDelay = Number(delay) || 0;
    $("#button-icon-delay").value = Math.max(0, Math.min(2000, state.buttonIconDelay));
    $("#button-icon-delay-value").value = `${$("#button-icon-delay").value} ms`;
    $("#button-icon-unlimited").checked = state.buttonIconUnlimited;
    $("#icon-range-controls").hidden = state.buttonIconUnlimited;
    $("#icon-custom-controls").hidden = !state.buttonIconUnlimited;
    $("#button-icon-delay-custom").value = state.buttonIconDelay;
    $("#button-icon-scale-custom").value = Number(scale) || 24;
    $("#button-icon-offset-custom").value = Number(offset) || 0;
    $("#button-icon-offset-x-custom").value = Number(offsetX) || 0;
    $("#remove-button-icon").disabled = !image;
  }

  async function applyChartSettings() {
    const [weekdayStyle, showMediaTime, hideUntracked, durationFormat, secondsThreshold, compactAllChart] = await Promise.all([
      VtmStorage.getSetting("weekday-label-style", "monday-short-title"),
      VtmStorage.getSetting("show-media-time", false),
      VtmStorage.getSetting("hide-untracked-periods", true),
      VtmStorage.getSetting("duration-format", "smart"),
      VtmStorage.getSetting("duration-seconds-threshold", 1),
      VtmStorage.getSetting("compact-all-chart", true),
    ]);
    const styles = ["full-lower", "full-title", "short-lower", "short-title", "short-upper",
      "monday-short-lower", "monday-short-title", "monday-short-upper"];
    state.weekdayLabelStyle = styles.includes(weekdayStyle) ? weekdayStyle : "monday-short-title";
    state.showMediaTime = Boolean(showMediaTime);
    state.hideUntracked = Boolean(hideUntracked);
    state.allChartCompact = Boolean(compactAllChart);
    state.durationFormat = ["always-seconds", "hours-minutes", "smart"].includes(durationFormat)
      ? durationFormat
      : "smart";
    state.durationSecondsThreshold = Number.isFinite(Number(secondsThreshold)) && Number(secondsThreshold) > 0
      ? Number(secondsThreshold)
      : 1;
    $("#weekday-label-style").value = state.weekdayLabelStyle;
    $("#show-media-time").checked = state.showMediaTime;
    $("#hide-untracked-periods").checked = state.hideUntracked;
    $("#compact-all-chart").checked = state.allChartCompact;
    $("#chart-panel").classList.toggle("compact-all-chart", state.allChartCompact);
    updateSettingChoices("duration-format", state.durationFormat);
    $("#duration-seconds-threshold").value = state.durationSecondsThreshold;
    $("#duration-threshold-setting").hidden = state.durationFormat !== "smart";
    $("#duration-seconds-threshold").disabled = state.durationFormat !== "smart";
    for (const period of ["day", "week", "month"]) {
      const mode = await VtmStorage.getSetting(`chart-scale-${period}`, "visible");
      const hours = await VtmStorage.getSetting(`chart-scale-hours-${period}`, state.chartScales[period].hours);
      const fixedWindow = await VtmStorage.getSetting(`chart-scale-fixed-window-${period}`, true);
      state.chartScales[period] = {
        mode: ["visible", "sinceStart", "fixed"].includes(mode) ? mode : "visible",
        hours: Number.isFinite(Number(hours)) && Number(hours) > 0
          ? Number(hours)
          : state.chartScales[period].hours,
      };
      state.chartFixedWindow[period] = Boolean(fixedWindow);
      updateSettingChoices(`chart-scale-${period}`, state.chartScales[period].mode);
      $(`#chart-scale-hours-${period}`).value = state.chartScales[period].hours;
      $(`#chart-scale-hours-${period}`).closest(".scale-hours").hidden = state.chartScales[period].mode !== "fixed";
      $(`#chart-scale-fixed-window-${period}`).checked = state.chartFixedWindow[period];
      $(`#chart-scale-fixed-window-${period}`).closest(".fixed-window-setting").hidden =
        state.chartScales[period].mode !== "visible";
    }
    return applyHistoryLayout();
  }

  async function applyHistoryLayout() {
    const [wheelRows, visibleRows, sortPersistence, videoSort, channelSort, defaultTypeFilter] = await Promise.all([
      VtmStorage.getSetting("history-wheel-rows", 2),
      VtmStorage.getSetting("history-visible-rows", 5),
      VtmStorage.getSetting("history-sort-persistence", "default"),
      VtmStorage.getSetting("history-video-sort", "time"),
      VtmStorage.getSetting("history-channel-sort", "time"),
      VtmStorage.getSetting("history-default-type-filter", "video"),
    ]);
    state.historyWheelRows = Math.max(1, Math.min(5, Number(wheelRows) || 2));
    state.historyVisibleRows = Math.max(3, Math.min(7, Number(visibleRows) || 5));
    state.sortPersistence = sortPersistence === "remember" ? "remember" : "default";
    state.videoSort = state.sortPersistence === "remember" && videoSort === "recent" ? "recent" : "time";
    state.channelSort = state.sortPersistence === "remember" && channelSort === "videos" ? "videos" : "time";
    state.historyTypeFilter = defaultTypeFilter === "all" ? null : "video";
    $("#history-wheel-rows").value = String(state.historyWheelRows);
    $("#history-visible-rows").value = String(state.historyVisibleRows);
    $("#history-sort-persistence").value = state.sortPersistence;
    $("#history-default-type-filter").value = state.historyTypeFilter ? "video" : "all";
    updateHistorySortControl();
    updateHistoryTypeFilter();
    document.documentElement.style.setProperty("--history-visible-rows", state.historyVisibleRows);
    $("#app").style.paddingBottom = "5px";
    resizePopupToHistory();
  }

  function resizePopupToHistory() {
    requestAnimationFrame(() => {
      const list = $("#history-list");
      const rows = [...list.querySelectorAll(".history-row")];
      const visibleCount = Math.min(rows.length, state.historyVisibleRows);
      if (visibleCount > 0 && rows.length > visibleCount) {
        const gap = Number.parseFloat(getComputedStyle(list).rowGap) || 0;
        const height = rows.slice(0, visibleCount)
          .reduce((sum, row) => sum + row.getBoundingClientRect().height, 0)
          + gap * (visibleCount - 1);
        list.style.height = `${Math.ceil(height)}px`;
        list.style.maxHeight = "none";
      } else {
        list.style.height = "auto";
        list.style.maxHeight = "none";
      }
      const height = Math.max(300, Math.ceil(list.getBoundingClientRect().bottom + 5));
      const heightValue = `${height}px`;
      document.documentElement.style.setProperty("--popup-height", heightValue);
      document.documentElement.style.height = heightValue;
      document.documentElement.style.maxHeight = heightValue;
      document.body.style.height = heightValue;
      document.body.style.maxHeight = heightValue;
      $("#app").style.height = heightValue;
      updateHistoryScrollIndicator();
      if (EMBEDDED) parent.postMessage({ type: "vtm:resize-embedded-dashboard", height }, "*");
    });
  }

  function updateHistorySortControl() {
    const count = $("#result-count");
    const tooltip = $("#history-sort-tooltip");
    if (!count || !tooltip) return;
    const mode = state.view === "videos" ? state.videoSort : state.channelSort;
    const description = state.view === "videos"
      ? mode === "time" ? "według czasu oglądania" : "według kolejności oglądania"
      : mode === "time" ? "według czasu oglądania" : "według liczby obejrzanych filmów";
    const label = `${count.textContent} wpisów. Sortowanie: ${description}. Kliknij, aby zmienić.`;
    count.setAttribute("aria-label", label);
    tooltip.textContent = `Sortowanie: ${description}`;
  }

  function scheduleHistorySortTooltip() {
    const tooltip = $("#history-sort-tooltip");
    if (state.historySortTooltipTimer) clearTimeout(state.historySortTooltipTimer);
    state.historySortTooltipTimer = setTimeout(() => {
      tooltip.hidden = false;
      state.historySortTooltipTimer = 0;
    }, 2500);
  }

  function hideHistorySortTooltip() {
    if (state.historySortTooltipTimer) clearTimeout(state.historySortTooltipTimer);
    state.historySortTooltipTimer = 0;
    $("#history-sort-tooltip").hidden = true;
  }

  async function storeButtonImage(file) {
    const supportedTypes = new Set(["image/png", "image/jpeg", "image/webp", "image/gif"]);
    const extensionTypes = {
      ".png": "image/png",
      ".jpg": "image/jpeg",
      ".jpeg": "image/jpeg",
      ".webp": "image/webp",
      ".gif": "image/gif",
    };
    const rawType = file.type.toLowerCase();
    const normalizedType = rawType === "image/jpg" || rawType === "image/pjpeg"
      ? "image/jpeg"
      : supportedTypes.has(rawType)
        ? rawType
        : extensionTypes[file.name.slice(file.name.lastIndexOf(".")).toLowerCase()];
    if (!normalizedType) throw new Error("Wybierz plik PNG, JPEG, WebP lub GIF.");
    if (file.size > 4 * 1024 * 1024) throw new Error("Obraz nie może być większy niż 4 MB.");
    const rawDataUrl = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(reader.error ?? new Error("Nie udało się odczytać obrazu."));
      reader.readAsDataURL(file);
    });
    if (typeof rawDataUrl !== "string") throw new Error("Nie udało się odczytać pliku obrazu.");
    const dataUrl = rawDataUrl.replace(/^data:[^;,]+/i, `data:${normalizedType}`);
    await VtmButtonImage.validateDataUrl(dataUrl);
    await VtmStorage.setSetting("youtube-button-image", dataUrl);
    const fastCopySaved = await setPersistentButtonImage(dataUrl);
    await VtmStorage.removeSettings(["youtube-button-image-original"]);
    await notifyButtonSettingsChanged();
    await applyButtonSettings();
    showStatus(fastCopySaved
      ? "Ikonka została zapisana w lokalnych danych rozszerzenia."
      : "Ikonka została zapisana w bazie TimeYT. Nie udało się utworzyć jej szybkiej kopii, ale zostanie wczytana z bazy.");
  }

  async function setPersistentButtonImage(image) {
    try {
      await new Promise((resolve, reject) => {
        chrome.storage.local.set({ vtmButtonImage: image }, () => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
            return;
          }
          resolve();
        });
      });
      return true;
    } catch (error) {
      console.warn("[VTM Local] Ikonka jest zapisana w bazie TimeYT, ale nie udało się utworzyć jej szybkiej kopii:", error);
      return false;
    }
  }

  async function cacheButtonSizeSettings(scale, unlimited) {
    try {
      await new Promise((resolve, reject) => {
        chrome.storage.local.set({
          vtmButtonScale: Number(scale),
          vtmButtonUnlimited: Boolean(unlimited),
        }, () => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
            return;
          }
          resolve();
        });
      });
    } catch (error) {
      console.warn("[VTM Local] Nie udało się utworzyć szybkiej kopii skali ikonki:", error);
    }
  }

  function removePersistentButtonImage() {
    return new Promise((resolve, reject) => {
      chrome.storage.local.remove("vtmButtonImage", () => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        resolve();
      });
    });
  }

  function getPersistentButtonImage() {
    return new Promise((resolve, reject) => {
      chrome.storage.local.get({ vtmButtonImage: "" }, (settings) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        resolve(settings.vtmButtonImage);
      });
    });
  }

  async function saveButtonImageSettings(scale, additionalSettings = {}) {
    const original = await VtmStorage.getSetting("youtube-button-image-original", "");
    const settings = { ...additionalSettings, "youtube-button-scale": scale };
    if (original) settings["youtube-button-image"] = original;
    await VtmStorage.setSettings(settings);
    if (original) await VtmStorage.removeSettings(["youtube-button-image-original"]);
    const unlimited = Object.hasOwn(additionalSettings, "youtube-button-unlimited")
      ? additionalSettings["youtube-button-unlimited"]
      : await VtmStorage.getSetting("youtube-button-unlimited", false);
    await cacheButtonSizeSettings(scale, unlimited);
  }

  document.querySelectorAll(".period-button").forEach((button) => {
    button.addEventListener("click", () => setPeriod(button.dataset.period));
  });
  $("#date-picker").addEventListener("click", () => {
    state.calendarOpen = !state.calendarOpen;
    $("#calendar-popover").hidden = !state.calendarOpen;
    $("#date-picker").setAttribute("aria-expanded", String(state.calendarOpen));
    if (state.calendarOpen) renderCalendar();
  });
  $("#calendar-back").addEventListener("click", () => {
    state.calendarOffset += 1;
    renderCalendar();
  });
  $("#calendar-forward").addEventListener("click", () => {
    if (state.calendarOffset === 0) return;
    state.calendarOffset -= 1;
    renderCalendar();
  });
  document.addEventListener("pointerdown", (event) => {
    if (!state.calendarOpen || event.target.closest("#date-controls")) return;
    closeCalendar();
  });
  document.addEventListener("wheel", (event) => {
    const chart = event.target.closest("#chart");
    const scrollRegion = event.target.closest("#history-list, .settings-content");
    event.preventDefault();
    event.stopPropagation();
    const wheelSelect = event.target.closest(".wheel-select");
    if (wheelSelect) {
      const direction = event.deltaY || event.deltaX;
      const nextIndex = Math.max(0, Math.min(wheelSelect.options.length - 1,
        wheelSelect.selectedIndex + (direction > 0 ? 1 : -1)));
      if (nextIndex !== wheelSelect.selectedIndex) {
        wheelSelect.selectedIndex = nextIndex;
        wheelSelect.dispatchEvent(new Event("change", { bubbles: true }));
      }
      return;
    }
    if (event.target.closest("#button-icon-delay")) {
      const input = $("#button-icon-delay");
      const next = Math.max(0, Math.min(2000, Number(input.value) + (event.deltaY < 0 ? 100 : -100)));
      if (next !== Number(input.value)) {
        input.value = String(next);
        input.dispatchEvent(new Event("input", { bubbles: true }));
        input.dispatchEvent(new Event("change", { bubbles: true }));
      }
      return;
    }
    if (chart) {
      if (state.period === "year") {
        const delta = event.deltaY || event.deltaX;
        state.allZoom = Math.max(1, Math.min(maximumAllZoom(), state.allZoom + (delta < 0 ? 1 : -1)));
        renderAllTimeChart(state.rows);
        return;
      }
      const direction = Math.abs(event.deltaY) >= Math.abs(event.deltaX) ? event.deltaY : event.deltaX;
      if (!direction) return;
      moveChartByWheel(direction > 0 ? 1 : -1);
      return;
    }
    if (scrollRegion) {
      if (scrollRegion.id !== "history-list") {
        const direction = event.deltaY || event.deltaX;
        scrollRegion.scrollTop += direction;
        return;
      }
      let wheelDelta = Math.abs(event.deltaY) >= Math.abs(event.deltaX) ? event.deltaY : event.deltaX;
      if (!wheelDelta) return;
      const maximum = Math.max(0, scrollRegion.scrollHeight - scrollRegion.clientHeight);
      if (wheelDelta < 0 && scrollRegion.scrollTop <= 0.5 && state.historyScrollTarget <= 0.5) {
        state.historyWheelRemainder = 0;
        return;
      }
      if (wheelDelta > 0 && maximum - scrollRegion.scrollTop <= 0.5
        && maximum - state.historyScrollTarget <= 0.5) {
        state.historyWheelRemainder = 0;
        updateHistoryScrollIndicator();
        return;
      }
      if (event.deltaMode === WheelEvent.DOM_DELTA_LINE) wheelDelta *= 40;
      else if (event.deltaMode === WheelEvent.DOM_DELTA_PAGE) wheelDelta *= scrollRegion.clientHeight;
      state.historyWheelRemainder += wheelDelta / 100;
      const notches = Math.trunc(state.historyWheelRemainder);
      if (!notches) return;
      state.historyWheelRemainder -= notches;
      const row = scrollRegion.querySelector(".history-row");
      const rowHeight = row
        ? row.getBoundingClientRect().height + (Number.parseFloat(getComputedStyle(scrollRegion).rowGap) || 0)
        : 74;
      if (!state.historyScrollFrame) {
        state.historyScrollTarget = scrollRegion.scrollTop <= 1
          ? 0
          : Math.round(scrollRegion.scrollTop / rowHeight) * rowHeight;
      }
      state.historyScrollTarget = Math.max(0, Math.min(maximum,
        state.historyScrollTarget + notches * rowHeight * state.historyWheelRows));
      if (state.historyScrollTarget === 0 || state.historyScrollTarget === maximum) {
        state.historyWheelRemainder = 0;
      }
      if (!state.historyScrollFrame) {
        const step = () => {
          const maximum = Math.max(0, scrollRegion.scrollHeight - scrollRegion.clientHeight);
          state.historyScrollTarget = Math.max(0, Math.min(maximum, state.historyScrollTarget));
          const distance = state.historyScrollTarget - scrollRegion.scrollTop;
          if (Math.abs(distance) < 0.6) {
            scrollRegion.scrollTop = state.historyScrollTarget <= 1
              ? 0
              : maximum - state.historyScrollTarget <= 1
                ? maximum
                : state.historyScrollTarget;
            state.historyScrollTarget = scrollRegion.scrollTop;
            state.historyScrollFrame = 0;
            updateHistoryScrollIndicator();
            return;
          }
          scrollRegion.scrollTop += distance * 0.28;
          state.historyScrollFrame = requestAnimationFrame(step);
        };
        state.historyScrollFrame = requestAnimationFrame(step);
      }
    }
  }, { capture: true, passive: false });
  $("#chart").addEventListener("pointerdown", (event) => {
    if (state.period === "year" || event.button !== 0 || !maximumOffset()) return;
    const chart = $("#chart");
    state.draggingChart = true;
    state.dragStartX = event.clientX;
    state.dragDeltaX = 0;
    state.ignoreNextChartClick = false;
    state.dragColumnWidth = chart.clientWidth / Math.max(1, chart.children.length);
    chart.classList.add("chart-dragging");
    chart.setPointerCapture(event.pointerId);
  });
  $("#chart").addEventListener("pointermove", (event) => {
    if (!state.draggingChart) return;
    state.dragDeltaX = event.clientX - state.dragStartX;
    if (Math.abs(state.dragDeltaX) > 5) state.ignoreNextChartClick = true;
    $("#chart").style.transform = `translateX(${state.dragDeltaX}px)`;
  });
  const finishChartDrag = () => {
    if (!state.draggingChart) return;
    const chart = $("#chart");
    const steps = state.dragColumnWidth > 0 ? Math.round(state.dragDeltaX / state.dragColumnWidth) : 0;
    const nextOffset = Math.max(0, Math.min(maximumOffset(), state.offset + steps));
    const moved = nextOffset !== state.offset;
    state.draggingChart = false;
    chart.classList.remove("chart-dragging");
    if (!moved) {
      chart.style.transform = "";
      setTimeout(() => { state.ignoreNextChartClick = false; }, 0);
      return;
    }
    void slideChartToOffset(nextOffset, `translateX(${state.dragDeltaX}px)`);
    setTimeout(() => { state.ignoreNextChartClick = false; }, 0);
  };
  $("#chart").addEventListener("pointerup", finishChartDrag);
  $("#chart").addEventListener("pointercancel", finishChartDrag);
  $("#history-list").addEventListener("scroll", () => {
    if (!state.historyScrollFrame) state.historyScrollTarget = $("#history-list").scrollTop;
    updateHistoryScrollIndicator();
  }, { passive: true });
  window.addEventListener("resize", () => {
    resizePopupToHistory();
    updateHistoryScrollIndicator();
  });
  $("#zoom-in").addEventListener("click", () => {
    state.allZoom = Math.min(maximumAllZoom(), state.allZoom + 1);
    if (state.period === "year") renderAllTimeChart(state.rows);
  });
  $("#zoom-out").addEventListener("click", () => {
    state.allZoom = Math.max(1, state.allZoom - 1);
    if (state.period === "year") renderAllTimeChart(state.rows);
  });
  document.querySelectorAll(".view-button").forEach((button) => {
    button.addEventListener("click", () => {
      state.view = button.dataset.view;
      document.querySelectorAll(".view-button").forEach((candidate) => {
        const selected = candidate === button;
        candidate.classList.toggle("selected", selected);
        candidate.setAttribute("aria-selected", String(selected));
      });
      updateHistorySortControl();
      resetHistoryScroll();
      renderHistory(state.rows);
    });
  });
  document.querySelectorAll(".legend-filter").forEach((button) => {
    button.addEventListener("click", () => {
      const selectedType = button.dataset.historyType;
      state.historyTypeFilter = state.historyTypeFilter === selectedType ? null : selectedType;
      resetHistoryScroll();
      updateHistoryTypeFilter();
      renderHistory(state.rows);
    });
  });
  $("#result-count").addEventListener("click", async () => {
    hideHistorySortTooltip();
    const isVideos = state.view === "videos";
    const current = isVideos ? state.videoSort : state.channelSort;
    const next = isVideos
      ? current === "time" ? "recent" : "time"
      : current === "time" ? "videos" : "time";
    if (isVideos) state.videoSort = next;
    else state.channelSort = next;
    updateHistorySortControl();
    resetHistoryScroll();
    renderHistory(state.rows);
    if (state.sortPersistence !== "remember") return;
    try {
      await saveSetting(isVideos ? "history-video-sort" : "history-channel-sort", next);
    } catch (error) {
      if (isVideos) state.videoSort = current;
      else state.channelSort = current;
      updateHistorySortControl();
      resetHistoryScroll();
      renderHistory(state.rows);
      showStatus(`Nie udało się zapamiętać sortowania: ${error.message}`, true);
    }
  });
  $("#result-count").addEventListener("pointerenter", scheduleHistorySortTooltip);
  $("#result-count").addEventListener("pointerleave", hideHistorySortTooltip);
  $("#result-count").addEventListener("focus", scheduleHistorySortTooltip);
  $("#result-count").addEventListener("blur", hideHistorySortTooltip);
  $("#search-toggle").addEventListener("click", () => {
    const panel = $("#search-panel");
    panel.hidden = !panel.hidden;
    $("#search-toggle").classList.toggle("selected", !panel.hidden);
    if (!panel.hidden) $("#search").focus();
    else {
      $("#search").value = "";
      renderHistory(state.rows);
    }
  });
  $("#search").addEventListener("input", () => renderHistory(state.rows));
  $("#history-sort-persistence").addEventListener("change", async (event) => {
    const value = event.target.value === "remember" ? "remember" : "default";
    const previous = state.sortPersistence;
    try {
      await saveSetting("history-sort-persistence", value);
      state.sortPersistence = value;
      if (value === "remember") {
        await Promise.all([
          saveSetting("history-video-sort", state.videoSort),
          saveSetting("history-channel-sort", state.channelSort),
        ]);
      } else {
        state.videoSort = "time";
        state.channelSort = "time";
        updateHistorySortControl();
        resetHistoryScroll();
        renderHistory(state.rows);
      }
      showStatus(value === "remember"
        ? "Ostatni sposób sortowania będzie zapamiętany."
        : "Po ponownym otwarciu historia będzie sortowana według czasu oglądania.");
    } catch (error) {
      state.sortPersistence = previous;
      event.target.value = previous;
      showStatus(`Nie udało się zapisać ustawienia sortowania: ${error.message}`, true);
    }
  });
  $("#history-default-type-filter").addEventListener("change", async (event) => {
    const value = event.target.value === "all" ? "all" : "video";
    try {
      await saveSetting("history-default-type-filter", value);
      showStatus(value === "video"
        ? "Po ponownym otwarciu historia będzie domyślnie filtrować filmy."
        : "Po ponownym otwarciu historia domyślnie pokaże wszystkie typy.");
    } catch (error) {
      event.target.value = value === "video" ? "all" : "video";
      showStatus(`Nie udało się zapisać domyślnego filtra historii: ${error.message}`, true);
    }
  });
  $("#settings-open").addEventListener("click", () => $("#settings-dialog").showModal());
  document.querySelectorAll("[data-settings-tab]").forEach((button) => {
    button.addEventListener("click", () => {
      for (const candidate of document.querySelectorAll("[data-settings-tab]")) {
        const selected = candidate === button;
        candidate.classList.toggle("selected", selected);
        candidate.setAttribute("aria-selected", String(selected));
      }
      for (const panel of document.querySelectorAll("[data-settings-panel]")) {
        panel.hidden = panel.dataset.settingsPanel !== button.dataset.settingsTab;
      }
    });
  });
  document.querySelectorAll("[data-style-choice]").forEach((button) => {
    button.addEventListener("click", async () => {
      try {
        await saveSetting("appearance-style", button.dataset.styleChoice);
        await applyAppearance();
      } catch (error) {
        showStatus(`Nie udało się zmienić motywu: ${error.message}`, true);
      }
    });
  });
  document.querySelectorAll("[data-mode-choice]").forEach((button) => {
    button.addEventListener("click", async () => {
      try {
        await saveSetting("appearance-mode", button.dataset.modeChoice);
        await applyAppearance();
      } catch (error) {
        showStatus(`Nie udało się zmienić kolorystyki: ${error.message}`, true);
      }
    });
  });
  for (const [selector, key] of [["#light-start", "appearance-light-start"], ["#light-end", "appearance-light-end"]]) {
    $(selector).addEventListener("change", async (event) => {
      try {
        await saveSetting(key, event.target.value);
        await applyAppearance();
      } catch (error) {
        showStatus(`Nie udało się zapisać harmonogramu: ${error.message}`, true);
      }
    });
  }
  $("#hide-untracked-periods").addEventListener("change", async (event) => {
    try {
      state.hideUntracked = event.target.checked;
      await saveSetting("hide-untracked-periods", state.hideUntracked);
      state.offset = Math.min(state.offset, maximumOffset());
      await render();
    } catch (error) {
      showStatus(`Nie udało się zapisać ustawienia wykresu: ${error.message}`, true);
    }
  });
  $("#compact-all-chart").addEventListener("change", async (event) => {
    const previousValue = state.allChartCompact;
    state.allChartCompact = event.target.checked;
    $("#chart-panel").classList.toggle("compact-all-chart", state.allChartCompact);
    try {
      await saveSetting("compact-all-chart", state.allChartCompact);
      if (state.period === "year") renderAllTimeChart(state.rows);
    } catch (error) {
      state.allChartCompact = previousValue;
      event.target.checked = previousValue;
      $("#chart-panel").classList.toggle("compact-all-chart", previousValue);
      if (state.period === "year") renderAllTimeChart(state.rows);
      showStatus(`Nie udało się zapisać ustawienia wykresu All: ${error.message}`, true);
    }
  });
  $("#show-media-time").addEventListener("change", async (event) => {
    const previousValue = state.showMediaTime;
    state.showMediaTime = event.target.checked;
    try {
      await saveSetting("show-media-time", state.showMediaTime);
      await render();
    } catch (error) {
      state.showMediaTime = previousValue;
      event.target.checked = previousValue;
      void render();
      showStatus(`Nie udało się zapisać ustawienia czasu filmu: ${error.message}`, true);
    }
  });
  document.querySelectorAll(".mono-choice").forEach((button) => {
    button.addEventListener("click", async () => {
      const { settingKey, settingValue } = button.dataset;
      const period = settingKey.startsWith("chart-scale-")
        ? settingKey.slice("chart-scale-".length)
        : "";
      const previousValue = settingKey === "duration-format"
        ? state.durationFormat
        : period
          ? state.chartScales[period].mode
          : "";
      updateSettingChoices(settingKey, settingValue);
      if (settingKey === "duration-format") {
        state.durationFormat = settingValue;
        $("#duration-threshold-setting").hidden = settingValue !== "smart";
        $("#duration-seconds-threshold").disabled = settingValue !== "smart";
      } else if (period) {
        state.chartScales[period].mode = settingValue;
        $(`#chart-scale-hours-${period}`).closest(".scale-hours").hidden = settingValue !== "fixed";
        $(`#chart-scale-fixed-window-${period}`).closest(".fixed-window-setting").hidden = settingValue !== "visible";
      } else {
        return;
      }
      try {
        await saveSetting(settingKey, settingValue);
        if (settingKey === "duration-format") await render();
        else renderChart();
      } catch (error) {
        if (settingKey === "duration-format") {
          state.durationFormat = previousValue;
          $("#duration-threshold-setting").hidden = previousValue !== "smart";
          $("#duration-seconds-threshold").disabled = previousValue !== "smart";
        } else {
          state.chartScales[period].mode = previousValue;
          $(`#chart-scale-hours-${period}`).closest(".scale-hours").hidden = previousValue !== "fixed";
          $(`#chart-scale-fixed-window-${period}`).closest(".fixed-window-setting").hidden = previousValue !== "visible";
        }
        updateSettingChoices(settingKey, previousValue);
        showStatus(`Nie udało się zapisać ustawienia: ${error.message}`, true);
      }
    });
  });
  $("#duration-seconds-threshold").addEventListener("change", async (event) => {
    const threshold = Number(event.target.value);
    if (!Number.isFinite(threshold) || threshold < 0.25 || threshold > 168) {
      event.target.value = state.durationSecondsThreshold;
      showStatus("Próg sekund musi wynosić od 0,25 do 168 godzin.", true);
      return;
    }
    const previousValue = state.durationSecondsThreshold;
    state.durationSecondsThreshold = threshold;
    try {
      await saveSetting("duration-seconds-threshold", threshold);
      await render();
    } catch (error) {
      state.durationSecondsThreshold = previousValue;
      event.target.value = previousValue;
      showStatus(`Nie udało się zapisać progu sekund: ${error.message}`, true);
    }
  });
  $("#weekday-label-style").addEventListener("change", async (event) => {
    try {
      state.weekdayLabelStyle = event.target.value;
      await saveSetting("weekday-label-style", state.weekdayLabelStyle);
      renderChart();
    } catch (error) {
      showStatus(`Nie udało się zapisać formatu dni: ${error.message}`, true);
    }
  });
  for (const period of ["day", "week", "month"]) {
    $(`#chart-scale-fixed-window-${period}`).addEventListener("change", async (event) => {
      const previous = state.chartFixedWindow[period];
      const value = event.target.checked;
      state.chartFixedWindow[period] = value;
      try {
        await saveSetting(`chart-scale-fixed-window-${period}`, value);
        renderChart();
      } catch (error) {
        state.chartFixedWindow[period] = previous;
        event.target.checked = previous;
        renderChart();
        showStatus(`Nie udało się zapisać stałej bazy skali: ${error.message}`, true);
      }
    });
    $(`#chart-scale-hours-${period}`).addEventListener("change", async (event) => {
      const hours = Number(event.target.value);
      if (!Number.isFinite(hours) || hours <= 0) {
        event.target.value = state.chartScales[period].hours;
        showStatus("Czas skali musi być większy od zera.", true);
        return;
      }
      state.chartScales[period].hours = hours;
      try {
        await saveSetting(`chart-scale-hours-${period}`, hours);
        renderChart();
      } catch (error) {
        showStatus(`Nie udało się zapisać czasu skali: ${error.message}`, true);
      }
    });
  }
  $("#button-icon-file").addEventListener("change", async (event) => {
    const [file] = event.target.files;
    if (!file) return;
    try {
      showStatus("Zapisywanie ikonki…");
      await storeButtonImage(file);
    } catch (error) {
      console.error("[VTM Local] Nie udało się zapisać ikonki YouTube:", error);
      showStatus(`Nie udało się zapisać ikonki: ${error.message}`, true);
    } finally {
      event.target.value = "";
    }
  });
  $("#remove-button-icon").addEventListener("click", async () => {
    try {
      await VtmStorage.removeSettings(["youtube-button-image-original", "youtube-button-image"]);
      await removePersistentButtonImage();
      await notifyButtonSettingsChanged();
      await applyButtonSettings();
      showStatus("Własna ikonka została usunięta.");
    } catch (error) {
      console.error("[VTM Local] Nie udało się usunąć ikonki YouTube:", error);
      showStatus(`Nie udało się usunąć ikonki: ${error.message}`, true);
    }
  });
  $("#button-icon-unlimited").addEventListener("change", async (event) => {
    const enabled = event.target.checked;
    let saved = false;
    try {
      const scale = Number(await VtmStorage.getSetting("youtube-button-scale", 24));
      await saveButtonImageSettings(scale, { "youtube-button-unlimited": enabled });
      saved = true;
      state.buttonIconUnlimited = enabled;
      await applyButtonSettings();
      await notifyButtonSettingsChanged();
      showStatus(enabled
        ? "Włączono własne, całkowite wartości ikonki."
        : "Przywrócono zakresy suwaków ikonki.");
    } catch (error) {
      if (saved) {
        await applyButtonSettings();
        showStatus(`Zapisano tryb ikonki, ale nie udało się odświeżyć otwartych kart: ${error.message}`, true);
      } else {
        event.target.checked = !enabled;
        showStatus(`Nie udało się zmienić trybu ikonki: ${error.message}`, true);
      }
    }
  });
  for (const [id, key, minimum] of [
    ["button-icon-delay-custom", "youtube-button-delay", 0],
    ["button-icon-scale-custom", "youtube-button-scale", 1],
    ["button-icon-offset-custom", "youtube-button-offset", -Number.MAX_SAFE_INTEGER],
    ["button-icon-offset-x-custom", "youtube-button-offset-x", -Number.MAX_SAFE_INTEGER],
  ]) {
    $(`#${id}`).addEventListener("change", async (event) => {
      const value = Number(event.target.value);
      let previous;
      let saved = false;
      try {
        previous = Number(await VtmStorage.getSetting(key, 0));
        if (!Number.isSafeInteger(value) || value < minimum) {
          event.target.value = String(previous);
          showStatus("Wartość musi być całkowitą liczbą bezpieczną dla przeglądarki.", true);
          return;
        }
        if (key === "youtube-button-scale") {
          await saveButtonImageSettings(value, { "youtube-button-unlimited": true });
        } else {
          await saveSetting(key, value);
        }
        saved = true;
        await applyButtonSettings();
        await notifyButtonSettingsChanged();
        showStatus("Własna wartość ikonki została zapisana.");
      } catch (error) {
        if (saved) {
          await applyButtonSettings();
          showStatus(`Zapisano wartość, ale nie udało się odświeżyć otwartych kart: ${error.message}`, true);
        } else {
          if (previous !== undefined) event.target.value = String(previous);
          showStatus(`Nie udało się zapisać wartości ikonki: ${error.message}`, true);
        }
      }
    });
  }
  $("#button-icon-scale").addEventListener("input", (event) => {
    $("#button-icon-scale-value").value = `${event.target.value} px`;
  });
  $("#button-icon-scale").addEventListener("change", async (event) => {
    const size = Math.max(8, Math.min(60, Number(event.target.value) || 24));
    let saved = false;
    try {
      event.target.value = size;
      $("#button-icon-scale-value").value = `${size} px`;
      await saveButtonImageSettings(size, { "youtube-button-unlimited": false });
      saved = true;
      await notifyButtonSettingsChanged();
    } catch (error) {
      if (saved) {
        await applyButtonSettings();
        showStatus(`Zapisano rozmiar, ale nie udało się odświeżyć otwartych kart: ${error.message}`, true);
      } else {
        await applyButtonSettings();
        showStatus(`Nie udało się zmienić rozmiaru ikonki: ${error.message}`, true);
      }
    }
  });
  $("#button-icon-offset").addEventListener("input", (event) => {
    const value = Number(event.target.value);
    $("#button-icon-offset-value").value = `${value > 0 ? "+" : ""}${value} px`;
  });
  $("#button-icon-offset").addEventListener("change", async (event) => {
    try {
      await saveSetting("youtube-button-offset", Number(event.target.value));
      await notifyButtonSettingsChanged();
      showStatus("Położenie ikonki zostało zapisane.");
    } catch (error) {
      showStatus(`Nie udało się zmienić położenia ikonki: ${error.message}`, true);
    }
  });
  $("#button-icon-offset-x").addEventListener("input", (event) => {
    const value = Number(event.target.value);
    $("#button-icon-offset-x-value").value = `${value > 0 ? "+" : ""}${value} px`;
  });
  $("#button-icon-offset-x").addEventListener("change", async (event) => {
    try {
      await saveSetting("youtube-button-offset-x", Number(event.target.value));
      await notifyButtonSettingsChanged();
      showStatus("Położenie poziome ikonki zostało zapisane.");
    } catch (error) {
      showStatus(`Nie udało się zmienić położenia ikonki: ${error.message}`, true);
    }
  });
  $("#button-icon-delay").addEventListener("change", async (event) => {
    const delay = Number(event.target.value);
    if (!Number.isInteger(delay) || delay < 0 || delay > 2000 || delay % 100 !== 0) {
      event.target.value = state.buttonIconDelay;
      showStatus("Opóźnienie musi wynosić od 0 do 2000 ms, z krokiem 100 ms.", true);
      return;
    }
    const previousValue = state.buttonIconDelay;
    try {
      await saveSetting("youtube-button-delay", delay);
    } catch (error) {
      event.target.value = previousValue;
      showStatus(`Nie udało się zapisać opóźnienia ikonki: ${error.message}`, true);
      return;
    }
    state.buttonIconDelay = delay;
    try {
      await notifyButtonSettingsChanged();
      showStatus(`Opóźnienie ikonki ustawiono na ${delay} ms.`);
    } catch (error) {
      showStatus(`Zapisano opóźnienie, ale nie udało się odświeżyć ikonki na otwartych kartach: ${error.message}`, true);
    }
  });
  $("#button-icon-delay").addEventListener("input", (event) => {
    $("#button-icon-delay-value").value = `${event.target.value} ms`;
  });
  for (const [id, key, minimum, maximum] of [
    ["history-wheel-rows", "history-wheel-rows", 1, 5],
    ["history-visible-rows", "history-visible-rows", 3, 7],
  ]) {
    $(`#${id}`).addEventListener("change", async (event) => {
      const value = Number(event.target.value);
      if (!Number.isInteger(value) || value < minimum || value > maximum) return;
      const previous = id === "history-wheel-rows" ? state.historyWheelRows : state.historyVisibleRows;
      try {
        await saveSetting(key, value);
        await applyHistoryLayout();
      } catch (error) {
        event.target.value = String(previous);
        showStatus(`Nie udało się zapisać ustawienia historii: ${error.message}`, true);
      }
    });
  }
  $("#export-button").addEventListener("click", async () => {
    try {
      await exportHistory();
    } catch (error) {
      console.error("[VTM Local] Eksport historii nie powiódł się:", error);
      showStatus(`Eksport nie powiódł się: ${error.message}`, true);
    }
  });
  $("#import-file").addEventListener("change", async (event) => {
    const [file] = event.target.files;
    if (!file) return;
    try {
      showStatus("Importowanie historii…");
      await importHistoryFile(file);
    } catch (error) {
      console.error("[VTM Local] Import historii nie powiódł się:", error);
      showStatus(`Import nie powiódł się: ${error.message}`, true);
    } finally {
      event.target.value = "";
    }
  });
  globalThis.chrome?.runtime?.onMessage?.addListener((message) => {
    if (message?.type === "vtm:history-changed") {
      mergeHistoryEvent(message.event);
      void render();
    }
  });

  void (async () => {
    try {
      if (navigator.storage?.persist) {
        try {
          const persisted = await navigator.storage.persist();
          if (!persisted) {
            console.warn("[VTM Local] Przeglądarka nie zagwarantowała ochrony IndexedDB przed automatycznym czyszczeniem.");
          }
        } catch (error) {
          console.warn("[VTM Local] Nie udało się zażądać ochrony IndexedDB:", error);
        }
      }
      await applyAppearance();
      await applyButtonSettings();
      await applyChartSettings();
      setInterval(() => {
        VtmStorage.getSetting("appearance-mode", "dark")
          .then((mode) => mode === "auto" ? applyAppearance() : undefined)
          .catch((error) => console.error("[VTM Local] Nie udało się sprawdzić motywu automatycznego:", error));
      }, 60_000);
      await render();
    } catch (error) {
      console.error("[VTM Local] Inicjalizacja pulpitu nie powiodła się:", error);
      $("#history-list").textContent = `Nie można otworzyć lokalnego magazynu: ${error.message}`;
    }
  })();
})();
