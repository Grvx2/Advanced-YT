"use strict";

(() => {
  if (globalThis.AutoHDBrowser) return;
  globalThis.AutoHDBrowser = globalThis.createNamespacedExtensionApi({
    name: "Auto HD",
    prefix: "autohd:",
    moduleEnabledKey: "autoHdModuleEnabled",
    visibleSettingKey: "isExtensionEnabled",
    resourceRoot: "modules/autohd",
  });
})();
